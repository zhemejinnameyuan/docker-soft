<template>
    <div class="app-container player-list">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" style="width: 280px" @change="toQuery" />
                <el-select v-model="query.subType" placeholder="黑名单类型" size="medium" class="filter-item" style="width: 180px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in BLACKLIST_SUB_TYPE_CONF" v-if="showSubTypeList.indexOf(index) !== -1" :key="index" :value="index" :label="item" />
                </el-select>
                <el-input v-model="query.value" size="medium" clearable placeholder="黑名单信息" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>
            <el-button v-permission="[permission.appBlacklistBatchAdd]" class="filter-item" size="small" type="primary" @click="showAdd">添加退款黑名单</el-button>
            <el-button v-permission="[permission.appBlacklistBatchDel]" class="filter-item" size="small" type="danger" :disabled="batchRemoveBtn" @click="toBatchRemove('batch')">移除</el-button>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list" @selection-change="changeSelect">
            <el-table-column type="selection" width="50" />
            <el-table-column width="170" prop="createTime" align="center" label="添加时间" />
            <el-table-column width="200" prop="subType" align="center" label="退款黑名单类型">
                <template slot-scope="scope">
                    {{ getArrayValue(BLACKLIST_SUB_TYPE_CONF, scope.row.subType) }}
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="300" align="center" prop="value" label="黑名单信息">
                <template slot-scope="scope">
                    <div v-if="scope.row.subType !== BLACKLIST_SUB_TYPE.PLAYER_ID">{{ scope.row.value }}</div>
                    <UserIdJump v-if="scope.row.subType === BLACKLIST_SUB_TYPE.PLAYER_ID" :id="scope.row.value" />
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="reason" label="加入原因">
                <template slot-scope="scope">
                    {{ scope.row.reason | filterEmpty }}
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" prop="operator" label="操作人" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="operator" align="center" label="操作来源">
                <template slot-scope="scope">
                    <span>
                        {{ scope.row.channelId ? `渠道(${scope.row.channelId})` : '平台' }}
                    </span>
                </template>
            </el-table-column>
            <el-table-column label="操作" width="200" align="center">
                <template slot-scope="scope">
                    <el-button class="filter-item" size="mini" type="text" @click="toDetail(scope.row)">详情</el-button>
                    <el-button v-permission="[permission.appBlacklistBatchDel]" class="filter-item" size="mini" type="text" @click="toRemove(scope.row)">移除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[50, 100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />

        <!--添加-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="addDialogVisible" title="添加黑名单" width="780px">
            <el-form ref="form" :inline="true" :model="dialogObj" :rules="rules" size="small" label-width="150px" label-position="left">
                <el-form-item label="黑名单类型:" prop="subType">
                    <el-select
                        v-model="dialogObj.subType"
                        placeholder="黑名单类型"
                        size="medium"
                        class="filter-item"
                        style="width: 180px"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    >
                        <el-option v-for="(item, index) in BLACKLIST_SUB_TYPE_CONF" v-if="showSubTypeList.indexOf(index) !== -1" :key="index" :value="index" :label="item" />
                    </el-select>
                </el-form-item>

                <el-form-item label="信息:" prop="value">
                    <el-input
                        v-model="dialogObj.value"
                        rows="10"
                        type="textarea"
                        placeholder="请输入信息"
                        show-word-limit
                        style="width: 420px"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                    <div>
                        <span class="text_blue fs-12 mt-5">一行一条信息，手机号要加国码，如+919232323234</span>
                    </div>
                </el-form-item>
                <el-form-item label="原因:" prop="reason">
                    <el-input
                        v-model="dialogObj.reason"
                        maxlength="50"
                        minlength="2"
                        rows="7"
                        type="textarea"
                        placeholder="请输入原因"
                        show-word-limit
                        style="width: 420px"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="toAddSubmit" :loading="submitLoading">确认</el-button>
            </div>
        </el-dialog>

        <!--移除-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="removeDialogVisible" title="移除黑名单" width="500px">
            <el-form ref="form" :inline="true" size="small" label-width="150px" label-position="left">
                <div class="text_red">移除后，玩家退款将不再依据该信息而列入异常订单，确定移除？</div>
                <div class="mt-10">{{ detailDialogInfo.createTime }}-{{ detailDialogInfo.operator }} 加入退款黑名单</div>
                <div class="mt-10">原因:{{ detailDialogInfo.reason | filterEmpty }}</div>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="toBatchRemove('single', detailDialogInfo.id)">确定移除</el-button>
            </div>
        </el-dialog>

        <!--详情-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="detailDialogVisible" title="黑名单信息" width="500px">
            <el-form ref="form" :inline="true" size="small" label-width="150px" label-position="left">
                <div class="mt-10">{{ detailDialogInfo.createTime }}-{{ detailDialogInfo.operator }} 加入退款黑名单</div>
                <div class="mt-10">原因:{{ detailDialogInfo.reason | filterEmpty }}</div>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/player'
import { BLACKLIST_SUB_TYPE_CONF, BLACKLIST_TYPE, BLACKLIST_SUB_TYPE } from '@/constant/common'
import { confirmRequest } from '@/utils'
export default {
    name: 'Refund',
    components: {
        pagination,
        UserIdJump,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            BLACKLIST_SUB_TYPE,
            BLACKLIST_SUB_TYPE_CONF,
            BLACKLIST_TYPE,
            loading: false,
            batchRemoveBtn: true,
            list: [],
            ids: [],
            addDialogVisible: false,
            removeDialogVisible: false,
            detailDialogVisible: false,
            detailDialogInfo: {},
            submitLoading: false,
            dialogObj: {
                subType: '',
                value: '',
                reason: ''
            },
            showSubTypeList: ['1', '2', '3', '4', '9'],
            query: {
                size: 50,
                page: 1,
                sort: 'createTime;desc',
                type: BLACKLIST_TYPE.REFUND,
                subType: null
            },
            rules: {
                subType: [{ required: true, message: '请选择黑名单类型', trigger: 'blur' }],
                value: [{ required: true, message: '请输入信息', trigger: 'blur' }]
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 330
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appBlacklistQueryList])) {
                this.loading = true
                api.blackQueryList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        showAdd() {
            this.dialogObj = {}
            this.addDialogVisible = true
        },
        toAddSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    let params = []
                    let splitValue = this.dialogObj.value.split('\n')
                    splitValue.forEach((item) => {
                        if (item) {
                            params.push({
                                type: this.query.type,
                                subType: this.dialogObj.subType,
                                value: item.trim(),
                                reason: this.dialogObj.reason
                            })
                        }
                    })
                    api.blackBatchAdd(params)
                        .then((rep) => {
                            this.$message.success('操作成功')
                            this.dialogCancel()
                            this.toQuery(true)
                        })
                        .catch(() => {
                            this.dialogCancel()
                        })
                }
            })
        },
        toRemove(info) {
            this.removeDialogVisible = true
            this.detailDialogInfo = info
        },
        toDetail(info) {
            this.detailDialogVisible = true
            this.detailDialogInfo = info
        },
        toBatchRemove(type, id = '') {
            if (type === 'single') {
                let params = { idList: [id], reason: '' }
                api.blackBatchDel(params).then((rep) => {
                    this.$message.success('操作成功')
                    this.dialogCancel()
                    this.toQuery()
                })
            } else {
                let params = { idList: this.ids, reason: '' }
                confirmRequest('移除后，玩家退款将不再依据该信息而列入异常订单，确定移除？', () => {
                    api.blackBatchDel(params).then((rep) => {
                        this.$message.success('操作成功')
                        this.dialogCancel()
                        this.toQuery()
                    })
                })
            }
        },
        dialogCancel() {
            this.addDialogVisible = false
            this.removeDialogVisible = false
            this.detailDialogVisible = false
        },
        changeSelect(val) {
            this.ids = []
            val.forEach((e) => {
                this.ids.push(e.id)
            })
            if (this.ids.length > 0) {
                this.batchRemoveBtn = false
            } else {
                this.batchRemoveBtn = true
            }
        }
    }
}
</script>
