<template>
    <div class="">
        <el-form ref="form" size="small" label-width="100px" label-position="left">
            <el-form-item label="处罚类型:" prop="type">
                <el-checkbox-group v-model="bannedType">
                    <el-checkbox v-for="(item, index) in typeConf" :key="index" :label="index">{{ item }}</el-checkbox>
                </el-checkbox-group>
            </el-form-item>

            <el-form-item label="原因:" prop="value">
                <el-input
                    v-model="reason"
                    rows="5"
                    type="textarea"
                    placeholder="请输入封禁原因"
                    maxlength="50"
                    show-word-limit
                    style="width: 520px"
                    @change="
                        () => {
                            $forceUpdate()
                        }
                    "
                />
                <div class="text_red fs-12 mt-5">
                    <span>刷子：玩家游戏会按概率触发机器人作弊；</span>
                    <br />
                    <span>账号封禁：玩家账号无法登录；</span>
                    <br />
                    <span>退款黑名单：玩家退款会被加入异常订单</span>
                </div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer" style="margin-left: 500px">
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
            <el-button type="primary" @click="toSubmit()">确认</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/player'
import Base from '@/views/base'
import { BLACKLIST_SUB_TYPE } from '@/constant/common'
export default {
    components: {},
    props: {
        ids: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            BLACKLIST_SUB_TYPE,
            bannedType: [],
            reason: '',
            typeConf: {
                1: '刷子',
                2: '账号封禁',
                3: '退款黑名单'
            }
        }
    },
    mixins: [Base],
    mounted() {},
    methods: {
        toSubmit() {
            let params = []
            if (this.bannedType.length === 0) {
                return this.$message.error('请选择处罚类型')
            }
            this.ids.forEach((id) => {
                this.bannedType.forEach((type) => {
                    params.push({
                        type: type,
                        subType: BLACKLIST_SUB_TYPE.PLAYER_ID,
                        value: id,
                        reason: this.reason
                    })
                })
            })

            api.blackBatchAdd(params)
                .then((rep) => {
                    this.$message.success('操作成功')
                    this.dialogCancel()
                    this.toQuery(true)
                })
                .catch(() => {
                    this.dialogCancel()
                })
        },

        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
