<template>
    <div class="ml-40">
        <el-form ref="form" size="small" label-width="100px" label-position="top">
            <div class="title_info">禁止账户登录</div>
            <el-form-item label="" prop="value">
                <div class="dp-f ml-20">
                    <div>
                        <span v-show="existType.indexOf('2_1') !== -1">✔</span>
                        账号封禁
                    </div>
                    <div class="ml-40">
                        <span class="text_gray mr-20" style="font-weight: bold">触发禁用设备</span>
                        <span v-show="existType.indexOf('2_2') !== -1">✔</span>
                        <span class="mr-10">手机号</span>
                        <span v-show="existType.indexOf('2_7') !== -1">✔</span>
                        <span class="mr-10">UUID</span>
                        <span v-show="existType.indexOf('2_8') !== -1">✔</span>
                        <span class="mr-10">IP</span>
                    </div>
                </div>
            </el-form-item>

            <div class="title_info">加入退款异常订单</div>
            <el-form-item label="" prop="value">
                <div class="dp-f ml-20">
                    <div>
                        <span v-show="existType.indexOf('3_1') !== -1">✔</span>
                        退款黑名单
                    </div>
                    <div class="ml-40">
                        <span class="text_gray mr-20" style="font-weight: bold">触发退款黑名单库</span>
                        <span v-show="existType.indexOf('3_2') !== -1">✔</span>
                        <span class="mr-10">手机号</span>
                        <span v-show="existType.indexOf('3_3') !== -1">✔</span>
                        <span class="mr-10">银行卡号</span>
                        <span v-show="existType.indexOf('3_4') !== -1">✔</span>
                        <span class="mr-10">IFSC</span>
                        <span v-show="existType.indexOf('3_9') !== -1">✔</span>
                        <span class="mr-10">Email</span>
                    </div>
                </div>
            </el-form-item>

            <div class="title_info">推广处罚</div>
            <el-form-item label="" prop="value">
                <div class="dp-f ml-20">
                    <div>
                        <span v-show="existType.indexOf('4_1') !== -1">✔</span>
                        推广封禁
                    </div>
                </div>
            </el-form-item>

            <div class="title_info">标记为刷子</div>
            <el-form-item label="" prop="value">
                <div class="dp-f ml-20">
                    <div>
                        <span v-show="existType.indexOf('1_1') !== -1">✔</span>
                        刷子
                    </div>
                </div>
            </el-form-item>

            <div>
                <span class="text_red">注</span>
                ：✔代表该账号当前对应处罚
                <UserIdJump v-if="source === 'list'" :id="dataInfo.id" :onlyNickname="true" :nickname="'点击进入玩家详情查看详细处罚记录'" />
            </div>
        </el-form>
        <div slot="footer" class="dialog-footer mt-40" style="margin-left: 500px">
            <el-button type="primary" @click="dialogCancel">关闭</el-button>
        </div>
    </div>
</template>
<script>
import UserIdJump from '@/components/UserIdJump'
import * as api from '@/api/player'
import Base from '@/views/base'
import { BLACKLIST_SUB_TYPE } from '@/constant/common'
export default {
    components: {
        UserIdJump
    },
    props: {
        dataInfo: {
            type: Object,
            default: ''
        },
        source: {
            type: String,
            default: 'list'
        }
    },
    data() {
        return {
            BLACKLIST_SUB_TYPE,
            existType: []
        }
    },
    mixins: [Base],
    mounted() {
        this.initData()
    },
    methods: {
        initData() {
            api.blackQueryOne({ playerId: this.dataInfo.id }).then((rep) => {
                if (rep.data.length > 0) {
                    for (let i = 0; i < rep.data.length; i++) {
                        this.existType.push(rep.data[i].type.toString() + '_' + rep.data[i].subType.toString())
                    }
                }
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>

<style scoped lang="scss">
.title_info {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 10px;
}
</style>
