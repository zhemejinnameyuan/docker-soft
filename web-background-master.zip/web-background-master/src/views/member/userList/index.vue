<template>
    <div class="app-container player-list">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="创建开始日期" end-placeholder="创建结束日期" style="width: 280px" />
                <DateRangePicker v-model="query.registerTime" class="filter-item" start-placeholder="注册开始日期" end-placeholder="注册结束日期" style="width: 280px" />
                <span class="label_title">账号类型</span>
                <el-select v-model="query.type" placeholder="玩家类型" size="medium" class="filter-item" style="width: 120px" clearable @change="toQuery">
                    <el-option v-for="item in userTypes" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.blockFlag" placeholder="是否封禁" size="medium" class="filter-item" style="width: 120px" clearable @change="toQuery">
                    <el-option label="已封禁" :value="true" />
                    <el-option label="未封禁" :value="false" />
                </el-select>
                <el-select v-model="query.bindState" placeholder="绑定状态" size="medium" class="filter-item" style="width: 120px" clearable @change="toQuery">
                    <el-option label="未绑定" :value="1" />
                    <el-option label="绑定手机号" :value="2" />
                    <el-option label="绑定Facebook账号" :value="3" />
                </el-select>
                <label class="label_title">渠道信息</label>
                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.playerChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 140px"
                    clearable
                    filterable
                    @change="toQuery"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-input v-model="query.channelPackageId" size="medium" clearable placeholder="渠道包ID" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <div>
                    <label class="label_title">账号信息</label>
                    <el-input v-model="query.nickname" size="medium" clearable placeholder="玩家昵称" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                    <el-input v-model="query.id" size="medium" clearable placeholder="玩家ID" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                    <el-input v-model="query.uuid" size="medium" clearable placeholder="UUID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                    <el-input v-model="query.phone" size="smamediumll" clearable placeholder="手机号" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                    <IconButton v-permission="[permission.playerList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                </div>
            </el-row>
            <el-button v-permission="[permission.appBlacklistBatchAdd]" class="filter-item" size="small" type="primary" :disabled="batchBlackBtn" @click="toBatchAddBlack">批量封禁</el-button>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list" @selection-change="changeSelect">
            <el-table-column type="selection" width="50" />
            <el-table-column :show-overflow-tooltip="true" width="110" align="center" label="玩家ID">
                <template slot-scope="scope">
                    <UserIdJump :id="scope.row.id" />
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140" prop="nickname" align="center" label="玩家昵称" />
            <el-table-column :show-overflow-tooltip="true" width="80" align="center" label="玩家类型">
                <template slot-scope="scope">
                    <span>{{ getUserType(scope.row.type) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="80" align="center" label="是否封禁">
                <template slot-scope="scope">
                    <span :class="scope.row.blockFlag ? 'text_red' : 'text_green'">{{ scope.row.blockFlag ? '已封禁' : '未封禁' }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140" align="center" prop="code" label="邀请码" />
			<el-table-column width="180" align="center" label="UUID">
				<template slot-scope="scope">
					<span v-clipboard:copy="scope.row.uuid" v-clipboard:success="copySuccess" v-clipboard:error="copyError">{{ scope.row.uuid }}</span>
				</template>
			</el-table-column>
			
            <el-table-column :show-overflow-tooltip="true" width="200" align="left" label="绑定信息">
                <template slot-scope="scope">
                    <span>手机号：{{ scope.row.phone ? scope.row.phone : '未绑定' }}</span>
                    <br />
                    <span>Facebook：{{ scope.row.fbName ? scope.row.fbName : '未绑定' }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="100" align="center" prop="terminal" label="所属终端" />
            <el-table-column :show-overflow-tooltip="true" width="155" align="center" label="渠道（ID）">
                <template slot-scope="scope">
                    <span>{{ scope.row.channelName }}({{ scope.row.channelId }})</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="155" align="center" label="渠道包(ID)">
                <template slot-scope="scope">
                    <span>{{ scope.row.channelPackageName }}({{ scope.row.channelPackageId }})</span>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" width="155" align="center" prop="createTime" label="创建时间" />
            <el-table-column :show-overflow-tooltip="true" width="155" align="center" prop="registerTime" label="注册时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.registerTime ? scope.row.registerTime : '未注册' }}</span>
                </template>
            </el-table-column>
            <el-table-column label="操作" width="200" align="center" fixed="right">
                <template slot-scope="scope">
                    <el-button class="filter-item ml-5" size="small" type="text">
                        <a :href="'/player?id=' + scope.row.id" target="_blank" :title="scope.row.id">详情</a>
                    </el-button>
                    <el-button
                        v-permission="[permission.appBlacklistBatchAdd, permission.appBlacklistBatchDelByPlayerIds, permission.appBlacklistQueryPlayerBlackState]"
                        class="filter-item ml-5"
                        size="small"
                        type="text"
                        @click="toAddBlack(scope.row)"
                    >
                        处罚
                    </el-button>
                    <el-button v-permission="[permission.appBlacklistQueryPlayerBlackState]" class="filter-item" size="small" type="text" @click="viewBlackInfo(scope.row)">异常信息</el-button>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[50, 100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />

        <!--添加-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" title="处罚" width="680px">
            <AddBlack v-if="dialogVisible" @onclose="dialogCancel" @queryData="toQuery" :dataInfo="dialogObj" />
        </el-dialog>

        <!--批量添加-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="batchDialogVisible" title="批量处罚" width="680px">
            <BatchAddBlack v-if="batchDialogVisible" @onclose="dialogCancel" :ids="ids" />
        </el-dialog>

        <!--异常信息-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="exceptionDialogVisible" title="异常信息" width="680px">
            <BlackInfo v-if="exceptionDialogVisible" @onclose="dialogCancel" :dataInfo="dialogObj" />
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import { userTypeConfig } from '@/constant/game'
import Base from '@/views/base'
import * as api from '@/api/player'
import UserIdJump from '@/components/UserIdJump'
import { getChannelList } from '@/utils'
import AddBlack from './addBlack'
import BatchAddBlack from './batchAddBlack'
import BlackInfo from './blackInfo'
export default {
    name: 'UserList',
    components: {
        UserIdJump,
        pagination,
        DateRangePicker,
        AddBlack,
        BatchAddBlack,
        BlackInfo
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            batchBlackBtn: true,
            dialogVisible: false,
            batchDialogVisible: false,
            exceptionDialogVisible: false,
            dialogObj: {},
            detailDialogInfo: {},
            channels: [],
            userTypes: Object.values(userTypeConfig),
            list: [],
            ids: [],
            query: {
                size: 50,
                page: 1,
                sort: 'createTime;desc',
                channelId: null,
                type: null,
                channelPackageId: null,
                nickname: null,
                id: null,
                uuid: null,
                blockFlag: null,
                phone: null,
                createTime: [],
                registerTime: []
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 330

        this.getChannel()
        this.toQuery()
    },
    methods: {
        async getChannel() {
            if (this.checkPermission([this.permission.playerChannelList])) {
                this.channels = await getChannelList()
            }
        },
        toQuery(page) {
            this.dialogCancel()
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.playerList])) {
                this.loading = true
                api.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        getUserType(type) {
            return userTypeConfig[type] ? userTypeConfig[type].name : ''
        },
        //查看异常信息
        viewBlackInfo(row) {
            this.ids = [row.id]
            this.dialogObj = row
            this.exceptionDialogVisible = true
        },
        //处罚
        toAddBlack(row) {
            this.ids = [row.id]
            this.dialogObj = row
            this.dialogVisible = true
        },
        //批量操作
        toBatchAddBlack() {
            this.batchDialogVisible = true
        },
        changeSelect(val) {
            this.ids = []
            val.forEach((e) => {
                if (!e.blockFlag) {
                    this.ids.push(e.id)
                }
            })
            if (this.ids.length > 0) {
                this.batchBlackBtn = false
            } else {
                this.batchBlackBtn = true
            }
        },
        dialogCancel() {
            this.dialogVisible = false
            this.batchDialogVisible = false
            this.exceptionDialogVisible = false
        }
    }
}
</script>
