<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-input v-model="query.uuid" size="medium" clearable placeholder="UUID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
            <el-input v-model="query.phone" size="medium" clearable placeholder="输入手机号" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
            <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="发送开始日期" end-placeholder="发送结束日期" @change="toQuery" />

            <IconButton v-permission="[permission.playerCaptchaList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column :show-overflow-tooltip="true" width="120" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump v-if="scope.row.playerId" :id="scope.row.playerId" />
                        </template>
                    </el-table-column>

                    <el-table-column :show-overflow-tooltip="true" prop="uuid" align="center" label="UUID" />
                    <el-table-column :show-overflow-tooltip="true" width="200" prop="phone" align="center" label="手机号" />
                    <el-table-column :show-overflow-tooltip="true" width="160" prop="captcha" align="center" label="验证码" />
                    <el-table-column :show-overflow-tooltip="true" width="140" prop="service" align="center" label="服务商" />
                    <el-table-column :show-overflow-tooltip="true" width="220" prop="result" align="center" label="返回结果" />
                    <el-table-column :show-overflow-tooltip="true" width="220" prop="createTime" align="center" label="发送时间" />
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/player'
export default {
    name: 'Sms',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: {
                size: 100,
                page: 1,
                phone: '',
                sort: 'id;desc',
                uuid: '',
                createTime: []
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 300
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.playerCaptchaList])) {
                api.captcha(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                    })
                    .catch(() => {})
            }
        }
    }
}
</script>
