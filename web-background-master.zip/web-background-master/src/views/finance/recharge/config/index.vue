<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-form ref="form" :model="dataObj" size="medium" label-width="150px" label-position="top">
                <el-form-item label="充值状态:" prop="switch" class="big-label">
                    <div class="inline-item table_state_switch">
                        <span class="small-label">开关:</span>
                        <el-switch v-model="dataObj.open" />
                    </div>
                </el-form-item>

                <el-form-item label="平台充值金额配置(可配金额为当前开启通道支持金额并集):">
                    <el-table :data="dataObj.goodsList" class="common_form_table" style="width: 1100px" :row-style="{ height: '50px', background: '#F7F7F7' }" :span-method="objectSpanMethod">
                        <el-table-column label="ID" width="100" align="center">
                            <template slot-scope="scope">
                                {{ scope.row.id }}
                            </template>
                        </el-table-column>
                        <el-table-column label="手续费(%)" width="150" align="center">
                            <template slot-scope="scope">
                                <InputNumber disabled v-model="dataObj.serviceFeeRate" range-width="130px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                            </template>
                        </el-table-column>
                        <el-table-column label="开关" width="125" align="center">
                            <template slot-scope="scope">
                                <div class="table_state_switch">
                                    <el-switch v-model="dataObj.goodsList[scope.$index].open" @change="changeSwitch(scope.row.id)" />
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="可选金额" width="220" align="center">
                            <template slot-scope="scope">
                                <div class="dp-c">
                                    <div class="dp-f" style="height: 10px">
                                        <div class="default-tag" v-show="dataObj.selected == scope.row.id">默认</div>
                                    </div>
                                    <div class="mt-5" v-if="scope.row.amount > 0">{{ fenToYuan(scope.row.amount) }}</div>
                                    <div class="mt-5" v-if="scope.row.amount == 0">未配置</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="D账户赠送" width="150" align="center">
                            <template slot-scope="scope">
                                <InputNumber
                                    v-model="dataObj.goodsList[scope.$index].giveAmount_D"
                                    range-width="120px"
                                    :precision="2"
                                    :min-number="0"
                                    :max-number="99999"
                                    placeholder="0-99999"
                                    clearable
                                />
                            </template>
                        </el-table-column>
                        <el-table-column label="B账户赠送" width="150" align="center">
                            <template slot-scope="scope">
                                <InputNumber
                                    v-model="dataObj.goodsList[scope.$index].giveAmount_B"
                                    range-width="120px"
                                    :precision="2"
                                    :min-number="0"
                                    :max-number="99999"
                                    placeholder="0-99999"
                                    clearable
                                />
                                <InputNumber
                                    hidden
                                    v-model="dataObj.goodsList[scope.$index].giveAmount_W"
                                    range-width="120px"
                                    :precision="2"
                                    :min-number="0"
                                    :max-number="99999"
                                    placeholder="0-99999"
                                    clearable
                                />
                            </template>
                        </el-table-column>
                        <el-table-column label="操作" width="200" align="left">
                            <template slot-scope="scope">
                                <div class="dp-f">
                                    <div class="ml-10">
                                        <el-button type="primary" size="small" @click="amountConfig(scope.$index)">配置金额</el-button>
                                    </div>
                                    <div class="ml-10">
                                        <el-button
                                            type="primary"
                                            size="small"
                                            plain
                                            :disabled="dataObj.selected == scope.row.id || scope.row.amount == 0 || scope.row.open == false"
                                            @click="setDefault(scope.row.id)"
                                        >
                                            默认选中
                                        </el-button>
                                    </div>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-form-item>
            </el-form>

            <el-dialog append-to-body :close-on-click-modal="false" :visible.sync="configAmountDialog" title="请配置金额" width="600px">
                <ConfigAmount
                    v-if="configAmountDialog"
                    @onclose="dialogCancel"
                    @toChannel="toChannel"
                    @setConfig="setConfig"
                    :channelAmountConf="channelAmountConf"
                    :dataObj="dataObj"
                    :defaultAmount="defaultAmount"
                />
            </el-dialog>

            <div style="padding-left: 720px; margin-top: 20px">
                <el-button size="medium" type="primary" @click="submit" v-permission="[permission.appRechargeSaveConfig]" v-exclude-channel-user>保存</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import ConfigAmount from './configAmount'
import * as api from '@/api/finance/recharge'
import { deepClone, fenToYuan, yuanToFen } from '@/utils'
export default {
    name: 'RechargeConfig',
    components: {
        InputNumber,
        ConfigAmount
    },
    mixins: [Base],
    data() {
        return {
            dataObj: {
                serviceFeeRate: '',
                selected: '',
                open: '',
                goodsList: []
            },
            submitObj: {},
            configAmountDialog: false,
            configAmountIndex: '',
            channelAmountConf: {
                amountMulti: [],
                amountRange: []
            },
            defaultAmount: 0
        }
    },
    computed: {},
    watch: {},
    mounted() {
        this.fixed_height = 330
        this.initData()
        this.getRechargeChannel()
    },
    methods: {
        //开关切换事件，关闭的时候处理默认值
        changeSwitch(id) {
            //根据ID获取index
            let index = _.findIndex(this.dataObj.goodsList, function (o) {
                return o.id == id
            })
            if (this.dataObj.goodsList[index]['open'] == true) {
                return
            }
            //取最小的金额，将其设置成为默认
            let minAmount = _.minBy(this.dataObj.goodsList, function (o) {
                if (o.open == true) {
                    return o.amount
                }
            })
            if (minAmount === undefined) {
                this.$message.error('请至少配置一个档位')
                this.dataObj.goodsList[index].open = true
                return
            }
            //当前关闭的档位有默认值，就重新指定最小的为默认
            if (this.dataObj.selected == id) {
                this.dataObj.selected = minAmount.id
            }
        },
        initData() {
            api.queryConfig()
                .then((rep) => {
                    this.dataObj = rep.data
                    //金额缩小100
                    for (const i in this.dataObj.goodsList) {
                        // this.dataObj.goodsList[i]['amount'] = fenToYuan(this.dataObj.goodsList[i]['amount'])
                        this.dataObj.goodsList[i]['giveAmount_D'] = fenToYuan(this.dataObj.goodsList[i]['giveAmount_D'])
                        this.dataObj.goodsList[i]['giveAmount_B'] = fenToYuan(this.dataObj.goodsList[i]['giveAmount_B'])
                    }
                })
                .catch(() => {})
        },
        amountConfig(index) {
            this.configAmountIndex = index
            this.defaultAmount = fenToYuan(this.dataObj.goodsList[index].amount)
            this.configAmountDialog = true
        },
        //默认选中
        setDefault(id) {
            this.dataObj.selected = id
        },
        toChannel() {
            this.$parent.changeTabActiveName('channel')
        },
        //样式
        objectSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 1) {
                if (rowIndex % 9 === 0) {
                    return {
                        rowspan: 9,
                        colspan: 1
                    }
                } else {
                    return {
                        rowspan: 0,
                        colspan: 0
                    }
                }
            }
        },
        //设置金额回调
        setConfig(amount) {
            for (let i in this.dataObj.goodsList) {
                if (this.dataObj.goodsList[i].amount == amount && i != this.configAmountIndex) {
                    return this.$message.error('该金额已被占用')
                }
            }
            this.dataObj.goodsList[this.configAmountIndex].amount = amount
            this.configAmountDialog = false
        },
        dialogCancel() {
            this.configAmountDialog = false
        },
        checkChannelAmount() {
            for (const i in this.submitObj.goodsList) {
                let tmpItem = this.submitObj.goodsList[i]
                if (tmpItem.open) {
                    let checkAmountTmp = 0
                    let checkAmountTag = 0

                    if (this.channelAmountConf.amountMulti && this.channelAmountConf.amountMulti.indexOf(_.toNumber(fenToYuan(tmpItem.amount))) != -1) {
                        checkAmountTag = 1
                    }
                    if (this.channelAmountConf.amountRange) {
                        //校验范围金额
                        for (let index in this.channelAmountConf.amountRange) {
                            checkAmountTmp = this.channelAmountConf.amountRange[index]
                            if (_.toNumber(fenToYuan(tmpItem.amount)) >= _.toNumber(checkAmountTmp[0]) && _.toNumber(fenToYuan(tmpItem.amount)) <= _.toNumber(checkAmountTmp[1])) {
                                checkAmountTag = 1
                                break
                            }
                        }
                    }
                    if (checkAmountTag == 0) {
                        this.$message.error('ID' + _.toNumber(tmpItem.id) + ':金额超出通道支持金额范围')
                        return false
                    }
                }
            }

            return true
        },
        submit() {
            this.submitObj = deepClone(this.dataObj)
            //校验渠道金额
            if (!this.checkChannelAmount()) {
                return false
            }
            //金额放大100
            for (const i in this.submitObj.goodsList) {
                this.submitObj.goodsList[i]['giveAmount_D'] = yuanToFen(this.submitObj.goodsList[i]['giveAmount_D'])
                this.submitObj.goodsList[i]['giveAmount_B'] = yuanToFen(this.submitObj.goodsList[i]['giveAmount_B'])
            }
            api.saveConfig(this.submitObj)
                .then((rep) => {
                    this.$message.success('保存成功')
                    this.initData()
                })
                .catch(() => {})
        },
        //获取开启中的支付通道，并处理
        getRechargeChannel() {
            api.channelList({ channelState: 1, all: true }).then((rep) => {
                let paySupportTypeArr_1 = []
                let paySupportTypeArr_2 = []
                //处理可选金额
                let tmpPaySupportAmountList = []
                for (let i in rep.data) {
                    //金额缩小100
                    tmpPaySupportAmountList = rep.data[i].paySupportAmountList.map((value) => _.toNumber(fenToYuan(value)))
                    if (rep.data[i].paySupportType == 1) {
                        //范围金额
                        paySupportTypeArr_1.push(tmpPaySupportAmountList)
                    }

                    if (rep.data[i].paySupportType == 2) {
                        //固定金额
                        paySupportTypeArr_2 = _.concat(paySupportTypeArr_2, tmpPaySupportAmountList)
                    }
                }
                //固定金额-去重
                paySupportTypeArr_2 = paySupportTypeArr_2.filter(function (item, index) {
                    return paySupportTypeArr_2.indexOf(item) === index // 因为indexOf 只能查找到第一个
                })
                //固定金额-排序
                paySupportTypeArr_2 = paySupportTypeArr_2.sort(function (a, b) {
                    return a - b
                })

                this.channelAmountConf.amountRange = paySupportTypeArr_1
                this.channelAmountConf.amountMulti = paySupportTypeArr_2
            })
        }
    }
}
</script>
<style scoped lang="scss">
.default-tag {
    background: rgba(27, 162, 255, 0.1);
    border-radius: 2px;
    min-width: 36px;
    height: 18px;
    font-size: 10px;
    margin-top: -5px;
    color: #1ba2ff;
}
.default-game-tag {
    color: #08dce6;
    background-color: rgba(8, 220, 230, 0.1);
    min-width: 36px;
    height: 18px;
    font-size: 10px;
    margin-top: -5px;
}

::v-deep .el-table--small .el-table__cell {
    padding: 0;
}
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
//移除hover效果
::v-deep .el-table--enable-row-hover .el-table__body tr:hover > td {
    background-color: rgba(0, 0, 0, 0) !important;
}
</style>
