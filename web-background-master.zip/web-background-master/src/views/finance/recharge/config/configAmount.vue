<template>
    <div>
        <div class="inner_item" style="padding-left: 20px" v-if="configStatus == 1">
            <el-form ref="form" label-width="100px" label-position="left">
                <el-form-item v-if="this.channelAmountConf.amountMulti.length > 0">
                    <template slot="label">可选金额:</template>
                    <div class="ml-5">
                        <el-tag v-for="(item, index) in channelAmountConf.amountMulti" :key="index" :type="getTagClassName(item)" size="medium" class="ml-10" @click="selectAmount(item)">
                            {{ item }}
                        </el-tag>
                    </div>
                </el-form-item>

                <el-form-item v-if="this.channelAmountConf.amountRange.length > 0">
                    <template slot="label">区间金额:</template>
                    <div style="color: #f78114" class="fs-12 ml-5">金额支持范围 {{ rangeAmountTips }} 之间正整数</div>
                </el-form-item>

                <el-form-item>
                    <template slot="label">金额:</template>
                    <div class="ml-5">
                        <div class="item">
                            <InputNumber v-model="amount" maxlength="12" minlength="2" placeholder="请选择可选或输入金额" show-word-limit rangeWidth="250px" clearable />
                        </div>
                    </div>
                </el-form-item>
            </el-form>
            <div class="footer-add mt-20">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">保存</el-button>
            </div>
        </div>

        <div class="inner_item" style="padding-left: 20px" v-if="configStatus != 1">
            <span class="notice">当前无可用通道，无法配置金额，请去【通道管理】中配置并开启通道。</span>
            <div class="footer-add mt-20">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="toChannel()">前往</el-button>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { yuanToFen } from '@/utils'
export default {
    components: { InputNumber },
    props: {
        channelAmountConf: {
            type: Object,
            default: {}
        },
        dataObj: {
            type: Object,
            default: {}
        },
        defaultAmount: {
            type: String,
            default: 0
        }
    },
    data() {
        return {
            amount: '',
            type: '',
            configStatus: 0,
            rangeAmountTips: ''
        }
    },
    mixins: [Base],
    mounted() {},
    created() {
        if (this.channelAmountConf.amountMulti.length > 0) {
            this.configStatus = 1
        } else if (this.channelAmountConf.amountRange.length > 0) {
            this.configStatus = 1
        } else {
            this.configStatus = 0
        }
        if (this.defaultAmount) {
            this.amount = this.defaultAmount
        }
        this.getRangeAmountTips()
    },
    methods: {
        //金额支持范围tips
        getRangeAmountTips() {
            const tmpArr = []
            for (let i in this.channelAmountConf.amountRange) {
                tmpArr.push(this.channelAmountConf.amountRange[i].join('~'))
            }
            let inputRanges = this.channelAmountConf.amountRange
            inputRanges = inputRanges.sort(function (a, b) {
                if (a[0] === b[0]) {
                    return a[1] - b[1]
                } else {
                    return a[0] - b[0]
                }
            })
            // 创建一个空数组来存储合并后的结果
            let mergedRanges = []

            // 遍历排序后的二维数组
            for (let i = 0; i < inputRanges.length; i++) {
                let currentRange = inputRanges[i]
                // 如果 mergedRanges 数组为空，直接将当前范围添加到 mergedRanges 数组中
                if (mergedRanges.length === 0) {
                    mergedRanges.push(currentRange)
                } else {
                    // 获取 mergedRanges 数组中最后一个范围
                    let lastRange = mergedRanges[mergedRanges.length - 1]

                    // 如果当前范围的起始值大于最后一个范围的结束值加1，说明不连续，直接将当前范围添加到 mergedRanges 数组中
                    if (currentRange[0] > lastRange[1] + 1) {
                        mergedRanges.push(currentRange)
                    } else {
                        // 如果当前范围的起始值小于等于最后一个范围的结束值加1，说明连续，更新最后一个范围的结束值为当前范围的结束值
                        lastRange[1] = Math.max(lastRange[1], currentRange[1])
                    }
                }
            }
            this.rangeAmountTips = mergedRanges
                .map(function (range) {
                    return range[0] + '~' + range[1]
                })
                .join('、')
        },
        //可选金额选择事件
        selectAmount(amount) {
            for (let i in this.dataObj.goodsList) {
                if (this.dataObj.goodsList[i].amount == yuanToFen(amount)) {
                    //该金额已被占用,不能点击
                    return false
                }
            }
            this.amount = amount
        },
        //处理可选金额class
        getTagClassName(tagAmount) {
            for (let i in this.dataObj.goodsList) {
                if (this.dataObj.goodsList[i].amount == yuanToFen(tagAmount)) {
                    return 'danger'
                }
            }

            if (tagAmount == this.amount) {
                return ''
            } else {
                return 'info'
            }
        },
        submit() {
            let amount = this.amount

            let checkAmountTag = 0
            if (this.channelAmountConf.amountMulti && this.channelAmountConf.amountMulti.indexOf(amount) != -1) {
                checkAmountTag = 1
            } else {
                let checkAmountTmp = 0
                for (let i in this.channelAmountConf.amountRange) {
                    checkAmountTmp = this.channelAmountConf.amountRange[i]
                    if (amount >= checkAmountTmp[0] && amount <= checkAmountTmp[1]) {
                        checkAmountTag = 1
                    }
                }
            }
            if (checkAmountTag == 0) {
                return this.$message.error('金额超出通道支持金额范围')
            }

            this.$emit('setConfig', yuanToFen(amount))
        },
        dialogCancel() {
            this.$emit('onclose')
        },
        toChannel() {
            this.$emit('toChannel')
        }
    }
}
</script>

<style lang="scss" scoped>
.inner_item {
    display: flex;
    flex-direction: column;
    .footer-add {
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
    }
}

.notice {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #282829;
    letter-spacing: 0;
    line-height: 28px;
    font-weight: 400;
}
::v-deep .el-tag {
    border-radius: 15px;
    cursor: pointer;
}
::v-deep .el-tag.el-tag--danger {
    background: #f0f2f7;
    border-color: #f0f2f7;
    color: #a1a4a7;
    cursor: not-allowed;
}

::v-deep .el-tag.el-tag--info {
    background: none;
    border: 1px solid rgba(220, 223, 230, 1);
    color: #282829;
}
</style>
