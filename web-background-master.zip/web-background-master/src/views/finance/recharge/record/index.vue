<template>
    <div>
        <Report :data-obj="statData" @queryData="queryData" v-permission="[permission.appRechargeOrderStatistics]" />
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" style="width: 240px" />
                <el-input v-model="query.recordId" size="medium" clearable placeholder="记录ID" style="width: 90px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 120px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="平台订单号" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.channelOrderId" size="medium" clearable placeholder="通道订单号" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.fromType" placeholder="充值类型" size="medium" class="filter-item" style="width: 110px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_PAY_TYPE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.paymentMethod" placeholder="充值方式" size="medium" class="filter-item" style="width: 110px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_PAYMENT_METHOD" :key="index" :value="item" :label="item" />
                </el-select>
                <el-select v-model="query.orderState" placeholder="平台状态" size="medium" class="filter-item" style="width: 110px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.channelOrderState" placeholder="通道状态" size="medium" class="filter-item" style="width: 110px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_CHANNEL_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list" :row-style="{ height: '60px' }">
                    <el-table-column prop="recordId" :show-overflow-tooltip="true" width="80" align="center" label="记录ID">
                        <template slot-scope="scope">
                            <div class="dp-f" style="height: 60px">
                                <div style="width: 36px">
                                    <div class="order-to-success" v-show="scope.row.orderState == 4">置成功</div>
                                    <div class="order-to-error" v-show="scope.row.orderState == 5">置失败</div>
                                </div>
                                <span style="font-size: 14px; margin-top: 18px">{{ scope.row.recordId }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="playerId" width="110" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="155" align="center" label="时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="orderId" width="250" align="center" label="平台订单号">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.orderId" v-clipboard:success="copySuccess" v-clipboard:error="copyError">{{ scope.row.orderId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelOrderId" width="200" align="center" label="通道订单号">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.channelOrderId" v-clipboard:success="copySuccess" v-clipboard:error="copyError">
                                {{ scope.row.channelOrderId ? scope.row.channelOrderId : '-' }}
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="fromType" width="170" align="left" label="充值类型">
                        <template slot-scope="scope">
                            {{ getArrayValue(RECHARGE_PAY_TYPE, scope.row.fromType) }}
                            <div class="text_gray fs-12">{{ scope.row.productContent }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="paymentMethod" width="80" align="center" label="充值方式" />
                    <el-table-column :show-overflow-tooltip="true" prop="productAmount" width="120" align="center" label="下单金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="actualAmount" width="120" align="center" label="实际支付">
                        <template slot-scope="scope">
                            {{ scope.row.actualAmount ? fenToYuan(scope.row.actualAmount) : '-' | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="orderState" width="100" align="center" label="平台状态">
                        <template slot-scope="scope">
                            <span v-if="scope.row.orderState != 0" :class="`recharge-order-state-` + scope.row.orderState">{{ getArrayValue(RECHARGE_ORDER_STATE, scope.row.orderState) }}</span>
                            <span v-if="scope.row.orderState == 0">--</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelOrderState" width="100" align="center" label="通道状态">
                        <template slot-scope="scope">
                            <span v-if="scope.row.channelOrderState != 0" :class="`recharge-channel-order-state-` + scope.row.channelOrderState">
                                {{ getArrayValue(RECHARGE_CHANNEL_ORDER_STATE, scope.row.channelOrderState) }}
                            </span>
                            <span v-if="scope.row.channelOrderState == 0">--</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="110" align="left" fixed="right" label="操作">
                        <template slot="header">
                            <el-popover placement="left-end" width="430" trigger="hover">
                                <el-table size="mini" :data="orderStatusData" style="width: 400px">
                                    <el-table-column prop="clientStatus" label="客户端状态" width="80"></el-table-column>
                                    <el-table-column prop="platformStatus" label="平台状态" width="80"></el-table-column>
                                    <el-table-column prop="channelStatus" label="通道状态" width="120"></el-table-column>
                                    <el-table-column prop="operator" label="操作按钮" width="120"></el-table-column>
                                </el-table>
                                <span slot="reference">
                                    操作
                                    <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                </span>
                            </el-popover>
                        </template>
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                v-permission="[permission.appRechargeOrderDetail]"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                            />
                            <el-button
                                type="text"
                                v-permission="[permission.appRechargeSetSuccess]"
                                v-show="[3].indexOf(scope.row.channelOrderState) != -1 && [1].indexOf(scope.row.orderState) != -1"
                                @click="changeOrder(scope.row, 'success')"
                            >
                                置成功
                            </el-button>
                            <el-button
                                type="text"
                                v-permission="[permission.appRechargeSetFail]"
                                v-show="[1].indexOf(scope.row.channelOrderState) != -1 && [3].indexOf(scope.row.orderState) != -1"
                                @click="changeOrder(scope.row, 'fail')"
                            >
                                置失败
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="orderInfoDrawer" title="订单详情">
            <Detail :data-info="dataObj" v-if="orderInfoDrawer" />
        </Drawer>

        <Drawer :visible.sync="changeStatusDrawer" :title="changeStatusTitle">
            <ChangeStatus :data-info="dataObj" :submitType="changeStatusSubmitType" :key="dataObj.id" v-if="changeStatusDrawer" @onclose="closeDrawer" />
        </Drawer>
    </div>
</template>

<script>
import { RECHARGE_CHANNEL_ORDER_STATE, RECHARGE_ORDER_STATE, RECHARGE_PAY_TYPE, RECHARGE_PAYMENT_METHOD } from '@/constant/finance'
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/recharge'
import Report from './report.vue'
import Detail from './detail.vue'
import UserIdJump from '@/components/UserIdJump'

import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import ChangeStatus from './changeStatus'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'id;desc',
    createTime: [],
    recordId: '',
    playerId: '',
    orderId: null,
    channelOrderId: null,
    fromType: '',
    paymentMethod: '',
    orderState: '',
    channelOrderState: ''
}

export default {
    name: 'RechargeRecord',
    components: {
        ChangeStatus,
        Drawer,
        Detail,
        pagination,
        DateRangePicker,
        Report,
        UserIdJump
    },
    mixins: [Base],
    data() {
        return {
            RECHARGE_CHANNEL_ORDER_STATE,
            RECHARGE_ORDER_STATE,
            RECHARGE_PAY_TYPE,
            RECHARGE_PAYMENT_METHOD,
            loading: false,
            orderInfoDrawer: false,
            changeStatusDrawer: false,
            changeStatusTitle: '',
            changeStatusSubmitType: '',
            dataObj: {},
            orderInfoParams: {
                orderId: '',
                playerId: ''
            },
            statData: {},
            list: [],
            query: {
                size: 10,
                page: 1,
                sort: 'id;desc',
                createTime: [],
                recordId: '',
                playerId: '',
                orderId: null,
                channelOrderId: null,
                fromType: '',
                paymentMethod: '',
                orderState: '',
                channelOrderState: ''
            },
            orderStatusData: [
                { clientStatus: '失败', platformStatus: '提交失败', channelStatus: '--', operator: '详情' },
                { clientStatus: '处理中', platformStatus: '已提交', channelStatus: '等待支付', operator: '详情、置成功' },
                { clientStatus: '成功', platformStatus: '置成功', channelStatus: '通道当前状态', operator: '详情' },
                { clientStatus: '成功', platformStatus: '成功', channelStatus: '成功', operator: '详情、置失败' },
                { clientStatus: '失败', platformStatus: '置失败', channelStatus: '成功', operator: '详情' }
            ],
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 375
        this.query.createTime.push(this.$moment().subtract(30, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))

        this.toQuery()
        this.queryData()
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toDetail(row) {
            this.orderInfoDrawer = true
            this.dataObj = row
        },
        changeOrder(row, status) {
            this.changeStatusDrawer = true
            this.changeStatusSubmitType = status
            if (status === 'success') {
                this.changeStatusTitle = '置成功'
            } else if (status === 'fail') {
                this.changeStatusTitle = '置失败'
            } else {
                this.changeStatusTitle = ''
            }
            this.dataObj = row
        },
        //列表
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            if (this.checkPermission([this.permission.appRechargeOrderList])) {
                api.orderList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        //数据统计
        queryData(isCache = false) {
            if (this.checkPermission([this.permission.appRechargeOrderStatistics])) {
                api.orderStatistics({ isCache: isCache })
                    .then((rep) => {
                        this.statData = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        closeDrawer() {
            this.changeStatusDrawer = false
            this.toQuery()
        }
    }
}
</script>

<style lang="scss" scoped>
//处理记录ID标签
::v-deep .el-table tbody tr {
    td:first-child .cell {
        padding-left: 0px;
    }
}
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
::v-deep .el-table tbody .el-table__cell {
    padding-top: 0px;
    padding-bottom: 0px;
}
</style>
