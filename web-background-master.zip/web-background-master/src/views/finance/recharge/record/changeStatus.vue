<template>
    <div class="common-drawer-table-detail no-scrollbar" style="width: 770px">
        <div class="order-info-item_bg">
            <div class="dp-f">
                <div>
                    <img src="@/assets/images/avatar.png" alt="" width="60px" height="60px" />
                </div>

                <div class="dp-c ml-20">
                    <span>{{ orderInfo.nickname }}</span>
                    <span class="mt-10 des_title" style="color: #686b6d">ID:{{ orderInfo.playerId }}</span>
                </div>
            </div>
            <div class="order-create-info dp-f mt-20 mb-20">
                <div>
                    <span class="des_title" style="color: #686b6d">创建时间:</span>
                    <span class="des_title ml-10">{{ orderInfo.createTime }}</span>
                </div>

                <div class="ml-40">
                    <span class="des_title" style="color: #686b6d">记录ID:</span>
                    <span class="des_title ml-10">{{ orderInfo.recordId }}</span>
                </div>
            </div>
            <div style="border-bottom: #dcdfe6 1px solid" class="mb-20" />

            <el-form :inline="true" label-position="left">
                <div class="item_rows">
                    <div class="item_rows_left">
                        <el-form-item label="下单金额:">
                            <span class="des_title">{{ fenToYuan(orderInfo.productAmount) | filterThousandths }}</span>
                        </el-form-item>
                    </div>
                </div>
                <div class="item_rows">
                    <div class="item_rows_left">
                        <el-form-item label="平台订单号:">
                            <span class="des_title">{{ orderInfo.orderId }}</span>
                        </el-form-item>
                    </div>
                    <div class="item_rows_right">
                        <el-form-item label="通道订单号:">
                            <span class="des_title">{{ orderInfo.channelOrderId }}</span>
                        </el-form-item>
                    </div>
                </div>
                <div class="item_rows">
                    <div class="item_rows_left">
                        <el-form-item label="平台状态:">
                            <span class="des_title">{{ getArrayValue(RECHARGE_ORDER_STATE, orderInfo.orderState) }}</span>
                        </el-form-item>
                    </div>
                    <div class="item_rows_right">
                        <el-form-item label="通道状态:">
                            <span class="des_title">{{ getArrayValue(RECHARGE_CHANNEL_ORDER_STATE, orderInfo.channelOrderState) }}</span>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="item_title mt-40 mb-20">提交信息</div>

        <el-form :inline="true" :model="form" ref="form" :rules="rules" label-position="top">
            <div class="fs-14 text_gray">上传凭证</div>
            <div class="item_bg" style="padding: 20px">
                <UploadImage :limit="9" :fileSize="5" :multiple="true" @updateFileList="updateFileList" />
                <div class="label_title mt-20">最多上传9张图片，支持jpg、png、jpeg格式图片，单张图片大小不超过5MB</div>
                <el-dialog :visible.sync="dialogVisible">
                    <img width="50%" :src="dialogImageUrl" alt="" />
                </el-dialog>
            </div>

            <el-form-item label="备注说明:" prop="remark">
                <div style="width: 700px">
                    <el-input type="textarea" :rows="6" placeholder="请输入内容" v-model="form.remark" maxlength="500" show-word-limit></el-input>
                </div>
            </el-form-item>
        </el-form>

        <div class="dp-f-center mt-30">
            <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </div>
</template>

<script>
import Card from '@/components/Card'
import Base from '@/views/base'
import UploadImage from '@/components/UploadImage'
import { RECHARGE_CHANNEL_ORDER_STATE, RECHARGE_ORDER_STATE } from '@/constant/finance'
import * as api from '@/api/finance/recharge'

export default {
    components: {
        Card,
        UploadImage
    },
    mixins: [Base],
    props: {
        dataInfo: {
            type: Object,
            default: {}
        },
        submitType: {
            type: String,
            default: 'success'
        }
    },
    data() {
        return {
            dialogImageUrl: '',
            dialogVisible: false,
            disabled: false,
            RECHARGE_ORDER_STATE,
            RECHARGE_CHANNEL_ORDER_STATE,
            orderInfo: [],
            form: {
                remark: '',
                imgList: []
            },
            rules: {
                remark: [
                    { required: true, message: '请输入备注内容', trigger: 'blur' },
                    { min: 10, max: 500, message: '备注内容长度在10到500字符', trigger: 'blur' }
                ]
            }
        }
    },
    created() {
        this.getOrderInfo()
    },
    methods: {
        getOrderInfo() {
            api.orderDetail({ orderId: this.dataInfo.orderId, playerId: this.dataInfo.playerId }).then((rep) => {
                this.orderInfo = rep.data
            })
        },
        submit() {
            const postParams = {
                orderId: this.dataInfo.orderId,
                credentialList: this.form.imgList ? this.form.imgList : [],
                playerId: this.dataInfo.playerId
            }
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.submitType == 'success') {
                        postParams['remark'] = this.getUserInfo().username + `[置成功]` + this.form.remark
                        api.setSuccess(postParams).then((rep) => {
                            this.$message.success('操作成功')
                            this.$emit('onclose')
                        })
                    }
                    if (this.submitType == 'fail') {
                        postParams['remark'] = this.getUserInfo().username + `[置失败]` + this.form.remark
                        api.setFail(postParams).then((rep) => {
                            this.$message.success('操作成功')
                            this.$emit('onclose')
                        })
                    }
                }
            })
        },
        updateFileList: function (list) {
            this.form.imgList = list
        }
    }
}
</script>

<style lang="scss" scoped>
.common-drawer-table-detail {
    .item_rows {
        width: 100%;
        display: flex;

        &_left {
            width: 55%;
        }

        &_right {
            width: 45%;
        }
    }
}

.order-info-item_bg {
    padding: 30px;
    background: #f4f8fe;
    border-radius: 4px;
}
</style>
