<template>
    <div class="mb-5">
        <div class="zhankai_shouqi_btn">
            <IconButton size="small" :icon="showData ? 'oms_ico_shouqi' : 'oms_ico_zhankai'" @click="showData = !showData" :title="showData ? '收起统计' : '展开统计'" />
        </div>
        <div class="report-data-box-new" style="margin-bottom: 30px" v-if="showData">
            <div class="item-box" style="width: 600px; height: 180px">
                <div class="content">
                    <div class="dp-f-space-between">
                        <div class="top-title top-title-green" style="width: 120px">充值订单数</div>
                        <div class="mr-10">
                            <span class="item-title" style="margin-top: -10px">
                                <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                            </span>
                        </div>
                    </div>
                    <div class="dp-f ml-40 mt-20">
                        <div class="dp-f">
                            <div class="dp-f">
                                <el-tooltip class="icon-tips-max" effect="dark" content="总充值订单数=有产生充值订单的数量汇总，包含处理中、成功、失败三种状态" placement="right">
                                    <svg-icon icon-class="oms_ico_query" />
                                </el-tooltip>
                                <span class="item-title">总充值</span>
                            </div>
                            <span class="item-number-max" style="width: 150px">{{ dataObj.orderCount | filterThousandths }}</span>
                        </div>
                        <div class="dp-f ml-40">
                            <div class="dp-f">
                                <el-tooltip
                                    class="icon-tips-max"
                                    effect="dark"
                                    content="状态为处理中的充值订单数量(前端只要产生订单计数+1，不判断玩家是否有真实充值行为)，用户在前端删除订单后也不影响计数统计"
                                    placement="right"
                                >
                                    <svg-icon icon-class="oms_ico_query" />
                                </el-tooltip>
                                <span class="item-title">处理中</span>
                            </div>
                            <span class="item-number-max">{{ dataObj.doingCount | filterThousandths }}</span>
                        </div>
                    </div>
                    <div class="split-line ml-30 mb-20" style="width: 540px; margin-top: 18px" />
                    <div class="dp-f ml-40">
                        <div class="item">
                            <div class="dp-f">
                                <el-tooltip class="icon-tips-max" effect="dark" content="已完结订单数=成功充值订单数+失败充值订单数" placement="right">
                                    <svg-icon icon-class="oms_ico_query" />
                                </el-tooltip>
                                <span class="item-title">已完结</span>
                            </div>
                            <span class="item-number-medium" style="margin-top: 15px; width: 160px">{{ dataObj.endCount | filterThousandths }}</span>
                        </div>
                        <div class="item" style="margin-left: 30px">
                            <div class="dp-f">
                                <el-tooltip class="icon-tips-min" style="margin-top: 2px" effect="dark" content="成功订单数=状态为成功的充值订单数量" placement="right">
                                    <svg-icon icon-class="oms_ico_query" />
                                </el-tooltip>
                                <span class="item-title-min" style="margin-top: 2px">成功</span>
                                <span class="item-number-medium color-num-one" style="width: 120px">{{ dataObj.successCount | filterThousandths }}</span>
                            </div>

                            <span class="item-title-per mt-10">占比:{{ getPercentage(dataObj.successCount, dataObj.endCount) }}</span>
                        </div>
                        <div class="item" style="margin-left: 20px">
                            <div class="dp-f">
                                <el-tooltip class="icon-tips-min" style="margin-top: 2px" effect="dark" content="失败订单数=状态为失败的充值订单数量" placement="right">
                                    <svg-icon icon-class="oms_ico_query" />
                                </el-tooltip>
                                <span class="item-title-min" style="margin-top: 2px">失败</span>
                                <span class="item-number-medium color-num-two" style="width: 120px">{{ dataObj.failCount | filterThousandths }}</span>
                            </div>
                            <span class="item-title-per mt-10">占比:{{ getPercentage(dataObj.failCount, dataObj.endCount) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item-box ml-10" style="width: 590px; height: 180px">
                <div class="content">
                    <div class="dp-f-space-between">
                        <div class="top-title top-title-yellow" style="width: 100px">充值到账</div>
                        <div class="mr-10">
                            <span class="item-title" style="margin-top: -10px">
                                <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                            </span>
                        </div>
                    </div>

                    <div class="dp-f mt-20">
                        <div class="dp-c ml-30">
                            <div class="dp-f">
                                <div class="dp-f">
                                    <el-tooltip class="icon-tips-max" effect="dark" content="玩家累计充值金额=玩家充值成功的订单金额累计(取玩家“充值金额”字段)" placement="right">
                                        <svg-icon icon-class="oms_ico_query" />
                                    </el-tooltip>
                                    <span class="item-title">累计充值金额</span>
                                </div>
                                <span class="item-number-max" style="width: 120px" v-autoFontSize="'finance-max'">{{ fenToYuan(dataObj.amountCount) | filterThousandths }}</span>
                            </div>
                            <div class="split-line mt-20 mb-20" style="width: 230px" />

                            <div class="dp-f">
                                <div class="item">
                                    <div class="dp-f">
                                        <el-tooltip
                                            class="icon-tips-min"
                                            effect="dark"
                                            content="通道费=充值成功订单渠道手续费金额累计(通道费是在渠道管理模块维护，若未配置通道费率，将无通道费数据计入)"
                                            placement="right"
                                        >
                                            <svg-icon icon-class="oms_ico_query" />
                                        </el-tooltip>
                                        <span class="item-title-min">通道费</span>
                                    </div>
                                    <span class="item-number-medium mt-10 color-num-one" style="width: 100px" v-autoFontSize="'finance-medium'">
                                        {{ fenToYuan(dataObj.channelFeeCount) | filterThousandths }}
                                    </span>
                                </div>
                                <div class="item ml-20">
                                    <div class="dp-f">
                                        <el-tooltip
                                            class="icon-tips-min"
                                            effect="dark"
                                            content="手续费=充值成功订单平台收取的充值手续费金额累计(手续费是在充值配置模块维护，若配置为0，则将不扣除手续费)"
                                            placement="right"
                                        >
                                            <svg-icon icon-class="oms_ico_query" />
                                        </el-tooltip>
                                        <span class="item-title-min">手续费</span>
                                    </div>
                                    <span class="item-number-medium mt-10 color-num-two" style="width: 100px" v-autoFontSize="'finance-medium'">
                                        {{ fenToYuan(dataObj.serverFeeCount) | filterThousandths }}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="vertical-split-line ml-30 mr-30" style="height: 80px" />
                        <div class="dp-c">
                            <div class="item">
                                <div class="dp-f">
                                    <el-tooltip class="icon-tips" effect="dark" content="玩家实际到账金额=充值成功订单D账户到账金额累计+充值成功订单B账户到账金额累计" placement="right">
                                        <svg-icon icon-class="oms_ico_query" />
                                    </el-tooltip>
                                    <span class="item-title">实际到账</span>
                                    <span class="item-number-max" style="width: 120px" v-autoFontSize="'finance-max'">{{ fenToYuan(dataObj.actualAmountCount) | filterThousandths }}</span>
                                </div>
                            </div>
                            <div class="split-line mt-20 mb-20" style="width: 240px" />

                            <div class="dp-f">
                                <div class="item">
                                    <div class="dp-f">
                                        <el-tooltip class="icon-tips-min" effect="dark" content="D账户实际到账=充值成功订单D账户到账金额累计" placement="right">
                                            <svg-icon icon-class="oms_ico_query" />
                                        </el-tooltip>
                                        <span class="item-title-min">D账户</span>
                                    </div>
                                    <span class="item-number-medium mt-10 color-num-one" style="width: 110px" v-autoFontSize="'finance-medium'">
                                        {{ fenToYuan(dataObj.damountCount) | filterThousandths }}
                                    </span>
                                </div>
                                <div class="item ml-20">
                                    <div class="dp-f">
                                        <el-tooltip class="icon-tips-min" effect="dark" content="B账户实际到账=B账户明细中有充值订单号的金额累计" placement="right">
                                            <svg-icon icon-class="oms_ico_query" />
                                        </el-tooltip>
                                        <span class="item-title-min">B账户</span>
                                    </div>
                                    <span class="item-number-min mt-10 color-num-two" style="width: 110px" v-autoFontSize="'finance-medium'">
                                        {{ fenToYuan(dataObj.bamountCount) | filterThousandths }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import IconButton from '@/components/IconButton'
import Base from '@/views/base'
export default {
    mixins: [Base],
    components: {
        IconButton
    },
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            loading: false,
            showData: true
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData', true)
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>

<style scoped lang="scss">
.zhankai_shouqi_btn {
    .el-button {
        background: #f7f7f7;
        border-radius: 4px;

        font-family: PingFangSC-Regular;
        font-size: 12px;
        color: #282829;
        letter-spacing: 0;
        line-height: 16px;
        font-weight: 400;
    }
}
</style>
