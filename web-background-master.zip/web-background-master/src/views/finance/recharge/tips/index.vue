<template>
    <div>
        <el-form ref="form" size="small" label-width="150px" label-position="top">
            <el-form-item label="充值记录主页小贴士:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="5" placeholder="" v-model="dataObj[0].content" class="text_area"></el-input>
                <div class="text_gray fs-12">
                    邮箱地址填写
                    <span class="text_red">{KEFU_EMAIL}</span>
                </div>
            </el-form-item>

            <el-form-item label="优惠券使用小贴士:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="6" placeholder="" v-model="dataObj[1].content" class="text_area"></el-input>
            </el-form-item>

            <el-form-item label="充值教程小贴士:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="5" placeholder="" v-model="dataObj[2].content" class="text_area"></el-input>
            </el-form-item>
        </el-form>

        <div style="padding: 5px">
            <UploadFile v-if="showUpload" :accept="'.mp4'" :fileSize="50" :fileExt="['video/mp4']" :existFileList="existFileList" @updateFileList="updateFileList" />
            <div slot="tip" class="el-upload__tip">只能上传mp4文件，且不超过50MB</div>
        </div>
        <div style="padding-left: 720px; margin-top: 20px">
            <el-button size="medium" type="primary" @click="submit" v-permission="[permission.appRechargeSaveTipsConfig]" v-exclude-channel-user>保存</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import UploadFile from '@/components/UploadFile'
import * as api from '@/api/finance/recharge'

export default {
    name: 'Tips',
    components: {
        UploadFile
    },
    mixins: [Base],
    data() {
        return {
            dataObj: [{}, {}, {}],
            showUpload: false,
            existFileList: []
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 330
        this.initData()
    },
    methods: {
        initData() {
            api.queryTipsConfig()
                .then((rep) => {
                    this.dataObj = rep.data
                    //拼装已经上传的文件
                    if (this.dataObj[2].resourceLink) {
                        this.existFileList = [{ name: this.dataObj[2].resourceLink, url: this.dataObj[2].resourceLink }]
                    }
                    this.showUpload = true
                })
                .catch(() => {})
        },
        submit() {
            api.saveTipsConfig(this.dataObj)
                .then((rep) => {
                    this.$message.success('保存成功')
                })
                .catch(() => {})
        },
        //上传文件回调
        updateFileList: function (list) {
            this.dataObj[2].resourceLink = list[0]
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.big-label {
    font-size: 16px;

    ::v-deep .el-form-item__label {
        font-family: PingFangSC-Medium;
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        text-align: center;
        font-weight: 500;
    }
}

.text_area {
    ::v-deep .el-textarea__inner {
        background: #f4f8fe;
        border: 0px;
    }
}
.upload-box {
    background: #f4f8fe;
}
</style>
