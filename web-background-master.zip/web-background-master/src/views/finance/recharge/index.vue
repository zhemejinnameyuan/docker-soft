<template>
    <div class="app-container finance">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane v-for="(item, index) in tabList" :key="index" :label="item.title" :name="item.type"></el-tab-pane>
        </el-tabs>

        <Record v-if="activeName === 'record'" />
        <Channel v-if="activeName === 'channel'" />
        <Config v-if="activeName === 'config'" />
        <Tips v-if="activeName === 'tips'" />
        <Feedback v-if="activeName === 'feedback'" />
    </div>
</template>

<script>
import Base from '@/views/base'
import Record from './record/index'
import Channel from './channel/index'
import Config from './config/index'
import Tips from './tips/index'
import Feedback from './feedback/index'
export default {
    name: 'Recharge',
    components: {
        Feedback,
        Record,
        Channel,
        Config,
        Tips
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'record',
            config: [],
            tabList: []
        }
    },
    computed: {},
    mounted() {
        this.config = [
            {
                type: 'record',
                title: '充值明细',
                permissions: [this.permission.appRechargeOrderList],
                excludeChannelUser: false
            },
            {
                type: 'channel',
                title: '通道管理',
                permissions: [this.permission.appRechargeChannelList],
                excludeChannelUser: true
            },
            {
                type: 'config',
                title: '充值配置',
                permissions: [this.permission.appRechargeQueryConfig],
                excludeChannelUser: true
            },
            {
                type: 'tips',
                title: '小贴士',
                permissions: [this.permission.appRechargeQueryTipsConfig],
                excludeChannelUser: true
            },
            {
                type: 'feedback',
                title: '意见反馈',
                permissions: [this.permission.appRechargeFeedbackList],
                excludeChannelUser: false
            }
        ]
        for (let index = 0; index < this.config.length; index++) {
            const element = this.config[index]
            if (this.checkPermission(element.permissions)) {
                //渠道用户逻辑处理
                if (element.excludeChannelUser && this.isChannelUser()) {
                    continue
                }
                this.tabList.push(element)
            }
        }
        if (this.tabList) {
            this.activeName = this.tabList[0].type
        }
    },
    methods: {
        changeTabActiveName(activeName) {
            this.activeName = activeName
        }
    }
}
</script>
