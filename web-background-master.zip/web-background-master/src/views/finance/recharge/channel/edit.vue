<template>
    <div class="common-drawer-table-detail no-scrollbar" style="width: 680px">
        <el-form label-width="150px" :model="formInfo" ref="formInfo" :rules="rules" :inline="true" label-position="left">
            <div class="item_title">通道状态</div>
            <el-form-item label="开关:" prop="channelState" style="text-align: left">
                <el-switch v-model="formInfo.channelState" :active-value="1" :inactive-value="0" />
            </el-form-item>

            <div class="item_title">通道信息</div>
            <div class="item_bg">
                <el-form-item label="通道名称:" prop="channelName">
                    <el-input v-model="formInfo.channelName" size="medium" maxlength="100" minlength="2" placeholder="请输入通道名称" show-word-limit style="width: 380px" clearable />
                </el-form-item>
                <el-form-item label="通道KEY:" prop="channelKey">
                    <el-input v-model="formInfo.channelKey" size="medium" maxlength="100" minlength="2" placeholder="请输入通道key" show-word-limit style="width: 380px" clearable />
                </el-form-item>
                <el-form-item label="支付方式" prop="paymentMethod">
                    <el-select v-model="formInfo.paymentMethod" filterable placeholder="请选择" clearable>
                        <el-option v-for="(item, index) in RECHARGE_PAYMENT_METHOD" :key="index" :label="item" :value="item" />
                    </el-select>
                </el-form-item>

                <br />
                <el-form-item label="通道类型:" prop="channelLabel">
                    <el-radio v-model="formInfo.channelLabel" :label="1">平台通道</el-radio>
                    <el-radio v-model="formInfo.channelLabel" :label="2">渠道自有</el-radio>

                    <el-select v-if="formInfo.channelLabel == 2" v-model="formInfo.appChannel" filterable placeholder="请选择">
                        <el-option v-for="item in channels" :key="item.id" :label="item.channelName + '(' + item.id + ')'" :value="item.id" />
                    </el-select>
                </el-form-item>
            </div>

            <div class="item_title">费率/限额</div>
            <div class="item_bg">
                <el-form-item label="通道费率(%):" prop="feeRate">
                    <InputNumber v-model="formInfo.feeRate" :min-number="0" :precision="2" :max-number="100" placeholder="请输入通道费率" show-word-limit rangeWidth="280" clearable />
                </el-form-item>
                <el-form-item label="通道费率(固定税值):" prop="fixedFee">
                    <InputNumber v-model="formInfo.fixedFee" :min-number="0" :precision="0" :max-number="1000" placeholder="请输入通道费率" show-word-limit rangeWidth="280" clearable />
                </el-form-item>
                <el-form-item label="支持金额:">
                    <el-radio v-model="formInfo.paySupportType" :label="1">区间金额</el-radio>
                    <el-radio v-model="formInfo.paySupportType" :label="2">固定金额</el-radio>

                    <InputNumberRange
                        v-if="formInfo.paySupportType == 1"
                        v-model="amountConf.amountRange"
                        range-width="100px"
                        :precision="2"
                        range-separator="～"
                        min-placeholder="1"
                        max-placeholder="999999"
                        :minNumber="1"
                        :maxNumber="999999"
                        clearable
                    />

                    <el-input
                        v-if="formInfo.paySupportType == 2"
                        v-model="amountConf.amountMulti"
                        type="textarea"
                        maxlength="100"
                        minlength="2"
                        :rows="3"
                        show-word-limit
                        placeholder="多个金额用/号分割"
                    />
                </el-form-item>

                <el-form-item label="每日限额<=:" prop="payDailyLimit">
                    <InputNumber v-model="amountConf.payDailyLimit" :min-number="1" :max-number="9999999999" placeholder="请输入每日限额" show-word-limit style="width: 280px" clearable />
                </el-form-item>
            </div>
        </el-form>
        <div style="margin-left: 40%">
            <el-button type="primary" @click="submit">保存</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumberRange from '@/components/InputNumberRange'
import InputNumber from '@/components/InputNumber'
import { RECHARGE_PAYMENT_METHOD } from '@/constant/finance'
import * as api from '@/api/finance/recharge'
import { deepClone, fenToYuan, getChannelList, yuanToFen } from '@/utils'

export default {
    name: 'Edit',
    components: {
        InputNumberRange,
        InputNumber
    },
    mixins: [Base],
    props: {
        dataInfo: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            RECHARGE_PAYMENT_METHOD,
            channels: [],
            formInfo: {},
            rules: {
                channelName: [{ required: true, trigger: 'blur', message: '请输入通道名称' }],
                channelKey: [{ required: true, trigger: 'blur', message: '请输入通道KEY' }],
                paymentMethod: [{ required: true, trigger: 'blur', message: '请选择支付方式' }],
                feeRate: [{ required: true, trigger: 'blur', message: '请输入通道费率' }],
                fixedFee: [{ required: true, trigger: 'blur', message: '请输入通道费率' }]
            },
            amountConf: {
                payDailyLimit: '',
                amountRange: [],
                amountMulti: ''
            }
        }
    },
    mounted() {},
    created() {
        this.getAppChannel()
        this.formInfo = deepClone(this.dataInfo)
        this.formInfo.groupType = 1 //充值通道
        //缩小金额
        this.amountConf.payDailyLimit = fenToYuan(this.formInfo.payDailyLimit)
        if (this.formInfo.paySupportType == 1 && this.formInfo.paySupportAmountList) {
            this.amountConf.amountRange['l'] = _.toNumber(fenToYuan(this.formInfo.paySupportAmountList[0]))
            this.amountConf.amountRange['r'] = _.toNumber(fenToYuan(this.formInfo.paySupportAmountList[1]))
        } else if (this.formInfo.paySupportType == 2 && this.formInfo.paySupportAmountList) {
            this.amountConf.amountMulti = this.formInfo.paySupportAmountList.map((value) => _.toNumber(fenToYuan(value))).join('/')
        }
    },
    methods: {
        async getAppChannel() {
            this.channels = await getChannelList()
        },
        dialogCancel() {},
        submit() {
            this.$refs.formInfo.validate((valid) => {
                if (valid) {
                    if (this.formInfo.channelLabel == 1) {
                        this.formInfo.appChannel = 0
                    }
                    if (this.amountConf.payDailyLimit < 1) {
                        return this.$message.error('请填写正确的每日限额')
                    }
                    let paySupportAmountList = []
                    if (this.formInfo.paySupportType == 1) {
                        //区间金额
                        if (typeof this.amountConf.amountRange.l === 'undefined' || typeof this.amountConf.amountRange.r === 'undefined') {
                            return this.$message.error('区间金额:请填写正确的金额')
                        }
                        if (this.amountConf.amountRange.l >= this.amountConf.amountRange.r) {
                            return this.$message.error('区间金额:结束金额不能比开始金额小')
                        }
                        paySupportAmountList.push(yuanToFen(this.amountConf.amountRange.l))
                        paySupportAmountList.push(yuanToFen(this.amountConf.amountRange.r))
                    } else if (this.formInfo.paySupportType == 2) {
                        if (this.amountConf.amountMulti == '') {
                            return this.$message.error('固定金额:请填写正确的金额')
                        }
                        const tmpAmountArr = this.amountConf.amountMulti.split('/')
                        for (let i in tmpAmountArr) {
                            if (_.toArray(tmpAmountArr[i]) <= 0 || isNaN(_.toNumber(tmpAmountArr[i]))) {
                                return this.$message.error('固定金额:请填写正确的金额[1]')
                            }
                            if (tmpAmountArr[i] < 1 || tmpAmountArr[i] > 999999) {
                                return this.$message.error('固定金额:范围区间只能是1～999999之间')
                            }
                            paySupportAmountList.push(yuanToFen(tmpAmountArr[i]))
                        }
                        //固定金额-排序
                        paySupportAmountList = paySupportAmountList.sort(function (a, b) {
                            return a - b
                        })
                    }

                    //还原金额
                    this.formInfo.payDailyLimit = yuanToFen(this.amountConf.payDailyLimit)
                    this.formInfo.paySupportAmountList = _.uniq(paySupportAmountList)
                    api.saveChannel(this.formInfo).then((rep) => {
                        this.$message.success('操作成功')
                        this.$emit('onclose')
                    })
                }
            })
        }
    }
}
</script>
<style lang="scss" scoped>
.el-form-item--small.el-form-item {
    margin-bottom: 18px !important;
}
</style>
