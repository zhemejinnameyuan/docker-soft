<template>
    <div class="common-drawer-table-detail" style="width: 660px">
        <el-form ref="form" :model="dataInfo" size="small" label-width="150px">
            <div :class="getOrderStateClass(dataInfo.channelState)" style="margin-bottom: 10px">通道状态: {{ getArrayValue(RECHARGE_CHANNEL_STATE, dataInfo.channelState) }}</div>
            <div class="item_bg dp-f">
                <div style="width: 200px" class="ml-30">
                    <span class="label_title">通道类型:</span>
                    <span class="label_title">{{ getArrayValue(RECHARGE_CHANNEL_LABEL, dataInfo.channelLabel) }}</span>
                </div>
                <div style="width: 220px">
                    <span class="label_title">通道ID:</span>
                    <span class="label_title">{{ dataInfo.id }}</span>
                </div>
                <div style="width: 220px">
                    <span class="label_title">通道名称:</span>
                    <span class="label_title">{{ dataInfo.channelName }}</span>
                </div>
            </div>

            <div class="item_title">通道信息</div>
            <div class="item_bg">
                <el-form-item label="创建时间:">
                    <label class="label_title">{{ dataInfo.createTime }}</label>
                </el-form-item>
                <el-form-item label="近期更新时间:">
                    <label class="label_title">{{ dataInfo.createTime }}</label>
                </el-form-item>
                <el-form-item label="通道ID:">
                    <label class="label_title">{{ dataInfo.id }}</label>
                </el-form-item>
                <el-form-item label="通道名称:">
                    <label class="label_title">{{ dataInfo.channelName }}</label>
                </el-form-item>
                <el-form-item label="通道KEY:">
                    <label class="label_title">{{ dataInfo.channelKey }}</label>
                </el-form-item>
                <el-form-item label="支付方式:">
                    <label class="label_title">{{ dataInfo.paymentMethod }}</label>
                </el-form-item>
            </div>

            <div class="item_title">费率/限额</div>
            <div class="item_bg">
                <el-form-item label="通道费率:">
                    <span class="label_title">
                        {{ dataInfo.feeRate }}%
                        <span v-if="dataInfo.fixedFee > 0">+ {{ dataInfo.fixedFee }}</span>
                    </span>
                </el-form-item>
                <el-form-item label="每日限额:">
                    <label class="label_title">{{ fenToYuan(dataInfo.payDailyLimit) | filterThousandths }}</label>
                </el-form-item>

                <el-form-item label="支持金额:">
                    <label class="label_title" style="word-break: break-word">{{ handleSupportAmount(dataInfo.paySupportType, dataInfo.paySupportAmountList) }}</label>
                </el-form-item>
            </div>

            <div class="item_title" v-permission="[permission.appRechargeChannelStatistics]">通道统计</div>
            <div class="item_bg" v-permission="[permission.appRechargeChannelStatistics]">
                <el-form-item>
                    <template slot="label">
                        当日剩余限额:
                        <el-tooltip class="item" effect="dark" content="分别对应通道当日剩余可用额度以及通道当日总额度，当日剩余可用额度=当日总额度-当日充值成功总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" style="font-size: 14px; margin-left: 6px; cursor: pointer" />
                        </el-tooltip>
                    </template>

                    <label class="label_title">{{ fenToYuan(_.subtract(statInfo.dayUseMax, statInfo.dayUse)) | filterThousandths }}/ {{ fenToYuan(statInfo.dayUseMax) | filterThousandths }}</label>
                </el-form-item>
                <el-form-item>
                    <template slot="label">
                        累计充值金额:
                        <el-tooltip class="item" effect="dark" content="累计充值金额=通道成功充值累计金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" style="font-size: 14px; margin-left: 6px; cursor: pointer" />
                        </el-tooltip>
                    </template>
                    <label class="label_title">{{ fenToYuan(statInfo.amountCount) | filterThousandths }}</label>
                </el-form-item>
                <el-form-item>
                    <template slot="label">充值笔数:</template>
                    <label class="label_title">总笔数:{{ _.sum([statInfo.numCount.x, statInfo.numCount.y, statInfo.numCount.z]) }}</label>
                    <label class="label_title text_green">成功:{{ statInfo.numCount.x | filterThousandths }}</label>
                    <label class="label_title text_red">失败:{{ statInfo.numCount.y | filterThousandths }}</label>
                    <label class="label_title">处理中:{{ statInfo.numCount.z | filterThousandths }}</label>
                </el-form-item>
                <el-form-item>
                    <template slot="label">
                        充值成功率:
                        <el-tooltip class="item" effect="dark" content="充值成功率=[成功订单数/(成功订单数+失败订单数)]*100%，精确到小数点后2位，四舍五入" placement="right">
                            <svg-icon icon-class="oms_ico_query" style="font-size: 14px; margin-left: 6px; cursor: pointer" />
                        </el-tooltip>
                    </template>
                    <label class="label_title">{{ getPercentage(statInfo.numCount.x, _.sum([statInfo.numCount.x, statInfo.numCount.y])) }}</label>
                </el-form-item>
            </div>
        </el-form>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/finance/recharge'
import { RECHARGE_CHANNEL_LABEL, RECHARGE_CHANNEL_PAY_SUPPORT_TYPE, RECHARGE_CHANNEL_STATE } from '@/constant/finance'
import { filterThousandths } from '@/utils/filters'
import { fenToYuan } from '@/utils'
export default {
    name: 'Detail',
    components: {},
    mixins: [Base],
    props: {
        dataInfo: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            RECHARGE_CHANNEL_LABEL,
            RECHARGE_CHANNEL_PAY_SUPPORT_TYPE,
            RECHARGE_CHANNEL_STATE,
            statInfo: {
                numCount: { x: 0, y: 0, z: 0 }
            },
            rules: []
        }
    },
    mounted() {},
    created() {
        this.getStatInfo()
    },
    methods: {
        handleSupportAmount(type, amountList) {
            //先将金额转换
            const newAmountList = amountList.map((value) => _.toNumber(fenToYuan(value)))
            if (type == 1) {
                return newAmountList.join('~')
            } else if (type == 2) {
                return newAmountList.join('/')
            }
        },
        getStatInfo() {
            if (this.checkPermission([this.permission.appRechargeChannelStatistics])) {
                api.channelStatistics({ channelId: this.dataInfo.id }).then((rep) => {
                    this.statInfo = rep.data
                })
            }
        },
        getOrderStateClass(state) {
            let className = 'order-state-title'

            if (state == 1) {
                className += ' order-state-success'
            } else if (state == 2) {
                className += ' order-state-error'
            } else {
                className += ' order-state-default'
            }
            return className
        },
        dialogCancel() {},
        submit() {}
    }
}
</script>
