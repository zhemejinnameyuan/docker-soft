<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="充值订单号" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.utr" size="medium" clearable placeholder="UTR" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.orderState" placeholder="订单状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.feedbackFlag" placeholder="处理状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_FEEDBACK_FLAG" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :row-style="{ height: '60px' }" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="playerId" width="120" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="createTime" width="180" align="center" label="时间" />
                    <el-table-column prop="orderId" width="270" align="center" label="充值订单号">
                        <template slot-scope="scope">
                            <a class="text_blue" @click="toDetail(scope.row)">{{ scope.row.orderId }}</a>
                        </template>
                    </el-table-column>
                    <el-table-column prop="productAmount" width="120" align="center" label="充值金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column prop="utr" width="160" align="center" label="UTR" />
                    <el-table-column prop="orderState" width="140" align="center" label="订单状态">
                        <template slot-scope="scope">
                            <span :class="`recharge-order-state-` + scope.row.orderState">{{ getArrayValue(RECHARGE_ORDER_STATE, scope.row.orderState) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="userCredential" align="center" width="140px" label="反馈截图">
                        <template slot-scope="scope">
                            <el-image style="width: 40px; height: 50px; margin-top: 5px" :src="domain + scope.row.userCredential" :preview-src-list="[domain + scope.row.userCredential]">
                                <div slot="error" class="image-slot"></div>
                            </el-image>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="feedbackFlag" width="140px" align="center" label="处理状态">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(RECHARGE_FEEDBACK_FLAG, scope.row.feedbackFlag) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="200" align="left" label="操作" fixed="right">
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                v-permission="[permission.appRechargeOrderDetail]"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                            />
                            <el-button
                                v-if="scope.row.feedbackFlag === 1 && [1, 2].indexOf(scope.row.orderState) !== -1"
                                type="text"
                                v-permission="[permission.appRechargeSetSuccess]"
                                @click="changeOrder(scope.row, '1')"
                            >
                                置成功
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="changeStatusDrawer" :title="changeStatusTitle">
            <ChangeStatus :data-info="dataObj" :key="dataObj.orderId" @onclose="closeDrawer" />
        </Drawer>

        <Drawer :visible.sync="orderInfoDrawer" title="订单详情">
            <Detail :data-info="dataObj" v-if="orderInfoDrawer" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/recharge'
import UserIdJump from '@/components/UserIdJump'
import Drawer from '@/components/Drawer'
import Detail from '@/views/finance/recharge/record/detail.vue'
import ChangeStatus from '@/views/finance/recharge/record/changeStatus'

import Base from '@/views/base'
import { RECHARGE_FEEDBACK_FLAG, RECHARGE_ORDER_STATE } from '@/constant/finance'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'createTime;desc',
    createTime: [],
    playerId: '',
    orderId: '',
    orderState: '',
    utr: '',
    feedbackFlag: ''
}

export default {
    name: 'Feedback',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump,
        Drawer,
        ChangeStatus,
        Detail
    },
    mixins: [Base],
    data() {
        return {
            RECHARGE_ORDER_STATE,
            RECHARGE_FEEDBACK_FLAG,
            loading: false,
            dataObj: {},
            changeStatusDrawer: false,
            changeStatusTitle: '',
            list: [],
            domain: '',
            orderInfoDrawer: false,
            query: {
                size: 10,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                playerId: '',
                orderId: '',
                orderState: '',
                utr: '',
                feedbackFlag: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 335
        this.query.createTime.push(this.$moment().subtract(30, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))

        this.toQuery()
    },
    methods: {
        toDetail(row) {
            this.orderInfoDrawer = true
            this.dataObj = row
        },
        changeOrder(row, status) {
            this.changeStatusDrawer = true
            if (status == 1) {
                this.changeStatusTitle = '置成功'
            } else {
                this.changeStatusTitle = '置失败'
            }
            this.dataObj = row
        },

        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appRechargeFeedbackList])) {
                this.loading = true
                api.feedbackList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.domain = rep.domain.file
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        closeDrawer() {
            this.changeStatusDrawer = false
            this.toQuery()
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
::v-deep .el-table tbody .el-table__cell {
    padding-top: 0px;
    padding-bottom: 0px;
}
</style>
