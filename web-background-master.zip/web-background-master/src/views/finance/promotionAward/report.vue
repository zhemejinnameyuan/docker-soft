<template>
    <div class="report-data-box-new">
        <div class="item-box" style="width: 1200px; height: 90px; margin-bottom: 30px">
            <div class="content" style="flex-direction: row">
                <div class="item">
                    <div class="top-title top-title-yellow" style="width: 100px">推广奖励</div>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="推广总奖励=分红奖励+分享奖励+首充奖励" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title">推广总奖励</span>
                        <span class="item-number-max" style="font-size: 24px; width: 130px" v-autoFontSize="'max'">
                            {{ dataObj.totalIncome | filterThousandths }}
                        </span>
                    </div>
                </div>
                <div class="ml-20 mr-20" style="width: 1px; height: 20px; margin-top: 25px; background-color: rgba(27, 162, 255, 0.3)"></div>
                <div class="item ml-30 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="平台分红奖励总额，分红奖励占比=(分红奖励/推广总奖励)*100%，精确到小数点2位，四舍五入" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">分红奖励</span>
                        <span class="item-number-max" style="width: 110px" v-autoFontSize="'finance-max'">{{ dataObj.totalDivvyIncome | filterThousandths }}</span>
                    </div>
                    <span class="item-title-per mt-10">占比:{{ getPercentage(dataObj.totalDivvyIncome, dataObj.totalIncome) }}</span>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="平台分享奖励总额，分享奖励占比=(分享奖励/推广总奖励)*100%，精确到小数点2位，四舍五入" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">分享奖励</span>
                        <span class="item-number-max" style="width: 110px" v-autoFontSize="'finance-max'">{{ dataObj.totalShareIncome | filterThousandths }}</span>
                    </div>
                    <span class="item-title-per mt-10">占比:{{ getPercentage(dataObj.totalShareIncome, dataObj.totalIncome) }}</span>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="平台首充奖励总额，首充奖励占比=(首充奖励/推广总奖励)*100%，精确到小数点2位，四舍五入" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">首充奖励</span>
                        <span class="item-number-max" style="width: 110px" v-autoFontSize="'finance-max'">{{ dataObj.totalDepositedIncome | filterThousandths }}</span>
                    </div>
                    <span class="item-title-per mt-10">占比:{{ getPercentage(dataObj.totalDepositedIncome, dataObj.totalIncome) }}</span>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <span class="item-title" style="margin-top: -10px">
                        <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData')
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>
