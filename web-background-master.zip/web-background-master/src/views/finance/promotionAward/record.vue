<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>
        </div>
        <el-row>
            <!--表格-->
            <el-col style="margin-bottom: 10px">
                <el-card class="box-card" shadow="never">
                    <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 960px" :height="table_height" :data="list">
                        <el-table-column prop="time" width="200" align="center" label="时间" />
                        <el-table-column prop="playerId" align="center" label="下级玩家ID" v-if="['100'].indexOf(rewardType) === -1">
                            <template slot-scope="scope">
                                <UserIdJump :id="scope.row.belowPlayerId" />
                            </template>
                        </el-table-column>
                        <el-table-column prop="way" align="center" label="奖励类型">
                            <template slot-scope="scope">
                                {{ getArrayValue(PROMOTION_REWARD_WAY, scope.row.way) }}
                            </template>
                        </el-table-column>
                        <el-table-column prop="incomeStr" align="center" label="奖励金额" />
                        <el-table-column prop="state" align="center" label="状态" />
                        <el-table-column width="320" prop="content" align="left" label="摘要" v-if="rewardType !== '100'">
                            <template slot-scope="scope">
                                <div v-html="getSummary(scope.row)"></div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
                </el-card>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/finance'
import UserIdJump from '@/components/UserIdJump'
import Base from '@/views/base'
import { PROMOTION_REWARD_WAY } from '@/constant/promotion'
import { filterThousandths } from '@/utils/filters'
import { ACCOUNT_GAME_ROOM_TYPE } from '@/constant/finance'
import { getArrayValue } from '@/utils'

export default {
    components: {
        pagination,
        DateRangePicker,
        UserIdJump
    },
    props: {
        recordId: {
            type: String,
            default: ''
        },
        rewardType: {
            type: String,
            default: ''
        }
    },
    mixins: [Base],
    data() {
        return {
            PROMOTION_REWARD_WAY,
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                time: [],
                playerId: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 240
        this.toQuery()
    },
    methods: {
        //处理摘要
        getSummary(row) {
            let text = ''
            switch (row.way) {
                case 101:
                    //首充奖励
                    //“下级玩家昵称”首次充值300.00(充值订单:xxxxxxxx)
                    text = `首次充值<span>${filterThousandths(row.belowDepositAmountStr)}</span>`
                    text += `(充值订单:<span class="text_blue">${row.belowDepositOrder})</span>`
                    break
                case 102:
                    //投注分红
                    text = ` 在"<span>${getArrayValue(ACCOUNT_GAME_ROOM_TYPE, row.belowGameRoomType)}</span>"中下注${filterThousandths(row.belowGameBetStr)}`
                    text += `(分成比例${filterThousandths(row.percent)}%,牌局流水:<span class="text_blue">${row.belowGameFlowId})</span>`
                    break
                default:
                    text = '获得' + getArrayValue(PROMOTION_REWARD_WAY, row.way) + '奖励'
            }
            return text
        },
        toQuery(page) {
            this.query.rewardId = this.recordId
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.financeReferRewardLog])) {
                this.loading = true
                api.financeRewardLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.role-span {
    font-weight: bold;
    color: #303133;
    font-size: 15px;
}
</style>

<style rel="stylesheet/scss" lang="scss" scoped>
::v-deep .el-input-number .el-input__inner {
    text-align: left;
}

::v-deep .vue-treeselect__multi-value {
    margin-bottom: 0;
}

::v-deep .vue-treeselect__multi-value-item {
    border: 0;
    padding: 0;
}
.terminal {
    display: flex;
    flex-direction: column;
}
</style>
