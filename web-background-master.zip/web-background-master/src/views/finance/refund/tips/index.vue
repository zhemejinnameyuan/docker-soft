<template>
    <div>
        <el-form ref="form" size="small" label-width="150px" label-position="top">
            <el-form-item label="退款主页小贴士:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="7" placeholder="" v-model="dataObj[0].content" class="text_area"></el-input>
                <div class="text_gray fs-12 mb-30">
                    邮箱地址填写
                    <span class="text_red">{KEFU_EMAIL}</span>
                </div>
            </el-form-item>

            <el-form-item label="Deposit Cash:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="7" placeholder="" v-model="dataObj[1].content" class="text_area"></el-input>
            </el-form-item>

            <el-form-item label="Winnings Cash:" prop="rechargeRecord" class="big-label">
                <el-input type="textarea" rows="7" placeholder="" v-model="dataObj[2].content" class="text_area"></el-input>
            </el-form-item>
        </el-form>
        <div style="padding-left: 720px; margin-top: 50px">
            <el-button size="medium" type="primary" @click="submit" v-permission="[permission.appWithdrawSaveTipsConfig]" v-exclude-channel-user>保存</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/finance/refund'

export default {
    name: 'Tips',
    mixins: [Base],
    data() {
        return {
            dataObj: [{}, {}, {}]
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 330
        this.initData()
    },
    methods: {
        initData() {
            api.queryTipsConfig()
                .then((rep) => {
                    this.dataObj = rep.data
                })
                .catch(() => {})
        },
        submit() {
            api.saveTipsConfig(this.dataObj)
                .then((rep) => {
                    this.$message.success('保存成功')
                })
                .catch(() => {})
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.big-label {
    font-size: 16px;

    ::v-deep .el-form-item__label {
        font-family: PingFangSC-Medium;
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        text-align: center;
        font-weight: 500;
    }
}

.text_area {
    ::v-deep .el-textarea__inner {
        background: #f4f8fe;
        border: 0px;
    }
}
</style>
