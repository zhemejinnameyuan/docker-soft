<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.recordId" size="medium" clearable placeholder="记录ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="平台订单号" style="width: 240px" class="filter-item" @keyup.enter.native="toQuery" />

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list" :row-style="{ height: '60px' }">
                    <el-table-column :show-overflow-tooltip="true" prop="recordId" width="120" align="center" label="记录ID" />
                    <el-table-column prop="playerId" width="120" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="180" align="center" label="时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="orderId" width="270" align="center" label="平台订单号" />
                    <el-table-column :show-overflow-tooltip="true" prop="refundType" width="120" align="center" label="退款账户">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(REFUND_ACCOUNT_TYPE, scope.row.refundType) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="productAmount" width="110" align="center" label="下单金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="orderState" width="100" align="center" label="平台状态">
                        <template slot-scope="scope">
                            <span :class="`recharge-order-state-` + scope.row.orderState">{{ getArrayValue(REFUND_ORDER_STATE, scope.row.orderState) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :show-overflow-tooltip="true" prop="createTime" align="left" label="操作">
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                                v-permission="[permission.appWithdrawOrderDetail]"
                            />

                            <el-button type="text" v-permission="[permission.appWithdrawObsoleteCallback]" @click="toCallback(scope.row.orderId)">恢复</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="drawer">
            <Detail :data-info="dataObj" v-if="drawer" />
        </Drawer>

        <el-dialog append-to-body :close-on-click-modal="false" :visible.sync="dialogVisible" :title="dialogTitle" width="560px">
            <ToRemark @onclose="dialogCancel" @submitRemark="submitRemark" v-if="dialogType == 'toReject'" />
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/refund'
import UserIdJump from '@/components/UserIdJump'

import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import Detail from '@/views/finance/refund/record/detail'
import ToRemark from '@/views/finance/refund/record/toRemark'
import { REFUND_ORDER_STATE, REFUND_ACCOUNT_TYPE } from '@/constant/finance'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'createTime;desc',
    createTime: [],
    recordId: '',
    playerId: '',
    orderId: '',
    channelOrderId: '',
    orderState: '',
    channelOrderState: ''
}

export default {
    name: 'Obsolete',
    components: {
        Drawer,
        Detail,
        pagination,
        DateRangePicker,
        UserIdJump,
        ToRemark
    },
    mixins: [Base],
    data() {
        return {
            REFUND_ORDER_STATE,
            REFUND_ACCOUNT_TYPE,
            loading: false,
            drawer: false,
            batchChangeStateIds: {
                pass: [],
                reject: [],
                fail: []
            },
            batchChangeStateBtn: true,
            dataObj: {},
            dialogVisible: false,
            dialogTitle: '',
            dialogType: '',
            list: [],
            query: {
                size: 10,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                recordId: '',
                playerId: '',
                orderId: '',
                channelOrderId: '',
                orderState: '',
                channelOrderState: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 330
        this.toQuery()
    },
    methods: {
        //需要输入备注再执行请求操作
        submitRemark(remark) {
            let params = {}
            switch (this.submitRemarkType) {
                case 'toCallback':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: remark
                    }
                    api.obsoleteCallback(params).then((rep) => {
                        this.$message.success('恢复订单操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
            }
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toDetail(row) {
            this.drawer = true
            this.dataObj = row
        },
        toCallback(id = '') {
            this.submitRemarkId = [id]

            this.submitRemarkType = 'toCallback'
            this.dialogTitle = '请输入恢复订单原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appWithdrawObsoleteList])) {
                this.loading = true
                api.obsoleteList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        dialogCancel() {
            this.dialogVisible = false
        }
    }
}
</script>
