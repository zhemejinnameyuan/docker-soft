<template>
    <div class="report-data-box-new">
        <div class="item-box" style="width: 1200px; height: 70px; margin-bottom: 10px">
            <div class="content" style="flex-direction: row">
                <div class="item">
                    <div class="top-title top-title-yellow" style="width: 100px">平台限额</div>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="平台每日限额=显示平台当日配置的限额数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title">平台每日限额</span>
                        <span class="item-number-max" style="font-size: 24px; width: 150px" v-autoFontSize="'max'">
                            {{ fenToYuan(dataObj.dayMaxAmount) | filterThousandths }}
                        </span>
                    </div>
                </div>
                <div class="ml-20 mr-20" style="width: 1px; height: 20px; margin-top: 25px; background-color: rgba(27, 162, 255, 0.3)"></div>
                <div class="item ml-30 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="当日已用额度=当日玩家退款订单累计-当日玩家(已驳回+失败+置失败)退款订单累计" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">当日已用额度</span>
                        <span class="item-number-max" style="width: 150px" v-autoFontSize="'finance-max'">{{ fenToYuan(dataObj.dayUse) | filterThousandths }}</span>
                    </div>
                </div>
                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="当日剩余额度=平台每日限额-当日已用额度，若当日已用额度>平台每日限额，当日剩余额度显示0" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">当日剩余额度</span>
                        <span class="item-number-max" style="width: 150px" v-autoFontSize="'finance-max'">{{ fenToYuan(dataObj.leftAmount) | filterThousandths }}</span>
                    </div>
                </div>

                <div class="item ml-20 mr-10" style="margin-top: 26px">
                    <span class="item-title" style="margin-left: 60px; margin-top: -10px">
                        <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData')
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>
