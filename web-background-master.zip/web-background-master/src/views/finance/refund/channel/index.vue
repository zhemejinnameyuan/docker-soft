<template>
    <div>
        <!--搜索栏-->
        <Report :data-obj="statData" @queryData="queryData" v-permission="[permission.appWithdrawWithdrawChannelStatistics]" />

        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-select v-model="query.channelState" placeholder="状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_CHANNEL_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.channelLabel" placeholder="通道类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in RECHARGE_CHANNEL_LABEL" :key="index" :value="index" :label="item" />
                </el-select>
                <el-input v-model="query.channelName" size="medium" clearable placeholder="通道名称" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.channelKey" size="medium" clearable placeholder="通道KEY" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>

            <el-row type="flex">
                <el-col :span="12">
                    <div style="float: left">
                        <IconButton
                            class="filter-item"
                            size="small"
                            type="primary"
                            title="批量关闭"
                            @click="batchChangeState()"
                            :disabled="batchChangeStateBtn"
                            v-permission="[permission.appRechargeBatchChangeChannelState]"
                            v-exclude-channel-user
                        />
                    </div>
                </el-col>
                <el-col :span="12" style="float: right">
                    <div style="float: right">
                        <IconButton
                            class="filter-item"
                            size="small"
                            type="primary"
                            icon="oms_ico_add"
                            title="创建通道"
                            @click="toAdd"
                            v-permission="[permission.appRechargeSaveChannel]"
                            v-exclude-channel-user
                        />
                    </div>
                </el-col>
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list" @selection-change="changeSelect">
                    <el-table-column type="selection" align="center" width="45" />
                    <el-table-column prop="id" width="60" align="center" label="通道ID" />
                    <el-table-column :show-overflow-tooltip="true" prop="channelName" width="180" align="center" label="通道名称" />
                    <el-table-column :show-overflow-tooltip="true" prop="channelKey" width="180" align="center" label="通道KEY" />
                    <el-table-column :show-overflow-tooltip="true" prop="channelLabel" width="110" align="center" label="通道类型">
                        <template slot-scope="scope">{{ getArrayValue(RECHARGE_CHANNEL_LABEL, scope.row.channelLabel) }}</template>
                    </el-table-column>
                    <el-table-column prop="createTime" width="155" align="center" label="更新时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="feeRate" width="100" align="center" label="通道费率">
                        <template slot="header">
                            <span>
                                通道费率
                                <el-tooltip class="item" effect="dark" content="通道费率=百分比+固定税值" placement="top">
                                    <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                </el-tooltip>
                            </span>
                        </template>
                        <template slot-scope="scope">
                            {{ scope.row.feeRate }}%
                            <span v-if="scope.row.fixedFee > 0">+ {{ scope.row.fixedFee }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="paymentMethod" width="90" align="center" label="退款方式">
                        <template slot-scope="scope">{{ scope.row.paymentMethod }}</template>
                    </el-table-column>
                    <el-table-column prop="title" width="140" align="center" label="最小/最大限额">
                        <template slot="header">
                            <span>
                                最小/最大限额
                                <el-tooltip class="item" effect="dark" content="可退款最小金额数/可退款最大金额数" placement="top">
                                    <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                </el-tooltip>
                            </span>
                        </template>
                        <template slot-scope="scope">
                            <span>{{ fenToYuan(scope.row.withdrawSingleMin) | filterThousandths }}/{{ fenToYuan(scope.row.withdrawSingleMax) | filterThousandths }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="withdrawUserDayMaximum" width="120" align="center" label="每日限次">
                        <template slot="header">
                            <span>
                                每日限次
                                <el-tooltip class="item" effect="dark" content="单个玩家每天支持的退款次数限制" placement="top">
                                    <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                </el-tooltip>
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="payDailyLimit" :show-overflow-tooltip="true" width="200" align="center" label="当日剩余/每日限额">
                        <template slot-scope="scope">
                            <span>
                                {{ fenToYuan(_.subtract(scope.row.withdrawDayAmountMax, scope.row.dayUse)) | filterThousandths }}/{{ fenToYuan(scope.row.withdrawDayAmountMax) | filterThousandths }}
                            </span>
                        </template>
                    </el-table-column>

                    <el-table-column width="90" align="center" label="状态">
                        <template slot-scope="scope">
                            <div class="table_state_switch">
                                <el-switch v-model="scope.row.channelState" @change="stateChange(scope.row)" :active-value="1" :inactive-value="2"></el-switch>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="140" align="center" fixed="right">
                        <template slot-scope="scope">
                            <IconButton class="filter-item" size="medium" type="text" style="font-size: 20px" icon="oms_ico_xiangqing" @click="toDetail(scope.row)" />
                            <IconButton
                                class="filter-item"
                                size="mini"
                                type="text"
                                style="font-size: 20px"
                                icon="oms_ico_edit"
                                @click="toEdit(scope.row)"
                                v-permission="[permission.appRechargeSaveChannel]"
                                v-exclude-channel-user
                            />
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer class="drawer" :title="drawerTitle" :visible.sync="drawer">
            <Edit v-if="drawerType == 'edit' && drawer" :data-info="dataObj" @onclose="closeDrawer" />
            <Detail v-if="drawerType == 'detail' && drawer" :data-info="dataObj" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/refund'
import * as rechargeApi from '@/api/finance/recharge'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import Edit from './edit.vue'
import Detail from './detail.vue'
import Report from './report.vue'
import { RECHARGE_CHANNEL_STATE, RECHARGE_CHANNEL_LABEL } from '@/constant/finance'
import { fenToYuan } from '@/utils'

const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'id;desc',
    createTime: [],
    channelState: '',
    channelName: '',
    channelKey: '',
    channelLabel: ''
}

export default {
    name: 'ChannelManage',
    components: {
        Edit,
        Detail,
        pagination,
        DateRangePicker,
        Drawer,
        Report
    },
    mixins: [Base],
    data() {
        return {
            RECHARGE_CHANNEL_STATE,
            RECHARGE_CHANNEL_LABEL,
            batchChangeStateBtn: true,
            loading: false,
            banVisible: false,
            detailVisible: false,
            drawerTitle: '',
            drawer: false,
            drawerType: false,
            list: [],
            dataObj: {},
            statData: {},
            query: {
                size: 10,
                page: 1,
                sort: 'id;desc',
                createTime: [],
                channelState: '',
                channelName: '',
                channelKey: '',
                channelLabel: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 465
        this.toQuery()
        this.queryData()
    },
    methods: {
        handleSupportAmount(type, amountList) {
            //先将金额转换
            const newAmountList = amountList.map((value) => _.toNumber(fenToYuan(value)))
            if (type == 1) {
                return newAmountList.join('~')
            } else if (type == 2) {
                return newAmountList.join('/')
            }
        },
        stateChange(data) {
            this.changeState([data.id], data.channelState)
        },
        toAdd() {
            this.drawerTitle = '创建通道'
            this.drawer = true
            //初始化
            this.dataObj = {
                channelLabel: 1,
                channelState: 1,
                withdrawSingleMin: '',
                withdrawSingleMax: '',
                withdrawUserDayMaximum: '',
                withdrawDayAmountMax: ''
            }
            this.drawerType = 'edit'
        },
        toEdit(row) {
            this.drawerTitle = '编辑通道'
            this.drawer = true
            this.drawerType = 'edit'
            this.dataObj = row
        },
        toDetail(row) {
            this.drawerTitle = '通道详情'
            this.drawer = true
            this.drawerType = 'detail'
            this.dataObj = row
        },
        changeState(ids, state) {
            const postParams = {
                channelIdList: ids,
                channelState: state
            }
            rechargeApi.batchChangeChannelState(postParams).then((rep) => {
                this.$message.success('操作成功')
                this.toQuery()
            })
        },
        //批量关闭
        batchChangeState() {
            this.changeState(this.ids, 2)
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.channelList(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        changeSelect(val) {
            this.ids = []
            val.forEach((e) => {
                //只允许关闭开启状态的
                if (e.channelState == 1) {
                    this.ids.push(e.id)
                }
            })
            if (this.ids.length > 0) {
                this.batchChangeStateBtn = false
            } else {
                this.batchChangeStateBtn = true
            }
        },
        closeDrawer() {
            this.drawer = false
            this.toQuery()
        },
        //数据统计
        queryData() {
            if (this.checkPermission([this.permission.appWithdrawWithdrawChannelStatistics])) {
                api.withdrawChannelStatistics()
                    .then((rep) => {
                        this.statData = rep.data
                        let leftAmount = this.statData.dayMaxAmount - this.statData.dayUse
                        this.statData.leftAmount = leftAmount <= 0 ? 0 : leftAmount
                        //处理汇总
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
