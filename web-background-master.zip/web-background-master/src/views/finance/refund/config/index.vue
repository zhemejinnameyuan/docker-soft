<template>
    <div>
        <!--搜索栏-->
        <div class="head-container common-drawer-table-detail no-scrollbar" style="width: 1550px; height: auto">
            <el-form ref="form" :model="dataObj" size="medium" label-width="150px" label-position="top">
                <el-form-item label="退款状态:" prop="switch" class="big-label">
                    <div class="inline-item table_state_switch">
                        <span class="small-label">开关:</span>
                        <el-switch v-model="dataObj.open" />
                    </div>
                </el-form-item>
                <div class="dp-f" style="flex-wrap: wrap">
                    <el-form-item label="平台充值金额配置(可配金额为当前开启通道支持金额并集):">
                        <el-table :data="dataObj.goodsList" class="common_form_table" style="width: 950px" :row-style="{ height: '53px', background: '#F7F7F7' }" :span-method="objectSpanMethod">
                            <el-table-column label="ID" width="100" align="center">
                                <template slot-scope="scope">
                                    {{ scope.row.id }}
                                </template>
                            </el-table-column>
                            <el-table-column label="手续费" width="160" align="center">
                                <template slot-scope="scope">
                                    <div class="mb-20">
                                        <span class="small-label">费率(%):</span>
                                        <InputNumber v-model="dataObj.serviceFeeRate" range-width="130px" :min-number="0" :max-number="100" :precision="2" placeholder="0-100" clearable />
                                    </div>

                                    <div class="mt-20">
                                        <span class="small-label">每笔固定费用:</span>
                                        <InputNumber v-model="dataObj.serviceFixedFee" range-width="130px" :min-number="0" :max-number="1000" placeholder="0-1000" clearable />
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column label="开关" width="160" align="center">
                                <template slot-scope="scope">
                                    <div class="table_state_switch">
                                        <el-switch v-model="dataObj.goodsList[scope.$index].open" @change="changeSwitch(scope.row.id)" />
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column label="可选金额" width="270" align="center">
                                <template slot-scope="scope">
                                    <div class="dp-c">
                                        <div class="dp-f" style="height: 10px">
                                            <div class="default-tag" v-show="dataObj.selected == scope.row.id">默认</div>
                                        </div>
                                        <div class="mt-5" v-if="scope.row.amount > 0">{{ fenToYuan(scope.row.amount) }}</div>
                                        <div class="mt-5" v-if="scope.row.amount == 0">未配置</div>
                                    </div>
                                </template>
                            </el-table-column>

                            <el-table-column label="操作" width="255" align="left">
                                <template slot-scope="scope">
                                    <div class="dp-f">
                                        <div class="ml-10">
                                            <el-button type="primary" size="small" @click="amountConfig(scope.$index)">配置金额</el-button>
                                        </div>
                                        <div class="ml-10">
                                            <el-button
                                                type="primary"
                                                size="small"
                                                plain
                                                :disabled="dataObj.selected == scope.row.id || scope.row.amount == 0 || scope.row.open == false"
                                                @click="setDefault(scope.row.id)"
                                            >
                                                默认选中
                                            </el-button>
                                        </div>
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-form-item>

                    <div class="ml-40">
                        <el-form-item label="风控配置:">
                            <div class="item_bg" style="width: 380px; height: 520px; padding: 20px 40px 20px 40px; margin-top: 0px">
                                <el-form-item label="账户关联设备个数" prop="rate">
                                    <InputNumber
                                        v-model="dataObj.related_num"
                                        :single-big-input="true"
                                        :min-number="1"
                                        :max-number="999"
                                        placeholder="请输入个数"
                                        show-word-limit
                                        style="width: 280px"
                                        clearable
                                    />

                                    <span class="fs-12 text_blue">退款账户ID关联的设备个数不能超过配置参数</span>
                                </el-form-item>
                                <el-form-item label="玩家每日次数不超过" prop="amount">
                                    <InputNumber
                                        v-model="dataObj.dailyUserMaximum"
                                        :single-big-input="true"
                                        :min-number="1"
                                        :max-number="999"
                                        placeholder="请输入次数"
                                        show-word-limit
                                        style="width: 280px"
                                        clearable
                                    />
                                </el-form-item>
                                <el-form-item label="玩家每日累计金额限制" prop="amount">
                                    <InputNumber
                                        v-model="handleAmount.dailyUserWithdrawMax"
                                        :single-big-input="true"
                                        :min-number="1"
                                        :max-number="9999999"
                                        placeholder="请输入金额"
                                        show-word-limit
                                        style="width: 280px"
                                        clearable
                                    />
                                </el-form-item>
                                <el-form-item label="平台每日累计金额限制" prop="amount">
                                    <InputNumber
                                        v-model="handleAmount.dailyPatWithdrawMax"
                                        :single-big-input="true"
                                        :min-number="1"
                                        :max-number="999999999"
                                        placeholder="请输入金额"
                                        show-word-limit
                                        style="width: 280px"
                                        clearable
                                    />
                                </el-form-item>
                            </div>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
            <div style="padding-left: 720px">
                <el-button size="medium" type="primary" @click="submit" v-permission="[permission.appWithdrawSaveConfig]" v-exclude-channel-user>保存</el-button>
            </div>

            <el-dialog append-to-body :close-on-click-modal="false" :visible.sync="configAmountDialog" title="请配置金额" width="600px">
                <ConfigAmount
                    v-if="configAmountDialog"
                    @onclose="dialogCancel"
                    @toChannel="toChannel"
                    @setConfig="setConfig"
                    :channelAmountConf="channelAmountConf"
                    :dataObj="dataObj"
                    :defaultAmount="defaultAmount"
                />
            </el-dialog>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import ConfigAmount from './configAmount'
import * as api from '@/api/finance/refund'
import { deepClone, fenToYuan, yuanToFen } from '@/utils'
export default {
    name: 'RefundConfig',
    components: {
        InputNumber,
        ConfigAmount
    },
    mixins: [Base],
    data() {
        return {
            dataObj: {
                serviceFee: '',
                selected: '',
                open: true,
                related_num: '',
                dailyUserMaximum: '',
                dailyUserWithdrawMax: '',
                dailyPatWithdrawMax: '',
                goodsList: []
            },
            configAmountDialog: false,
            configAmountIndex: '',
            channelAmountConf: {
                min: 0,
                max: 0
            },
            handleAmount: {
                dailyUserWithdrawMax: '',
                dailyPatWithdrawMax: ''
            },
            defaultAmount: 0
        }
    },
    computed: {},
    watch: {},
    mounted() {
        this.initData()
        this.getRefundChannel()
    },
    methods: {
        //开关切换事件，关闭的时候处理默认值
        changeSwitch(id) {
            //根据ID获取index
            let index = _.findIndex(this.dataObj.goodsList, function (o) {
                return o.id == id
            })
            if (this.dataObj.goodsList[index]['open'] == true) {
                return
            }

            if (this.dataObj.selected != id) {
                return
            }
            //取最小的金额，将其设置成为默认
            let minAmount = _.minBy(this.dataObj.goodsList, function (o) {
                if (o.open == true) {
                    return o.amount
                }
            })
            if (minAmount === undefined) {
                this.$message.error('请至少配置一个档位')
                this.dataObj.goodsList[index].open = true
                return
            }
            if (this.dataObj.selected == id) {
                this.dataObj.selected = minAmount.id
            }
        },
        initData() {
            api.queryConfig()
                .then((rep) => {
                    this.dataObj = rep.data
                    //金额缩小100
                    this.handleAmount.dailyUserWithdrawMax = _.toNumber(fenToYuan(this.dataObj.dailyUserWithdrawMax))
                    this.handleAmount.dailyPatWithdrawMax = _.toNumber(fenToYuan(this.dataObj.dailyPatWithdrawMax))
                })
                .catch(() => {})
        },
        amountConfig(index) {
            this.configAmountIndex = index
            this.defaultAmount = fenToYuan(this.dataObj.goodsList[index].amount)
            this.configAmountDialog = true
        },
        //默认选中
        setDefault(index) {
            this.dataObj.selected = index
        },

        toChannel() {
            this.$parent.changeTabActiveName('channel')
        },
        //样式
        objectSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 1) {
                if (rowIndex % 9 === 0) {
                    return {
                        rowspan: 9,
                        colspan: 1
                    }
                } else {
                    return {
                        rowspan: 0,
                        colspan: 0
                    }
                }
            }
        },
        dialogCancel() {
            this.configAmountDialog = false
        },
        submit() {
            this.submitObj = deepClone(this.dataObj)
            //校验渠道金额
            for (const i in this.submitObj.goodsList) {
                let tmpItem = this.submitObj.goodsList[i]
                if (tmpItem.open) {
                    if (tmpItem.amount < this.channelAmountConf.min || tmpItem.amount > this.channelAmountConf.max) {
                        return this.$message.error('排序' + (_.toNumber(i) + 1) + ':金额超出通道支持金额范围')
                    }
                }
            }
            //金额放大100
            this.submitObj.dailyUserWithdrawMax = yuanToFen(this.handleAmount.dailyUserWithdrawMax)
            this.submitObj.dailyPatWithdrawMax = yuanToFen(this.handleAmount.dailyPatWithdrawMax)
            api.saveConfig(this.submitObj)
                .then((rep) => {
                    this.$message.success('保存成功')
                    this.initData()
                })
                .catch(() => {})
        },
        //获取开启中的退款通道，并处理最小/最大金额
        getRefundChannel() {
            api.channelList({ channelState: 1, all: true }).then((rep) => {
                if (rep.data.length > 0) {
                    let tmpMinAmount = []
                    let tmpMaxAmount = []
                    for (let i in rep.data) {
                        tmpMinAmount.push(rep.data[i].withdrawSingleMin)
                        tmpMaxAmount.push(rep.data[i].withdrawSingleMax)
                    }

                    this.channelAmountConf = {
                        min: _.min(tmpMinAmount),
                        max: _.max(tmpMaxAmount)
                    }
                }
            })
        },
        //设置金额回调
        setConfig(amount) {
            for (let i in this.dataObj.goodsList) {
                if (this.dataObj.goodsList[i].amount == amount && i != this.configAmountIndex) {
                    return this.$message.error('该金额已被占用')
                }
            }

            this.dataObj.goodsList[this.configAmountIndex].amount = amount
            this.configAmountDialog = false
        }
    }
}
</script>
<style scoped lang="scss">
.default-tag {
    background: rgba(27, 162, 255, 0.1);
    border-radius: 2px;
    min-width: 36px;
    height: 18px;
    font-size: 10px;
    margin-top: -5px;
    color: #1ba2ff;
}

::v-deep .el-table--small .el-table__cell {
    padding: 0;
}
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
</style>
