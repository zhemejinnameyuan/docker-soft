<template>
    <div>
        <div class="inner_item" style="padding-left: 20px" v-if="configStatus == 1">
            <el-form label-width="150px" label-position="left">
                <el-form-item label="配置金额:">
                    <InputNumber v-model="amount" :min-number="minAmount" :max-number="maxAmount" placeholder="请输入金额" show-word-limit style="width: 280px" clearable />
                    <div style="color: #f78114" class="fs-12">金额支持范围 {{ getRangeAmountTips() }} 之间正整数</div>
                </el-form-item>
            </el-form>
            <div class="footer-add mt-20">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">保存</el-button>
            </div>
        </div>

        <div class="inner_item" style="padding-left: 20px" v-if="configStatus != 1">
            <span class="notice">当前无可用通道，无法配置金额，请去【通道管理】中配置并开启通道。</span>
            <div class="footer-add mt-20">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="toChannel()">前往</el-button>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { fenToYuan, yuanToFen } from '@/utils'
export default {
    components: { InputNumber },
    props: {
        channelAmountConf: {
            type: Object,
            default: {}
        },
        dataObj: {
            type: Object,
            default: {}
        },
        defaultAmount: {
            type: String,
            default: 0
        }
    },
    data() {
        return {
            amount: '',
            minAmount: 0,
            maxAmount: 0,
            configStatus: 0
        }
    },
    mixins: [Base],
    mounted() {},
    created() {
        if (this.channelAmountConf.min > 0 && this.channelAmountConf.max > 0) {
            this.configStatus = 1
        } else {
            this.configStatus = 0
        }
        if (this.defaultAmount) {
            this.amount = this.defaultAmount
        }
    },
    methods: {
        //金额支持范围tips
        getRangeAmountTips() {
            this.minAmount = _.toNumber(fenToYuan(this.channelAmountConf.min))
            this.maxAmount = _.toNumber(fenToYuan(this.channelAmountConf.max))
            return this.minAmount + '~' + this.maxAmount
        },
        submit() {
            if (this.amount == '') {
                return this.$message.error('请输入配置金额')
            }
            //校验金额是否在正常范围
            let amount = yuanToFen(this.amount)
            if (amount < this.channelAmountConf.min || amount > this.channelAmountConf.max) {
                return this.$message.error('金额超出通道支持金额范围')
            }
            this.$emit('setConfig', amount)
        },
        dialogCancel() {
            this.$emit('onclose')
        },
        toChannel() {
            this.$emit('toChannel')
        }
    }
}
</script>

<style lang="scss" scoped>
.inner_item {
    display: flex;
    flex-direction: column;
    .footer-add {
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
    }
}

.notice {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #282829;
    letter-spacing: 0;
    line-height: 28px;
    font-weight: 400;
}
::v-deep .el-tag {
    border-radius: 15px;
}
::v-deep .el-tag.el-tag--danger {
    background: #f0f2f7;
    border-color: #f0f2f7;
    color: #a1a4a7;
}

::v-deep .el-tag.el-tag--info {
    background: none;
    border: 1px solid rgba(220, 223, 230, 1);
    color: #282829;
}
</style>
