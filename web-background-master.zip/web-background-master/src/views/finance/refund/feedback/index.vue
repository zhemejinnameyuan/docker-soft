<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="退款订单号" style="width: 240px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.orderState" placeholder="订单状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in REFUND_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.feedbackFlag" placeholder="处理状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in REFUND_FEEDBACK_FLAG" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :row-style="{ height: '60px' }" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="playerId" width="180" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="createTime" width="180" align="center" label="时间" />
                    <el-table-column prop="orderId" width="270" align="center" label="退款订单号">
                        <template slot-scope="scope">
                            <a class="text_blue" @click="toDetail(scope.row)">{{ scope.row.orderId }}</a>
                        </template>
                    </el-table-column>
                    <el-table-column prop="productAmount" width="150" align="center" label="退款金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column prop="orderState" width="180" align="center" label="订单状态">
                        <template slot-scope="scope">
                            <span :class="`recharge-order-state-` + scope.row.orderState">{{ getArrayValue(REFUND_ORDER_STATE, scope.row.orderState) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="adminCredential" align="center" width="160" label="反馈截图">
                        <template slot-scope="scope">
                            <el-image style="width: 40px; height: 50px; margin-top: 5px" :src="domain + scope.row.feedbackImg" :preview-src-list="[domain + scope.row.feedbackImg]">
                                <div slot="error" class="image-slot"></div>
                            </el-image>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="feedbackFlag" width="160" align="center" label="处理状态">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(REFUND_FEEDBACK_FLAG, scope.row.feedbackFlag) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" align="left" label="操作">
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                v-permission="[permission.appRechargeOrderDetail]"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                            />
                            <el-button
                                type="text"
                                v-show="scope.row.channelOrderState === 0 && scope.row.orderState === 6"
                                v-permission="[permission.appWithdrawRequestAgain]"
                                @click="toTryAgain('single', scope.row.orderId)"
                            >
                                重新请求
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
        <Drawer :visible.sync="orderInfoDrawer" title="订单详情">
            <Detail :data-info="dataObj" v-if="orderInfoDrawer" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/refund'
import UserIdJump from '@/components/UserIdJump'
import Drawer from '@/components/Drawer'
import ToRemark from '@/views/finance/refund/record/toRemark'
import Detail from '@/views/finance/refund/record/detail.vue'

import Base from '@/views/base'
import { REFUND_FEEDBACK_FLAG, REFUND_ORDER_STATE } from '@/constant/finance'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'id;desc',
    createTime: [],
    playerId: '',
    orderId: '',
    orderState: '',
    feedbackFlag: ''
}

export default {
    name: 'Feedback',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump,
        Drawer,
        ToRemark,
        Detail
    },
    mixins: [Base],
    data() {
        return {
            REFUND_ORDER_STATE,
            REFUND_FEEDBACK_FLAG,
            loading: false,
            dataObj: {},
            dialogVisible: false,
            dialogTitle: '',
            dialogType: '',
            list: [],
            domain: '',
            orderInfoDrawer: false,
            query: {
                size: 10,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                playerId: '',
                orderId: '',
                orderState: '',
                feedbackFlag: ''
            },
            total: 0,
            submitRemarkType: '',
            submitRemarkId: []
        }
    },
    mounted() {
        this.fixed_height = 335
        this.toQuery()
    },
    methods: {
        toDetail(row) {
            this.orderInfoDrawer = true
            this.dataObj = row
        },

        toTryAgain(type, id = '') {
            let params = {}
            if (type == 'single') {
                params = {
                    orderIdList: [id],
                    remark: this.getUserInfo().username + '[后台重新请求]'
                }
            } else if (type == 'batch') {
                params = {
                    orderIdList: this.batchChangeStateIds.tryAgain,
                    remark: this.getUserInfo().username + '[后台重新请求]'
                }
            }
            confirmRequest('重新向通道发起退款请求，通道会重新执行退款逻辑并返回新的退款状态…？', () => {
                api.requestAgain(params).then((rep) => {
                    this.$message.success('操作成功')
                    this.toQuery()
                })
            })
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appWithdrawFeedbackList])) {
                this.loading = true
                api.feedbackList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.domain = rep.domain.file
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        dialogCancel() {
            this.dialogVisible = false
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
::v-deep .el-table tbody .el-table__cell {
    padding-top: 0px;
    padding-bottom: 0px;
}
</style>
