<template>
    <div class="app-container finance">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane v-for="(item, index) in tabList" :key="index" :label="item.title" :name="item.type"></el-tab-pane>
        </el-tabs>

        <Record v-if="activeName === 'record'" />
        <Channel v-if="activeName === 'channel'" />
        <Config v-if="activeName === 'config'" />
        <Tips v-if="activeName === 'tips'" />
        <Feedback v-if="activeName === 'feedback'" />
        <Exception v-if="activeName === 'exception'" />
        <Obsolete v-if="activeName === 'obsolete'" />
    </div>
</template>

<script>
import Base from '@/views/base'
import Channel from './channel/index'
import Record from './record/index'
import Config from './config/index'
import Tips from './tips/index'
import Feedback from './feedback/index'
import Exception from './exception/index'
import Obsolete from './obsolete/index'

export default {
    name: 'Refund',
    components: {
        Channel,
        Record,
        Config,
        Tips,
        Feedback,
        Exception,
        Obsolete
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'record',
            config: [],
            tabList: []
        }
    },
    computed: {},
    mounted() {
        this.config = [
            {
                type: 'record',
                title: '退款明细',
                permissions: [this.permission.appWithdrawOrderList],
                excludeChannelUser: false
            },
            {
                type: 'channel',
                title: '通道管理',
                permissions: [this.permission.appWithdrawChannelList],
                excludeChannelUser: true
            },
            {
                type: 'config',
                title: '退款配置',
                permissions: [this.permission.appWithdrawQueryConfig],
                excludeChannelUser: true
            },
            {
                type: 'tips',
                title: '小贴士',
                permissions: [this.permission.appWithdrawQueryTipsConfig],
                excludeChannelUser: true
            },
            {
                type: 'feedback',
                title: '意见反馈',
                permissions: [this.permission.appWithdrawFeedbackList],
                excludeChannelUser: false
            },
            {
                type: 'exception',
                title: '异常订单',
                permissions: [this.permission.appWithdrawExceptionList],
                excludeChannelUser: false
            },
            {
                type: 'obsolete',
                title: '废弃订单',
                permissions: [this.permission.appWithdrawObsoleteList],
                excludeChannelUser: false
            }
        ]
        for (let index = 0; index < this.config.length; index++) {
            const element = this.config[index]
            if (this.checkPermission(element.permissions)) {
                //渠道用户逻辑处理
                if (element.excludeChannelUser && this.isChannelUser()) {
                    continue
                }
                this.tabList.push(element)
            }
        }
        if (this.tabList) {
            this.activeName = this.tabList[0].type
        }
    },
    methods: {
        changeTabActiveName(activeName) {
            this.activeName = activeName
        }
    }
}
</script>
