<template>
    <div class="inner_item ml-20">
        <div class="dp-c">
            <span class="text_gray mb-5">原因:</span>
            <span class="ml-20">{{ dataInfo.rejectContent }}</span>
        </div>
        <div class="footer-add mt-20">
            <el-button type="primary" @click="dialogCancel">关闭</el-button>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'

export default {
    components: {},
    props: {
        dataInfo: {
            type: Object,
            default() {
                return {}
            }
        }
    },
    data() {
        return {
            remark: ''
        }
    },
    mixins: [Base],
    mounted() {},
    methods: {
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>

<style lang="scss" scoped>
.inner_item {
    display: flex;
    flex-direction: column;
    .footer-add {
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
    }
}
</style>
