<template>
    <div class="common-drawer-table-detail no-scrollbar" style="width: 1220px">
        <div :class="getOrderStateClass(orderInfo.orderState)" style="margin-bottom: 10px">订单状态: {{ getArrayValue(REFUND_ORDER_STATE, orderInfo.orderState) }}</div>
        <div class="dp-f">
            <div style="width: 720px">
                <div class="item_title">玩家信息</div>
                <div class="item_bg">
                    <el-form label-width="140px" :inline="true" label-position="left">
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="玩家ID:">
                                    <span class="des_title">{{ orderInfo.playerId }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="玩家昵称:">
                                    <span class="des_title">{{ orderInfo.nickname }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="玩家渠道ID:">
                                    <span class="des_title">{{ orderInfo.channelId }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="玩家渠道名称:">
                                    <span class="des_title">{{ orderInfo.channelName }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="玩家渠道包ID:">
                                    <span class="des_title">{{ orderInfo.channelPackageId }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_left">
                                <el-form-item label="玩家渠道包名称:">
                                    <span class="des_title">{{ orderInfo.channelPackageName }}</span>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>

                <div class="item_title">订单信息</div>
                <div class="item_bg">
                    <el-form label-width="140px">
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="记录ID:">
                                    <span class="des_title">{{ orderInfo.recordId }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="平台订单号:">
                                    <span class="des_title">{{ orderInfo.orderId }}</span>
                                </el-form-item>
                            </div>
                        </div>

                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="下单时间:">
                                    <span class="des_title">{{ orderInfo.createTime }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="下单金额:">
                                    <span class="des_title">{{ fenToYuan(orderInfo.productAmount) | filterThousandths }}</span>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>

                <div class="item_title">到账信息</div>
                <div class="item_bg">
                    <el-form label-width="140px">
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="手续费率:">
                                    {{ orderInfo.serviceFeeRate }}%
                                    <span v-if="orderInfo.serviceFixedFee > 0">+ {{ orderInfo.serviceFixedFee }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="手续费:">
                                    <span class="des_title">{{ fenToYuan(orderInfo.serviceFee) | filterThousandths }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="提交金额:">
                                    <span class="des_title">{{ fenToYuan(orderInfo.productAmount) | filterThousandths }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="到账金额:">
                                    <span class="des_title">{{ fenToYuan(orderInfo.actualAmount) | filterThousandths }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="操作终端:">
                                    <span class="des_title">{{ orderInfo.terminal }}</span>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>

                <div class="item_title">收款人信息</div>
                <div class="item_bg">
                    <el-form label-width="140px">
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="收款账号:">
                                    <span class="des_title" style="word-wrap: break-word">{{ orderInfo.accountNumber }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="姓名:">
                                    <span class="des_title" style="word-wrap: break-word">{{ orderInfo.payerName }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="IFSC Code:">
                                    <span class="des_title">{{ orderInfo.ifscCode }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="邮箱:">
                                    <span class="des_title" style="word-wrap: break-word">{{ orderInfo.payerEmail }}</span>
                                </el-form-item>
                            </div>
                        </div>

                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="手机:">
                                    <span class="des_title">{{ orderInfo.payerPhone }}</span>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>

                <div class="item_title">通道信息</div>
                <div class="item_bg">
                    <el-form label-width="140px">
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="通道订单号:">
                                    <span class="des_title">{{ orderInfo.channelOrderId }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="通道ID:">
                                    <span class="des_title">{{ orderInfo.payChannelId }}</span>
                                </el-form-item>
                            </div>
                        </div>
                        <div class="item_rows">
                            <div class="item_rows_left">
                                <el-form-item label="通道名称:">
                                    <span class="des_title">{{ orderInfo.payChannelName }}</span>
                                </el-form-item>
                            </div>
                            <div class="item_rows_right">
                                <el-form-item label="通道费:">
                                    <span class="des_title">{{ fenToYuan(orderInfo.channelFee) | filterThousandths }}</span>
                                    <span class="des_title">
                                        (费率{{ orderInfo.channelFeeRate }}%
                                        <span v-if="orderInfo.channelFixedFee > 0">+ {{ orderInfo.channelFixedFee }}</span>
                                        )
                                    </span>
                                </el-form-item>
                            </div>
                        </div>
                    </el-form>
                </div>
            </div>
            <div class="ml-20">
                <div class="item_title">订单状态变更明细</div>
                <div class="item_bg" style="width: 400px">
                    <el-timeline>
                        <el-timeline-item v-for="(item, index) in orderInfo.changeList" :key="index" :timestamp="getTimeLineTitle(item)" placement="top" :color="index == 0 ? '#0FC933' : ''">
                            <div class="timeline-item dp-c">
                                <span>{{ item.remark }}</span>
                            </div>
                        </el-timeline-item>
                    </el-timeline>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Card from '@/components/Card'
import Base from '@/views/base'
import * as api from '@/api/finance/refund'
import { REFUND_ORDER_STATE } from '@/constant/finance'
import { getArrayValue } from '@/utils'

export default {
    components: {
        Card
    },
    mixins: [Base],
    props: {
        dataInfo: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            REFUND_ORDER_STATE,
            orderInfo: {}
        }
    },
    computed: {},
    created() {
        this.getOrderInfo()
    },
    methods: {
        getTimeLineTitle(item) {
            let title = getArrayValue(REFUND_ORDER_STATE, item.orderState)
            title += ' ' + item.createTime
            return title
        },
        getOrderInfo() {
            api.orderDetail({ orderId: this.dataInfo.orderId, playerId: this.dataInfo.playerId }).then((rep) => {
                this.orderInfo = rep.data
            })
        },
        getOrderStateClass(state) {
            let className = 'order-state-title'

            if (state == 1) {
                className += ' order-state-success'
            } else if (state == 2 || state == 3 || state == 4) {
                className += ' order-state-error'
            } else {
                className += ' order-state-default'
            }
            return className
        }
    }
}
</script>

<style lang="scss" scoped>
.common-drawer-table-detail {
    .item_rows {
        width: 100%;
        display: flex;

        &_left {
            width: 50%;
        }

        &_right {
            width: 50%;
        }
    }
}

::v-deep .el-timeline-item__tail {
    position: absolute;
    left: 4px;
    height: 100%;
    border-left: 2px dashed #e4e7ed;
}

::v-deep .el-timeline-item:first-child .is-top {
    color: #1ba2ff;
}

::v-deep .el-timeline-item__timestamp {
    font-family: PingFangSC-Regular;
    font-size: 16px;
    letter-spacing: 0;
    line-height: 16px;
    font-weight: 400;
}

::v-deep .el-timeline-item__content {
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #686b6d;
    letter-spacing: 0;
    font-weight: 400;
}

.timeline-item {
    min-height: 75px;
}
</style>
