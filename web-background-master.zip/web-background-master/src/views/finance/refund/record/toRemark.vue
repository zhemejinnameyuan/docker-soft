<template>
    <div class="inner_item">
        <el-form ref="form" label-width="120px">
            <el-input type="textarea" rows="8" placeholder="" v-model="remark" class="text_area" maxlength="500" show-word-limit></el-input>
        </el-form>
        <div class="footer-add mt-20">
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
            <el-button type="primary" @click="submit">确认</el-button>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    components: {},
    data() {
        return {
            remark: ''
        }
    },
    mixins: [Base],
    mounted() {},
    methods: {
        submit() {
            this.$emit('submitRemark', this.remark)
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>

<style lang="scss" scoped>
.inner_item {
    display: flex;
    flex-direction: column;
    .footer-add {
        display: flex;
        flex-direction: row;
        justify-content: flex-end;
    }
}
</style>
