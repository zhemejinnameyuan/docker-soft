<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.recordId" size="medium" clearable placeholder="记录ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="平台订单号" style="width: 240px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>

            <el-row type="flex">
                <el-col :span="12">
                    <IconButton
                        class="filter-item"
                        size="small"
                        type="primary"
                        plain
                        title="批量通过"
                        @click="toSuccess('batch')"
                        :disabled="batchChangeStateIds.pass.length == 0"
                        v-permission="[permission.appWithdrawBatchPass]"
                    />
                    <IconButton
                        class="filter-item"
                        size="small"
                        type="danger"
                        plain
                        title="批量驳回"
                        @click="toReject('batch')"
                        :disabled="batchChangeStateIds.reject.length == 0"
                        v-permission="[permission.appWithdrawBatchReject]"
                    />
                    <IconButton
                        class="filter-item"
                        size="small"
                        type="warning"
                        plain
                        title="废弃订单"
                        @click="toObsolete('batch')"
                        :disabled="batchChangeStateIds.obsolete.length == 0"
                        v-permission="[permission.appWithdrawObsolete]"
                    />
                </el-col>
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table
                    ref="table"
                    v-loading="loading"
                    highlight-current-row
                    style="width: 100%"
                    :height="table_height"
                    :data="list"
                    :row-style="{ height: '60px' }"
                    @selection-change="changeSelect"
                >
                    <el-table-column type="selection" align="center" width="45" />
                    <el-table-column :show-overflow-tooltip="true" prop="recordId" width="120" align="center" label="记录ID" />
                    <el-table-column prop="playerId" width="120" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="180" align="center" label="时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="orderId" width="270" align="center" label="平台订单号" />
                    <el-table-column :show-overflow-tooltip="true" prop="refundType" width="120" align="center" label="退款账户">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(REFUND_ACCOUNT_TYPE, scope.row.refundType) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="productAmount" width="110" align="center" label="下单金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="orderState" width="100" align="center" label="平台状态">
                        <template slot-scope="scope">
                            <span :class="`recharge-order-state-` + scope.row.orderState">{{ getArrayValue(REFUND_ORDER_STATE, scope.row.orderState) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="exceptionContent" width="300" align="center" label="异常类型" />
                    <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="left" label="操作">
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                                v-permission="[permission.appWithdrawOrderDetail]"
                            />
                            <el-button
                                type="text"
                                v-show="scope.row.channelOrderState == 0 && scope.row.orderState == 0"
                                v-permission="[permission.appWithdrawBatchPass]"
                                @click="toSuccess('single', scope.row.orderId)"
                            >
                                通过
                            </el-button>
                            <el-button
                                type="text"
                                v-show="scope.row.channelOrderState == 0 && scope.row.orderState == 0"
                                v-permission="[permission.appWithdrawBatchReject]"
                                @click="toReject('single', scope.row.orderId)"
                            >
                                驳回
                            </el-button>
                            <el-button
                                type="text"
                                v-show="scope.row.channelOrderState == 0 && scope.row.orderState == 0"
                                v-permission="[permission.appWithdrawObsolete]"
                                @click="toObsolete('single', scope.row.orderId)"
                            >
                                废弃订单
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="drawer">
            <Detail :data-info="dataObj" v-if="drawer" />
        </Drawer>

        <el-dialog append-to-body :close-on-click-modal="false" :visible.sync="dialogVisible" :title="dialogTitle" width="560px">
            <ToRemark @onclose="dialogCancel" @submitRemark="submitRemark" v-if="dialogType == 'toReject'" />
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/refund'
import UserIdJump from '@/components/UserIdJump'

import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import ToRemark from '@/views/finance/refund/record/toRemark'
import Detail from '@/views/finance/refund/record/detail'
import { REFUND_ORDER_STATE, REFUND_ACCOUNT_TYPE } from '@/constant/finance'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'createTime;desc',
    createTime: [],
    recordId: '',
    playerId: '',
    orderId: '',
    channelOrderId: '',
    orderState: '',
    channelOrderState: ''
}

export default {
    name: 'Exception',
    components: {
        Drawer,
        Detail,
        pagination,
        DateRangePicker,
        UserIdJump,
        ToRemark
    },
    mixins: [Base],
    data() {
        return {
            REFUND_ORDER_STATE,
            REFUND_ACCOUNT_TYPE,
            loading: false,
            drawer: false,
            batchChangeStateIds: {
                pass: [],
                reject: [],
                obsolete: []
            },
            batchChangeStateBtn: true,
            dataObj: {},
            dialogVisible: false,
            dialogTitle: '',
            dialogType: '',
            list: [],
            query: {
                size: 10,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                recordId: '',
                playerId: '',
                orderId: '',
                channelOrderId: '',
                orderState: '',
                channelOrderState: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 330
        this.toQuery()
    },
    methods: {
        //需要输入备注再执行请求操作
        submitRemark(remark) {
            let params = {}
            switch (this.submitRemarkType) {
                case 'toObsolete':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: remark
                    }
                    api.obsolete(params).then((rep) => {
                        this.$message.success('加入废弃操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
                case 'toReject':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: remark
                    }
                    api.batchReject(params).then((rep) => {
                        this.$message.success('驳回操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
            }
        },
        toSuccess(type, id = '') {
            let params = {}
            if (type == 'single') {
                params = {
                    orderIdList: [id],
                    remark: '后台通过'
                }
            } else if (type == 'batch') {
                params = {
                    orderIdList: this.batchChangeStateIds.pass,
                    remark: '后台通过'
                }
            }
            confirmRequest('确定要通过吗?', () => {
                api.batchPass(params).then((rep) => {
                    this.$message.success('操作成功')
                    this.toQuery()
                })
            })
        },
        toReject(type, id = '') {
            this.submitRemarkType = 'toReject'
            if (type == 'single') {
                this.submitRemarkId = [id]
            } else if (type == 'batch') {
                this.submitRemarkId = this.batchChangeStateIds.reject
            } else {
                this.submitRemarkId = []
            }

            this.dialogTitle = '请输入驳回原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        toObsolete(type, id = '') {
            if (type == 'single') {
                this.submitRemarkId = [id]
            } else if (type == 'batch') {
                this.submitRemarkId = this.batchChangeStateIds.obsolete
            } else {
                this.submitRemarkId = []
            }

            this.submitRemarkType = 'toObsolete'
            this.dialogTitle = '请输入加入废弃原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toDetail(row) {
            this.drawer = true
            this.dataObj = row
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appWithdrawExceptionList])) {
                this.loading = true
                api.exceptionList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        changeSelect(val) {
            //初始化
            this.batchChangeStateIds = {
                pass: [],
                reject: [],
                obsolete: []
            }
            val.forEach((e) => {
                this.batchChangeStateIds.pass.push(e.orderId)
                this.batchChangeStateIds.reject.push(e.orderId)
                this.batchChangeStateIds.obsolete.push(e.orderId)
            })
        },
        dialogCancel() {
            this.dialogVisible = false
        }
    }
}
</script>
