<template>
    <div class="app-container finance">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane label="D账户明细" name="accountD"></el-tab-pane>
            <el-tab-pane label="W账户明细" name="accountW"></el-tab-pane>
            <el-tab-pane label="B账户明细" name="accountB"></el-tab-pane>
            <el-tab-pane label="推广账户明细" name="accountPromotion"></el-tab-pane>
        </el-tabs>

        <AccountD v-if="activeName == 'accountD'" />
        <AccountW v-if="activeName == 'accountW'" />
        <AccountB v-if="activeName == 'accountB'" />
        <AccountPromotion v-if="activeName == 'accountPromotion'" />
    </div>
</template>

<script>
import Base from '@/views/base'
import AccountB from './accountB.vue'
import AccountD from './accountD.vue'
import AccountW from './accountW.vue'
import AccountPromotion from './accountPromotion.vue'

export default {
    name: 'Recharge',
    components: {
        AccountPromotion,
        AccountB,
        AccountD,
        AccountW
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'accountD'
        }
    },
    computed: {},
    mounted() {},
    methods: {}
}
</script>
