<template>
    <div>
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" style="width: 250px" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.id" size="medium" clearable placeholder="资金流水" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select
                    v-model="query.baccountType"
                    placeholder="账户类型"
                    size="medium"
                    class="filter-item"
                    style="width: 140px"
                    clearable
                    @clear="baccountTypeChange"
                    @change="baccountTypeChange"
                >
                    <el-option v-for="(item, index) in ACCOUNT_B_TYPE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select
                    v-model="query.businessType"
                    placeholder="业务类型"
                    size="medium"
                    class="filter-item"
                    style="width: 140px"
                    clearable
                    @clear="businessTypeChange"
                    @change="businessTypeChange"
                >
                    <el-option value="1" label="游戏" v-if="query.baccountType != ''" />
                    <el-option value="2" label="充值" v-if="query.baccountType == 1" />
                    <el-option value="6" label="活动" v-if="query.baccountType == 1" />
                    <el-option value="5" label="兑换" v-if="query.baccountType == 2" />
                </el-select>
                <el-select v-model="query.subType" placeholder="子类型" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in subTypeList" :key="index" :value="item.id" :label="item.title" />
                </el-select>
                <el-input v-model="query.businessId" size="medium" clearable placeholder="业务流水" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="playerId" width="120" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="170" align="center" label="时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="id" width="180" align="center" label="资金流水" />
                    <el-table-column :show-overflow-tooltip="true" prop="todo" width="100" align="center" label="账户类型">
                        <template slot-scope="scope">
                            {{ getArrayValue(ACCOUNT_B_TYPE, scope.row.baccountType) }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="businessType" width="100" align="center" label="业务类型">
                        <template slot-scope="scope">
                            {{ getArrayValue(ACCOUNT_BUSINESS_TYPE, scope.row.businessType) }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="subType" width="200" align="center" label="子类型">
                        <template slot-scope="scope">
                            {{ getArrayValue(ACCOUNT_SUB_TYPE, scope.row.subType) }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="businessId" width="270" align="center" label="业务流水" />
                    <el-table-column :show-overflow-tooltip="true" prop="amount" width="140" align="center" label="结算金额(扣税)">
                        <template slot-scope="scope">
                            {{ fenToYuan(scope.row.amount) | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="afterAmount" width="140" align="center" label="结算后余额">
                        <template slot-scope="scope">
                            {{ fenToYuan(scope.row.afterAmount) | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="500" prop="title" align="left" label="摘要">
                        <template slot-scope="scope">
                            <div v-html="getAccountSummary(scope.row)"></div>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50, 100]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/finance'
import Base from '@/views/base'
import UserIdJump from '@/components/UserIdJump'
import { ACCOUNT_RECORD_TYPE, ACCOUNT_BUSINESS_TYPE, ACCOUNT_SUB_TYPE_LIST, ACCOUNT_SUB_TYPE, ACCOUNT_B_TYPE } from '@/constant/finance'

const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'id;desc',
    playerId: '',
    businessId: '',
    businessType: '',
    id: '',
    accountType: '',
    baccountType: '',
    createTime: []
}

export default {
    name: 'AccountD',
    components: {
        UserIdJump,
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            ACCOUNT_RECORD_TYPE,
            ACCOUNT_BUSINESS_TYPE,
            ACCOUNT_SUB_TYPE,
            ACCOUNT_B_TYPE,
            loading: false,
            detailVisible: false,
            dataObj: {},
            list: [],
            subTypeList: [],
            query: {
                size: 20,
                page: 1,
                sort: 'id;desc',
                playerId: '',
                businessId: '',
                businessType: '',
                id: '',
                accountType: '',
                baccountType: '',
                createTime: []
            },
            total: 0,
            //排除非该配置项ID的类型
            showSubTypeList: [102, 103, 201, 204, 500, 600, 601, 602]
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 335
        this.query.createTime.push(this.$moment().subtract(30, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        baccountTypeChange() {
            this.query.businessType = ''
            this.query.subType = ''
            if (this.query.baccountType == 1) {
                //B账户类型
                this.showSubTypeList = [102, 201, 204, 600, 601, 602]
            } else if (this.query.baccountType == 2) {
                //可兑换账户
                this.showSubTypeList = [103, 500]
            }
            this.subTypeList = []
            this.toQuery()
        },
        //处理业务类型
        businessTypeChange() {
            this.subTypeList = []
            this.query.subType = ''
            const subTypeList = ACCOUNT_SUB_TYPE_LIST[this.query.businessType]
            for (let index in subTypeList) {
                if (this.showSubTypeList.indexOf(_.toNumber(index)) != -1) {
                    this.subTypeList.push({ id: index, title: subTypeList[index] })
                }
            }
            this.toQuery()
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            this.query.accountType = ACCOUNT_RECORD_TYPE.B
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.financeAccountDetailList])) {
                this.loading = true
                api.financeAccountDetailList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
