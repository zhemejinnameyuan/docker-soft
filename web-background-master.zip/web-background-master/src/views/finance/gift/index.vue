<template>
    <div class="app-container finance">
        <Report :data-obj="statData" @queryData="queryData" v-permission="[permission.financeGiftStats]" />
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="礼物订单" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.flowId" size="medium" clearable placeholder="牌局流水" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.roomType" placeholder="游戏名称" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in ACCOUNT_GAME_ROOM_TYPE" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="playerId" width="150" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="time" width="180" align="center" label="时间" />
                    <el-table-column prop="orderId" width="300" align="center" label="礼物订单" />
                    <el-table-column prop="flowId" width="180" align="center" label="牌局流水" />
                    <el-table-column prop="roomType" width="180" align="center" label="游戏名称">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(ACCOUNT_GAME_ROOM_TYPE, scope.row.roomType) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="amount" width="180" align="center" label="礼物金额">
                        <template slot-scope="scope">
                            {{ fenToYuan(scope.row.amount) | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="title" align="left" label="摘要">
                        <template slot-scope="scope">
                            <span v-html="scope.row.remark"></span>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import UserIdJump from '@/components/UserIdJump'
import * as api from '@/api/finance/finance'
import Report from './report.vue'
import { ACCOUNT_GAME_ROOM_TYPE } from '@/constant/finance'

import Base from '@/views/base'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'time;desc',
    roomType: '',
    flowId: '',
    orderId: '',
    time: []
}

export default {
    name: 'Gift',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump,
        Report
    },
    mixins: [Base],
    data() {
        return {
            ACCOUNT_GAME_ROOM_TYPE,
            loading: false,
            statData: {},
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                roomType: '',
                flowId: '',
                orderId: '',
                time: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 385
        this.query.time.push(this.$moment().subtract(30, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.time.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
        this.queryData(true)
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.financeGiftIncomeLog])) {
                this.loading = true
                api.financeGiftList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        //数据统计
        queryData(isCache = true) {
            if (this.checkPermission([this.permission.financeGiftStats])) {
                api.financeGiftStats({ isCache: isCache })
                    .then((rep) => {
                        this.statData = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
