<template>
    <div class="report-data-box-new">
        <div class="item-box" style="width: 1200px; height: 70px; margin-bottom: 30px">
            <div class="content" style="flex-direction: row">
                <div class="item">
                    <div class="top-title top-title-green" style="width: 70px">礼物</div>
                </div>
                <div class="item ml-40 mr-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips" effect="dark" content="累计礼物收益=非训练房玩家赠送礼物累计金额(训练房礼物都是免费，不计算在内)" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title">累计礼物收益</span>
                        <span class="item-number-max" style="font-size: 24px; width: 180px" v-autoFontSize="'max'">{{ fenToYuan(dataObj.allGiftIncome) | filterThousandths }}</span>
                    </div>
                </div>
                <div class="ml-20 mr-20" style="width: 1px; height: 20px; margin-top: 25px; background-color: rgba(27, 162, 255, 0.3)"></div>
                <div class="item ml-10" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips-min" style="margin-top: 2px" effect="dark" content="礼物赠送玩家数=非训练房有过礼物赠送行为的玩家数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title" style="font-weight: 400">礼物赠送玩家数</span>
                        <span class="item-number-max" style="width: 150px" v-autoFontSize="'finance-max'">{{ dataObj.allGiftsUserNum | filterThousandths }}</span>
                    </div>
                </div>
                <div class="item ml-20" style="margin-top: 26px">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips-min" style="margin-top: 2px" effect="dark" content="礼物赠送总个数=非训练房礼物赠送总次数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title dp-f" style="font-weight: 400">礼物赠送总次数</span>
                        <span class="item-number-max" style="width: 150px" v-autoFontSize="'finance-max'">{{ dataObj.allGiftsNum | filterThousandths }}</span>
                    </div>
                </div>
                <div class="item" style="margin-left: 60px">
                    <div class="dp-f">
                        <span class="item-title">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData', false)
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>
