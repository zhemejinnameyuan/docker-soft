<template>
    <div class="app-container finance">
        <Report :data-obj="dataObj" />
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-select v-model="query.gameType" placeholder="收益类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option value="1" label="游戏税收" />
                    <el-option value="2" label="充值税收" />
                    <el-option value="3" label="退款税收" />
                </el-select>
                <el-input v-model="query.userId" size="medium" clearable placeholder="业务流水" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="180" align="center" label="时间" />
                    <el-table-column prop="id" align="center" label="收益类型" />
                    <el-table-column prop="id" align="center" label="业务流水" />
                    <el-table-column prop="id" align="center" label="结算金额" />
                    <el-table-column prop="id" align="center" label="抽税比例" />
                    <el-table-column prop="id" align="center" label="应抽税金额" />
                    <el-table-column width="200px" align="center">
                        <template slot="header">
                            <span>
                                实际抽税金额
                                <el-tooltip
                                    class="item"
                                    effect="dark"
                                    content="游戏实际抽税金额=账户拆分后扣除赢家收益后剩余的金额；充值/退款实际抽税金额=按比例计算后精确到小数点2位四舍五入后的金额"
                                    placement="top"
                                >
                                    <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                </el-tooltip>
                            </span>
                        </template>
                        <template slot-scope="scope">
                            <span>{{ scope.row.newTourist | filterThousandths }}/{{ scope.row.newRegister | filterThousandths }}</span>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'
import Report from './report.vue'

import Base from '@/views/base'
const defaultQuery = {
    size: 100,
    page: 1,
    sort: 'endTime;desc',
    userId: '',
    nickName: '',
    inviteCode: '',
    channelId: '',
    packageId: '',
    invitePeople: '',
    balance: '',
    totalIncome: '',
    time: []
}

export default {
    name: 'Tax',
    components: {
        pagination,
        DateRangePicker,
        Report
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            banVisible: false,
            detailVisible: false,
            dataObj: {},
            activeName: '',
            channelList: [],
            packageList: [],
            list: [],
            query: {
                size: 10,
                page: 1,
                sort: 'id;desc',
                createTime: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 330
        this.games = this.getGames()
        this.query.createTime.push(this.$moment().subtract(30, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.noticeList])) {
                this.loading = true
                api.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
