<template>
    <div class="report-data-box-new" style="margin-bottom: 30px">
        <div class="item-box" style="width: 600px; height: 180px">
            <div class="content">
                <div class="dp-f-space-between">
                    <div class="top-title top-title-green" style="width: 120px">税收收益</div>
                    <div class="mr-10">
                        <span class="item-title" style="margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                </div>

                <div class="dp-f ml-40 mt-20">
                    <div class="dp-f">
                        <el-tooltip class="icon-tips-max" effect="dark" content="累计税收收益=游戏累计抽税金额+充值累计手续费+退款累计手续费" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                        <span class="item-title">累计税收收益</span>
                    </div>
                    <span class="item-number-max">0</span>
                </div>
                <div class="split-line ml-30 mb-20" style="width: 540px; margin-top: 18px" />

                <div class="dp-f ml-40">
                    <div class="item">
                        <div class="dp-f">
                            <el-tooltip
                                class="icon-tips-min"
                                style="margin-top: 2px"
                                effect="dark"
                                content="游戏税收=游戏针对玩家的抽税行为，不同的游戏抽税比例及抽税方式不一致，这里统计的是整个平台的累计游戏抽税金额"
                                placement="right"
                            >
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-min" style="margin-top: 2px">游戏</span>
                            <span class="item-number-medium color-num-one" style="width: 110px" v-autoFontSize="'finance-medium'">0</span>
                        </div>
                        <span class="item-title-per mt-10">占比：0%</span>
                    </div>
                    <div class="item ml-20">
                        <div class="dp-f">
                            <el-tooltip
                                class="icon-tips-min"
                                style="margin-top: 2px"
                                effect="dark"
                                content="充值税收=玩家充值时平台扣除的手续费累计金额，平台不扣除手续费时充值税收为0"
                                placement="right"
                            >
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-min dp-f" style="margin-top: 2px">充值</span>
                            <span class="item-number-medium color-num-two" style="width: 110px" v-autoFontSize="'finance-medium'">0</span>
                        </div>
                        <span class="item-title-per mt-10">占比：0%</span>
                    </div>
                    <div class="item ml-20">
                        <div class="dp-f">
                            <el-tooltip
                                class="icon-tips-min"
                                style="margin-top: 2px"
                                effect="dark"
                                content="退款税收=玩家退款时平台扣除的手续费累计金额，平台不扣除手续费时退款税收为0"
                                placement="right"
                            >
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-min" style="margin-top: 2px">退款</span>
                            <span class="item-number-medium color-num-three" style="width: 110px" v-autoFontSize="'finance-medium'">0</span>
                        </div>
                        <span class="item-title-per mt-10">占比：0%</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="item-box ml-10" style="width: 600px; height: 180px">
            <div class="content">
                <div class="dp-f-space-between">
                    <div class="top-title top-title-yellow" style="width: 120px">抽税</div>
                    <div class="mr-10">
                        <span class="item-title" style="margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                </div>

                <div class="dp-f ml-40 mt-10">
                    <div class="dp-c">
                        <div class="dp-f">
                            <el-tooltip class="icon-tips-min" effect="dark" content="游戏总场次=平台所有游戏场次累计值" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">游戏总场次</span>
                            <span class="item-number-medium color-num-one">0</span>
                        </div>
                        <div class="split-line" style="width: 240px; margin: 14px 0 14px 0"></div>
                        <div class="dp-f">
                            <el-tooltip class="icon-tips-min" effect="dark" content="充值成功笔数=充值订单状态为成功的笔数，包含客服手动标记为成功的充值订单" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">充值成功笔数</span>
                            <span class="item-number-medium color-num-two">0</span>
                        </div>
                        <div class="split-line" style="width: 240px; margin: 14px 0 14px 0"></div>
                        <div class="dp-f">
                            <el-tooltip class="icon-tips" effect="dark" content="退款成功笔数=退款订单状态为成功的笔数，包含客服手动标记为成功的退款订单" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">退款成功笔数</span>
                            <span class="item-number-medium color-num-three">0</span>
                        </div>
                    </div>

                    <div class="dp-c ml-40">
                        <div class="dp-f">
                            <el-tooltip class="icon-tips-min" effect="dark" content="抽税场次=抽税金额>0的游戏场次累计值" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">抽税场次</span>
                            <span class="item-number-medium color-num-one">0</span>
                        </div>
                        <div class="split-line" style="width: 240px; margin: 14px 0 14px 0"></div>
                        <div class="dp-f">
                            <el-tooltip class="icon-tips-min" effect="dark" content="抽税笔数=手续费>0的充值成功订单笔数" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">抽税笔数</span>
                            <span class="item-number-medium color-num-two">0</span>
                        </div>

                        <div class="split-line" style="width: 240px; margin: 14px 0 14px 0"></div>
                        <div class="dp-f">
                            <el-tooltip class="icon-tips-min" effect="dark" content="抽税笔数=手续费>0的退款成功订单笔数" placement="right">
                                <svg-icon icon-class="oms_ico_query" />
                            </el-tooltip>
                            <span class="item-title-medium">抽税笔数</span>
                            <span class="item-number-medium color-num-three">0</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        }
    }
}
</script>
