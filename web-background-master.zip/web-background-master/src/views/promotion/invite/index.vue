<template>
    <div class="app-container">
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <label class="label_title">分享时间</label>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.code" size="medium" clearable placeholder="请输入邀请码" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="playerId" width="200" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="code" width="200" align="center" label="邀请码" />
                    <el-table-column :show-overflow-tooltip="true" prop="time" width="200" align="center" label="分享时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="way" width="200" align="center" label="分享方式">
                        <template slot-scope="scope">
                            {{ getArrayValue(PROMOTION_SHARE_TYPE, scope.row.way) }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="incomeStr" width="200" align="center" label="奖励">
                        <template slot-scope="scope">
                            {{ scope.row.incomeStr | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="200" prop="state" align="center" label="状态" />
                    <el-table-column :show-overflow-tooltip="true" align="left" label="摘要">
                        <template slot-scope="scope">
                            <div v-html="getSummary(scope.row)"></div>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import { PROMOTION_SHARE_TYPE } from '@/constant/promotion'
import * as api from '@/api/promotion'

import Base from '@/views/base'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'time;desc',
    playerId: '',
    code: '',
    time: []
}

export default {
    name: 'Invite',
    components: {
        pagination,
        UserIdJump,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            PROMOTION_SHARE_TYPE,
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                playerId: '',
                code: '',
                time: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 280

        this.query.time.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.time.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        //处理摘要
        getSummary(row) {
            let text = ''
            if (row.number == 1) {
                text += '当日首次分享奖励'
            } else {
                text += '当日第 <span class="text_blue">' + row.number + '</span> 次分享奖励'
            }
            return text
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appReferShareLog])) {
                this.loading = true
                api.shareLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
