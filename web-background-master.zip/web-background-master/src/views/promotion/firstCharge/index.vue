<template>
    <div class="app-container">
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <label class="label_title">奖励时间</label>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="200" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="time" width="200" align="center" label="奖励时间" />
                    <el-table-column prop="incomeStr" width="200" align="center" label="金额">
                        <template slot-scope="scope">
                            {{ scope.row.incomeStr | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="state" width="150" align="center" label="状态" />
                    <el-table-column prop="id" align="center" label="摘要">
                        <template slot-scope="scope">
                            <div v-html="getSummary(scope.row)"></div>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'

import Base from '@/views/base'
import { filterThousandths } from '@/utils/filters'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'time;desc',
    playerId: '',
    time: []
}

export default {
    name: 'FirstCharge',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                playerId: '',
                time: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 280
        this.query.time.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.time.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        //处理摘要
        getSummary(row) {
            let text = '<span class="text_blue">' + row.belowPlayerId + '</span>'
            text += '首次充值 <span class="text_blue">' + filterThousandths(row.belowDepositAmountStr) + '</span>'
            text += '(充值流水 <span class="text_blue">' + row.accountDetailsId + '</span>|奖励配置:奖励' + '<span class="text_blue">' + filterThousandths(row.incomeStr) + '</span>'
            return text
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appReferDepositLog])) {
                this.loading = true
                api.depositLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
