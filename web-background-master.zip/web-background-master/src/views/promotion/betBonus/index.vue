<template>
    <div class="app-container">
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <label class="label_title">奖励时间</label>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入收益玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.belowPlayerId" size="medium" clearable placeholder="请输入下注玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.belowGameFlowId" size="medium" clearable placeholder="牌局流水" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="playerId" width="150" align="center" label="收益玩家">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="time" width="180" align="center" label="结算时间" />
                    <el-table-column prop="belowPlayerId" width="150" align="center" label="下注玩家">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.belowPlayerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="belowGameRoomType" width="150" align="center" label="所属游戏">
                        <template slot-scope="scope">
                            {{ getArrayValue(ACCOUNT_GAME_ROOM_TYPE, scope.row.belowGameRoomType) }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="belowGameFlowId" width="200" align="center" label="牌局流水">
                        <template slot-scope="scope">
                            <a class="text_blue" @click="toFlowDetail(scope.row)">{{ scope.row.belowGameFlowId }}</a>
                        </template>
                    </el-table-column>
                    <el-table-column prop="belowGameBetStr" width="200" align="center" label="下注金额">
                        <template slot-scope="scope">
                            {{ scope.row.belowGameBetStr | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="percent" width="100" align="center" label="分红比例">
                        <template slot-scope="scope">{{ scope.row.percent }}%</template>
                    </el-table-column>
                    <el-table-column prop="incomeStr" width="200" align="center" label="分红金额">
                        <template slot-scope="scope">
                            {{ scope.row.incomeStr | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="state" align="center" label="状态" />
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <!-- 流水详情 -->

        <Drawer :visible.sync="flowDetailDrawer">
            <DtDetail v-if="flowDetailDrawer && belowGameRoomType === 0" :flow-id="belowGameFlowId" />
            <PointsDetail v-if="flowDetailDrawer && belowGameRoomType === 1" :flow-id="belowGameFlowId" />
            <PoolDetail v-if="flowDetailDrawer && belowGameRoomType === 2" :flow-id="belowGameFlowId" />
            <DealsDetail v-if="flowDetailDrawer && belowGameRoomType === 3" :flow-id="belowGameFlowId" />
            <FxqClassicDetail v-if="flowDetailDrawer && belowGameRoomType === 4" :flow-id="belowGameFlowId" />
            <FxqQuickDetail v-if="flowDetailDrawer && belowGameRoomType === 5" :flow-id="belowGameFlowId" />
            <FxqMasterDetail v-if="flowDetailDrawer && belowGameRoomType === 6" :flow-id="belowGameFlowId" />
            <JmDetail v-if="flowDetailDrawer && belowGameRoomType === 7" :flow-id="belowGameFlowId" />
            <BabDetail v-if="flowDetailDrawer && belowGameRoomType === 8" :flow-id="belowGameFlowId" />
            <DltDetail v-if="flowDetailDrawer && belowGameRoomType === 9" :flow-id="belowGameFlowId" />
            <CszDetail v-if="flowDetailDrawer && belowGameRoomType === 10" :flow-id="belowGameFlowId" />
            <RbDetail v-if="flowDetailDrawer && belowGameRoomType === 11" :flow-id="belowGameFlowId" />
            <SupDetail v-if="flowDetailDrawer && belowGameRoomType === 12" :flow-id="belowGameFlowId" />
            <TpDetail v-if="flowDetailDrawer && belowGameRoomType === 13" :flow-id="belowGameFlowId" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'

import Drawer from '@/components/Drawer'
import DtDetail from '@/views/game/games/dtGame/dt/record/detail.vue'
import PointsDetail from '@/views/game/games/lmGame/points/record/detail.vue'
import PoolDetail from '@/views/game/games/lmGame/pool/record/detail.vue'
import DealsDetail from '@/views/game/games/lmGame/deals/record/detail.vue'
import JmDetail from '@/views/game/games/jmGame/jm/record/detail.vue'
import RbDetail from '@/views/game/games/rbGame/rb/record/detail.vue'
import BabDetail from '@/views/game/games/babGame/bab/record/detail.vue'
import CszDetail from '@/views/game/games/cszGame/csz/record/detail.vue'
import SupDetail from '@/views/game/games/supGame/sup/record/detail.vue'
import DltDetail from '@/views/game/games/dltGame/dlt/record/detail.vue'
import TpDetail from '@/views/game/games/tpGame/tp/record/detail.vue'
import FxqClassicDetail from '@/views/game/games/fxqGame/classic/record/detail.vue'
import FxqQuickDetail from '@/views/game/games/fxqGame/quick/record/detail.vue'
import FxqMasterDetail from '@/views/game/games/fxqGame/master/record/detail.vue'

import Base from '@/views/base'
import { ACCOUNT_GAME_ROOM_TYPE } from '@/constant/finance'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'time;desc',
    playerId: '',
    belowPlayerId: '',
    belowGameFlowId: '',
    time: []
}

export default {
    name: 'BetBonus',
    components: {
        pagination,
        DateRangePicker,
        UserIdJump,
        Drawer,
        DtDetail,
        PointsDetail,
        PoolDetail,
        DealsDetail,
        JmDetail,
        RbDetail,
        BabDetail,
        CszDetail,
        SupDetail,
        DltDetail,
        TpDetail,
        FxqClassicDetail,
        FxqQuickDetail,
        FxqMasterDetail
    },
    mixins: [Base],
    data() {
        return {
            ACCOUNT_GAME_ROOM_TYPE,
            loading: false,
            flowDetailDrawer: false,
            belowGameRoomType: '',
            belowGameFlowId: '',
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                playerId: '',
                belowPlayerId: '',
                belowGameFlowId: '',
                time: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 280

        this.query.time.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.time.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        toFlowDetail(row) {
            this.belowGameRoomType = row.belowGameRoomType
            this.belowGameFlowId = row.belowGameFlowId
            this.flowDetailDrawer = true
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appReferBetLog])) {
                this.loading = true
                api.betLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
