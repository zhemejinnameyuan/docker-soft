<template>
    <div>
        <div class="config_container">
            <div class="config_header">
                <div class="config_title">分享奖励</div>
            </div>
            <div class="config_setting" style="height: 290px">
                <el-form ref="form" :model="formData" :rules="rules">
                    <el-col :span="8">
                        <el-form-item label="开关">
                            <el-switch v-model="formData.shareDivvyEnable" @change="onChange"></el-switch>
                        </el-form-item>
                        <label class="label_title">{{ switchConfMessage }}</label>
                    </el-col>
                    <el-col :span="10" style="background-color: #f7f7f7; padding: 40px" v-show="formData.shareDivvyEnable">
                        <el-form-item label="可获奖励分享途径:">
                            <el-checkbox-group v-model="shareDivvyWayArr">
                                <el-checkbox v-for="(item, index) in PROMOTION_SHARE_TYPE" :key="index" :label="index">{{ item }}</el-checkbox>
                            </el-checkbox-group>
                        </el-form-item>
                        <el-form-item label="奖励规则:" prop="checkMultiAmount">
                            <label class="label_title mr-5">每日最多可获得分享奖励</label>
                            <div style="display: inline-block; width: 130px">
                                <InputNumber v-model="formData.shareDivvyDayFrequency" :min-number="1" :max-number="999" rangeWidth="120px" placeholder="请输入次数"></InputNumber>
                            </div>
                            <label class="label_title mr-5">,每次可获得奖励</label>
                            <div style="display: inline-block; width: 130px">
                                <InputNumber v-model="formData.shareDivvyFrequencyCoin" :min-number="1" :max-number="999" rangeWidth="120px" placeholder="请输入金额"></InputNumber>
                            </div>
                        </el-form-item>
                    </el-col>
                    <el-col :span="4" style="padding: 40px 40px 40px 100px">
                        <el-form-item>
                            <el-button type="primary" @click="onSubmit" v-permission="[permission.appReferConfigSave]">保存</el-button>
                        </el-form-item>
                    </el-col>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/promotion'
import { PROMOTION_SHARE_TYPE } from '@/constant/promotion'
import Base from '@/views/base'

export default {
    name: 'ShareReward',
    components: { InputNumber },
    mixins: [Base],
    data() {
        const checkMultiAmount = (rule, value, callback) => {
            if (this.formData.shareDivvyDayFrequency === '' || this.formData.shareDivvyDayFrequency === null) {
                callback(new Error('请输入分享奖励每日次数'))
            }
            if (this.formData.shareDivvyFrequencyCoin === '' || this.formData.shareDivvyFrequencyCoin === null) {
                callback(new Error('请输入分享奖励每次金额'))
            }
            callback()
        }
        return {
            PROMOTION_SHARE_TYPE,
            formData: {},
            shareDivvyWayArr: [],
            switchConfMessage: '',
            rules: {
                checkMultiAmount: [{ required: true, validator: checkMultiAmount, trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.onQuery()
    },
    methods: {
        onChange() {
            if (this.formData.betDivvyEnable) {
                this.switchConfMessage = '当前为开启状态，分享后将获得奖励，若关闭则实时生效'
            } else {
                this.switchConfMessage = '当前为关闭状态，分享后不再获得奖励，若开启则实时生效'
            }
        },
        onQuery() {
            if (this.checkPermission([this.permission.appReferConfigQuery])) {
                api.configQuery().then((rep) => {
                    this.formData = rep.data
                    //位运算 处理checkbox选项
                    let shareDivvyWay = this.formData.shareDivvyWay
                    const FACEBOOK = '1'
                    const WHATSAPP = '2'
                    const INVITE_FRIENDS = '4'
                    if (shareDivvyWay & FACEBOOK) {
                        this.shareDivvyWayArr.push(FACEBOOK)
                    }
                    if (shareDivvyWay & WHATSAPP) {
                        this.shareDivvyWayArr.push(WHATSAPP)
                    }
                    if (shareDivvyWay & INVITE_FRIENDS) {
                        this.shareDivvyWayArr.push(INVITE_FRIENDS)
                    }

                    this.onChange()
                })
            }
        },
        onSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    //计算分享方式的值
                    this.formData.shareDivvyWay = _.sum(this.shareDivvyWayArr.map(Number))
                    if (this.formData.shareDivvyEnable && this.formData.shareDivvyWay === 0) {
                        this.$message.error('可获奖励分享途径至少要开启一个')
                        return false
                    }
                    if (this.checkPermission([this.permission.appReferConfigSave])) {
                        api.configSave(this.formData).then((rep) => {
                            this.$message.success('保存成功')
                        })
                    }
                }
            })
        }
    }
}
</script>
