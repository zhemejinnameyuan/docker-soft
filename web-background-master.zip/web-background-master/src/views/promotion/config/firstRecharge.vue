<template>
    <div>
        <div class="config_container">
            <div class="config_header">
                <div class="config_title">首充奖励</div>
            </div>
            <div class="config_setting" style="height: 220px">
                <el-form ref="form" :model="formData" :rules="rules">
                    <el-col :span="8">
                        <el-form-item label="开关">
                            <el-switch v-model="formData.firstDepositDivvyEnable" @change="onChange"></el-switch>
                        </el-form-item>
                        <label class="label_title">{{ switchConfMessage }}</label>
                    </el-col>
                    <el-col :span="10" style="background-color: #f7f7f7; padding: 40px" v-show="formData.firstDepositDivvyEnable">
                        <el-form-item label="分成配置:" prop="checkMultiAmount">
                            <label class="label_title mr-5">充值金额>=:</label>
                            <div style="display: inline-block; width: 160px">
                                <InputNumber v-model="formData.firstDepositDivvyCoin" :min-number="1" :max-number="999999" rangeWidth="150px" placeholder="请输入奖励金额"></InputNumber>
                            </div>
                            <label class="label_title mr-5">,上级用户获得</label>
                            <div style="display: inline-block; width: 120px">
                                <InputNumber v-model="formData.firstDepositDivvySeniorCoin" :min-number="1" :max-number="999999" rangeWidth="120px" placeholder="请输入金额"></InputNumber>
                            </div>
                            <label class="label_title ml-5">充值奖励</label>
                        </el-form-item>
                    </el-col>
                    <el-col :span="4" style="padding: 40px 40px 40px 100px">
                        <el-form-item>
                            <el-button type="primary" @click="onSubmit" v-permission="[permission.appReferConfigSave]">保存</el-button>
                        </el-form-item>
                    </el-col>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/promotion'
import Base from '@/views/base'
export default {
    name: 'FirstRecharge',
    components: { InputNumber },
    mixins: [Base],
    data() {
        const checkMultiAmount = (rule, value, callback) => {
            if (this.formData.firstDepositDivvyCoin === '' || this.formData.firstDepositDivvyCoin === null) {
                callback(new Error('请输入首充奖励充值金额'))
            }
            if (this.formData.firstDepositDivvySeniorCoin === '' || this.formData.firstDepositDivvySeniorCoin === null) {
                callback(new Error('请输入上级用户获得金额'))
            }
            callback()
        }
        return {
            formData: {},
            switchConfMessage: '',
            rules: {
                checkMultiAmount: [{ required: true, validator: checkMultiAmount, trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.onQuery()
    },
    methods: {
        onChange() {
            if (this.formData.betDivvyEnable) {
                this.switchConfMessage = '当前为开启状态，上级用户将享受下级充值奖励，若关闭则实时生效'
            } else {
                this.switchConfMessage = '当前为关闭状态，上级用户不再享受下级充值奖励，若开启则实时生效'
            }
        },
        onQuery() {
            if (this.checkPermission([this.permission.appReferConfigQuery])) {
                api.configQuery().then((rep) => {
                    this.formData = rep.data
                    this.onChange()
                })
            }
        },
        onSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.checkPermission([this.permission.appReferConfigSave])) {
                        api.configSave(this.formData).then((rep) => {
                            this.$message.success('保存成功')
                        })
                    }
                }
            })
        }
    }
}
</script>
