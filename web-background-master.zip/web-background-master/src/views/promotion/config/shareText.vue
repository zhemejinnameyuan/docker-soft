<template>
    <div>
        <div class="config_container">
            <div class="config_header">
                <div class="config_title">分享文案</div>
            </div>
            <div class="config_setting" style="height: 650px">
                <el-form ref="form" :model="formData" :rules="rules" label-position="top">
                    <el-form-item prop="shareText" label="默认文案模版(前端分享链接的文案信息):">
                        <el-input type="textarea" placeholder="请输入内容" v-model="formData.shareText" maxlength="3000" show-word-limit rows="10" />
                    </el-form-item>

                    <div class="text_gray fs-12 mb-30">
                        渠道包下载地址填写
                        <span class="text_red">{CHANNEL_PACK_URL}</span>
                        ，玩家邀请码填写
                        <span class="text_red">{INVITATION_CODE}</span>
                    </div>

                    <el-form-item prop="shareText" label="落地页背景图:">
                        <UploadImage v-if="showUpload" class="upload-box" :limit="1" :fileSize="2" :existImgList="existImgList" @updateFileList="updateFileList" :width="750" :height="1334" />
                    </el-form-item>
                    <div class="text_gray fs-12">图片尺寸750*1334px，支持png、jpg、jpeg格式，大小不超过2M</div>

                    <el-form-item class="mt-40" style="margin-left: 300px">
                        <el-button type="primary" @click="onSubmit" v-permission="[permission.appReferConfigSave]">保存</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
import UploadImage from '@/components/UploadImage'
import * as api from '@/api/promotion'
import Base from '@/views/base'

export default {
    name: 'ShareText',
    mixins: [Base],
    components: {
        UploadImage
    },
    data() {
        return {
            formData: {
                shareImgAddr: ''
            },
            existImgList: [],
            showUpload: false,
            rules: {
                shareText: [{ required: true, message: '请输入内容', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.onQuery()
    },
    methods: {
        onQuery() {
            if (this.checkPermission([this.permission.appReferConfigQuery])) {
                api.configQuery().then((rep) => {
                    this.formData = rep.data
                    //拼装已经上传的图片
                    if (this.formData.shareImgAddr) {
                        this.existImgList = [{ name: this.formData.shareImgAddr, domain: rep.domain.file, url: this.formData.shareImgAddr }]
                    }
                    this.showUpload = true
                })
            }
        },
        //处理上传图片回调
        updateFileList(list) {
            this.formData.shareImgAddr = list[0] ? list[0] : ''
        },
        onSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.formData.shareImgAddr === '') {
                        return this.$message.warning('请上传落地页背景图')
                    }
                    if (this.checkPermission([this.permission.appReferConfigSave])) {
                        api.configSave(this.formData).then((rep) => {
                            this.$message.success('保存成功')
                        })
                    }
                }
            })
        }
    }
}
</script>

<style scoped lang="scss">
::v-deep .el-form .el-form-item__label {
    font-weight: 600;
    font-size: 16px;
}
</style>
