<template>
    <div class="app-container promotion-config" style="background-color: #f7f7f7; height: 100vh; width: 100vw">
        <el-tabs v-model="activeName" i type="card" @tab-click="handleClick">
            <el-tab-pane label="投注分红" name="betBonus">
                <BetBonus v-if="activeName == 'betBonus'" />
            </el-tab-pane>
            <el-tab-pane label="首充奖励" name="firstRecharge">
                <FirstCharge v-if="activeName == 'firstRecharge'" />
            </el-tab-pane>
            <el-tab-pane label="分享奖励" name="shareReward">
                <ShareReward v-if="activeName == 'shareReward'" />
            </el-tab-pane>
            <el-tab-pane label="分享文案" name="shareText">
                <ShareText v-if="activeName == 'shareText'" />
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
import Base from '@/views/base'
import BetBonus from './betBonus.vue'
import FirstCharge from './firstRecharge.vue'
import ShareReward from './shareReward.vue'
import ShareText from './shareText.vue'

export default {
    name: 'Config',
    components: {
        ShareText,
        ShareReward,
        FirstCharge,
        BetBonus
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'betBonus'
        }
    },
    mounted() {},
    methods: {
        handleClick() {}
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
    background-color: #1ba2ff;
    color: #ffffff;
}
.el-tabs__nav {
    background-color: #ffffff;
}
.el-tabs--card > .el-tabs__header {
    border-bottom: 0px;
}
.el-tabs--card > .el-tabs__header .el-tabs__item {
    border-bottom: 1px solid #e4e7ed;
}

.promotion-config {
    .el-form-item--small .el-form-item__label {
        line-height: 45px;
    }
}
.config_container {
    margin-top: 30px;
    width: 100%;
    background-color: #ffffff;
}

.config_header {
    width: 100%;
    background: rgba(27, 162, 255, 0.1);
    height: 60px;
    margin: auto;
    color: #282829;
    letter-spacing: 0;
    font-weight: 400;
}

.config_title {
    font-size: 18px;
    color: #282829;
    font-weight: 500;
    line-height: 60px;
    margin-left: 20px;
}

.config_setting {
    padding: 40px;
    white-space: nowrap;
}
</style>
