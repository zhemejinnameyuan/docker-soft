<template>
    <div class="app-container">
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <label class="label_title">成为推广员时间</label>
                <DateRangePicker v-model="query.referTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="请输入玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.code" size="medium" clearable placeholder="请输入邀请码" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.referState" placeholder="推广状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in PROMOTION_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="referTime" width="200" align="center" label="成为推广员时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="id" width="150" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.id" />
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="code" width="160" align="center" label="邀请码" />
                    <el-table-column :show-overflow-tooltip="true" prop="channelName" width="300" align="center" label="所属渠道">
                        <template slot-scope="scope">
                            <div>{{ scope.row.channelName }}({{ scope.row.channelId }})</div>
                            <div>{{ scope.row.channelPackageName }}({{ scope.row.channelPackageId }})</div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="id" width="100" align="center" label="推广人数">
                        <template slot-scope="scope">
                            <el-button type="text" class="text_underline fs-14" @click="viewDetail(scope.row.id)">{{ scope.row.referCount }}</el-button>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="referIncome" width="160" align="center" label="累计收益">
                        <template slot-scope="scope">
                            {{ scope.row.referIncome | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="referWithdrawable" width="160" align="center" label="可兑换余额">
                        <template slot-scope="scope">
                            {{ scope.row.referWithdrawable | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="100" align="center" label="推广状态">
                        <template slot-scope="scope">
                            <el-button type="text" class="text_underline fs-14" :class="scope.row.referState == 1 ? 'text_green' : 'text_red'" @click="viewBan(scope.row.id)">
                                {{ getArrayValue(PROMOTION_STATE, scope.row.referState) }}
                            </el-button>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" align="center">
                        <template slot-scope="scope">
                            <el-button v-permission="[permission.appBlacklistBatchAdd]" v-if="scope.row.referState == 1" type="danger" size="small" round @click="addBan(scope.row.id)">封禁</el-button>
                            <el-button v-permission="[permission.appBlacklistBatchDelByPlayerIds]" v-if="scope.row.referState == 2" type="primary" size="small" round @click="removeBan(scope.row.id)">
                                解封
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="banVisible" title="封禁记录">
            <Ban v-if="banVisible" :playerId="playerId" />
        </Drawer>

        <Drawer :visible.sync="detailVisible" title="推广明细">
            <Detail v-if="detailVisible" :playerId="playerId" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'
import Drawer from '@/components/Drawer'
import Ban from './ban.vue'
import Detail from './detail.vue'
import { PROMOTION_STATE } from '@/constant/promotion'
import Base from '@/views/base'
import { confirmRequest, getChannelList } from '@/utils'
import { mapGetters } from 'vuex'
import { BLACKLIST_SUB_TYPE, BLACKLIST_TYPE } from '@/constant/common'
import { Message, MessageBox } from 'element-ui'
import * as promotionApi from '@/api/promotion'
import * as playerApi from '@/api/player'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'referTime;desc',
    playerId: '',
    code: '',
    referState: '',
    referTime: []
}

export default {
    name: 'User',
    components: {
        Drawer,
        Ban,
        Detail,
        pagination,
        DateRangePicker,
        UserIdJump
    },
    mixins: [Base],
    data() {
        return {
            PROMOTION_STATE,
            loading: false,
            banVisible: false,
            detailVisible: false,
            list: [],
            playerId: '',
            query: {
                size: 20,
                page: 1,
                sort: 'referTime;desc',
                playerId: '',
                code: '',
                referState: '',
                referTime: []
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 280
        this.query.referTime.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        this.query.referTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        //封禁
        addBan(id) {
            confirmRequest('封禁后该玩家将无法被其他玩家绑定成为推荐者?', () => {
                this.$prompt('请输入原因', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    let params = [
                        {
                            type: BLACKLIST_TYPE.PROMOTION,
                            subType: BLACKLIST_SUB_TYPE.PLAYER_ID,
                            value: id,
                            reason: value
                        }
                    ]

                    playerApi
                        .blackBatchAdd(params)
                        .then((rep) => {
                            this.$message.success('操作成功')
                            this.toQuery(true)
                        })
                        .catch(() => {})
                })
            })
        },
        //解禁
        removeBan(id) {
            confirmRequest('解封后该玩家将可以被其他玩家绑定成为推荐者?', () => {
                this.$prompt('请输入原因', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    let params = {
                        typeList: [BLACKLIST_TYPE.PROMOTION],
                        valueList: [id],
                        reason: value
                    }
                    playerApi.batchDelByPlayerIds(params).then((rep) => {
                        this.$message.success('操作成功')
                        this.toQuery()
                    })
                })
            })
        },
        //封禁记录
        viewBan(id) {
            this.banVisible = true
            this.playerId = id
        },
        //推广明细
        viewDetail(id) {
            if (this.checkPermission([this.permission.appReferAccountDetail, this.permission.appReferAccountBelows])) {
                this.detailVisible = true
                this.playerId = id
            } else {
                this.$message.error('无权限')
            }
        },

        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appReferAccountList])) {
                this.loading = true
                api.accountList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.role-span {
    font-weight: bold;
    color: #303133;
    font-size: 15px;
}

::v-deep .el-input-number .el-input__inner {
    text-align: left;
}

::v-deep .vue-treeselect__multi-value {
    margin-bottom: 0;
}

::v-deep .vue-treeselect__multi-value-item {
    border: 0;
    padding: 0;
}
.terminal {
    display: flex;
    flex-direction: column;
}
</style>
