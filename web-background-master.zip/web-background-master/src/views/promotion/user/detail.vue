<template>
    <div class="web-container" style="background: #f7f7f7; width: 1600px; padding-top: 20px !important">
        <div class="player-detail">
            <div class="info no-scrollbar">
                <div class="info_crad">
                    <div class="info_crad_bg">
                        <div class="content">
                            <img class="avater" :src="getAvatar(domain, userInfo)" />
                            <div class="dp_c" style="margin-left: 12px">
                                <span class="name">{{ userInfo.nickname | filterEmpty }}</span>
                                <span class="user_id">ID:{{ userInfo.id | filterEmpty }}</span>
                            </div>
                        </div>
                        <div class="invitation">邀请码：{{ userInfo.code | filterEmpty }}</div>
                        <img class="state_tag" :src="getState()" />
                    </div>
                </div>
                <div class="info_crad_bottom" />
                <el-row style="margin-top: 30px">
                    <el-button
                        v-permission="[permission.appBlacklistBatchAdd]"
                        v-if="userInfo.referState == 1"
                        type="danger"
                        size="medium"
                        style="width: 280px; margin-left: 20px"
                        @click="addBan(playerId)"
                    >
                        封禁
                    </el-button>
                    <el-button
                        v-permission="[permission.appBlacklistBatchDelByPlayerIds]"
                        v-if="userInfo.referState == 2"
                        type="primary"
                        size="medium"
                        style="width: 280px; margin-left: 20px"
                        @click="removeBan(playerId)"
                    >
                        解封
                    </el-button>
                </el-row>
                <div class="dp-c mt-40">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">推广员信息</div>
                    </div>
                    <div class="line" />
                    <div class="ml-20 mt-10">
                        <span class="text_sub">成为推广员时间：</span>
                        <span class="text_des">{{ userInfo.referTime | filterEmpty }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">所属渠道：</span>
                        <span class="text_des">{{ userInfo.channelName }}({{ userInfo.channelId }})</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">所属渠道包：</span>
                        <span class="text_des">{{ userInfo.channelPackageName }}({{ userInfo.channelPackageId }})</span>
                    </div>
                </div>

                <div class="dp-c mt-40">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">收益信息</div>
                    </div>
                    <div class="line" />
                    <div class="ml-20 mt-10">
                        <span class="text_sub">累计收益：</span>
                        <span class="text_des">{{ userInfo.referIncome | filterThousandths }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">分享收益：</span>
                        <span class="text_des">{{ userInfo.referShareIncome | filterThousandths }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">充值分成：</span>
                        <span class="text_des">{{ userInfo.referDepositIncome | filterThousandths }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">投注分红：</span>
                        <span class="text_des">{{ userInfo.referBetIncome | filterThousandths }}</span>
                    </div>
                </div>

                <div class="dp-c mt-40">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">兑换信息</div>
                    </div>
                    <div class="line" />
                    <div class="ml-20 mt-10">
                        <span class="text_sub">可兑换金额：</span>
                        <span class="text_des">{{ userInfo.referWithdrawable | filterThousandths }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">已兑换金额：</span>
                        <span class="text_des">{{ userInfo.referExchanged | filterThousandths }}</span>
                    </div>
                    <div class="ml-20 mt-10">
                        <span class="text_sub">待结算金额：</span>
                        <span class="text_des">{{ userInfo.tobeSettlement | filterThousandths }}</span>
                    </div>
                </div>
            </div>
            <div class="dp-c">
                <div class="player-detail_content">
                    <div class="app-container">
                        <div class="head-container">
                            <el-row>
                                <label class="label_title">绑定时间</label>
                                <DateRangePicker v-model="query.referBindTime" class="filter-item" style="width: 250px" @change="toQuery" />
                                <el-input v-model="query.belowPlayerId" size="medium" clearable placeholder="下级玩家ID" style="width: 150px" class="filter-item" @keyup.enter.native="toQuery" />
                                <el-input v-model="query.code" size="medium" clearable placeholder="请输入邀请码" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                                <el-select v-model="query.referState" placeholder="推广状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                                    <el-option v-for="(item, index) in PROMOTION_STATE" :key="index" :value="index" :label="item" />
                                </el-select>
                                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
                            </el-row>

                            <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 970px" :height="table_height" :data="list">
                                <el-table-column prop="referBindTime" width="155" align="center" label="绑定时间" />
                                <el-table-column prop="loginTime" width="155" align="center" label="最近活跃时间" />
                                <el-table-column prop="id" width="100" align="center" label="下级玩家ID">
                                    <template slot-scope="scope">
                                        <UserIdJump :id="scope.row.id" />
                                    </template>
                                </el-table-column>
                                <el-table-column :show-overflow-tooltip="true" prop="code" width="130" align="center" label="邀请码" />
                                <el-table-column width="200" prop="channel" align="center" label="渠道" key="channel" v-if="!isChannelUser()">
                                    <template slot-scope="scope">
                                        <div>{{ scope.row.channelName }}({{ scope.row.channelId }})</div>
                                        <div>{{ scope.row.channelPackageName }}({{ scope.row.channelPackageId }})</div>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="referGameRound" width="100" align="center" label="累计场次">
                                    <template slot="header">
                                        <span>
                                            累计场次
                                            <el-tooltip class="item" effect="dark" content="玩家总游戏场次/绑定推广关系后的游戏场次" placement="top">
                                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                            </el-tooltip>
                                        </span>
                                    </template>
                                    <template slot-scope="scope">{{ scope.row.gameRound | filterThousandths }} / {{ scope.row.referGameRound | filterThousandths }}</template>
                                </el-table-column>
                                <el-table-column prop="content" width="160" align="center" label="投注金额/分红">
                                    <template slot-scope="scope">
                                        <div>{{ scope.row.referBet | filterThousandths }} / {{ scope.row.referBetDivvy | filterThousandths }}</div>
                                    </template>
                                </el-table-column>
                                <el-table-column width="100" prop="referDepositDivvy" align="center" label="首充奖励">
                                    <template slot-scope="scope">
                                        {{ scope.row.referDepositDivvy | filterThousandths }}
                                    </template>
                                </el-table-column>
                                <el-table-column width="70" prop="referState" align="center" label="推广状态">
                                    <template slot-scope="scope">
                                        <el-button type="text" class="text_underline fs-14" :class="scope.row.referState == 1 ? 'text_green' : 'text_red'" @click="viewBan(scope.row.id)">
                                            {{ getArrayValue(PROMOTION_STATE, scope.row.referState) }}
                                        </el-button>
                                    </template>
                                </el-table-column>
                            </el-table>
                            <!--分页组件-->
                            <pagination v-if="total" :page-sizes="[20, 50, 100]" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'
import { confirmRequest } from '@/utils'
import { PROMOTION_STATE } from '@/constant/promotion'
import { BLACKLIST_SUB_TYPE, BLACKLIST_TYPE } from '@/constant/common'
import * as playerApi from '@/api/player'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'referBindTime;desc',
    playerId: '',
    code: '',
    belowPlayerId: '',
    referBindTime: []
}
export default {
    name: 'Detail',
    mixins: [Base],
    props: {
        playerId: {
            type: Number,
            default: 0
        }
    },
    components: {
        DateRangePicker,
        UserIdJump,
        pagination
    },
    data() {
        return {
            PROMOTION_STATE,
            normal: require('@/assets/images/oms_lab_normal.png'),
            ban: require('@/assets/images/oms_lab_ban.png'),
            loading: false,
            userInfo: {},
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'referBindTime;desc',
                playerId: '',
                code: '',
                belowPlayerId: '',
                referBindTime: []
            },
            total: 0,
            domain: ''
        }
    },
    mounted() {
        this.fixed_height = 200
        this.getUserInfo()
        this.toQuery()
    },
    methods: {
        //封禁
        addBan(id) {
            confirmRequest('封禁后该玩家将无法被其他玩家绑定成为推荐者?', () => {
                this.$prompt('请输入原因', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    let params = [
                        {
                            type: BLACKLIST_TYPE.PROMOTION,
                            subType: BLACKLIST_SUB_TYPE.PLAYER_ID,
                            value: id,
                            reason: value
                        }
                    ]

                    playerApi
                        .blackBatchAdd(params)
                        .then((rep) => {
                            this.$message.success('添加成功')
                            this.getUserInfo()
                        })
                        .catch(() => {})
                })
            })
        },
        //解禁
        removeBan(id) {
            confirmRequest('解封后该玩家将可以被其他玩家绑定成为推荐者?', () => {
                this.$prompt('请输入原因', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    let params = {
                        typeList: [BLACKLIST_TYPE.PROMOTION],
                        valueList: [id],
                        reason: value
                    }
                    playerApi.batchDelByPlayerIds(params).then((rep) => {
                        this.$message.success('操作成功')
                        this.getUserInfo()
                    })
                })
            })
        },
        getUserInfo() {
            if (this.checkPermission([this.permission.appReferAccountDetail])) {
                api.accountDetail({ playerId: this.playerId })
                    .then((rep) => {
                        this.userInfo = rep.data
                    })
                    .catch(() => {})
            }
        },
        getState() {
            if (this.userInfo.referState == 1) {
                return this.normal
            }
            return this.ban
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.query.playerId = this.playerId
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.query.playerId = this.playerId
            if (this.checkPermission([this.permission.appReferAccountBelows])) {
                this.loading = true
                api.accountBelows(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.domain = rep.domain.file
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: row;
    justify-content: center;

    .info {
        width: 320px;
        height: calc(100vh - 80px);
        overflow-y: scroll;
        background: #ffffff;
        border-left: 1px solid rgba(220, 223, 230, 1);
        border-top: 1px solid rgba(220, 223, 230, 1);
        border-right: 1px solid rgba(220, 223, 230, 1);
        border-radius: 8px 8px 0px 0px;
        margin-right: 20px;
        padding: 40px 0px;

        &_crad {
            height: 119px;
            overflow: hidden;

            &_bg {
                position: relative;
                width: 280px;
                height: 129px;
                background: #dbf5f6;
                border: 1px solid rgb(189, 239, 246);
                box-shadow: inset 0px 0px 8px 0px rgb(87, 224, 243);
                margin-left: 20px;
                border-radius: 5px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            .content {
                display: flex;
                flex: 1;
                align-items: center;
                padding: 0px 10px;

                .avater {
                    width: 45px;
                    height: 45px;
                    border-radius: 50%;
                }

                .name {
                    display: flex;
                    font-size: 16px;
                    color: #282829;
                    letter-spacing: 0.89px;
                    font-weight: 500;
                    margin-bottom: 8px;
                }

                .user_id {
                    display: flex;
                    font-size: 14px;
                    color: #686b6d;
                    letter-spacing: 0.78px;
                    font-weight: 400;
                }
            }

            .invitation {
                display: flex;
                justify-content: center;
                align-items: center;
                padding-bottom: 10px;
                width: 100%;
                height: 38px;
                background: rgba(27, 162, 255, 0.15);
                font-size: 14px;
                color: #1ba2ff;
                letter-spacing: 0.88px;
                font-weight: 500;
            }

            .state_tag {
                position: absolute;
                right: 0px;
                top: 0px;
                width: 48px;
                height: 48px;
            }
        }

        &_crad_bottom {
            margin-top: -6px;
            width: 100%;
            box-shadow: inset 0px -6px 6px -6px #bbbbbb;
            height: 6px;
            z-index: 1;
            position: relative;
        }

        .text_main {
            font-size: 16px;
            color: #282829;
            letter-spacing: 0.89px;
            font-weight: 500;
        }

        .text_sub {
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0;
            font-weight: 400;
        }

        .text_des {
            font-size: 14px;
            color: #282829;
            letter-spacing: 0;
            font-weight: 400;
        }

        .tag {
            width: 16px;
            height: 4px;
            margin-right: 4px;
            background: linear-gradient(-135deg, transparent 3px, #1ba2ff 0) bottom left;
        }

        .line {
            width: 100px;
            height: 1px;
            background-color: #1ba2ff;
            margin-top: 2px;
            margin-bottom: 20px;
        }
    }

    .player-detail_content {
        width: 1060px;
        height: calc(100vh - 80px);
        display: flex;
        background: #ffffff;
        box-shadow: 0px -6px 10px 0px rgba(0, 0, 0, 0.1);
        border-radius: 4px;
    }
}
</style>
