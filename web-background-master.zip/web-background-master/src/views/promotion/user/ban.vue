<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="操作开始日期" end-placeholder="操作结束日期" @change="toQuery" />

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <el-row>
            <!--表格-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row :height="table_height" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="200" align="center" label="日期" />
                    <el-table-column :show-overflow-tooltip="true" prop="operateType" width="150" align="center" label="操作类型">
                        <template slot-scope="scope">
                            <span :class="scope.row.operateType % 2 == 1 ? 'text_red' : 'text_green'">
                                {{ getArrayValue(BLOCK_TYPE_CONF, scope.row.operateType) }}
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="operator" width="150" align="center" label="操作人" />
                    <el-table-column :show-overflow-tooltip="true" prop="reason" width="300" align="left" label="原因" />
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/promotion'
import Base from '@/views/base'
import { BLOCK_TYPE_CONF } from '@/constant/common'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'createTime;desc',
    createTime: [],
    playerId: ''
}
export default {
    name: 'Ban',
    components: {
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    props: {
        playerId: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            BLOCK_TYPE_CONF,
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                playerId: ''
            },
            total: 0,
            dialogType: '',
            dialogObj: {},
            dialogVisible: false
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 200
        this.toQuery()
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            this.query.playerId = this.playerId
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.appReferAccountBlockRecord])) {
                this.loading = true
                api.accountBlockRecord(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
