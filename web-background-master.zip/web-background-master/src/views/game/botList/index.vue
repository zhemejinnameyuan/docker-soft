<template>
    <div class="app-container bot">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-select v-model="query.gameType" placeholder="游戏类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in games" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.online" placeholder="机器人状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option :label="'空闲'" :value="0" />
                    <el-option :label="'忙碌'" :value="1" />
                </el-select>
                <el-input v-model="query.nickname" size="medium" clearable placeholder="机器人昵称" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.id" size="medium" clearable placeholder="机器人ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.roomId" size="medium" clearable placeholder="房间ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.deskId" size="medium" clearable placeholder="桌子ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton v-permission="[permission.robotList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column align="center" prop="id" label="机器人ID" />
            <el-table-column :show-overflow-tooltip="true" align="center" prop="avatarId" label="头像">
                <template slot-scope="scope">
                    <img class="user_img" :src="getAvatar(domain, scope.row)" />
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" align="center" prop="nickname" label="机器人昵称" />
            <el-table-column :show-overflow-tooltip="true" align="center" label="游戏名称">
                <template slot-scope="scope">
                    <span>{{ getGameName(scope.row.gameType) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" align="center" prop="roomId" label="房间ID" />
            <el-table-column :show-overflow-tooltip="true" align="center" prop="deskId" label="桌子ID" />
            <el-table-column :show-overflow-tooltip="true" align="center" prop="bankCoin" label="剩余本金" />
            <el-table-column :show-overflow-tooltip="true" width="155px" align="center" prop="online" label="机器人状态">
                <template slot-scope="scope">
                    <span :class="scope.row.online ? 'bot-state-red' : 'bot-state-green'">{{ scope.row.online ? '忙碌' : '空闲' }}</span>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import Base from '@/views/base'
import * as api from '@/api/game'
export default {
    name: 'BotList',
    components: {
        pagination
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            total: 0,
            games: [],
            query: {
                size: 100,
                page: 1,
                sort: 'id;desc',
                gameType: null,
                online: null,
                nickname: null,
                id: null,
                roomId: null,
                deskId: null
            },
            domain: ''
        }
    },
    mounted() {
        this.fixed_height = 250
        this.games = this.getGames()
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.robotList])) {
                this.loading = true
                api.robotList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.domain = rep.domain.file
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.bot {
    .bot-state-green {
        color: #0fc933;
    }
    .bot-state-red {
        color: #e60808;
    }
    .user_img {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        overflow: hidden;
    }
}
</style>
