<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="xsc">
                <span slot="title">蓄水池</span>
            </el-menu-item>
            <el-menu-item index="wcl">
                <span slot="title">无策略</span>
            </el-menu-item>
            <el-menu-item index="cscl">
                <span slot="title">抽水策略</span>
            </el-menu-item>
            <el-menu-item index="szcl">
                <span slot="title">刷子策略</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <CisternConfig v-if="type === 'xsc' && configData" :gameType="GAME_TYPE.DT" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.dtGlobalSave]" />
            <PlanConfig v-if="type === 'wcl' && configData" :gameType="GAME_TYPE.DT" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.dtGlobalSave]" />
            <PumpConfig v-if="type === 'cscl' && configData" :gameType="GAME_TYPE.DT" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.dtGlobalSave]" />
            <BrushConfig v-if="type === 'szcl' && configData" :gameType="GAME_TYPE.DT" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.dtGlobalSave]" />
        </div>
    </div>
</template>

<script>
import CisternConfig from '@/views/game/games/bairenCommon/global/cistern.vue'
import PlanConfig from '@/views/game/games/bairenCommon/global/plan.vue'
import PumpConfig from '@/views/game/games/bairenCommon/global/pump.vue'
import BrushConfig from '@/views/game/games/bairenCommon/global/brush.vue'
import Base from '@/views/base'
import * as api from '@/api/game/dt'
import { GAME_TYPE } from '@/constant/game'

export default {
    components: {
        CisternConfig,
        PlanConfig,
        PumpConfig,
        BrushConfig
    },
    mixins: [Base],
    data() {
        return {
            GAME_TYPE,
            type: 'xsc',
            configData: null
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        handleSelect(type) {
            this.type = type
            this.toQuery()
        },
        //查询
        toQuery() {
            api.dtGlobalGet().then((rep) => {
                this.repData = rep.data
                this.configData = { ...this.repData.jsonConfig }
            })
        },
        //保存
        toSubmit(configData) {
            this.repData.jsonConfig = { ...configData }
            api.dtGlobalSave(this.repData).then((rep) => {
                this.$message.success('保存成功')
            })
        }
    }
}
</script>
