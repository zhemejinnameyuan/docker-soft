<template>
    <div class="web-container" style="background: #f7f7f7">
        <GoHome />
        <div class="container_title">DT-游戏管理</div>
        <div class="container_game">
            <div class="game_tab">
                <div v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :class="tabClass(item.type)" @click="changeTab(item.type)">
                    {{ item.title }}
                </div>
            </div>
            <div class="game_content">
                <Dt v-if="type === 'dt'" />
                <Robot v-if="type === 'robot'" />
                <Global v-if="type === 'global'" />
            </div>
        </div>
    </div>
</template>

<script>
import Dt from './dt/index.vue'
import Robot from './robot/index.vue'
import Global from './global/index.vue'
import Base from '@/views/base'
import GoHome from '@/components/GoHome'

export default {
    name: 'DtGame',
    components: {
        Dt,
        Robot,
        Global,
        GoHome
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'dt',
                title: 'DT',
                permissions: [this.permission.dtRoomList, this.permission.dtFlowList, this.permission.dtReservoirLog]
            },
            {
                type: 'robot',
                title: '机器人',
                permissions: [this.permission.dtRobotGet]
            },
            {
                type: 'global',
                title: '全局配置',
                permissions: [this.permission.dtGlobalGet]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        tabClass(type) {
            return type === this.type ? 'game_tab_item_active' : 'game_tab_item'
        },
        changeTab(type) {
            this.type = type
        }
    }
}
</script>
