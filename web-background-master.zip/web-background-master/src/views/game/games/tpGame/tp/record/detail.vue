<template>
    <div class="common-record-detail no-scrollbar" style="width: 1300px">
        <div id="tp_drawer" class="wrapper_content">
            <div class="item_title">牌局基本信息</div>
            <div class="item_bg">
                <el-form label-width="170px">
                    <el-form-item label="牌局时间:">
                        <span class="des_title">{{ info.startTime }} 至 {{ info.endTime }}</span>
                    </el-form-item>
                    <el-form-item label="底注金额:">
                        <span class="des_title">{{ info.anteCoin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="房间准入金额:">
                        <span class="des_title">{{ info.joinMinCoin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="Chaal最大金额:">
                        <span class="des_title">{{ info.chaalMaxCoin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="奖池最大金额:">
                        <span class="des_title">{{ info.jackpotMaxCoin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="扣税比例:">
                        <span class="des_title">{{ info.taxPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="结算拆分比例:">
                        <span class="des_title">D:{{ info.depositedPercent | filterEmpty }}%｜W:{{ info.winningsPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="每轮操作限时:">
                        <span class="des_title">{{ info.operateSeconds | filterEmpty }} S</span>
                    </el-form-item>
                    <el-form-item label="盲注轮次限制:">
                        <span class="des_title">{{ info.blindMaxRound | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="踢出房间连续弃牌次数:">
                        <span class="des_title">{{ info.autoDropExit | filterEmpty }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title">策略详情</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item :label="getArrayValue(STRATEGY_TYPE, info.strategyType) + ':'" v-if="info.strategyType && info.strategyType != '无策略'">
                        <span class="des_title">触发区间:{{ info.strategyConfig | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['WINNER', 'BRUSH'].indexOf(info.strategyType) !== -1">机器人作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['NEWBIE', 'LOSER'].indexOf(info.strategyType) !== -1">玩家作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                        <span class="des_title ml-20">触发状态: {{ info.strategyOpen > 0 ? '已触发' : '未触发' }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div v-if="info.result" class="item_title">牌局结算信息</div>

            <div class="result-table">
                <el-table class="item_table" :header-row-style="{ height: '30px' }" :row-style="{ height: '30px' }" :data="[0, 1, 2, 3, 4, 5, 6, 7]" :border="true">
                    <el-table-column width="160px" :show-overflow-tooltip="true" align="center" label="玩家">
                        <template slot-scope="scope">
                            {{ resultMap[scope.$index] }}
                        </template>
                    </el-table-column>

                    <el-table-column v-for="(item, index) in info.result" :key="index" :show-overflow-tooltip="true" align="center">
                        <template slot="header">
                            <span class="score_name">
                                <svg-icon v-if="item.bank" icon-class="oms_lab_zhuangjia" class="z_tip" />
                                <svg-icon v-if="item.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                                <span v-if="item.robot">{{ item.playerId }}</span>
                                <UserIdJump :id="item.playerId" :nickname="item.nickname" v-if="!item.robot" />
                            </span>
                        </template>
                        <template slot-scope="scope">
                            <div v-if="scope.$index === 0">{{ item.pos }}</div>
                            <div v-if="scope.$index === 1">
                                <div class="card_reult">
                                    <MultipleCard :list="item.cardKeys" />
                                </div>
                                <div>
                                    {{ getCardType(item.cardType) }}
                                </div>
                            </div>
                            <div v-if="scope.$index === 2" :style="item.returnCoinStr > 0 ? 'background:#1ba2ff;color: #ffffff' : ''">
                                {{ item.operate }}
                            </div>
                            <div v-if="scope.$index === 3">{{ item.stage }}</div>
                            <div v-if="scope.$index === 4">{{ item.betStr }}</div>
                            <div v-if="scope.$index === 5" :class="textColor(item.bonusStr)">{{ !item.robot ? item.bonusStr : '' }}</div>
                            <div v-if="scope.$index === 6" :class="textColor(item.returnCoinStr)">{{ !item.robot ? item.returnCoinStr : '' }}</div>
                            <div v-if="scope.$index === 7" :class="textColor(item.taxStr)">{{ !item.robot ? item.taxStr : '' }}</div>
                        </template>
                    </el-table-column>
                </el-table>
            </div>

            <div class="game-round">
                <div id="classic_back" class="item_title mb-10">牌局回放</div>
                <el-table
                    class="back_table"
                    :span-method="rowSpanMethod"
                    :cell-class-name="tableRowClassName"
                    @cell-mouse-leave="cellMouseLeave"
                    @cell-mouse-enter="cellMouseEnter"
                    :row-style="{ height: '100px' }"
                    :header-row-style="{ height: '40px' }"
                    :data="roundList"
                    :border="true"
                >
                    <el-table-column width="50" align="center" label="轮次">
                        <template slot-scope="scope">
                            <span v-if="scope.row.stage > 0">{{ scope.row.stage }}</span>
                            <span v-if="scope.row.stage == 0">定庄</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="createTime" width="110" align="center" label="玩家">
                        <template slot-scope="scope">
                            <div :class="scope.row.leave ? 'leave_bg' : ''">
                                <div class="cell-item" style="width: 110px; text-align: center">
                                    <svg-icon v-if="scope.row.bank" icon-class="oms_lab_zhuangjia" class="z_tip" />
                                    <svg-icon v-if="scope.row.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                                    <UserIdJump v-if="!scope.row.robot" :id="scope.row.playerId" />
                                    <span v-if="scope.row.robot">{{ scope.row.playerId }}</span>

                                    <div v-if="scope.row.strategy">({{ scope.row.strategy }})</div>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column width="420" prop="card" align="center" label="操作位行为">
                        <template slot-scope="scope">
                            <div :class="scope.row.leave ? 'leave_bg' : ''" style="text-align: left; font-size: 12px">
                                <div class="cell-item" v-html="scope.row.operate"></div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column width="140" align="center" label="累计下注(操作后余额)">
                        <template slot-scope="scope">
                            <div :class="scope.row.leave ? 'leave_bg' : ''">
                                <div class="cell-item" style="margin: auto !important">{{ scope.row.betStr }}({{ scope.row.balanceStr }})</div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column width="420" align="center" label="非操作位操作行为">
                        <template slot-scope="scope">
                            <div :class="scope.row.leave ? 'leave_bg' : ''" style="text-align: left; font-size: 12px">
                                <div class="cell-item" v-html="scope.row.unOperate"></div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column width="100" align="center" label="当前奖金池">
                        <template slot-scope="scope">
                            <div :class="scope.row.leave ? 'leave_bg' : ''">
                                <div class="cell-item" style="margin: auto !important">{{ scope.row.bonusStr }}</div>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
                <pagination v-if="total" :page-sizes="[5, 10, 20]" :query="query" :total="total" @pageChangeHandler="getRound(true)" />
            </div>
        </div>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import Card from '@/components/Card'
import LmCardGroup from '@/components/Card/lmCardGroup.vue'
import * as api from '@/api/game/tp'
import Base from '@/views/base'
import UserIdJump from '@/components/UserIdJump'
import MultipleCard from '@/components/Card/MultipleCard'
import { STRATEGY_TYPE } from '@/constant/game'

const resultMap = {
    0: '牌桌号',
    1: '手牌',
    2: '结局',
    3: '轮次',
    4: '总下注金额',
    5: '系统结算输赢(扣税)',
    6: '实际输赢(扣税)',
    7: '税收收入'
}
export default {
    components: {
        Card,
        pagination,
        LmCardGroup,
        UserIdJump,
        MultipleCard
    },
    mixins: [Base],
    props: {
        flowId: {
            type: Number | String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            resultMap,
            STRATEGY_TYPE,
            playerCount: '',
            info: {},
            roundList: [], // 回合列表
            query: {
                size: 5,
                page: 1,
                flowId: this.flowId,
                turnsId: this.round
            },
            orderIndexArr: [], //按回合分组处理样式
            hoverOrderArr: [], //单元格hove记录
            indexCountArr: [], //用于记录合并数量
            count: '',
            total: 0
        }
    },
    computed: {},
    watch: {
        flowId: {
            handler(val) {
                val && this.initData()
            },
            immediate: true
        }
    },
    methods: {
        /** 获取详情 */
        initData() {
            this.rounds = []
            api.tpFlowDetail({ flowId: this.flowId })
                .then((rep) => {
                    this.info = rep.data
                    this.result = this.info.result
                    //玩家数量
                    this.playerCount = this.result.length
                    this.getRound()
                })
                .catch(() => {})
        },
        /** 获取回合回放数据 */
        getRound() {
            api.tpFlowTurns(this.query)
                .then((rep) => {
                    //初始化分页索引，合并表格
                    this.indexCountArr = []
                    this.orderIndexArr = []
                    this.count = 0

                    this.roundList = this.handleData(rep.data)
                    this.handleSpanGroup()
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {})
        },
        rowSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                const rowCell = this.indexCountArr[rowIndex]
                if (rowCell > 0) {
                    const colCell = 1
                    return {
                        rowspan: rowCell,
                        colspan: colCell
                    }
                } else {
                    return {
                        rowspan: 0,
                        colspan: 0
                    }
                }
            }
            return [1, 1]
        },
        getCardType(type) {
            const cardType = {
                0: '散牌',
                1: '对子',
                2: '同花',
                3: '顺子',
                4: '同花顺',
                5: '豹子'
            }
            return cardType[type]
        },
        handleData(data) {
            const tableData = []
            data.forEach((i) => {
                if (i.operates) {
                    i.operates.forEach((j) => {
                        j.stage = i.stage
                        tableData.push(j)
                    })
                }
            })
            // 处理合并表格索引
            for (let i = 0; i < tableData.length; i++) {
                if (i == 0) {
                    this.indexCountArr.push(1)
                    this.count = 0
                } else {
                    if (tableData[i].stage == tableData[i - 1].stage) {
                        this.indexCountArr[this.count] += 1
                        this.indexCountArr.push(0)
                    } else {
                        this.indexCountArr.push(1)
                        this.count = i
                    }
                }
            }

            return tableData
        },
        // 数据样式按第几圈分组
        handleSpanGroup() {
            const OrderObj = {}
            this.roundList.forEach((element, index) => {
                element.rowIndex = index
                if (OrderObj[element.stage]) {
                    OrderObj[element.stage].push(index)
                } else {
                    OrderObj[element.stage] = []
                    OrderObj[element.stage].push(index)
                }
            })
            for (const k in OrderObj) {
                if (OrderObj[k].length > 1) {
                    this.orderIndexArr.push(OrderObj[k])
                }
            }
        },
        // 处理类名
        tableRowClassName({ rowIndex }) {
            const arr = this.hoverOrderArr
            for (let i = 0; i < arr.length; i++) {
                if (rowIndex === arr[i]) {
                    return 'hovered-row'
                }
            }
        },
        // 单元格 hover 进入
        cellMouseEnter(row, column, cell, event) {
            this.rowIndex = row.rowIndex
            this.hoverOrderArr = []
            this.orderIndexArr.forEach((element) => {
                if (element.indexOf(this.rowIndex) >= 0) {
                    this.hoverOrderArr = element
                }
            })
        },
        // 单元格 hover 退出
        cellMouseLeave() {
            this.rowIndex = '-1'
            this.hoverOrderArr = []
        }
    }
}
</script>

<style lang="scss" scoped>
.result-table {
    ::v-deep .el-table--enable-row-hover .el-table__body tr:hover > td {
        background-color: rgba(0, 0, 0, 0) !important;
    }
}
.game-round {
    ::v-deep .el-table .el-table__cell {
        padding: 0 !important;
    }
    ::v-deep .el-table .cell {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
    .leave_bg {
        height: 100px;
        overflow-y: auto;
        width: 100%;
        background: rgba(255, 231, 128, 0.3);
        display: flex;
    }
    .cell-item {
        height: 100px;
        align-self: center;
        justify-content: center;
    }
}
</style>
