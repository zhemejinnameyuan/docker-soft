<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" label-position="left" style="width: 1300px">
                <span class="head-title">留局配置</span>
                <div class="dp-f">
                    <div class="item" style="margin-left: 40px">
                        <el-form-item label="赢留局概率(%):" prop="winStayPercent">
                            <InputNumber v-model="form.winStayPercent" range-width="100px" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item ml-40">
                        <el-form-item label="输留局概率(%):" prop="loseStayPercent">
                            <InputNumber v-model="form.loseStayPercent" range-width="100px" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                        </el-form-item>
                    </div>
                </div>

                <span class="head-title">离场配置</span>
                <div class="dp-f">
                    <div class="item" style="margin-left: 40px">
                        <el-form-item label="连续同局次数:" prop="playRound">
                            <InputNumber v-model="form.playRound" range-width="100px" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'

export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: null,
            rules: {
                winStayPercent: [{ required: true, message: '请输入赢留局概率', trigger: 'blur' }],
                loseStayPercent: [{ required: true, message: '请输入输留局概率', trigger: 'blur' }],
                playRound: [{ required: true, message: '请输入同局次数', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
