<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="play">
                <span slot="title">陪玩机器人</span>
            </el-menu-item>
            <el-menu-item index="bind">
                <span slot="title">Bind状态配置</span>
            </el-menu-item>
            <el-menu-item index="see">
                <span slot="title">看牌状态配置</span>
            </el-menu-item>
            <el-menu-item index="out">
                <span slot="title">留局离场</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <Play v-if="type === 'play' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.tpRobotSave]" />
            <Bind v-if="type === 'bind' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.tpRobotSave]" />
            <See v-if="type === 'see' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.tpRobotSave]" />
            <Out v-if="type === 'out' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.tpRobotSave]" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/game/tp'
import { GAME_TYPE } from '@/constant/game'
import Play from './play'
import Bind from './bind'
import See from './see'
import Out from './out'

export default {
    components: {
        Play,
        Bind,
        See,
        Out
    },
    mixins: [Base],
    data() {
        return {
            GAME_TYPE,
            type: 'play',
            configData: null
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        handleSelect(type) {
            this.type = type
            this.toQuery()
        },
        //查询
        toQuery() {
            api.tpGetRobotConfig().then((rep) => {
                this.repData = rep.data
                this.configData = { ...this.repData.jsonConfig }
            })
        },
        //保存
        toSubmit(configData) {
            this.repData.jsonConfig = { ...configData }
            api.tpSaveRobotConfig(this.repData).then((rep) => {
                this.$message.success('保存成功')
            })
        }
    }
}
</script>
