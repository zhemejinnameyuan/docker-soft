<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" labelWidth="330px" label-position="left" style="width: 1300px">
                <span class="head-title">Blind状态</span>
                <div class="dp-c">
                    <div class="dp-f">
                        <div style="margin-left: 40px">
                            <span class="head-title">非操作位看牌行为</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <el-form-item label="场上无人看牌，看牌概率(‱)：" prop="blindNoneSee">
                                    <InputNumber v-model="form.blindNoneSee" range-width="100px" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                                </el-form-item>
                                <el-form-item label="场上有人看牌（下注未加倍），看牌概率(‱)：" prop="blindNoneSeeChaal">
                                    <InputNumber v-model="form.blindNoneSeeChaal" range-width="100px" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                                </el-form-item>
                                <el-form-item label="场上有人看牌（下注有加倍），看牌概率(‱)：" prop="blindNoneSeeChaal2">
                                    <InputNumber v-model="form.blindNoneSeeChaal2" range-width="100px" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                                </el-form-item>
                            </div>
                        </div>
                    </div>

                    <div class="dp-f mt-20">
                        <div style="margin-left: 40px">
                            <span class="head-title">操作位行为</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <div class="item">
                                    <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                        <el-table-column label="形势分" align="center" width="200">
                                            <template slot-scope="scope">{{ configTitle[scope.row] }}</template>
                                        </el-table-column>
                                        <el-table-column label="看牌概率" align="center" width="200px">
                                            <template slot-scope="scope">形势分/400*100%</template>
                                        </el-table-column>
                                        <el-table-column label="跟注权重" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <InputNumber v-model="form.blindSituationOp[scope.row].y" :rangeWidth="'160px'" placeholder="" :min-number="0" :max-number="10000" clearable />
                                            </template>
                                        </el-table-column>

                                        <el-table-column label="加注权重" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <InputNumber v-model="form.blindSituationOp[scope.row].z" :rangeWidth="'160px'" placeholder="" :min-number="0" :max-number="10000" clearable />
                                            </template>
                                        </el-table-column>
                                    </el-table>

                                    <div class="mt-20 text_blue fs-12">配置说明：权重取值范围0～10000，跟注权重+加注权重=10000</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { range } from '@/utils'

export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {},
            config: [],
            configTitle: {
                0: '<=100',
                1: '100<形势分<=500',
                2: '500<形势分<=2000',
                3: '>2000'
            },
            rules: {
                blindNoneSee: [{ required: true, message: '请输入概率', trigger: 'blur' }],
                blindNoneSeeChaal: [{ required: true, message: '请输入概率', trigger: 'blur' }],
                blindNoneSeeChaal2: [{ required: true, message: '请输入概率', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },
    methods: {
        initData() {
            this.config = range(0, 3)
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    for (let i = 0; i < this.form.blindSituationOp.length; i++) {
                        let item = this.form.blindSituationOp[i]
                        if (_.add(item.y, item.z) != 10000) {
                            return this.$message.error('形式分:' + this.configTitle[i] + '配置，跟注权重+加注权重 必须为10000')
                        }
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
