<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" labelWidth="330px" label-position="left" style="width: 1300px">
                <span class="head-title">看牌状态</span>
                <div class="dp-c">
                    <div class="dp-f">
                        <div style="margin-left: 40px">
                            <span class="head-title">非操作位行为</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <el-table :data="[1]" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                    <el-table-column label="机器人牌型" align="center" width="160px">
                                        <template slot-scope="scope">
                                            <div>侧边比牌同意权重</div>
                                            <div class="mt-30">侧边比牌拒绝权重</div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="中单及以下" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.a" :rangeWidth="'140px'" placeholder="0~10000" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.a)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>

                                    <el-table-column label="大单和中对" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.b" :rangeWidth="'140px'" placeholder="0~100" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.b)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="大对及小同花" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.c" :rangeWidth="'140px'" placeholder="0~100" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.c)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="中同花及大同花" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.d" :rangeWidth="'140px'" placeholder="0~100" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.d)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="小顺及中顺" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.e" :rangeWidth="'140px'" placeholder="0~100" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.e)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="大顺及以上" align="center" width="165px">
                                        <template slot-scope="scope">
                                            <div class="dp-c">
                                                <div>
                                                    <InputNumber v-model="form.seenSideShow.f" :rangeWidth="'140px'" placeholder="0~100" :min-number="0" :max-number="10000" clearable />
                                                </div>
                                                <div class="mt-10">
                                                    <InputNumber
                                                        :value="_.subtract(10000, form.seenSideShow.f)"
                                                        :rangeWidth="'140px'"
                                                        placeholder="0~10000"
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        :disabled="true"
                                                    />
                                                </div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                </el-table>

                                <div class="text_blue fs-12 mt-10">配置说明：权重取值范围0～10000，同一牌型侧边比牌同意权重+侧边比牌拒绝权重=10000</div>
                            </div>
                        </div>
                    </div>

                    <div class="dp-f mt-20">
                        <div style="margin-left: 40px">
                            <span class="head-title">操作位行为</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <div class="item">
                                    <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                        <el-table-column label="形势分" align="center" width="150px">
                                            <template slot-scope="scope">{{ configTitle[scope.row] }}</template>
                                        </el-table-column>
                                        <el-table-column label="中对及以下" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <div class="dp-c">
                                                    <div class="dp-f-vertical-center">
                                                        <span class="action-title">弃牌概率‱</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].b.a" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">比牌权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].b.b" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">跟注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].b.c" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">加注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].b.d" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                </div>
                                            </template>
                                        </el-table-column>

                                        <el-table-column label="大对及小同花" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <div class="dp-c">
                                                    <div class="dp-f-vertical-center">
                                                        <span class="action-title">弃牌概率‱</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].c.a" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">比牌权重</span>
                                                        <InputNumber
                                                            v-model="form.seenSituationOp[scope.row].c.b"
                                                            placeholder="0~10000"
                                                            :rangeWidth="'100px'"
                                                            :min-number="0"
                                                            :max-number="10000"
                                                            clearable
                                                        />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">跟注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].c.c" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">加注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].c.d" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="中同花及大同花" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <div class="dp-c">
                                                    <div class="dp-f-vertical-center">
                                                        <span class="action-title">弃牌概率‱</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].d.a" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">比牌权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].d.b" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">跟注权重</span>
                                                        <InputNumber
                                                            v-model="form.seenSituationOp[scope.row].d.c"
                                                            placeholder="0~10000"
                                                            :rangeWidth="'100px'"
                                                            :min-number="0"
                                                            :max-number="10000"
                                                            clearable
                                                        />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">加注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].d.d" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="小顺及中顺" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <div class="dp-c">
                                                    <div class="dp-f-vertical-center">
                                                        <span class="action-title">弃牌概率‱</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].e.a" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">比牌权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].e.b" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">跟注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].e.c" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">加注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].e.d" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="大顺及以上" align="center" width="200px">
                                            <template slot-scope="scope">
                                                <div class="dp-c">
                                                    <div class="dp-f-vertical-center">
                                                        <span class="action-title">弃牌概率‱</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].f.a" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">比牌权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].f.b" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">跟注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].f.c" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                    <div class="dp-f-vertical-center mt-5">
                                                        <span class="action-title">加注权重</span>
                                                        <InputNumber v-model="form.seenSituationOp[scope.row].f.d" :rangeWidth="'100px'" :min-number="0" :max-number="10000" clearable />
                                                    </div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                    </el-table>

                                    <div class="mt-20 text_blue fs-12">配置说明：优先执行弃牌操作(杀牌机器人不执行弃牌行为)，若未触发弃牌，则从比牌、跟注、加注中触发一个行为执行</div>
                                    <div class="mt-20 text_blue fs-12">概率和权重取值范围0～10000，同一形势分的同一牌型比牌权重+跟注权重+加注权重=10000</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { range } from '@/utils'

export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {
                seenSideShow: {}
            },
            config: [],
            configTitle: {
                0: '<=-700',
                1: '-700<形势分<=0',
                2: '0<形势分<=2800',
                3: '>2800'
            },
            configRowTitle: {
                b: '中对及以下',
                c: '大对及小同花',
                d: '中同花及大同花',
                e: '小顺及中顺',
                f: '大顺及以上'
            },
            rules: {}
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },
    methods: {
        initData() {
            this.config = range(0, 3)
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    //非操作位行为
                    for (let i in this.form.seenSideShow) {
                        let item = this.form.seenSideShow[i]
                        if (_.isNull(item)) {
                            return this.$message.error('非操作位:权重不能为空')
                        }
                    }
                    //操作位行为
                    for (let i = 0; i < this.form.seenSituationOp.length; i++) {
                        let item = this.form.seenSituationOp[i]
                        for (let childKey in item) {
                            let childItem = item[childKey]
                            if (_.isNull(childItem.a) || _.isNull(childItem.b) || _.isNull(childItem.c) || _.isNull(childItem.d)) {
                                return this.$message.error('操作位行为:形式分:' + this.configTitle[i] + ',牌型<' + this.configRowTitle[childKey] + '>，概率或权重不能为空')
                            }
                            if (childKey === 'a') continue
                            if (_.sum([childItem.b, childItem.c, childItem.d]) !== 10000) {
                                return this.$message.error('操作位行为:形式分:' + this.configTitle[i] + ',牌型<' + this.configRowTitle[childKey] + '>，比牌权重+跟注权重+加注权重 必须为10000')
                            }
                        }
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.action-title {
    margin-right: 10px;
    font-size: 12px;
    width: 70px;
}
</style>
