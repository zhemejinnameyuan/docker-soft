<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" label-position="top">
                <div class="horizontal-container">
                    <div class="item card-type-table">
                        <el-table :data="cardConfig" class="common_form_table" :row-style="{ height: '60px' }">
                            <el-table-column label="牌型" align="center" width="180">
                                <template slot-scope="scope">{{ scope.row.title }}</template>
                            </el-table-column>
                            <el-table-column label="自然概率(万分比)" align="center" width="180">
                                <template slot-scope="scope">{{ scope.row.initRate }}</template>
                            </el-table-column>
                            <el-table-column label="调整系数" align="center" width="180">
                                <template slot-scope="scope">
                                    <span v-if="scope.$index == 0">--</span>
                                    <span v-if="scope.$index != 0">{{ _.round(_.divide(form.dealPercent[scope.row.model], scope.row.initRate), 2) }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column label="调整概率(万分比)" align="center" width="150px">
                                <template slot-scope="scope">
                                    <el-input
                                        v-model="form.dealPercent[scope.row.model]"
                                        range-width="120px"
                                        @change="inputChange"
                                        :min-number="0"
                                        :max-number="10000"
                                        placeholder="0-10000"
                                        clearable
                                        :disabled="scope.$index === 0"
                                    />
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="[permission.tpGlobalSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/tp'
import { form } from '@/components/Crud/crud'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {
                dealPercent: {
                    a: '',
                    b: '',
                    c: '',
                    d: '',
                    e: '',
                    f: ''
                }
            },
            cardConfig: [
                { title: '散牌', initRate: '7438', updateRate: '0', model: 'a' },
                { title: '对子', initRate: '1694', updateRate: '0', model: 'b' },
                { title: '同花', initRate: '496', updateRate: '0', model: 'c' },
                { title: '顺子', initRate: '326', updateRate: '0', model: 'd' },
                { title: '同花顺', initRate: '22', updateRate: '0', model: 'e' },
                { title: '豹子', initRate: '24', updateRate: '0', model: 'f' }
            ]
        }
    },
    mounted() {
        this.toQuery()
    },

    methods: {
        inputChange() {
            let updateRateSum = 0
            let isFullRate = -1
            this.cardConfig.forEach((rep, index) => {
                if (this.form.dealPercent[rep.model] > 10000) {
                    this.form.dealPercent[rep.model] = 10000
                }
                if (this.form.dealPercent[rep.model] < 0) {
                    this.form.dealPercent[rep.model] = 0
                }

                if (index != 0) {
                    updateRateSum += _.toNumber(this.form.dealPercent[rep.model])
                }
                if (this.form.dealPercent[rep.model] == 10000 && index !== 0) {
                    isFullRate = index
                }
            })

            if (isFullRate != -1) {
                this.cardConfig.forEach((rep, index) => {
                    if (index != isFullRate) {
                        this.form.dealPercent[this.cardConfig[index].model] = 0
                    }
                })
            } else {
                if (updateRateSum > 10000) {
                    console.log(updateRateSum)
                    return this.$message.warning('概率累加超过10000')
                } else {
                    this.form.dealPercent[this.cardConfig[0].model] = 10000 - updateRateSum
                }
            }
        },
        toQuery() {
            api.tpGlobalGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    let updateRateSum = 0
                    this.cardConfig.forEach((rep, index) => {
                        updateRateSum += _.toNumber(this.form.dealPercent[rep.model])
                    })

                    if (updateRateSum > 10000) {
                        return this.$message.error('概率累加超过10000')
                    }

                    this.repData.jsonConfig = { ...this.form }
                    api.tpGlobalSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
<style lang="scss" scoped>
// 取消element原有的input框样式
::v-deep .el-input__inner {
    height: 40px;
    font-size: 16px;
}
//居中对齐
.center-input {
    ::v-deep .el-input__inner {
        text-align: center;
    }
}

//关闭hover
.card-type-table {
    ::v-deep .el-table tbody tr:hover {
        td:first-child {
            background: rgba(27, 162, 255, 0.1) !important;
        }
        td:not(first-child) {
            background-color: transparent !important;
        }
    }
}

::v-deep .el-table .el-table__row td:first-child {
    background: rgba(27, 162, 255, 0.1);
    border: 1px solid rgba(220, 223, 230, 1);
}
</style>
