<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-position="top">
                <span class="head-title">新手保护策略</span>
                <el-form-item label="新手保护策略开关:" prop="reservoir.newbieSwitch" label-width="110px" class="inline-item">
                    <el-switch v-model="form.reservoir.newbieSwitch" />
                </el-form-item>

                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="新手保护局数:" prop="reservoir.newbieWin.l">
                            <InputNumber v-model="form.reservoir.newbieWin.l" range-width="200px" :single-big-input="true" placeholder="0-10" :min-number="0" :max-number="10" clearable />
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="玩家作弊概率（万分比）:" prop="reservoir.newbieWin.r">
                            <InputNumber v-model="form.reservoir.newbieWin.r" range-width="200px" :single-big-input="true" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                        </el-form-item>
                    </div>
                </div>
                <span class="head-title">新手房间</span>
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="新手房选择:" prop="reservoir.newbieRoomIds">
                            <el-select v-model="form.reservoir.newbieRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in rooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="[permission.tpGlobalSave]" class="filter-item" size="medium" type="primary" title="保存" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/tp'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            query: { all: true, enableFlag: true },
            form: {
                reservoir: {
                    newbieWin: { l: '', r: '' }
                }
            },
            rooms: [],
            rules: {
                'reservoir.newbieSwitch': [{ required: true, message: '请选择新手保护策略开关', trigger: 'blur' }],
                'reservoir.newbieWin.l': [{ required: true, message: '请配置新手保护局数', trigger: 'blur' }],
                'reservoir.newbieWin.r': [{ required: true, message: '请配置玩家作弊概率', trigger: 'blur' }],
                'reservoir.newbieRoomIds': [{ required: true, message: '请选择新手房间', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.getRoom()
        this.toQuery()
    },

    methods: {
        getRoomTitle(item) {
            var config = item.baseConfig
            return `${config.deskPlayer}人房｜底注${config.anteCoin}`
        },

        getRoom() {
            if (this.checkPermission([this.permission.tpRoomList])) {
                api.tpRoomList(this.query).then((rep) => {
                    this.rooms = rep.data
                })
            }
        },
        toQuery() {
            api.tpGlobalGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    api.tpGlobalSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
