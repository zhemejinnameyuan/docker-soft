<template>
    <div class="web-container" style="background: #f7f7f7">
        <GoHome />
        <div class="container_title">TP-游戏管理</div>
        <div class="container_game">
            <div class="game_tab">
                <div v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :class="tabClass(item.type)" @click="changeTab(item.type)">
                    {{ item.title }}
                </div>
            </div>
            <div class="game_content">
                <TP v-if="type === 'tp'" />
                <Robot v-if="type === 'robot'" />
                <Global v-if="type === 'global'" />
                <Practise v-if="type === 'practise'" />
            </div>
        </div>
    </div>
</template>

<script>
import TP from './tp/index.vue'
import Robot from './robot/index.vue'
import Global from './global/index.vue'
import Practise from './practise/index.vue'
import Base from '@/views/base'
import GoHome from '@/components/GoHome'

export default {
    name: 'TpGame',
    components: {
        TP,
        Robot,
        Global,
        Practise,
        GoHome
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'tp',
                title: 'TP管理',
                permissions: [this.permission.tpRoomList, this.permission.tpFlowList]
            },
            {
                type: 'robot',
                title: '机器人',
                permissions: [this.permission.tpRobotSave, this.permission.tpRobotGet]
            },
            {
                type: 'global',
                title: '全局配置',
                permissions: [this.permission.tpGlobalSave, this.permission.tpGlobalGet]
            },
            {
                type: 'practise',
                title: '练习场',
                permissions: [this.permission.tpRoomPracticeList, this.permission.tpConfigPracticeGet]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        tabClass(type) {
            return type === this.type ? 'game_tab_item_active' : 'game_tab_item'
        },
        changeTab(type) {
            this.type = type
        }
    }
}
</script>
