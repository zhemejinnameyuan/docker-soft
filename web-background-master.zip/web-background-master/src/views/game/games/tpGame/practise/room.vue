<template>
    <div class="game-common-record no-scrollbar">
        <div class="head-container">
            <el-row>
                <el-select v-model="query.enableFlag" placeholder="状态" size="medium" class="filter-item" style="width: 160px" @change="toQuery">
                    <el-option v-for="item in roomStates" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.anteCoin" placeholder="底注金额" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in anteCoins" :key="item" :label="item" :value="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end" style="margin-top: 10px">
                <IconButton v-permission="[permission.tpRoomPracticeAdd]" size="medium" type="primary" icon="oms_ico_add" title="创建房间" @click="toAdd" />
            </el-row>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row :height="table_height" style="width: 100%; margin-top: 20px" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="220" align="center" label="ID">
                <template slot-scope="scope">
                    <svg-icon v-if="scope.row.newbieRoom && scope.row.baseConfig.enableFlag" icon-class="oms_lab_xin" class="new_tag" />
                    <span>{{ scope.row.id }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140" align="center" label="底注金额">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.anteCoin | filterCion }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="房间准入金额">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.joinMinCoin | filterCion }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" label="Chaal最大金额" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.chaalMaxCoin | filterCion }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" label="奖池上限金额" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.jackpotMaxCoin }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" prop="playerCount" align="center" label="在线玩家数">
                <template slot-scope="scope">
                    <span>{{ _.add(scope.row.playerCount, scope.row.robotCount, scope.row.navyNumber) }}</span>
                </template>
            </el-table-column>
            <el-table-column width="140" align="center" label="状态">
                <template slot-scope="scope">
                    <div class="table_state_switch">
                        <el-switch v-model="scope.row.baseConfig.enableFlag" @change="roomStateChange(scope.row)" :disabled="scope.row.newbieRoom"></el-switch>
                    </div>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" prop="updateTime" align="center" label="操作">
                <template slot-scope="scope">
                    <IconButton v-permission="[permission.tpRoomPracticeEdit]" type="text" class="mr-10" size="medium" style="font-size: 20px" icon="oms_ico_edit" @click="toEdit(scope.row)" />
                </template>
            </el-table-column>
        </el-table>
        <Drawer class="drawer" :title="drawerTitle" :visible.sync="drawer">
            <div class="drawer_content">
                <el-form ref="form" :model="form" :rules="rules" label-width="160px">
                    <span class="drawer_content_title">房间基础配置</span>
                    <div class="item_bg">
                        <el-form-item label="房间开关:" prop="enableFlag">
                            <el-switch v-model="form.enableFlag" />
                        </el-form-item>
                        <el-form-item label="底注金额:" prop="anteCoin">
                            <InputNumber v-model="form.anteCoin" range-width="280px" :precision="2" placeholder="0-9999999" :min-number="0" :max-number="9999999" clearable />
                            <span class="tips">精确到小数点后2位</span>
                        </el-form-item>

                        <el-form-item label="房间准入金额:" prop="joinMinCoin">
                            <InputNumber v-model="form.joinMinCoin" range-width="280px" :precision="2" placeholder="0-9999999" :min-number="0" :max-number="9999999" clearable />
                        </el-form-item>
                        <el-form-item label="Chaal最大金额:" prop="chaalMaxCoin">
                            <InputNumber v-model="form.chaalMaxCoin" range-width="280px" :precision="2" placeholder="0-9999999" :min-number="0" :max-number="9999999" clearable />
                            <span class="tips">单次下注最大金额=2*Chaal，通常Chaal最大金额=底注金额*128</span>
                        </el-form-item>
                        <el-form-item label="奖池最大金额:" prop="jackpotMaxCoin">
                            <InputNumber v-model="form.jackpotMaxCoin" range-width="280px" :precision="2" placeholder="0-9999999" :min-number="0" :max-number="9999999" clearable />
                            <span class="tips">通常奖池最大金额=底注金额*1024</span>
                        </el-form-item>
                        <el-form-item label="礼物价格:" prop="giftCoin">
                            <InputNumber v-model="form.giftCoin" :precision="2" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable :disabled="true" />
                        </el-form-item>
                    </div>
                </el-form>
            </div>
            <div class="footer">
                <IconButton class="filter-item" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
            </div>
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import { roomState } from '@/constant/game'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/tp'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    page: 1,
    size: 10,
    sort: 'createTime;desc',
    all: true,
    enableFlag: true,
    deskPlayer: null,
    anteCoin: null
}
const defaultRoom = {
    deskPlayer: '5', // 牌桌类型
    anteCoin: '', // 底注
    taxPercent: 0, // 税率
    depositedPercent: 100, // D账户
    winningsPercent: 0, // W账户
    enableFlag: true, // 房间状态
    joinMinCoin: '' // 最小入场金额
}
export default {
    components: {
        Drawer,
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            roomStates: Object.values(roomState),
            anteCoins: [],
            form: {},
            drawer: false,
            drawerType: '',
            drawerTitle: '',
            loading: false,
            query: { ...defaultQuery },
            list: [],
            roomId: undefined,
            rules: {
                anteCoin: [{ required: true, message: '请输入底注金额', trigger: 'blur' }],
                taxPercent: [{ required: true, message: '请输入税率', trigger: 'blur' }],
                enableFlag: [{ required: true, message: '请选择房间状态', trigger: 'blur' }],
                joinMinCoin: [{ required: true, message: '请输入最小入场金额', trigger: 'blur' }]
            }
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 300
        this.toQuery()
    },

    methods: {
        getRoomState(type) {
            return roomState[type] ? roomState[type].name : ''
        },
        toAdd() {
            this.form = { ...defaultRoom }
            this.drawerType = 'add'
            this.drawer = true
            this.drawerTitle = '创建房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toEdit(row) {
            this.drawerType = 'edit'
            this.roomId = row.id
            this.form = { ...row.baseConfig }
            this.drawer = true
            this.drawerTitle = '编辑房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toDetail(row) {
            this.drawerType = 'detail'
            this.form = { ...row }
            this.drawer = true
            this.drawerTitle = '房间详情'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery() {
            // 查询房间列表和dz
            if (this.checkPermission([this.permission.tpRoomPracticeList])) {
                api.tpPracticeRoomList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                    })
                    .catch(() => {})
                api.tpPracticeRoomAnte(this.query)
                    .then((rep) => {
                        this.anteCoins = rep.data
                    })
                    .catch(() => {})
            }
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.drawerType === 'add') {
                        api.tpPracticeRoomAdd({ baseConfig: this.form })
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间添加成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                    if (this.drawerType === 'edit') {
                        var dic = { baseConfig: this.form, id: this.roomId }
                        api.tpPracticeRoomEdit(dic)
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间编辑成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                }
            })
        },
        roomStateChange(data) {
            if (!data.baseConfig.enableFlag) {
                confirmRequest(
                    '禁用以后游戏中将不展示该房间，房间内的玩家结束后将全部离开。确定是否禁用？',
                    () => {
                        this.toEnabled(data)
                    },
                    () => {
                        data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                    }
                )
            } else {
                this.toEnabled(data)
            }
        },
        toEnabled(data) {
            if (this.checkPermission([this.permission.tpRoomPracticeEnableDisable])) {
                api.tpPracticeRoomEnableDisable(data)
                    .then((res) => {
                        if (data.baseConfig.enableFlag) {
                            this.$message.success('启用成功')
                        } else {
                            this.$message.success('禁用成功')
                        }
                        this.toQuery()
                    })
                    .catch(() => {
                        data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                    })
            }
        }
    }
}
</script>
