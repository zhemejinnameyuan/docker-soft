<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="fjlb">
                <span slot="title">房间列表</span>
            </el-menu-item>
            <el-menu-item index="jepz">
                <span slot="title">金额配置</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <Room v-if="type === 'fjlb'" />
            <Coin v-if="type === 'jepz'" />
        </div>
    </div>
</template>

<script>
import Room from './room.vue'
import Coin from './coin.vue'
import Base from '@/views/base'

export default {
    components: {
        Room,
        Coin
    },
    mixins: [Base],
    data() {
        return {
            type: 'fjlb'
        }
    },
    mounted() {},
    methods: {
        handleSelect(type) {
            this.type = type
        }
    }
}
</script>
