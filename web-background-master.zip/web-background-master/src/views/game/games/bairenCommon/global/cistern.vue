<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">蓄水池</span>
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="初始值:" prop="globalConfig.reservoir.bankCoin">
                            <InputNumber
                                v-model="form.globalConfig.reservoir.bankCoin"
                                range-width="200px"
                                :single-big-input="true"
                                :min-number="1"
                                :max-number="9999999999"
                                placeholder="0-20000000"
                                clearable
                            />
                            <span class="tips">最后修改时间: {{ form.globalConfig.reservoir.bankCoinChangeTime | filterEmpty }}</span>
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="重置周期:" prop="globalConfig.reservoir.resetPeriod">
                            <el-select v-model="form.globalConfig.reservoir.resetPeriod" size="medium" placeholder="请选择重置周期" style="width: 200px" clearable>
                                <el-option v-for="item in resetCycle" :key="item.id" :label="item.name" :value="item.id" />
                            </el-select>
                            <span class="tips">从0分0秒开始每N分钟执行一次</span>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { isEqual } from '@/utils/object'
import InputNumberRange from '@/components/InputNumberRange'
import { resetCycle } from '@/constant/game'
export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            resetCycle: resetCycle,
            form: null,
            origin: null,
            rules: {
                'globalConfig.reservoir.bankCoin': [{ required: true, message: '请输入初始金额', trigger: 'blur' }],
                'globalConfig.reservoir.resetPeriod': [{ required: true, message: '请选择重置周期', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },

    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (isEqual(this.form, this.origin)) {
                        this.$message.success('保存成功')
                    } else {
                        this.$emit('toSubmit', this.form)
                    }
                }
            })
        }
    }
}
</script>
