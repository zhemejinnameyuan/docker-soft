<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" label-width="205px" label-position="top">
                <span class="head-title">抽水策略</span>
                <el-form-item label="抽水策略开关:" prop="globalConfig.killSwitch" class="inline-item">
                    <el-switch v-model="form.globalConfig.reservoir.killOpen" />
                </el-form-item>

                <span class="head-title">抽水档位</span>
                <div class="horizontal-container mt-20">
                    <div class="item">
                        <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                            <el-table-column label="档位" align="center" width="100">
                                <template slot-scope="scope">抽水{{ scope.$index + 1 }}档</template>
                            </el-table-column>
                            <el-table-column label="开始值" align="center" width="160px">
                                <template slot-scope="scope">
                                    <InputNumber
                                        v-model="form.globalConfig.reservoir.killList[scope.$index].x"
                                        range-width="140px"
                                        :min-number="-1"
                                        :precision="2"
                                        :max-number="10"
                                        placeholder="-1-10"
                                        clearable
                                    />
                                </template>
                            </el-table-column>
                            <el-table-column label="条件" align="center" width="150px">
                                <template slot-scope="scope">
                                    <span v-if="scope.$index != 7" v-html="'<=t<'"></span>
                                    <span v-if="scope.$index == 7" v-html="'< t'"></span>
                                </template>
                            </el-table-column>
                            <el-table-column label="结束值" align="center" width="160px">
                                <template slot-scope="scope">
                                    <InputNumber
                                        :disabled="scope.$index == 7"
                                        v-model="form.globalConfig.reservoir.killList[scope.$index].y"
                                        range-width="140px"
                                        :min-number="-1"
                                        :precision="2"
                                        :max-number="10"
                                        placeholder="-1-10"
                                        clearable
                                    />
                                </template>
                            </el-table-column>
                            <el-table-column label="概率(万分比)" align="center" width="160px">
                                <template slot-scope="scope">
                                    <InputNumber
                                        v-model="form.globalConfig.reservoir.killList[scope.$index].z"
                                        range-width="140px"
                                        :min-number="0"
                                        :max-number="10000"
                                        placeholder="0-10000"
                                        clearable
                                    />
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { range } from '@/utils'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: {
                globalConfig: {
                    reservoir: {
                        killList: []
                    }
                }
            },
            config: []
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },

    methods: {
        initData() {
            this.config = range(1, 8)
            for (let i in this.config) {
                if (this.form.globalConfig.reservoir.killList[i] === undefined) {
                    this.form.globalConfig.reservoir.killList[i] = { x: '', y: '', z: '' }
                }
            }

            //第八档位结束值设置为-1
            this.form.globalConfig.reservoir.killList[7].y = -1
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    let total = 0
                    for (let i in this.form.globalConfig.reservoir.killList) {
                        let tmp = this.form.globalConfig.reservoir.killList[i]
                        if (tmp['x'] <= 0 && tmp['x'] != -1) {
                            return this.$message.error('第' + (_.toNumber(i) + 1) + '档，开始值有误,应为0.1～10和-1')
                        }
                        if (tmp['y'] <= 0 && tmp['y'] != -1) {
                            return this.$message.error('第' + (_.toNumber(i) + 1) + 1 + '档，结束值有误,应为0.1～10和-1')
                        }

                        total += tmp['z']
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
