<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">无策略</span>

                <el-form-item label="概率(%):" prop="globalConfig.cheatPercent">
                    <InputNumber v-model="form.globalConfig.cheatPercent" range-width="200px" :single-big-input="true" :min-number="1" :max-number="100" placeholder="0-100" clearable />
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: null,
            rules: {
                'globalConfig.cheatPercent': [{ required: true, message: '请输入概率', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },

    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
