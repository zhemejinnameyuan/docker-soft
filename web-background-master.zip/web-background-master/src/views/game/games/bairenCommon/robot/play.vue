<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="240px" label-position="top">
                <span class="head-title">陪玩机器人</span>
                <el-form-item label="陪玩机器人开关:" prop="playEnableFlag" label-width="130px" class="inline-item">
                    <el-switch v-model="form.playEnableFlag" />
                </el-form-item>
                <el-form-item label="下注量（取整倍数）%:" prop="playBetTimes">
                    <div class="form_item">
                        <div class="item_bg">
                            <span class="input-append-desc">非R</span>
                            &ensp;
                            <InputNumberRange
                                v-model="form.playBetTimes.a"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="10"
                                max-placeholder="100"
                                :min-number="10"
                                :max-number="100"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">小R</span>
                            &ensp;
                            <InputNumberRange
                                v-model="form.playBetTimes.b"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="10"
                                max-placeholder="100"
                                :min-number="10"
                                :max-number="100"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">中R</span>
                            <InputNumberRange
                                v-model="form.playBetTimes.c"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="10"
                                max-placeholder="100"
                                :min-number="10"
                                :max-number="100"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">大R</span>
                            &ensp;
                            <InputNumberRange
                                v-model="form.playBetTimes.d"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="10"
                                max-placeholder="100"
                                :min-number="10"
                                :max-number="100"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">超R</span>
                            <InputNumberRange
                                v-model="form.playBetTimes.e"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="10"
                                max-placeholder="100"
                                :min-number="10"
                                :max-number="100"
                                clearable
                            />
                        </div>
                    </div>
                </el-form-item>
                <el-form-item label="机器人下注概率(%):" prop="playBetPercent">
                    <div class="form_item">
                        <div class="item_bg">
                            <span class="input-append-desc">非R</span>
                            <InputNumber v-model="form.playBetPercent.a" :min-number="1" :max-number="100" placeholder="1-100" range-width="100px" :text-center="true" clearable />
                            <span class="input-append-desc">%</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">小R</span>
                            <InputNumber v-model="form.playBetPercent.b" :min-number="1" :max-number="100" placeholder="1-100" range-width="100px" :text-center="true" clearable />
                            <span class="input-append-desc">%</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">中R</span>
                            <InputNumber v-model="form.playBetPercent.c" :min-number="1" :max-number="100" placeholder="1-100" range-width="100px" :text-center="true" clearable />
                            <span class="input-append-desc">%</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">大R</span>
                            <InputNumber v-model="form.playBetPercent.d" :min-number="1" :max-number="100" placeholder="1-100" range-width="100px" :text-center="true" clearable />
                            <span class="input-append-desc">%</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">超R</span>
                            <InputNumber v-model="form.playBetPercent.e" :min-number="1" :max-number="100" placeholder="1-100" range-width="100px" :text-center="true" clearable />
                            <span class="input-append-desc">%</span>
                        </div>
                    </div>
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import InputNumberRange from '@/components/InputNumberRange'
import { GAME_TYPE } from '@/constant/game'
import { checkObj } from '@/utils/filters'
export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        },
        gameType: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            GAME_TYPE,
            form: null,
            rules: {
                playEnableFlag: [{ required: true, message: '', trigger: 'blur' }],
                playBetTimes: [{ required: true, validator: checkObj, message: '请输入下注量', trigger: 'blur' }],
                playBetSeconds: [{ required: true, validator: checkObj, message: '请输入多少秒后下注', trigger: 'blur' }],
                playBetPercent: [{ required: true, validator: checkObj, message: '请输入机器人下注概率', trigger: 'blur' }],
                playBetAreaPercent: [{ required: true, validator: checkObj, message: '请输入当前下注区域权重', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },

    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                let tag = 0
                Object.values(this.form.playBetTimes).forEach((e) => {
                    if (e.l % 10 != 0 || e.r % 10 != 0) {
                        tag = 1
                    }
                })
                if (tag == 1) {
                    return this.$message.warning('下注量只能填写10的倍数')
                }
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
