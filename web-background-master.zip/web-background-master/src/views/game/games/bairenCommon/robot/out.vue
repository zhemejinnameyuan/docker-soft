<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="240px" label-position="top">
                <span class="head-title">机器人累计局数离开</span>
                <div class="dp-c">
                    <div class="item dp-f">
                        <el-form-item label="机器人累计局数:" prop="leaveRound" label-width="140px">
                            <InputNumber v-model="form.leaveRound" :min-number="1" :max-number="999999" placeholder="" :single-big-input="true" range-width="200px" :text-center="true" clearable />
                        </el-form-item>
                        <el-form-item label="概率(%):" prop="leavePercent" label-width="140px" class="ml-5">
                            <InputNumber v-model="form.leavePercent" :min-number="0" :max-number="100" placeholder="" :single-big-input="true" range-width="200px" :text-center="true" clearable />
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="没有触发增加的概率（%）:" prop="leaveAddPercent" label-width="140px">
                            <InputNumber v-model="form.leaveAddPercent" :min-number="0" :max-number="100" placeholder="" :single-big-input="true" range-width="200px" :text-center="true" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import InputNumberRange from '@/components/InputNumberRange'
import { GAME_TYPE } from '@/constant/game'

export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            GAME_TYPE,
            form: null,
            rules: {
                leaveRound: [{ required: true, message: '请输入机器人累计不下注局数', trigger: 'blur' }],
                leavePercent: [{ required: true, message: '请输入概率', trigger: 'blur' }],
                leaveAddPercent: [{ required: true, message: '请输入没有触发增加的概率', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },

    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
