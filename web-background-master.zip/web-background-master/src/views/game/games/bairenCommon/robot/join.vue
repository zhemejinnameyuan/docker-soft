<template>
    <div class="game-common-config">
        <div class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="240px" label-position="top">
                <span class="head-title">机器人入场人数</span>
                <el-form-item label="机器人最低要求人数:" prop="roomMinPlayer" label-width="140px">
                    <InputNumber v-model="form.roomMinPlayer" :single-big-input="true" placeholder="" :min-number="0" :max-number="9999" clearable />
                </el-form-item>
                <span class="head-title">机器人等级分配权重</span>
                <el-form-item label="等级权重（%）:" prop="joinRobotLevelPercent">
                    <div class="form_item">
                        <div class="item_bg">
                            <span class="input-append-desc">非R&ensp;</span>
                            <InputNumber v-model="form.joinRobotLevelPercent.a" :min-number="0" :max-number="100" :text-center="true" placeholder="0-100" range-width="100px" clearable />
                            <span class="input-append-desc">%&ensp;</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">小R</span>
                            <InputNumber v-model="form.joinRobotLevelPercent.b" :min-number="0" :max-number="100" :text-center="true" placeholder="0-100" range-width="100px" clearable />
                            <span class="input-append-desc">%&ensp;</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">中R</span>
                            <InputNumber v-model="form.joinRobotLevelPercent.c" :min-number="0" :max-number="100" :text-center="true" placeholder="0-100" range-width="100px" clearable />
                            <span class="input-append-desc">%&ensp;</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">大R</span>
                            <InputNumber v-model="form.joinRobotLevelPercent.d" :min-number="0" :max-number="100" :text-center="true" placeholder="0-100" range-width="100px" clearable />
                            <span class="input-append-desc">%&ensp;</span>
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">超R</span>
                            <InputNumber v-model="form.joinRobotLevelPercent.e" :min-number="0" :max-number="100" :text-center="true" placeholder="0-100" range-width="100px" clearable />
                            <span class="input-append-desc">%&ensp;</span>
                        </div>
                    </div>
                </el-form-item>
                <el-form-item label="携带金额（倍）:" prop="joinRobotLevelCoinTimes">
                    <div class="form_item">
                        <div class="item_bg">
                            <span class="input-append-desc">非R</span>
                            &ensp;
                            <InputNumberRange
                                v-model="form.joinRobotLevelCoinTimes.a"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="1"
                                max-placeholder="10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">小R</span>
                            <InputNumberRange
                                v-model="form.joinRobotLevelCoinTimes.b"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="1"
                                max-placeholder="10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">中R</span>
                            <InputNumberRange
                                v-model="form.joinRobotLevelCoinTimes.c"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="1"
                                max-placeholder="10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">大R</span>
                            <InputNumberRange
                                v-model="form.joinRobotLevelCoinTimes.d"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="1"
                                max-placeholder="10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item_bg">
                            <span class="input-append-desc">超R</span>
                            <InputNumberRange
                                v-model="form.joinRobotLevelCoinTimes.e"
                                range-width="100px"
                                range-separator="—"
                                min-placeholder="1"
                                max-placeholder="10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                    </div>
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import InputNumberRange from '@/components/InputNumberRange'
import { checkObj } from '@/utils/filters'
import { GAME_TYPE } from '@/constant/game'
export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            GAME_TYPE,
            form: {
                roomMinPlayer: '',
                joinRobotLevelPercent: {
                    a: 0,
                    b: 0,
                    c: 0,
                    d: 0,
                    e: 0
                },
                joinRobotLevelCoinTimes: {
                    a: {},
                    b: {},
                    c: {},
                    d: {},
                    e: {}
                }
            },
            rules: {
                roomMinPlayer: [{ required: true, message: '请输入机器人入场人数', trigger: 'blur' }],
                joinRobotLevelPercent: [{ required: true, validator: checkObj, message: '请输入机器人等级权重', trigger: 'blur' }],
                joinRobotLevelCoinTimes: [{ required: true, validator: checkObj, message: '请输入机器人携带金额', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    let p = 0
                    Object.values(this.form.joinRobotLevelPercent).forEach((e) => {
                        p += e
                    })
                    if (p !== 100) {
                        return this.$message.warning('等级权重之和应为100')
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
