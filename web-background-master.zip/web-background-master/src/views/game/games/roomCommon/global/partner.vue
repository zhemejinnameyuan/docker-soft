<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">同IP游戏</span>
                <el-form-item label="同IP游戏开关:" prop="mateIpSwitch" class="inline-item">
                    <div class="dp-f">
                        <div class="mt-5">
                            <el-switch v-model="form.mateIpSwitch" />
                        </div>
                        <span class="tips ml-20" style="margin-top: 15px">开启表示容许同IP玩家在同一牌桌上，关闭表示不容许同IP玩家在同一牌桌上</span>
                    </div>
                </el-form-item>
                <span class="head-title">每日不能与累计x局的队友游戏(24:00重置)</span>
                <el-form-item label="局数控制:" prop="mateDayLimit">
                    <InputNumber v-model="form.mateDayLimit" range-width="200px" :single-big-input="true" :min-number="0" :max-number="10" placeholder="0-10" clearable />
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: null,
            rules: {
                mateIpSwitch: [{ required: true, message: '', trigger: 'blur' }],
                mateDayLimit: [{ required: true, message: '请输入局数控制', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
