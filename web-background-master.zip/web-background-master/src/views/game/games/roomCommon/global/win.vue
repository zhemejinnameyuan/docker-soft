<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">输赢策略</span>
                <el-form-item label="输赢策略开关:" prop="reservoir.winnerSwitch" class="inline-item">
                    <el-switch v-model="form.reservoir.winnerSwitch" />
                </el-form-item>

                <div class="horizontal-container mt-20">
                    <div class="item">
                        <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                            <el-table-column label="等级" align="center" width="100">
                                <template slot-scope="scope">{{ scope.$index + 1 }}</template>
                            </el-table-column>
                            <el-table-column label="最小累计赢金额" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.reservoir.winnerKill[scope.$index].a" range-width="140px" placeholder="" :min-number="-999999999" :max-number="1000000000" clearable />
                                </template>
                            </el-table-column>
                            <el-table-column label="最大累计赢金额" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.reservoir.winnerKill[scope.$index].b" range-width="140px" placeholder="" :min-number="-99999999" :max-number="1000000000" clearable />
                                </template>
                            </el-table-column>
                            <el-table-column label="机器人作弊概率(万分比)" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.reservoir.winnerKill[scope.$index].c" range-width="140px" :min-number="0" :max-number="10000" placeholder="0-10000" clearable />
                                </template>
                            </el-table-column>

                            <el-table-column label="玩家作弊概率(万分比)" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.reservoir.winnerKill[scope.$index].d" range-width="140px" :min-number="0" :max-number="10000" placeholder="0-10000" clearable />
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import InputNumberRange from '@/components/InputNumberRange'
import { range } from '@/utils'
export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: {
                reservoir: {
                    winnerKill: []
                }
            },
            config: [],
            rules: {
                'reservoir.winnerSwitch': [{ required: true, message: '请选择赢家策略开关', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },

    methods: {
        initData() {
            this.config = range(1, 9)
            for (let i in this.config) {
                if (this.form.reservoir.winnerKill[i] === undefined) {
                    this.form.reservoir.winnerKill[i] = { a: '', b: '', c: '0', d: '0' }
                }
            }
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    for (let i in this.form.reservoir.winnerKill) {
                        let preTmp = this.form.reservoir.winnerKill[i - 1]
                        let currentTmp = this.form.reservoir.winnerKill[i]

                        let tmpA = _.toNumber(currentTmp['a'])
                        let tmpB = _.toNumber(currentTmp['b'])
                        let tmpC = _.toNumber(currentTmp['c'])
                        let tmpD = _.toNumber(currentTmp['d'])

                        if (i != 0 && tmpA < _.toNumber(preTmp['b'])) {
                            this.$message.error('等级' + (_.toNumber(i) + 1) + ':最小金额必须大于等于上一档最大金额')
                            return false
                        }
                        if (tmpA > tmpB) {
                            this.$message.error('等级' + (_.toNumber(i) + 1) + ':最小金额不能比最大金额大')
                            return false
                        }
                        if (tmpA < 0 && tmpB < 0 && tmpC > 0) {
                            this.$message.error('等级' + (_.toNumber(i) + 1) + ':机器人作弊概率不应大于0')
                            return false
                        }

                        if (tmpA > 0 && tmpB > 0 && tmpD > 0) {
                            this.$message.error('等级' + (_.toNumber(i) + 1) + ':玩家作弊概率不应大于0')
                            return false
                        }
                    }

                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
