<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">刷子策略</span>
                <el-form-item label="刷子策略开关:" prop="reservoir.brushSwitch" class="inline-item">
                    <el-switch v-model="form.reservoir.brushSwitch" />
                </el-form-item>

                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="机器人作弊概率（万分比）:" prop="reservoir.brushKill" class="inline-item input-label-bg-gray">
                            <InputNumber v-model="form.reservoir.brushKill" range-width="120px" :text-center="true" placeholder="1-10000" :min-number="1" :max-number="10000" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: null,
            rules: {
                'reservoir.brushSwitch': [{ required: true, message: '请选择刷子策略开关', trigger: 'blur' }],
                'reservoir.brushKill': [{ required: true, message: '请输入机器人作弊概率', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
