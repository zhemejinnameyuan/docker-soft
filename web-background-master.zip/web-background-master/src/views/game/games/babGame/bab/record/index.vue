<template>
    <div class="game-common-record">
        <div>
            <!--工具栏-->
            <div class="head-container game-stat">
                <div class="report-data-box dp-f">
                    <div class="item-box" style="width: 240px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">在线玩家</span>
                                <span class="item-number-max ml-10" style="width: 124px" v-autoFontSize="'max'">{{ statsData.onlineTotal | filterThousandths }}</span>
                            </div>
                            <div class="split-line mb-20" />
                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">真实玩家数</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 100px" v-autoFontSize="'medium'">{{ statsData.onlinePlayers | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.onlinePlayers, statsData.onlineTotal) }}</span>
                                </div>
                                <div class="item ml-10">
                                    <span class="item-title-min">机器人</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 100px" v-autoFontSize="'medium'">{{ statsData.onlineRobots | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.onlineRobots, statsData.onlineTotal) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item-box ml-10" style="width: 270px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">系统总收益</span>
                                <span class="item-number-max ml-10" style="width: 135px" v-autoFontSize="'max'">
                                    {{ _.round(_.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax)), 2) | filterThousandths }}
                                </span>
                            </div>
                            <div class="split-line mb-20" />
                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">系统税收</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 110px" v-autoFontSize="'medium'">{{ statsData.stats.systemTax | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">
                                        {{ getPercentage(statsData.stats.systemTax, _.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax))) }}
                                    </span>
                                </div>
                                <div class="item ml-10">
                                    <span class="item-title-min">系统输赢(扣税)</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 120px" v-autoFontSize="'medium'">
                                        {{ statsData.stats.systemWin | filterThousandths }}
                                    </span>
                                    <span class="item-title-desc mt-12">
                                        {{ getPercentage(statsData.stats.systemWin, _.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax))) }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item-box ml-10" style="width: 290px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">蓄水池t值</span>
                                <span class="item-number-max ml-10">{{ statsData.systemBankRate | filterThousandths }}</span>
                            </div>
                            <div class="split-line mb-20" />
                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">当前蓄水池</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 128px" v-autoFontSize="'medium'">{{ statsData.currSystemBank | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12 reservoir-time">{{ statsData.currSystemBankTime }}</span>
                                </div>
                                <div class="item ml-10">
                                    <span class="item-title-min">初始蓄水池</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 128px" v-autoFontSize="'medium'">{{ statsData.initSystemBank | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12 reservoir-time">{{ statsData.initSystemBankTime }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-box ml-10" style="width: 410px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">游戏总场次</span>
                                <span class="item-number-max ml-10">{{ statsData.stats.gameRound | filterThousandths }}</span>
                            </div>
                            <div class="split-line mb-20" />

                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">蓝胜场次</span>
                                    <span class="item-number-medium mt-10 color-num-one" style="width: 76px" v-autoFontSize="'medium'">{{ statsData.stats.blueWin | filterThousandths }}</span>
                                    <span class="item-title-desc mt-10">{{ getPercentage(statsData.stats.blueWin, statsData.stats.gameRound) }}</span>
                                </div>

                                <div class="item ml-10">
                                    <span class="item-title-min">红胜场次</span>
                                    <span class="item-number-medium mt-10 color-num-two" style="width: 66px" v-autoFontSize="'medium'">{{ statsData.stats.redWin | filterThousandths }}</span>
                                    <span class="item-title-desc mt-10">{{ getPercentage(statsData.stats.redWin, statsData.stats.gameRound) }}</span>
                                </div>
                                <div class="ml-10" style="margin-top: -10px">
                                    <div class="dp-f">
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">1-5</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenOneWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">6-10</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenTwoWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">11-15</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenThreeWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">16-25</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenFourWin | filterThousandths }}</span>
                                        </span>
                                    </div>
                                    <div class="dp-f mt-10">
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">26-30</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenFiveWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">31-35</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenSixWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">36-40</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenSevenWin | filterThousandths }}</span>
                                        </span>
                                        <span class="result-type dp-c">
                                            <span class="item-title-min">41以上</span>
                                            <span class="item-title-desc-max mt-5">{{ statsData.stats.greenEightWin | filterThousandths }}</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <el-row type="flex" justify="space-between" style="margin-top: 38px">
                    <el-radio-group v-model="day" size="medium" @change="selectDays">
                        <el-radio-button :label="0">今日</el-radio-button>
                        <el-radio-button :label="1">昨日</el-radio-button>
                        <el-radio-button :label="7">7日</el-radio-button>
                        <el-radio-button :label="30">30天</el-radio-button>
                    </el-radio-group>
                    <div>
                        <el-select v-model="query.deskType" placeholder="全部" clearable size="medium" class="filter-item" style="width: 160px" @change="toQuery">
                            <el-option label="混合桌" value="0" />
                            <el-option label="隔离桌" value="1" />
                        </el-select>
                        <el-input v-model="query.flowId" placeholder="流水号" class="filter-item" size="medium" show-word-limit style="width: 160px" clearable @keyup.enter.native="toQuery" />
                        <DateRangePicker v-model="query.endTime" class="filter-item" style="width: 332px" @change="dataChange" />
                        <IconButton size="medium" type="primary" class="filter-item" icon="oms_ico_search" title="搜索" style="margin-right: 0px" @click="toQuery" />
                    </div>
                </el-row>
            </div>
            <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" class="tble game-table" :data="list">
                <el-table-column :show-overflow-tooltip="true" width="240" prop="createTime" align="center" label="时间">
                    <template slot-scope="scope">
                        <span>{{ scope.row.endTime }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" prop="flowId" width="240" align="center" label="流水号" />
                <el-table-column :show-overflow-tooltip="true" prop="deskType" width="160" align="center" label="桌子类型">
                    <template slot-scope="scope">
                        {{ scope.row.deskType == 0 ? '混合桌' : '隔离桌' }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140" align="center" label="玩家数">
                    <template slot-scope="scope">
                        <span>{{ scope.row.playerCount }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="160" prop="systemWinStr" align="center" label="系统输赢(扣税)">
                    <template slot-scope="scope">
                        <span :class="textColor(scope.row.systemWinStr)">{{ scope.row.systemWinStr }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="160" prop="systemTaxStr" align="center" label="系统税收" />
                <el-table-column :show-overflow-tooltip="true" width="140" prop="createTime" align="center" label="操作">
                    <template slot-scope="scope">
                        <IconButton
                            v-permission="[permission.babFlowDetail]"
                            class="filter-item"
                            size="medium"
                            type="text"
                            style="font-size: 20px"
                            icon="oms_ico_xiangqing"
                            @click="toDetail(scope.row)"
                        />
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
        <Drawer :visible.sync="drawer" title="详情">
            <Detail :flow-id="flowId" v-if="drawer" />
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import Drawer from '@/components/Drawer'
import pagination from '@/components/Pagination'
import Detail from './detail.vue'
import * as api from '@/api/game/bab'
export default {
    components: {
        Drawer,
        pagination,
        DateRangePicker,
        Detail
    },
    mixins: [Base],
    data() {
        return {
            drawer: false,
            flowId: '',
            query: {
                size: 10,
                page: 1,
                flowId: null,
                sort: 'endTime;desc',
                endTime: []
            },
            total: 0,
            day: null,
            loading: false,
            list: [],
            statsData: {
                stats: {}
            }
        }
    },
    mounted() {
        this.fixed_height = 480
        this.day = 0
        this.selectDays()
    },
    methods: {
        dataChange() {
            this.day = null
        },
        selectDays() {
            var start = new Date().daysAgo(this.day).format('yyyy-MM-dd hh:mm:ss')
            var end
            if (this.day === 1) {
                end = start
            } else {
                end = new Date().format('yyyy-MM-dd hh:mm:ss')
            }
            this.query.endTime = [start, end]
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }

            this.loading = true
            api.babFlowList(this.query)
                .then((rep) => {
                    this.loading = false
                    this.list = rep.data
                    this.total = rep.page.tc
                })
                .catch(() => {
                    this.loading = false
                })
            api.babFlowStats(this.query)
                .then((rep) => {
                    this.statsData = rep.data
                })
                .catch(() => {})
        },
        toDetail(row) {
            this.flowId = row.flowId
            this.drawer = true
        }
    }
}
</script>
<style lang="scss" scoped>
.result-type {
    padding: 0px;
    width: 55px;
}
</style>
