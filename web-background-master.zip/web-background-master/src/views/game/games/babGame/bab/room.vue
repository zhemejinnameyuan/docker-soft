<template>
    <div class="game-common-record no-scrollbar">
        <div class="head-container">
            <el-row type="flex" justify="end" style="margin-top: 10px">
                <IconButton v-permission="[permission.babRoomAdd]" size="medium" type="primary" icon="oms_ico_add" title="创建房间" @click="toAdd" />
            </el-row>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%; margin-top: 20px" :height="table_height" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="房间ID">
                <template slot-scope="scope">
                    <span>{{ scope.row.id }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="牌桌类型">
                <span>百人桌</span>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="260px" prop="baseConfig.betCoin" align="center" label="下注金额">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.betCoin.join('、') }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" prop="baseConfig.joinMinCoin" align="center" label="进入限制" />
            <el-table-column :show-overflow-tooltip="true" width="100px" label="税率" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.taxPercent }}%</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" label="桌子数量" align="center">
                <template slot-scope="scope">
                    <div>混合桌:{{ scope.row.deskCount }}</div>
                    <div>隔离桌:{{ scope.row.ddeskCount }}</div>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" prop="playerCount" align="center" label="玩家/机器人数量">
                <template slot-scope="scope">
                    <div>{{ scope.row.playerCount }}/{{ scope.row.robotCount }}</div>
                    <div>{{ scope.row.dplayerCount }}/{{ scope.row.drobotCount }}</div>
                </template>
            </el-table-column>
            <el-table-column width="120px" align="center" label="状态">
                <template slot-scope="scope">
                    <div class="table_state_switch">
                        <el-switch v-model="scope.row.baseConfig.enableFlag" @change="roomStateChange(scope.row)" :disabled="!checkPermission([permission.babRoomEnableDisable])"></el-switch>
                    </div>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" width="120px" prop="updateTime" align="center" label="操作">
                <template slot-scope="scope">
                    <IconButton v-permission="[permission.babRoomEdit]" type="text" size="medium" style="font-size: 20px" icon="oms_ico_edit" @click="toEdit(scope.row)" />
                </template>
            </el-table-column>
        </el-table>
        <Drawer class="drawer" :title="drawerTitle" :visible.sync="drawer">
            <div class="drawer_content">
                <el-form ref="form" :model="form" :rules="rules" label-width="220px">
                    <span class="drawer_content_title">房间基础配置</span>
                    <div class="item_bg">
                        <el-form-item label="房间开关:" prop="enableFlag">
                            <el-switch v-model="form.enableFlag" />
                        </el-form-item>
                        <el-form-item label="牌桌类型:">
                            <span>百人场</span>
                        </el-form-item>

                        <el-form-item label="进入条件(金币):" prop="joinMinCoin">
                            <InputNumber v-model="form.joinMinCoin" range-width="280px" :precision="2" :min-number="0" clearable />
                        </el-form-item>

                        <el-form-item label="下注币种:" prop="betCoin">
                            <el-select v-model="form.betCoin" placeholder="请选择" multiple size="medium" :multiple-limit="6" style="width: 280px" @change="betChange">
                                <el-option v-for="item in betCoins" :key="item" :label="item" :value="item" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="下注要求玩家身上最少金额:" prop="minBetCoinRound">
                            <el-select v-model="form.minBetCoinRound" placeholder="请选择" size="medium" style="width: 280px">
                                <el-option v-for="item in betCoins" :key="item" :label="item" :value="item" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="玩家单个区域最大下注限制:" prop="maxBetCoinArea">
                            <InputNumber v-model="form.maxBetCoinArea" range-width="280px" :min-number="0" :max-number="99999999" clearable />
                        </el-form-item>
                        <el-form-item label="所有玩家单局最大下注限制:" prop="maxBetCoinRound">
                            <InputNumber v-model="form.maxBetCoinRound" range-width="280px" :min-number="0" :max-number="99999999" clearable />
                        </el-form-item>
                        <el-form-item label="税率(%):" prop="taxPercent">
                            <InputNumber v-model="form.taxPercent" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                            <span class="tips">现金比例+赢钱比例+税率=100%</span>
                        </el-form-item>
                        <el-form-item label="结算现金比例(%):" prop="depositedPercent">
                            <InputNumber v-model="form.depositedPercent" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                        <el-form-item label="结算赢钱比例(%):" prop="winningsPercent">
                            <InputNumber v-model="form.winningsPercent" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                        <el-form-item label="礼物价格:" prop="giftCoin">
                            <InputNumber v-model="form.giftCoin" :precision="2" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                </el-form>
            </div>

            <div class="footer">
                <IconButton class="filter-item" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
            </div>
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { roomState } from '@/constant/game'
import Drawer from '@/components/Drawer'
import * as api from '@/api/game/bab'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    page: 1,
    size: 10,
    sort: 'createTime;desc',
    all: true
}
export default {
    components: {
        Drawer,
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            betCoins: [],
            form: {},
            drawer: false,
            drawerType: '',
            drawerTitle: '',
            loading: false,
            query: { ...defaultQuery },
            list: [],
            roomId: undefined,
            rules: {
                enableFlag: [{ required: true, message: '请输入底注金额', trigger: 'blur' }],
                deskPlayer: [{ required: true, message: '请选择房间等级', trigger: 'blur' }],
                joinMinCoin: [{ required: true, message: '请输入进入条件', trigger: 'blur' }],
                betCoin: [{ required: true, message: '请选择下注币种', trigger: 'blur' }],
                maxBetCoinArea: [{ required: true, message: '请输入玩家单个区域最大下注限制', trigger: 'blur' }],
                maxBetCoinRound: [{ required: true, message: '请输入所有玩家单局最大下注限制', trigger: 'blur' }],
                minBetCoinRound: [{ required: true, message: '请输入下注要求玩家身上最少金额', trigger: 'blur' }],
                taxPercent: [{ required: true, message: '请输入税率', trigger: 'blur' }],
                depositedPercent: [{ required: true, message: '请输入结算现金比例', trigger: 'blur' }],
                winningsPercent: [{ required: true, message: '请输入结算赢钱比例', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.fixed_height = 250
        this.toQuery()
    },

    methods: {
        getRoomState(type) {
            return roomState[type].name
        },
        toAdd() {
            this.form = {
                enableFlag: true, // 开关
                deskPlayer: 100,
                joinMinCoin: 0, // 进入条件
                betCoin: [50, 100, 200, 500, 1000, 2000], // 下注金额
                maxBetCoinArea: 30000, // 区域最大限制
                maxBetCoinRound: 200000, // 单局最大限制
                minBetCoinRound: 100, // 单局最小金额限制
                taxPercent: 5, // 税率
                depositedPercent: 56, // 结算现金比例
                winningsPercent: 39 // 结算赢钱比例
            }
            this.drawerType = 'add'
            this.drawer = true
            this.drawerTitle = '创建房间'
            this.$forceUpdate()
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toEdit(row) {
            this.drawerType = 'edit'
            this.roomId = row.id
            this.form = { ...row.baseConfig }
            this.drawer = true
            this.drawerTitle = '编辑房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toQuery() {
            if (this.checkPermission([this.permission.babRoomList])) {
                api.babRoomList(this.query).then((rep) => {
                    this.list = rep.data
                })
                api.babBetCoins().then((rep) => {
                    this.betCoins = rep.data
                })
            }
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.form.betCoin.length !== 6) {
                        return this.$message.warning('下注币种必须选择6个选项')
                    }
                    if (this.form.winningsPercent + this.form.depositedPercent + this.form.taxPercent !== 100) {
                        return this.$message.warning('现金比例+赢钱比例+税率=100%')
                    }
                    if (this.drawerType === 'add' && this.checkPermission([this.permission.babRoomAdd])) {
                        api.babRoomAdd({ baseConfig: this.form }).then((rep) => {
                            this.drawer = false
                            this.$message.success('房间添加成功')
                            this.toQuery()
                        })
                    }
                    if (this.drawerType === 'edit' && this.checkPermission([this.permission.babRoomEdit])) {
                        var dic = { baseConfig: this.form, id: this.roomId }
                        api.babRoomEdit(dic).then((rep) => {
                            this.drawer = false
                            this.$message.success('房间编辑成功')
                            this.toQuery()
                        })
                    }
                }
            })
        },
        roomStateChange(data) {
            if (!data.baseConfig.enableFlag) {
                confirmRequest(
                    '禁用以后游戏中将不展示该房间，房间内的玩家结束后将全部离开。确定是否禁用？',
                    () => {
                        this.toEnabled(data)
                    },
                    () => {
                        data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                    }
                )
            } else {
                this.toEnabled(data)
            }
        },
        toEnabled(data) {
            api.babRoomEnableDisable(data)
                .then((res) => {
                    if (data.baseConfig.enableFlag) {
                        this.$message.success('启用成功')
                    } else {
                        this.$message.success('禁用成功')
                    }
                })
                .catch(() => {
                    data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                })
        },
        betChange() {
            this.form.betCoin.sort(function (a, b) {
                return a - b
            })
        }
    }
}
</script>
