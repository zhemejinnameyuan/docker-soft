<template>
    <div class="app-container game_room">
        <div v-permission="[permission.gameConfigSave]" class="dp-f mb-10" style="flex-direction: row-reverse; margin-right: 100px">
            <el-button v-if="isEdit" size="medium" class="mb-5 mr-20" type="info" @click="changeEditMode(0)">取消</el-button>
            <el-button v-if="isEdit" size="medium" class="mb-5 mr-20" type="primary" @click="submit()">确定</el-button>
            <el-button v-if="!isEdit" size="medium" class="mb-5 mr-20" type="primary" @click="changeEditMode(1)">编辑</el-button>
        </div>

        <!--正常模式-->
        <div class="game_list" v-if="!isEdit">
            <div v-for="item in gameList" :key="item.id" :class="item.enable ? 'box-card' : 'box-card-gray'" :style="getGameImg(item.img)" @click="toGamePage(item)">
                <div class="tag-box">
                    <img src="~@/assets/images/oms_lab_hot.png" class="tag-img" v-if="item.enable && item.label == '1'" />
                    <img src="~@/assets/images/oms_lab_new.png" class="tag-img" v-if="item.enable && item.label == '2'" />
                    <img src="~@/assets/images/oms_lab_xiajia.png" v-if="!item.enable" />
                </div>
                <div class="game-title">{{ item.name }}</div>
            </div>
        </div>

        <!--编辑模式-->
        <div class="game_list" v-if="isEdit">
            <div v-for="(item, index) in gameListEdit" :key="item.id" class="box-card" :style="getGameImg(item.img)" v-dragging="{ item: item, list: gameListEdit, group: 'game' }">
                <div class="dp-f">
                    <div class="tag-box" style="width: 50%">
                        <img src="~@/assets/images/oms_lab_hot.png" class="tag-img" v-if="gameListEdit[index].enable && gameListEdit[index].label == '1'" />
                        <img src="~@/assets/images/oms_lab_new.png" class="tag-img" v-if="gameListEdit[index].enable && gameListEdit[index].label == '2'" />
                        <img src="~@/assets/images/oms_lab_xiajia.png" v-if="!gameListEdit[index].enable" />
                    </div>

                    <div style="width: 50%">
                        <IconButton class="sort-btn" size="medium" type="text" icon="oms_ico_drag" style="font-size: 14px" />
                    </div>
                </div>
                <div class="game-title">{{ item.name }}</div>

                <div class="action-box dp-f">
                    <div style="width: 75%">
                        <el-radio-group v-model="gameListEdit[index].label">
                            <el-radio label="0">无</el-radio>
                            <el-radio label="1">HOT</el-radio>
                            <el-radio label="2">NEW</el-radio>
                        </el-radio-group>
                    </div>

                    <div class="dp-f ml-20" style="width: 25%; cursor: pointer" @click="changeState(index)">
                        <IconButton class="up-down-btn fs-14" size="medium" type="text" :icon="gameListEdit[index].enable ? 'oms_ico_xiajia' : 'oms_ico_shangjia'" />
                        <span :class="gameListEdit[index].enable ? 'text_red' : 'text_green'" style="margin-top: 2px; font-size: 14px; margin-left: -5px">
                            {{ gameListEdit[index].enable ? '下架' : '上架' }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/game'
import { mapState } from 'vuex'
import { deepClone } from '@/utils/object'

export default {
    name: 'Games',
    mixins: [Base],
    data() {
        return {
            gameList: [],
            serverList: [],
            gameListEdit: [],
            isEdit: 0
        }
    },
    computed: {
        ...mapState({
            routers: (state) => state.permission.routers
        })
    },
    mounted() {
        // 拖拽后触发的事件
        this.$dragging.$on('dragged', ({ value }) => {})
        this.$dragging.$on('dragend', () => {})

        // this.gameListEdit.forEach((e) => {
        //     if (this.routers.find((r) => r.path === e.path)) {
        //         this.gameList.push(e)
        //     }
        // })
    },
    created() {
        this.initData()
    },
    methods: {
        initData() {
            this.gameList = []
            let games = this.getGames()

            if (this.checkPermission([this.permission.gameConfigList])) {
                api.gameConfigList().then((rep) => {
                    this.serverList = rep.data
                    for (let i in this.serverList) {
                        let game = this.serverList[i]
                        let index = _.findIndex(games, function (o) {
                            return o.id == game.id
                        })
                        game = Object.assign({}, game, games[index])
                        this.gameList.push(game)
                    }
                    this.gameListEdit = deepClone(this.gameList)
                    //固定金额-排序
                    this.gameListEdit = this.gameListEdit.sort(function (a, b) {
                        return a - b
                    })
                })
            }
        },
        changeEditMode(type) {
            this.isEdit = type
        },
        changeState(index) {
            this.gameListEdit[index].enable = this.gameListEdit[index].enable ? false : true
        },
        getGameImg(img) {
            const imgObj = require('@/assets/images/' + img)
            return {
                background: `url(${imgObj})`,
                'background-size': '100% 100%'
            }
        },
        toGamePage(row) {
            window.open(row.path)
        },
        submit() {
            let newParams = []
            //处理排序相关
            for (let i in this.gameListEdit) {
                let game = this.gameListEdit[i]
                let newGame = {
                    id: game['id'],
                    enable: game['enable'],
                    sort: _.toNumber(i) + 1,
                    label: _.toNumber(game['label'])
                }
                newParams.push(newGame)
            }
            if (this.checkPermission([this.permission.gameConfigSave])) {
                api.saveGameConfig(newParams).then((rep) => {
                    this.$message.success('操作成功')
                    this.initData()
                    this.isEdit = false
                })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.game_room {
    .game_list {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .game-title {
        height: 58px;
        display: flex;
        //align-items: center;
        margin-left: 30px;
        margin-top: -10px;
        font-size: 28px;
        color: #282829;
        letter-spacing: 2.33px;
        font-weight: 500;
    }

    .box-card {
        width: 280px;
        height: 140px;
        margin: 0px 20px 20px 0px;
        background: #f6fafd;
    }

    .box-card-gray {
        width: 280px;
        height: 140px;
        margin: 0px 20px 20px 0px;
        opacity: 0.7;
        background: #d4d9da;
    }

    .tag-box {
        width: 60px;
        height: 60px;
    }

    .tag-img {
        margin-top: -5px;
        margin-left: -5px;
    }

    .sort-btn {
        cursor: move;
        float: right;
        margin-right: 8px;
    }

    .action-box {
        padding: 6px 0 5px 10px;
        height: 30px;
        width: 280px;
        background: rgba(223, 254, 255, 0.7);

        .el-radio {
            margin-right: 10px;
        }

        .up-down-btn {
            float: right;
            margin-right: 8px;
            margin-top: -8px;
        }
    }
}
</style>
