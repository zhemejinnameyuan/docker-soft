<template>
    <div class="web-container" style="background: #f7f7f7">
        <GoHome />
        <div class="container_title">猜数字-游戏管理</div>
        <div class="container_game">
            <div class="game_tab">
                <div v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :class="tabClass(item.type)" @click="changeTab(item.type)">
                    {{ item.title }}
                </div>
            </div>
            <div class="game_content">
                <Csz v-if="type === 'csz'" />
                <Robot v-if="type === 'robot'" />
                <Global v-if="type === 'global'" />
            </div>
        </div>
    </div>
</template>

<script>
import Csz from './csz/index.vue'
import Robot from './robot/index.vue'
import Global from './global/index.vue'
import Base from '@/views/base'
import GoHome from '@/components/GoHome'

export default {
    name: 'CszGame',
    components: {
        Csz,
        Robot,
        Global,
        GoHome
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'csz',
                title: '猜数字',
                permissions: [this.permission.cszRoomList, this.permission.cszFlowList]
            },
            {
                type: 'robot',
                title: '机器人',
                permissions: [this.permission.cszRobotGet]
            },
            {
                type: 'global',
                title: '全局配置',
                permissions: [this.permission.cszGlobalGet]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        tabClass(type) {
            return type === this.type ? 'game_tab_item_active' : 'game_tab_item'
        },
        changeTab(type) {
            this.type = type
        }
    }
}
</script>
