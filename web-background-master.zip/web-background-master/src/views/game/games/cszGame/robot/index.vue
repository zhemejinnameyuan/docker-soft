<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="rcgz">
                <span slot="title">入场规则</span>
            </el-menu-item>
            <el-menu-item index="lcgz">
                <span slot="title">离场规则</span>
            </el-menu-item>
            <el-menu-item index="pwjqr">
                <span slot="title">陪玩机器人</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <JoinConfig v-if="type === 'rcgz' && configData" :gameType="GAME_TYPE.CSZ" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.cszRobotSave]" />
            <OutConfig v-if="type === 'lcgz' && configData" :gameType="GAME_TYPE.CSZ" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.cszRobotSave]" />
            <PlayConfig v-if="type === 'pwjqr' && configData" :gameType="GAME_TYPE.CSZ" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.cszRobotSave]" />
        </div>
    </div>
</template>

<script>
import JoinConfig from '@/views/game/games/bairenCommon/robot/join'
import OutConfig from '@/views/game/games/bairenCommon/robot/out'
import PlayConfig from '@/views/game/games/bairenCommon/robot/play'
import Base from '@/views/base'
import * as api from '@/api/game/csz'
import { GAME_TYPE } from '@/constant/game'

export default {
    components: {
        JoinConfig,
        OutConfig,
        PlayConfig
    },
    mixins: [Base],
    data() {
        return {
            GAME_TYPE,
            type: 'rcgz',
            configData: null
        }
    },
    mounted() {
        this.toQuery()
    },

    methods: {
        handleSelect(type) {
            this.type = type
            this.toQuery()
        },
        //查询
        toQuery() {
            api.cszGetRobotConfig().then((rep) => {
                this.repData = rep.data
                this.configData = { ...this.repData.jsonConfig }
            })
        },
        //保存
        toSubmit(configData) {
            this.repData.jsonConfig = { ...configData }
            api.cszSaveRobotConfig(this.repData).then((rep) => {
                this.$message.success('保存成功')
            })
        }
    }
}
</script>
