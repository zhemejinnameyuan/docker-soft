<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">骰子控制</span>
                <el-form-item label="骰子控制开关:" prop="dealStrategy.enableRollPoint" class="inline-item">
                    <el-switch v-model="form.dealStrategy.enableRollPoint" />
                </el-form-item>

                <div class="horizontal-container mt-20">
                    <div class="item">
                        <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                            <el-table-column label="点数" align="center" width="100">
                                <template slot-scope="scope">点数{{ scope.$index + 1 }}</template>
                            </el-table-column>
                            <el-table-column label="棋子未出巢配置权重" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.dealStrategy.type0RollPoint[scope.row]" range-width="160px" :min-number="1" :max-number="10000" placeholder="1-10000" clearable />
                                </template>
                            </el-table-column>
                            <el-table-column label="棋子非安全区配置权重" align="center" width="200px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.dealStrategy.type1RollPoint[scope.row]" range-width="160px" :min-number="1" :max-number="10000" placeholder="1-10000" clearable />
                                </template>
                            </el-table-column>
                            <el-table-column label="两人桌配置权重" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.dealStrategy.type2RollPoint[scope.row]" range-width="140px" :min-number="1" :max-number="10000" placeholder="0-10000" clearable />
                                </template>
                            </el-table-column>
                            <el-table-column label="默认配置权重" align="center" width="180px">
                                <template slot-scope="scope">
                                    <InputNumber v-model="form.dealStrategy.type3RollPoint[scope.row]" range-width="140px" :min-number="1" :max-number="10000" placeholder="0-10000" clearable />
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="[permission.fxqGlobalSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import InputNumberRange from '@/components/InputNumberRange'
import * as api from '@/api/game/fxq'

export default {
    components: {
        InputNumber,
        InputNumberRange
    },
    mixins: [Base],
    data() {
        return {
            form: {
                dealStrategy: {
                    type0RollPoint: [],
                    type1RollPoint: [],
                    type2RollPoint: [],
                    type3RollPoint: []
                }
            },
            config: [],
            rules: {
                'dealStrategy.enableRollPoint': [{ required: true, message: '请选择骰子控制开关', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.toQuery()
    },

    methods: {
        initData() {
            this.config = ['a', 'b', 'c', 'd', 'e', 'f']
            for (let i in this.config) {
                if (this.form.dealStrategy.type0RollPoint[i] === undefined) {
                    this.form.dealStrategy.type0RollPoint[i] = ''
                }
                if (this.form.dealStrategy.type1RollPoint[i] === undefined) {
                    this.form.dealStrategy.type1RollPoint[i] = ''
                }
                if (this.form.dealStrategy.type2RollPoint[i] === undefined) {
                    this.form.dealStrategy.type2RollPoint[i] = ''
                }
                if (this.form.dealStrategy.type3RollPoint[i] === undefined) {
                    this.form.dealStrategy.type3RollPoint[i] = ''
                }
            }
        },
        toQuery() {
            api.fxqGlobalGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }
                this.initData()
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    api.fxqGlobalSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
