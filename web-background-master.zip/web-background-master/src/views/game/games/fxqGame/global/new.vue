<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-position="top">
                <span class="head-title">新手保护策略</span>
                <el-form-item label="新手保护策略开关:" prop="reservoir.newbieSwitch" label-width="110px" class="inline-item">
                    <el-switch v-model="form.reservoir.newbieSwitch" />
                </el-form-item>

                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="新手保护局数:" prop="reservoir.newbieWin.l">
                            <InputNumber v-model="form.reservoir.newbieWin.l" range-width="200px" :single-big-input="true" placeholder="0-10" :min-number="0" :max-number="10" clearable />
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="玩家作弊概率（万分比）:" prop="reservoir.newbieWin.r">
                            <InputNumber v-model="form.reservoir.newbieWin.r" range-width="200px" :single-big-input="true" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                        </el-form-item>
                    </div>
                </div>
                <span class="head-title">新手房间</span>

                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="Classic:" prop="newbieClassicRoomIds">
                            <el-select v-model="newbieClassicRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in classicRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="Quick:" prop="newbieQuickRoomIds">
                            <el-select v-model="newbieQuickRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in quickRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="Master:" prop="newbieMasterRoomIds">
                            <el-select v-model="newbieMasterRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in masterRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="[permission.fxqGlobalSave]" class="filter-item" size="medium" type="primary" title="保存" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/fxq'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        const checkNewbieClassicRoomIds = (rule, value, callback) => {
            if (this.newbieClassicRoomIds.length === 0) {
                callback(new Error('请选择Classic房间'))
            }
            callback()
        }
        const checkNewbieQuickRoomIds = (rule, value, callback) => {
            if (this.newbieQuickRoomIds.length === 0) {
                callback(new Error('请选择Quick房间'))
            }
            callback()
        }
        const checkNewbieMaterRoomIds = (rule, value, callback) => {
            if (this.newbieMasterRoomIds.length === 0) {
                callback(new Error('请选择Master房间'))
            }
            callback()
        }

        return {
            query: { all: true, enableFlag: true },
            form: {
                reservoir: {
                    newbieWin: { l: '', r: '' }
                }
            },
            classicRooms: [],
            newbieClassicRoomIds: [],
            quickRooms: [],
            newbieQuickRoomIds: [],
            masterRooms: [],
            newbieMasterRoomIds: [],
            rules: {
                'reservoir.newbieSwitch': [{ required: true, message: '请选择新手保护策略开关', trigger: 'blur' }],
                'reservoir.newbieWin.l': [{ required: true, message: '请配置新手保护局数', trigger: 'blur' }],
                'reservoir.newbieWin.r': [{ required: true, message: '请配置玩家作弊概率', trigger: 'blur' }],
                newbieClassicRoomIds: [{ required: true, validator: checkNewbieClassicRoomIds, trigger: 'blur' }],
                newbieQuickRoomIds: [{ required: true, validator: checkNewbieQuickRoomIds, trigger: 'blur' }],
                newbieMaterRoomIds: [{ required: true, validator: checkNewbieMaterRoomIds, trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.getRoom()
        setTimeout(() => {
            this.toQuery()
        }, 200)
    },

    methods: {
        getRoomTitle(item) {
            var config = item.baseConfig
            return `${config.deskPlayer}人房｜底注${config.anteCoin}`
        },

        getRoom() {
            if (this.checkPermission([this.permission.fxqGlobalNewbieClassic])) {
                api.fxqClassicRoomList(this.query).then((rep) => {
                    this.classicRooms = rep.data
                })
            }
            if (this.checkPermission([this.permission.fxqGlobalNewbieQuick])) {
                api.fxqQuickRoomList(this.query).then((rep) => {
                    this.quickRooms = rep.data
                })
            }
            if (this.checkPermission([this.permission.fxqGlobalNewbieMaster])) {
                api.fxqMasterRoomList(this.query).then((rep) => {
                    this.masterRooms = rep.data
                })
            }
        },
        toQuery() {
            api.fxqGlobalGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }

                //处理每个房间的ID
                this.classicRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbieClassicRoomIds.push(item.id)
                    }
                })

                this.quickRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbieQuickRoomIds.push(item.id)
                    }
                })

                this.masterRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbieMasterRoomIds.push(item.id)
                    }
                })
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    //拼装每个房间的ID
                    this.repData.jsonConfig.reservoir.newbieRoomIds = _.concat(this.newbieClassicRoomIds, this.newbieQuickRoomIds, this.newbieMasterRoomIds)
                    api.fxqGlobalSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
