<template>
    <div class="game-config-box">
        <div class="game-common-config">
            <div v-if="form" class="config_content no-scrollbar">
                <el-form ref="form" :model="form" :rules="rules" :inline="true" label-position="top" label-width="250px">
                    <span class="head-title">陪玩机器人开关</span>
                    <div class="item_bg_ai">
                        <div style="margin-left: 80px">
                            <el-form-item label="开关:" prop="playEnableFlag" class="inline-item">
                                <el-switch v-model="form.playEnableFlag" />
                            </el-form-item>
                        </div>
                    </div>
                    <span class="head-title">留局配置</span>
                    <div class="dp-f item_bg_ai">
                        <div class="item" style="margin-left: 80px">
                            <el-form-item label="赢留局概率(%):" prop="winStayPercent">
                                <InputNumber v-model="form.winStayPercent" range-width="200px" :single-big-input="true" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                            </el-form-item>
                        </div>
                        <div class="item ml-40">
                            <el-form-item label="输留局概率(%):" prop="loseStayPercent">
                                <InputNumber v-model="form.loseStayPercent" range-width="200px" :single-big-input="true" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                            </el-form-item>
                        </div>
                    </div>

                    <span class="head-title">离场配置</span>
                    <div class="item_bg_ai dp-f">
                        <div class="item" style="margin-left: 80px">
                            <el-form-item label="连续同局次数:" prop="playRound">
                                <InputNumber v-model="form.playRound" range-width="200px" :single-big-input="true" placeholder="1-100" :min-number="1" :max-number="100" clearable />
                            </el-form-item>
                        </div>
                    </div>
                </el-form>
            </div>
            <div class="footer">
                <IconButton v-permission="[permission.fxqRobotSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/fxq'

export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            repData: null,
            form: {},
            rules: {
                playEnableFlag: [{ required: true, message: '请选择开关', trigger: 'blur' }],
                winStayPercent: [{ required: true, message: '请输入赢留局概率', trigger: 'blur' }],
                loseStayPercent: [{ required: true, message: '请输入输留局概率', trigger: 'blur' }],
                playRound: [{ required: true, message: '请输入同局次数', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        toQuery() {
            api.fxqRobotGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    api.fxqRobotSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
<style scoped lang="scss">
.item_bg_ai {
    padding: 30px 0 30px 20px;
    background: #f7f7f7;
    border-radius: 4px;
    margin-bottom: 60px;
}

.sub_title_ai {
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #686b6d;
    text-align: right;
    font-weight: 400;
}
</style>
