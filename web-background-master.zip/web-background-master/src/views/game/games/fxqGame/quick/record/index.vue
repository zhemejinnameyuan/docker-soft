<template>
    <div class="game-common-record">
        <div>
            <!--工具栏-->
            <div class="head-container game-stat">
                <div class="report-data-box dp-f">
                    <div class="item-box" style="width: 310px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">在线玩家</span>
                                <span class="item-number-max ml-10" style="width: 124px" v-autoFontSize="'max'">{{ statsData.onlineTotal | filterThousandths }}</span>
                            </div>
                            <div class="split-line mb-20" />
                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">真实玩家数</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 130px" v-autoFontSize="'medium'">{{ statsData.onlinePlayers | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.onlinePlayers, statsData.onlineTotal) }}</span>
                                </div>
                                <div class="item ml-10">
                                    <span class="item-title-min">机器人</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 130px" v-autoFontSize="'medium'">{{ statsData.onlineRobots | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.onlineRobots, statsData.onlineTotal) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item-box ml-10" style="width: 400px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">系统总收益</span>
                                <span class="item-number-max ml-10" style="width: 135px" v-autoFontSize="'max'">
                                    {{ _.round(_.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax)), 2) | filterThousandths }}
                                </span>
                            </div>
                            <div class="split-line mb-20" />

                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">系统税收</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 150px" v-autoFontSize="'medium'">{{ statsData.stats.systemTax | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">
                                        {{ getPercentage(statsData.stats.systemTax, _.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax))) }}
                                    </span>
                                </div>

                                <div class="item ml-10">
                                    <span class="item-title-min">系统输赢(扣税)</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 150px" v-autoFontSize="'medium'">{{ statsData.stats.systemWin | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">
                                        {{ getPercentage(statsData.stats.systemWin, _.add(_.toNumber(statsData.stats.systemWin), _.toNumber(statsData.stats.systemTax))) }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item-box ml-10" style="width: 510px">
                        <div class="content">
                            <div class="dp-f">
                                <span class="item-title">游戏总场次</span>
                                <span class="item-number-max ml-10">{{ statsData.stats.gameRound | filterThousandths }}</span>
                            </div>
                            <div class="split-line mb-20" />

                            <div class="bottom-box">
                                <div class="item">
                                    <span class="item-title-min">机器人参与场次</span>
                                    <span class="item-number-medium mt-12 color-num-one" style="width: 150px" v-autoFontSize="'medium'">{{ statsData.stats.countRobotJoin | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.stats.countRobotJoin, statsData.stats.gameRound) }}</span>
                                </div>

                                <div class="item ml-10">
                                    <span class="item-title-min">纯真实玩家场次</span>
                                    <span class="item-number-medium mt-12 color-num-two" style="width: 150px" v-autoFontSize="'medium'">{{ statsData.stats.countPlayerJoin | filterThousandths }}</span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.stats.countPlayerJoin, statsData.stats.gameRound) }}</span>
                                </div>

                                <div class="item ml-10">
                                    <span class="item-title-min">机器人输/赢次数</span>
                                    <span class="item-number-medium mt-12 color-num-three" style="width: 150px" v-autoFontSize="'medium'">
                                        {{ statsData.stats.countRobotLose }}/{{ statsData.stats.countRobotWin }}
                                    </span>
                                    <span class="item-title-desc mt-12">{{ getPercentage(statsData.stats.countRobotWin, statsData.stats.countRobotLose + statsData.stats.countRobotWin) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <el-row type="flex" justify="space-between" style="margin-top: 38px">
                    <el-radio-group v-model="day" size="medium" @change="selectDays">
                        <el-radio-button :label="0">今日</el-radio-button>
                        <el-radio-button :label="1">昨日</el-radio-button>
                        <el-radio-button :label="7">7日</el-radio-button>
                        <el-radio-button :label="30">30天</el-radio-button>
                    </el-radio-group>
                    <div>
                        <el-input v-model="query.flowId" placeholder="流水号" class="filter-item" size="medium" show-word-limit style="width: 160px" clearable @keyup.enter.native="toQuery" />
                        <DateRangePicker v-model="query.endTime" class="filter-item" style="width: 332px" @change="dataChange" />
                        <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" style="margin-right: 0px" @click="toQuery" />
                    </div>
                </el-row>
            </div>
            <el-table ref="table" v-loading="loading" highlight-current-row :height="table_height" class="tble game-table" :data="list">
                <el-table-column align="center" label="时间" width="200px">
                    <template slot-scope="scope">
                        <div style="text-align: center">
                            <span>
                                {{ scope.row.startTime }}至
                                <br />
                                {{ scope.row.endTime }}
                            </span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="220px" prop="flowId" align="center" label="流水号" />

                <el-table-column :show-overflow-tooltip="true" width="220" align="center" label="牌桌信息">
                    <template slot-scope="scope">
                        <span>{{ scope.row.anteCoin }}底注|{{ scope.row.deskPlayer }}人桌</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="160" prop="playerCount" align="center" label="玩家数|机器人">
                    <template slot-scope="scope">
                        <span>{{ scope.row.playerCount }}|{{ scope.row.robotCount }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="160" prop="systemWinStr" align="center" label="系统输赢(扣税)">
                    <template slot-scope="scope">
                        <span :class="textColor(scope.row.systemWinStr)">{{ scope.row.systemWinStr }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140" prop="systemTaxStr" align="center" label="系统税收" />
                <el-table-column :show-overflow-tooltip="true" width="140" align="center" label="操作">
                    <template slot-scope="scope">
                        <IconButton
                            v-permission="[permission.fxqClassicFlowDetail]"
                            class="filter-item"
                            size="medium"
                            type="text"
                            style="font-size: 20px"
                            icon="oms_ico_xiangqing"
                            @click="toDetail(scope.row)"
                        />
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
        <Drawer :visible.sync="drawer" title="详情">
            <Detail :flow-id="flowId" v-if="drawer" />
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Detail from './detail.vue'
import * as api from '@/api/game/fxq'

export default {
    components: {
        Drawer,
        Detail,
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            flowId: null,
            drawer: false,
            query: {
                size: 10,
                page: 1,
                flowId: null,
                sort: 'endTime;desc',
                endTime: []
            },
            total: 0,
            day: null,
            loading: false,
            list: [],
            statsData: {
                stats: {}
            } // 统计数据
        }
    },
    mounted() {
        this.fixed_height = 480
        this.day = 0
        this.selectDays()
    },
    methods: {
        dataChange() {
            this.day = null
        },
        selectDays() {
            var start = new Date().daysAgo(this.day).format('yyyy-MM-dd hh:mm:ss')
            var end
            if (this.day === 1) {
                end = start
            } else {
                end = new Date().format('yyyy-MM-dd hh:mm:ss')
            }
            this.query.endTime = [start, end]
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.fxqQuickFlowList(this.query)
                .then((rep) => {
                    this.loading = false
                    this.list = rep.data
                    this.total = rep.page.tc
                })
                .catch(() => {
                    this.loading = false
                })
            api.fxqQuickFlowStats(this.query)
                .then((rep) => {
                    this.statsData = rep.data
                })
                .catch(() => {})
        },

        toDetail(row) {
            this.flowId = row.flowId
            this.drawer = true
        }
    }
}
</script>
