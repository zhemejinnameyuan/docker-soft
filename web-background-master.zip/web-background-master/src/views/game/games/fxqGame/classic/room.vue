<template>
    <div class="game-common-record no-scrollbar">
        <div class="head-container">
            <el-row>
                <el-select v-model="query.enableFlag" placeholder="状态" size="medium" class="filter-item" style="width: 160px" @change="toQuery">
                    <el-option v-for="item in roomStates" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.deskPlayer" placeholder="牌桌类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in deskTypes" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.anteCoin" placeholder="底注金额" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in anteCoins" :key="item" :label="item" :value="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end" style="margin-top: 10px">
                <IconButton v-permission="[permission.fxqClassicRoomAdd]" size="medium" type="primary" icon="oms_ico_add" title="创建房间" @click="toAdd" />
            </el-row>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row :height="table_height" style="width: 100%; margin-top: 20px" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="180px" align="center" label="房间ID">
                <template slot-scope="scope">
                    <svg-icon v-if="scope.row.newbieRoom && scope.row.baseConfig.enableFlag" icon-class="oms_lab_xin" class="new_tag" />
                    <span>{{ scope.row.id }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="牌桌类型">
                <template slot-scope="scope">
                    <span>{{ getDeskType(scope.row.baseConfig.deskPlayer) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="底注">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.anteCoin | filterCion }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" label="税率" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.taxPercent }}%</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="奖励">
                <template slot-scope="scope">
                    <span>{{ getAward(scope.row) | filterCion }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" label="桌子数量" align="center">
                <template slot-scope="scope">
                    <div>混合桌:{{ scope.row.deskCount }}</div>
                    <div>隔离桌:{{ scope.row.ddeskCount }}</div>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" prop="playerCount" align="center" label="玩家/机器人数量">
                <template slot-scope="scope">
                    <div>{{ scope.row.playerCount }}/{{ scope.row.robotCount }}</div>
                    <div>{{ scope.row.dplayerCount }}/{{ scope.row.drobotCount }}</div>
                </template>
            </el-table-column>
            <el-table-column width="120px" align="center" label="状态">
                <template slot-scope="scope">
                    <div class="table_state_switch">
                        <el-switch v-model="scope.row.baseConfig.enableFlag" :disabled="scope.row.newbieRoom" @change="roomStateChange(scope.row)"></el-switch>
                    </div>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" prop="updateTime" align="center" label="操作">
                <template slot-scope="scope">
                    <IconButton v-permission="[permission.fxqClassicRoomEdit]" type="text" size="medium" style="font-size: 20px" icon="oms_ico_edit" @click="toEdit(scope.row)" />
                </template>
            </el-table-column>
        </el-table>
        <Drawer class="drawer" :title="drawerTitle" :visible.sync="drawer">
            <div class="drawer_content">
                <el-form ref="form" :model="form" :rules="rules" label-width="160px">
                    <span class="drawer_content_title">房间基础配置</span>
                    <div class="item_bg">
                        <el-form-item label="房间开关:" prop="enableFlag">
                            <el-switch v-model="form.enableFlag" />
                        </el-form-item>
                        <el-form-item label="牌桌类型:" prop="deskPlayer">
                            <el-select v-model="form.deskPlayer" size="medium" placeholder="请选择牌桌类型" style="width: 280px">
                                <el-option v-for="item in deskTypes" :key="item.id" :label="item.name" :value="item.id" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="进入条件(金币):" prop="joinMinCoin">
                            <InputNumber v-model="form.joinMinCoin" range-width="280px" :precision="2" placeholder="0.01-99999999" :min-number="0.01" :max-number="99999999" clearable />
                        </el-form-item>
                        <el-form-item label="底注(金币):" prop="anteCoin">
                            <InputNumber v-model="form.anteCoin" range-width="280px" :precision="2" placeholder="0.01-99999999" :min-number="0.01" :max-number="99999999" clearable />
                        </el-form-item>
                        <el-form-item label="税率(%):" prop="taxPercent">
                            <InputNumber v-model="form.taxPercent" range-width="280px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                            <span class="tips">现金比例+赢钱比例+税率=100%</span>
                        </el-form-item>
                        <el-form-item label="结算现金比例(%):" prop="depositedPercent">
                            <InputNumber v-model="form.depositedPercent" range-width="280px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                        </el-form-item>
                        <el-form-item label="结算赢钱比例(%):" prop="winningsPercent">
                            <InputNumber v-model="form.winningsPercent" range-width="280px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                        </el-form-item>
                        <el-form-item label="礼物价格:" prop="giftCoin">
                            <InputNumber v-model="form.giftCoin" :precision="2" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                </el-form>
            </div>
            <div class="footer">
                <IconButton class="filter-item" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
            </div>
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import { roomState } from '@/constant/game'
import { deskType } from '@/constant/fxq'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/fxq'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    page: 1,
    size: 10,
    sort: 'createTime;desc',
    all: true,
    enableFlag: true,
    deskPlayer: null,
    anteCoin: null,
    roomRank: null
}
const defaultRoom = {
    enableFlag: false, // 房间状态
    deskPlayer: '', // 牌桌类型
    joinMinCoin: '', // 最小入场金额
    anteCoin: '', // 底注
    roomRank: '', // 房间等级
    taxPercent: 10, // 税率
    depositedPercent: 72, // D账户
    winningsPercent: 18 // W账户
}
export default {
    components: {
        Drawer,
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            deskTypes: Object.values(deskType),
            roomStates: Object.values(roomState),
            anteCoins: [],
            form: {},
            drawer: false,
            drawerType: '',
            drawerTitle: '',
            loading: false,
            query: { ...defaultQuery },
            list: [],
            roomId: undefined,
            newbieRoom: false,
            rules: {
                enableFlag: [{ required: true, message: '请选择房间状态', trigger: 'blur' }],
                deskPlayer: [{ required: true, message: '请选择牌桌类型', trigger: 'blur' }],
                joinMinCoin: [{ required: true, message: '请输入进入条件', trigger: 'blur' }],
                anteCoin: [{ required: true, message: '请输入底注金额', trigger: 'blur' }],
                taxPercent: [{ required: true, message: '请输入税率', trigger: 'blur' }],
                depositedPercent: [{ required: true, message: '请输入结算现金比例', trigger: 'blur' }],
                winningsPercent: [{ required: true, message: '请输入结算赢钱比例', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.fixed_height = 300
        this.toQuery()
    },

    methods: {
        getAward(row) {
            const { deskPlayer, anteCoin, taxPercent } = row.baseConfig
            return deskPlayer * anteCoin * (1 - taxPercent / 100)
        },
        getDeskType(type) {
            return deskType[type].name
        },
        getRoomState(type) {
            return roomState[type].name
        },
        toAdd() {
            this.newbieRoom = false
            this.form = { ...defaultRoom }
            this.drawerType = 'add'
            this.drawer = true
            this.drawerTitle = '创建房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toEdit(row) {
            this.drawerType = 'edit'
            this.roomId = row.id
            this.newbieRoom = row.newbieRoom
            this.form = { ...row.baseConfig }
            this.drawer = true
            this.drawerTitle = '编辑房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery() {
            // 查询房间列表和dz
            if (this.checkPermission([this.permission.fxqClassicRoomList])) {
                api.fxqClassicRoomList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                    })
                    .catch(() => {})
                api.fxqClassicRoomAnte(this.query)
                    .then((rep) => {
                        this.anteCoins = rep.data
                    })
                    .catch(() => {})
            }
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.form.winningsPercent + this.form.depositedPercent + this.form.taxPercent !== 100) {
                        return this.$message.error('请正确设置拆分比例')
                    }
                    if (this.drawerType === 'add') {
                        api.fxqClassicRoomAdd({ baseConfig: this.form })
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间添加成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                    if (this.drawerType === 'edit') {
                        if (this.newbieRoom && !this.form.enableFlag) {
                            return this.$message.error('新手房无法禁用')
                        }
                        var dic = { baseConfig: this.form, id: this.roomId }
                        api.fxqClassicRoomEdit(dic)
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间编辑成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                }
            })
        },
        roomStateChange(data) {
            if (!data.baseConfig.enableFlag) {
                confirmRequest(
                    '禁用以后游戏中将不展示该房间，房间内的玩家结束后将全部离开。确定是否禁用？',
                    () => {
                        this.toEnabled(data)
                    },
                    () => {
                        data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                    }
                )
            } else {
                this.toEnabled(data)
            }
        },

        toEnabled(data) {
            api.fxqClassicRoomEnableDisable(data)
                .then((res) => {
                    if (data.baseConfig.enableFlag) {
                        this.$message.success('启用成功')
                    } else {
                        this.$message.success('禁用成功')
                    }
                })
                .catch(() => {
                    data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                })
        }
    }
}
</script>
