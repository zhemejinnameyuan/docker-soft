<template>
    <div class="common-record-detail no-scrollbar">
        <div class="wrapper_content">
            <div class="item_title">牌局详情</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item label="时间:">
                        <span class="des_title">{{ info.startTime }} 至 {{ info.endTime }}</span>
                    </el-form-item>
                    <el-form-item label="房间ID:">
                        <span class="des_title">{{ info.roomId | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="牌桌信息:">
                        <span class="des_title">{{ info.anteCoin | filterEmpty }}底注 | {{ info.deskPlayer }}人桌</span>
                    </el-form-item>
                    <el-form-item label="税率:">
                        <span class="des_title">{{ info.taxPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="拆分比例:">
                        <span class="des_title">D:{{ info.depositedPercent | filterEmpty }}%｜W:{{ info.winningsPercent | filterEmpty }}%</span>
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title">策略详情</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item :label="getArrayValue(STRATEGY_TYPE, info.strategyType) + ':'" v-if="info.strategyType && info.strategyType != '无策略'">
                        <span class="des_title">触发区间:{{ info.strategyConfig | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['WINNER', 'BRUSH'].indexOf(info.strategyType) !== -1">机器人作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['NEWBIE', 'LOSER'].indexOf(info.strategyType) !== -1">玩家作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div v-if="info.result" class="item_title">牌局结果</div>
            <el-table
                v-if="info.result"
                class="item_table"
                :header-row-style="{ height: '40px' }"
                :row-style="{ height: '40px' }"
                :data="info.result"
                show-summary
                :summary-method="tableSumFixed"
                :border="true"
            >
                <el-table-column :show-overflow-tooltip="true" align="center" width="60" label="排名">
                    <template slot-scope="scope">
                        <span>{{ scope.row.rank === 9 ? '无' : scope.row.rank }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" align="center" width="238" label="玩家信息">
                    <template slot-scope="scope">
                        <i :class="'icon-map fxq-player-pos-color-' + scope.row.pos"></i>
                        <svg-icon v-if="scope.row.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                        <UserIdJump :id="scope.row.playerId" :nickname="scope.row.nickname" />
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" align="center" width="120" label="到达棋子数量">
                    <template slot-scope="scope">
                        <span>{{ scope.row.arriveChess | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" prop="resWinStr" align="center" width="150" label="系统结算输赢(扣税)">
                    <template slot-scope="scope">
                        <span :class="textColor(scope.row.resWinStr)">{{ scope.row.resWinStr | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" prop="actualWinStr" align="center" width="150" label="实际输赢(扣税)">
                    <template slot-scope="scope">
                        <span :class="textColor(scope.row.actualWinStr)">{{ scope.row.actualWinStr | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" prop="taxStr" align="center" width="120" label="税收">
                    <template slot-scope="scope">
                        <span>{{ scope.row.taxStr | filterThousandths }}</span>
                    </template>
                </el-table-column>
            </el-table>

            <div id="classic_back" class="item_title mb-10">牌局回放</div>
            <el-table
                class="back_table"
                :span-method="rowSpanMethod"
                :cell-class-name="tableRowClassName"
                @cell-mouse-leave="cellMouseLeave"
                @cell-mouse-enter="cellMouseEnter"
                :header-row-style="{ height: '40px' }"
                :data="roundList"
                :border="true"
            >
                <el-table-column :show-overflow-tooltip="true" width="100" align="center" label="类型">
                    <template slot-scope="scope">
                        <span v-if="scope.row.stage > 0">第{{ scope.row.stage }}圈</span>
                        <span v-if="scope.row.stage == 0">定庄</span>
                    </template>
                </el-table-column>
                <el-table-column prop="createTime" width="158" align="left" label="玩家">
                    <template slot-scope="scope">
                        <i :class="'icon-map fxq-player-pos-color-' + scope.row.pos"></i>
                        <svg-icon v-if="scope.row.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                        <span v-if="scope.row.robot">{{ scope.row.playerId }}</span>
                        <UserIdJump v-if="!scope.row.robot" :id="scope.row.playerId" />
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="400" prop="card" label="骰子/行为">
                    <template slot-scope="scope">
                        <div v-html="scope.row.operate"></div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="90" align="center" label="巢">
                    <template slot-scope="scope">
                        {{ scope.row.nestChess }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="90" align="center" label="终点">
                    <template slot-scope="scope">
                        {{ scope.row.arriveChess }}
                    </template>
                </el-table-column>
            </el-table>
            <pagination v-if="total" :page-sizes="[5, 10, 20]" :query="query" :total="total" @pageChangeHandler="getRound(true)" />
        </div>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import Card from '@/components/Card'
import * as api from '@/api/game/fxq'
import Base from '@/views/base'
import UserIdJump from '@/components/UserIdJump'
import { STRATEGY_TYPE } from '@/constant/game'

export default {
    components: {
        pagination,
        Card,
        UserIdJump
    },
    mixins: [Base],
    props: {
        flowId: {
            type: Number | String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            STRATEGY_TYPE,
            playerCount: '',
            info: {},
            roundList: [], // 回合列表
            query: {
                size: 5,
                page: 1,
                flowId: this.flowId,
                turnsId: this.round
            },
            orderIndexArr: [], //按回合分组处理样式
            hoverOrderArr: [], //单元格hove记录
            indexCountArr: [], //用于记录合并数量
            count: '',
            total: 0
        }
    },
    computed: {},
    watch: {
        flowId: {
            handler(val) {
                val && this.initData()
            },
            immediate: true
        }
    },
    methods: {
        /** 获取详情 */
        initData() {
            this.rounds = []
            api.fxqClassicFlowDetail({ flowId: this.flowId })
                .then((rep) => {
                    this.info = rep.data
                    //玩家数量
                    this.playerCount = this.info.deskPlayer
                    this.getRound()
                })
                .catch(() => {})
        },
        /** 获取回合回放数据 */
        getRound() {
            api.fxqClassicFlowTurns(this.query)
                .then((rep) => {
                    //初始化分页索引，合并表格
                    this.indexCountArr = []
                    this.orderIndexArr = []
                    this.count = 0
                    this.roundList = this.handleData(rep.data)
                    this.handleSpanGroup()
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {})
        },
        handleData(data) {
            const tableData = []
            data.forEach((i) => {
                if (i.operates) {
                    i.operates.forEach((j) => {
                        j.stage = i.stage
                        tableData.push(j)
                    })
                }
            })
            // 处理合并表格索引
            for (let i = 0; i < tableData.length; i++) {
                if (i == 0) {
                    this.indexCountArr.push(1)
                    this.count = 0
                } else {
                    if (tableData[i].stage == tableData[i - 1].stage) {
                        this.indexCountArr[this.count] += 1
                        this.indexCountArr.push(0)
                    } else {
                        this.indexCountArr.push(1)
                        this.count = i
                    }
                }
            }
            return tableData
        },
        /** 行合并 */
        rowSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                const rowCell = this.indexCountArr[rowIndex]
                if (rowCell > 0) {
                    const colCell = 1
                    return {
                        rowspan: rowCell,
                        colspan: colCell
                    }
                } else {
                    return {
                        rowspan: 0,
                        colspan: 0
                    }
                }
            }
            return [1, 1]
        },
        // 数据样式按第几圈分组
        handleSpanGroup() {
            const OrderObj = {}
            this.roundList.forEach((element, index) => {
                element.rowIndex = index
                if (OrderObj[element.stage]) {
                    OrderObj[element.stage].push(index)
                } else {
                    OrderObj[element.stage] = []
                    OrderObj[element.stage].push(index)
                }
            })
            for (const k in OrderObj) {
                if (OrderObj[k].length > 1) {
                    this.orderIndexArr.push(OrderObj[k])
                }
            }
        },
        // 处理类名
        tableRowClassName({ rowIndex }) {
            const arr = this.hoverOrderArr
            for (let i = 0; i < arr.length; i++) {
                if (rowIndex === arr[i]) {
                    return 'hovered-row'
                }
            }
        },
        // 单元格 hover 进入
        cellMouseEnter(row, column, cell, event) {
            this.rowIndex = row.rowIndex
            this.hoverOrderArr = []
            this.orderIndexArr.forEach((element) => {
                if (element.indexOf(this.rowIndex) >= 0) {
                    this.hoverOrderArr = element
                }
            })
        },
        // 单元格 hover 退出
        cellMouseLeave() {
            this.rowIndex = '-1'
            this.hoverOrderArr = []
        }
    }
}
</script>
