<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="80px" label-position="top">
                <span class="head-title">骰子概率</span>

                <div class="dp-f">
                    <div class="item" style="width: 180px">
                        <el-form-item label="2～6:" prop="globalConfig.sevenUpPercent.a">
                            <InputNumber v-model="form.globalConfig.sevenUpPercent.a" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item ml-10" style="width: 180px">
                        <el-form-item label="7:" prop="globalConfig.sevenUpPercent.b">
                            <InputNumber v-model="form.globalConfig.sevenUpPercent.b" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="8～14:" prop="globalConfig.sevenUpPercent.c">
                            <InputNumber v-model="form.globalConfig.sevenUpPercent.c" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="金骰子:" prop="globalConfig.sevenUpPercent.d">
                            <InputNumber v-model="form.globalConfig.sevenUpPercent.d" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="[permission.supGlobalSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: {
                globalConfig: {
                    sevenUpPercent: {
                        a: '',
                        b: '',
                        c: '',
                        d: ''
                    }
                }
            },
            rules: {
                'globalConfig.sevenUpPercent.a': [{ required: true, message: '请输入2～6概率', trigger: 'blur' }],
                'globalConfig.sevenUpPercent.b': [{ required: true, message: '请输入7概率', trigger: 'blur' }],
                'globalConfig.sevenUpPercent.c': [{ required: true, message: '请输入8～14概率', trigger: 'blur' }],
                'globalConfig.sevenUpPercent.d': [{ required: true, message: '请输入金骰子概率', trigger: 'blur' }]
            },
            config: []
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
