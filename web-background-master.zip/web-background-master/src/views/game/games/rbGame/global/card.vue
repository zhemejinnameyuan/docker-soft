<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="80px" label-position="top">
                <span class="head-title">牌型概率</span>

                <div class="dp-f">
                    <div class="item" style="width: 180px">
                        <el-form-item label="单张:" prop="globalConfig.rbPercent.a">
                            <InputNumber v-model="form.globalConfig.rbPercent.a" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item ml-10" style="width: 180px">
                        <el-form-item label="对子:" prop="globalConfig.rbPercent.b">
                            <InputNumber v-model="form.globalConfig.rbPercent.b" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="金花:" prop="globalConfig.rbPercent.c">
                            <InputNumber v-model="form.globalConfig.rbPercent.c" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="顺子:" prop="globalConfig.rbPercent.d">
                            <InputNumber v-model="form.globalConfig.rbPercent.d" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="顺金:" prop="globalConfig.rbPercent.e">
                            <InputNumber v-model="form.globalConfig.rbPercent.e" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <div class="item" style="width: 180px">
                        <el-form-item label="豹子:" prop="globalConfig.rbPercent.f">
                            <InputNumber v-model="form.globalConfig.rbPercent.f" range-width="150px" :precision="2" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="[permission.rbGlobalSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    data() {
        return {
            form: {
                globalConfig: {
                    rbPercent: {
                        a: '',
                        b: '',
                        c: '',
                        d: '',
                        e: '',
                        f: ''
                    }
                }
            },
            rules: {
                'globalConfig.rbPercent.a': [{ required: true, message: '请输入单张概率', trigger: 'blur' }],
                'globalConfig.rbPercent.b': [{ required: true, message: '请输入对子概率', trigger: 'blur' }],
                'globalConfig.rbPercent.c': [{ required: true, message: '请输入金花概率', trigger: 'blur' }],
                'globalConfig.rbPercent.d': [{ required: true, message: '请输入顺子概率', trigger: 'blur' }],
                'globalConfig.rbPercent.e': [{ required: true, message: '请输入顺金概率', trigger: 'blur' }],
                'globalConfig.rbPercent.f': [{ required: true, message: '请输入豹子概率', trigger: 'blur' }]
            },
            config: []
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
