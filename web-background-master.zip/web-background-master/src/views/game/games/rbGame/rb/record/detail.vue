<template>
    <div class="common-record-detail no-scrollbar" style="width: 1600px">
        <div class="detail-container">
            <div class="item">
                <div class="item_title">牌局详情</div>
                <div class="item_bg" style="width: 480px">
                    <el-form label-width="120px">
                        <el-form-item label="时间:">
                            <span class="des_title">{{ detail.endTime | filterEmpty }}</span>
                        </el-form-item>
                        <el-form-item label="房间ID:">
                            <span class="des_title">{{ detail.roomId | filterEmpty }}</span>
                        </el-form-item>
                        <el-form-item label="牌桌类型:">
                            <span class="des_title">百人场 | {{ detail.deskType == 0 ? '混合桌' : '隔离桌' }}</span>
                        </el-form-item>
                        <el-form-item label="税率:">
                            <span class="des_title">{{ detail.taxPercent | filterEmpty }}%</span>
                        </el-form-item>
                        <el-form-item label="拆分比率:">
                            <span class="des_title">D：{{ detail.depositedPercent | filterEmpty }}%｜W：{{ detail.winningsPercent | filterEmpty }}%</span>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
            <div class="item">
                <div class="item_title">蓄水池</div>
                <div class="item_bg" style="width: 480px">
                    <el-form label-width="120px">
                        <el-form-item label="初始值:">
                            <span class="des_title">{{ detail.initSystemBankStr | filterEmpty }}</span>
                        </el-form-item>
                        <el-form-item label="当前值:">
                            <span class="des_title">{{ detail.currSystemBankStr | filterEmpty }}</span>
                        </el-form-item>
                        <el-form-item label="t值:">
                            <span class="des_title">{{ detail.diffSystemBankStr | filterEmpty }}</span>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
            <div class="item">
                <div class="item_title">策略详情</div>
                <div class="item_bg" style="width: 480px">
                    <el-form label-width="120px">
                        <el-form-item :label="detail.strategyType + ':'">
                            <span class="des_title" v-html="detail.strategyConfig"></span>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
        </div>
        <div class="item_title">牌局结果</div>
        <el-table class="item_table" :header-row-style="scoreTable" show-summary :summary-method="tableSumFixed" :row-style="betTableCell" :data="results">
            <el-table-column width="210" align="center" label="下注区域">
                <template slot-scope="scope">
                    <span>{{ getBetTitle(scope.row.pos) }}</span>
                </template>
            </el-table-column>
            <el-table-column width="100" align="center" label="结果">
                <template slot-scope="scope">
                    <svg-icon v-if="scope.row.posWin" :class="scope.row.pos === 2 ? 'card_reult_win_tie' : 'card_reult_win'" />
                </template>
            </el-table-column>
            <el-table-column width="300" prop="createTime" align="center" label="牌面">
                <template slot-scope="scope">
                    <div class="card_reult">
                        <MultipleCard :list="scope.row.posResult" />
                    </div>
                </template>
            </el-table-column>
            <el-table-column width="310" prop="playerBet" align="center" label="玩家下注" />
            <el-table-column width="310" prop="systemWin" align="center" label="系统输赢">
                <template slot-scope="scope">
                    <span :class="textColor(scope.row.systemWin)">{{ scope.row.systemWin }}</span>
                </template>
            </el-table-column>

            <el-table-column width="310" prop="systemTax" align="center" label="税收" />
        </el-table>

        <div class="item_title">下注记录</div>
        <el-table class="item_table" :header-row-style="scoreTableHeader" :row-style="scoreTable" :data="players">
            <el-table-column :show-overflow-tooltip="true" width="130" align="center" label="玩家信息">
                <template slot-scope="scope">
                    <svg-icon v-if="scope.row.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                    <span v-if="scope.row.robot" style="height: 50px">{{ scope.row.playerId }}({{ scope.row.nickname }})</span>
                    <UserIdJump :id="scope.row.playerId" :nickname="scope.row.nickname" v-if="!scope.row.robot" />
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="蓝下注/赢">
                <template slot-scope="scope">
                    <span style="height: 50px">{{ scope.row.bet_pos_0 }}/{{ scope.row.win_pos_0 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="红下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_1 }}/{{ scope.row.win_pos_1 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="对子下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_2 }}/{{ scope.row.win_pos_2 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="金花下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_3 }}/{{ scope.row.win_pos_3 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="顺子下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_4 }}/{{ scope.row.win_pos_4 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="顺金下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_5 }}/{{ scope.row.win_pos_5 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="豹子下注/赢">
                <template slot-scope="scope">
                    <span>{{ scope.row.bet_pos_6 }}/{{ scope.row.win_pos_6 }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120" align="center" label="结算输赢(扣税)">
                <template slot-scope="scope">
                    <span :class="textColor(scope.row.resultWinStr)">{{ scope.row.resultWinStr }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120" align="center" label="实际输赢(扣税)">
                <template slot-scope="scope">
                    <span :class="textColor(scope.row.actualWinStr)">{{ scope.row.actualWinStr }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120" align="center" label="税收">
                <template slot-scope="scope">
                    <span>{{ scope.row.taxStr }}</span>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
import MultipleCard from '@/components/Card/MultipleCard'
import { BAIREN_POS_CONF, GAME_TYPE } from '@/constant/game'
import * as api from '@/api/game/rb'
import Base from '@/views/base'
import UserIdJump from '@/components/UserIdJump'
export default {
    components: {
        UserIdJump,
        MultipleCard
    },
    mixins: [Base],
    props: {
        flowId: {
            type: Number | String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            GAME_TYPE,
            BAIREN_POS_CONF,
            detail: {},
            players: [],
            results: []
        }
    },
    computed: {
        scoreTable() {
            return {
                height: '30px'
            }
        },
        scoreTableHeader() {
            return {
                height: '40px'
            }
        },
        betTableCell() {
            return {
                height: '60px'
            }
        }
    },
    watch: {
        flowId: {
            handler(val) {
                val && this.initData()
            },
            immediate: true
        }
    },
    methods: {
        scoreCell({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                if (rowIndex === 1 || rowIndex === 2) {
                    return { background: 'rgba(27,162,255,0.10)' }
                } else {
                    return { background: '#F7F7F7' }
                }
            }
        },
        scoreBackCell({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                return { background: '#F7F7F7' }
            }
        },
        initData() {
            api.rbFlowDetail({ flowId: this.flowId })
                .then((rep) => {
                    this.detail = rep.data
                    this.players = rep.data.players
                    this.results = rep.data.results
                    this.handleBetAreaData()
                })
                .catch(() => {})
        },
        //处理下注区域数据
        handleBetAreaData() {
            for (const i in this.players) {
                let betsStr = this.players[i].betsStr
                for (const j in betsStr) {
                    let bet = betsStr[j].y
                    let win = betsStr[j].z
                    this.players[i]['bet_pos_' + j] = bet
                    this.players[i]['win_pos_' + j] = win
                }
            }
        },
        getBetTitle(pos) {
            return BAIREN_POS_CONF[GAME_TYPE.RB][pos]
        }
    }
}
</script>
