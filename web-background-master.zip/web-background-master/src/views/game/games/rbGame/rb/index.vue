<template>
    <div class="game-config-box">
        <el-menu default-active="fjlb" class="menu" @select="handleSelect">
            <el-menu-item v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :index="item.type">
                <span slot="title">{{ item.title }}</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <Room v-if="type === 'fjlb'" />
            <Record v-if="type === 'pjjl'" />
            <Cistern v-if="type === 'xscmx'" :deskType="0" :key="0" />
            <Cistern v-if="type === 'glclmx'" :deskType="1" :key="1" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import Room from './room.vue'
import Record from './record/index.vue'
import Cistern from './cisternRecord.vue'

export default {
    components: {
        Room,
        Record,
        Cistern
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'fjlb',
                title: '房间列表',
                permissions: [this.permission.rbRoomList]
            },
            {
                type: 'pjjl',
                title: '牌局记录',
                permissions: [this.permission.rbFlowList]
            },
            {
                type: 'xscmx',
                title: '蓄水池明细',
                permissions: [this.permission.rbReservoirLog]
            },
            {
                type: 'glclmx',
                title: '隔离策略明细',
                permissions: [this.permission.rbReservoirLog]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        handleSelect(type) {
            this.type = type
        }
    }
}
</script>
