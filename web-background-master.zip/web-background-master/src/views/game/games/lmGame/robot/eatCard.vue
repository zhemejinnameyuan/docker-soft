<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" label-position="left" style="width: 1300px">
                <span class="head-title">机器人防吃牌配置</span>
                <div class="dp-c">
                    <div class="dp-f">
                        <div style="margin-left: 40px">
                            <div class="dp-c">
                                <div class="item">
                                    <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                        <el-table-column label="玩家手牌分区间" align="center" width="300px">
                                            <template slot-scope="scope">
                                                <div class="dp-f-center">
                                                    <div class="mr-10">{{ configTitle[form.defendNextPlayerConfig[scope.row].l] }}:</div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="概率" align="center" width="350px">
                                            <template slot-scope="scope">
                                                <div class="dp-f-center">
                                                    <InputNumber
                                                        v-model="form.defendNextPlayerConfig[scope.row].r"
                                                        :rangeWidth="'180px'"
                                                        placeholder=""
                                                        :min-number="0"
                                                        :max-number="10000"
                                                        clearable
                                                    />
                                                </div>
                                            </template>
                                        </el-table-column>
                                    </el-table>
                                </div>
                                <div class="mt-20 text_blue fs-12 dp-c">
                                    <span>配置说明：概率取值0～10000之间，触发到玩家上家机器人出牌时</span>
                                    <span class="mt-10">(会优先将玩家要不到的牌打出(如果上家是非杀牌机器人，从所有手牌中找，如果是杀牌机器人，从无效牌中找)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { range } from '@/utils'

export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {},
            config: [],
            configTitle: {
                70: '玩家手牌分>=70',
                60: '60<=玩家手牌分<70',
                40: '40<=玩家手牌分<60',
                0: '玩家手牌分<40'
            },
            rules: {}
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },
    methods: {
        initData() {
            this.config = range(0, 3)
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    for (let index in this.form.defendNextPlayerConfig) {
                        let childItem = this.form.defendNextPlayerConfig[index]
                        if (_.isNull(childItem.r)) {
                            return this.$message.error(this.configTitle[childItem.l] + ',概率不能为空')
                        }
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
