<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" label-position="left" style="width: 1300px">
                <span class="head-title">陪玩机器人开关</span>
                <div class="">
                    <div>
                        <el-form-item label="开关:" prop="playEnableFlag">
                            <el-switch v-model="form.playEnableFlag" class="inline-item"></el-switch>
                        </el-form-item>
                        <span class="text_blue fs-12">开启后才会有陪玩机器人加入，关闭不会有陪玩机器人加入。</span>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: null,
            rules: {
                playEnableFlag: [{ required: true, message: '请配置机器人开关', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
        }, 60)
    },
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
