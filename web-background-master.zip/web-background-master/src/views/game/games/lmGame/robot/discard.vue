<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" label-position="left" style="width: 1300px">
                <span class="head-title">弃牌配置</span>
                <div class="dp-c">
                    <div class="dp-f">
                        <div style="margin-left: 40px">
                            <span class="head-title">未摸牌</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <div class="item">
                                    <el-form-item label="" prop="noMoAiScore" style="margin-bottom: 0px">
                                        <div class="dp-f-vertical-center">
                                            <span class="sub_title_ai mr-5" style="width: 140px">
                                                <span class="text_red">*</span>
                                                机器人手牌类型为:
                                            </span>
                                            <el-select v-model="form.noMoDiscard.l" placeholder="不限类型" size="medium" class="filter-item" style="width: 160px">
                                                <el-option label="不限类型" :value="1" />
                                                <el-option label="非好牌" :value="2" />
                                                <el-option label="坏牌" :value="3" />
                                            </el-select>
                                        </div>
                                    </el-form-item>

                                    <el-form-item label="" prop="noMoDiscard.r" style="margin-bottom: 0px">
                                        <div class="dp-f-vertical-center ml-30">
                                            <span class="sub_title_ai mr-5" style="width: 140px">
                                                <span class="text_red">*</span>
                                                且机器人手牌分>=:
                                            </span>
                                            <InputNumber v-model="form.noMoDiscard.r" range-width="100px" placeholder="1-80" :min-number="1" :max-number="80" clearable />
                                        </div>
                                        <span class="tips" />
                                    </el-form-item>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="dp-f">
                        <div style="margin-left: 40px">
                            <span class="head-title">已摸牌</span>
                            <div class="dp-c" style="margin-left: 20px">
                                <div class="item">
                                    <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                        <el-table-column label="牌桌人数" align="center" width="100">
                                            <template slot-scope="scope">{{ form.moDiscard[scope.$index].a }}</template>
                                        </el-table-column>
                                        <el-table-column label="连续轮数手牌分>弃牌失分或" align="center" width="300px">
                                            <template slot-scope="scope">
                                                <div class="dp-f-vertical-center">
                                                    <div class="mr-10">轮数:</div>
                                                    <InputNumber
                                                        v-model="form.moDiscard[scope.$index].b"
                                                        :rangeWidth="'80px'"
                                                        placeholder=""
                                                        :min-number="inputRange[scope.row].min"
                                                        :max-number="inputRange[scope.row].max"
                                                        clearable
                                                    />
                                                    <div class="ml-10 text_blue fs-12">取值范围{{ inputRange[scope.row].min }}～{{ inputRange[scope.row].max }}</div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                        <el-table-column label="连续轮数手牌分变化<=阀值且>弃牌失分" align="center" width="550px">
                                            <template slot-scope="scope">
                                                <div class="dp-f-vertical-center">
                                                    <div class="mr-10">轮数:</div>
                                                    <InputNumber
                                                        v-model="form.moDiscard[scope.$index].c"
                                                        :rangeWidth="'80px'"
                                                        placeholder=""
                                                        :min-number="inputRange[scope.row].min"
                                                        :max-number="inputRange[scope.row].max"
                                                        clearable
                                                    />
                                                    <div class="ml-10 text_blue fs-12" style="width: 100px">取值范围{{ inputRange[scope.row].min }}～{{ inputRange[scope.row].max }}</div>

                                                    <div class="ml-40 mr-10">分值变化:</div>
                                                    <InputNumber v-model="form.moDiscard[scope.$index].d" :rangeWidth="'80px'" placeholder="" :min-number="0" :max-number="10" clearable />
                                                    <div class="ml-10 text_blue fs-12">取值范围0～10</div>
                                                </div>
                                            </template>
                                        </el-table-column>
                                    </el-table>

                                    <div class="mt-20 text_blue fs-12">配置说明：杀牌机器人不执行弃牌行为，Pool模式机器人掉落数为0时，不执行弃牌行为，Deals模式机器人无弃牌行为。</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="savePermission" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { range } from '@/utils'

export default {
    props: {
        configData: {
            type: Object,
            default: {}
        },
        savePermission: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {
                noMoDiscard: {
                    l: '',
                    r: ''
                }
            },
            discard: [],
            config: [],
            inputRange: {
                0: { min: 3, max: 20 },
                1: { min: 3, max: 20 },
                2: { min: 3, max: 12 },
                3: { min: 3, max: 8 },
                4: { min: 3, max: 4 }
            },
            rules: {
                'noMoDiscard.r': [{ required: true, message: '请配置机器人手牌分', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        //延迟赋值，保证渲染
        setTimeout(() => {
            this.form = this.configData
            this.initData()
        }, 60)
    },
    methods: {
        initData() {
            this.config = range(0, 4)
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    for (let index in this.form.moDiscard) {
                        let childItem = this.form.moDiscard[index]
                        if (_.isNull(childItem.b) || _.isNull(childItem.c) || _.isNull(childItem.d)) {
                            return this.$message.error('牌桌人数:' + childItem.a + '-对应配置不能为空')
                        }
                    }
                    this.$emit('toSubmit', this.form)
                }
            })
        }
    }
}
</script>
