<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="pwjqr">
                <span slot="title">陪玩机器人</span>
            </el-menu-item>
            <el-menu-item index="qppz">
                <span slot="title">弃牌配置</span>
            </el-menu-item>
            <el-menu-item index="jqrtspz">
                <span slot="title">机器人透视配置</span>
            </el-menu-item>
            <el-menu-item index="fwjmppz">
                <span slot="title">防玩家摸牌配置</span>
            </el-menu-item>
            <el-menu-item index="jqrfcppz">
                <span slot="title">机器人防吃牌配置</span>
            </el-menu-item>
            <el-menu-item index="ljlc">
                <span slot="title">留局离场</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <Play v-if="type === 'pwjqr' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
            <Discard v-if="type === 'qppz' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
            <Perspective v-if="type === 'jqrtspz' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
            <DrawCard v-if="type === 'fwjmppz' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
            <EatCard v-if="type === 'jqrfcppz' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
            <Out v-if="type === 'ljlc' && configData" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmRobotSave]" />
        </div>
    </div>
</template>

<script>
import Play from './play'
import Discard from './discard'
import Perspective from './perspective'
import DrawCard from './drawCard'
import EatCard from './eatCard'
import Out from './out'
import Base from '@/views/base'
import * as api from '@/api/game/lm'
import { GAME_TYPE } from '@/constant/game'

export default {
    components: {
        Play,
        Discard,
        Perspective,
        DrawCard,
        EatCard,
        Out
    },
    mixins: [Base],
    data() {
        return {
            GAME_TYPE,
            type: 'pwjqr',
            configData: null
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        handleSelect(type) {
            this.type = type
            this.toQuery()
        },
        //查询
        toQuery() {
            api.robotGet().then((rep) => {
                this.repData = rep.data
                this.configData = { ...this.repData.jsonConfig }
            })
        },
        //保存
        toSubmit(configData) {
            this.repData.jsonConfig = { ...configData }
            api.robotSave(this.repData).then((rep) => {
                this.$message.success('保存成功')
            })
        }
    }
}
</script>
