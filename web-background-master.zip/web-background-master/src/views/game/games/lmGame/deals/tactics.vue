<template>
    <div class="game-common-record">
        <div class="head-container">
            <el-input v-model="query.flowId" placeholder="牌局流水" class="filter-item" size="medium" show-word-limit style="width: 160px" clearable @keyup.enter.native="toQuery" />
            <DateRangePicker v-model="query.endTime" class="filter-item" @change="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
        </div>

        <el-table ref="table" v-loading="loading" highlight-current-row :height="table_height" class="tble mt-10 game-table" :data="list">
            <el-table-column prop="endTime" width="180" align="center" label="时间" />
            <el-table-column prop="flowId" width="180" align="center" label="牌局流水号">
                <template slot-scope="scope">
                    <a class="text_blue" @click="toDetail(scope.row)">{{ scope.row.flowId }}</a>
                </template>
            </el-table-column>
            <el-table-column prop="strategyType" width="120" align="center" label="策略">
                <template slot-scope="scope">
                    <span>{{ getArrayValue(STRATEGY_TYPE, scope.row.strategyType) | filterEmpty }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" prop="systemWinStr" width="120" align="center" label="系统输赢(扣税)">
                <template slot-scope="scope">
                    <span :class="textColor(scope.row.systemWinStr)">{{ scope.row.systemWinStr | filterThousandths }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="strategyValue" width="140" align="center" label="触发条件">
                <template slot-scope="scope">
                    <div v-if="scope.row.strategyType">
                        <span v-html="getStrategyValueTitle(scope.row.strategyType, scope.row.strategyValue)"></span>
                    </div>
                </template>
            </el-table-column>
            <el-table-column prop="strategyConfig" width="180" align="center" label="触发区间">
                <template slot-scope="scope">
                    <span v-if="scope.row.strategyType">{{ scope.row.strategyConfig }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="strategyPercent" width="180" align="center" label="触发概率">
                <template slot-scope="scope">
                    <div v-if="scope.row.strategyType">
                        <span v-if="['WINNER', 'BRUSH'].indexOf(scope.row.strategyType) !== -1">机器人作弊概率:</span>
                        <span v-if="['NEWBIE', 'LOSER'].indexOf(scope.row.strategyType) !== -1">玩家作弊概率:</span>
                        <br />
                        <span>{{ scope.row.strategyPercent }}</span>
                    </div>
                </template>
            </el-table-column>
            <el-table-column prop="strategyOpen" width="120" align="center" label="触发次数">
                <template slot-scope="scope">
                    <span v-if="scope.row.strategyType">{{ scope.row.strategyOpen | filterThousandths }}次</span>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />

        <Drawer :visible.sync="drawer" title="详情">
            <Detail :flow-id="flowId" v-if="drawer" />
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import DateRangePicker from '@/components/DateRangePicker'
import pagination from '@/components/Pagination'
import Detail from './record/detail'
import * as api from '@/api/game/lm'
import { STRATEGY_TYPE } from '@/constant/game'
const defaultQuery = {
    page: 1,
    size: 20,
    sort: 'endTime;desc',
    all: false,
    flowId: null,
    endTime: []
}
export default {
    components: {
        DateRangePicker,
        Drawer,
        Detail,
        pagination
    },
    mixins: [Base],
    data() {
        return {
            STRATEGY_TYPE,
            loading: false,
            total: 0,
            flowId: '',
            drawer: false,
            query: { ...defaultQuery },
            list: []
        }
    },
    mounted() {
        this.fixed_height = 300
        this.toQuery()
    },

    methods: {
        toDetail(row) {
            this.flowId = row.flowId
            this.drawer = true
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.dealsReservoirLog(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.loading = false
                    this.total = rep.page.tc
                })
                .catch(() => {
                    this.loading = false
                })
        }
    }
}
</script>
