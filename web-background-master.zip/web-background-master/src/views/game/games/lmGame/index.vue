<template>
    <div class="web-container" style="background: #f7f7f7">
        <GoHome />
        <div class="container_title">LM-游戏管理</div>
        <div class="container_game">
            <div class="game_tab">
                <div v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :class="tabClass(item.type)" @click="changeTab(item.type)">
                    {{ item.title }}
                </div>
            </div>
            <div class="game_content">
                <Points v-if="type === 'points'" />
                <Pool v-if="type === 'pool'" />
                <Deals v-if="type === 'deals'" />
                <Robot v-if="type === 'robot'" />
                <Train v-if="type === 'train'" />
                <Global v-if="type === 'global'" />
            </div>
        </div>
    </div>
</template>

<script>
import Points from './points/index.vue'
import Pool from './pool/index.vue'
import Deals from './deals/index.vue'
import Robot from './robot/index.vue'
import Train from './train/index.vue'
import Global from './global/index.vue'
import Base from '@/views/base'
import GoHome from '@/components/GoHome'

export default {
    name: 'LmGame',
    components: {
        Points,
        Pool,
        Deals,
        Robot,
        Train,
        Global,
        GoHome
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'points',
                title: 'Points',
                permissions: [this.permission.lmPointsRoomList, this.permission.lmPointsFlowList, this.permission.lmPointsDealGet, this.permission.lmPointsTutelageGet]
            },
            {
                type: 'pool',
                title: 'Pool',
                permissions: [this.permission.lmPoolRoomList, this.permission.lmPoolFlowList, this.permission.lmPoolDealGet, this.permission.lmPoolTutelageGet]
            },
            {
                type: 'deals',
                title: 'Deals',
                permissions: [this.permission.lmDealsRoomList, this.permission.lmDealsFlowList, this.permission.lmDealsDealGet, this.permission.lmDealsTutelageGet]
            },
            {
                type: 'robot',
                title: '机器人',
                permissions: [this.permission.lmRobotGet]
            },
            {
                type: 'global',
                title: '全局配置',
                permissions: [this.permission.lmGlobalGet]
            },
            {
                type: 'train',
                title: '练习场',
                permissions: [this.permission.lmPracticeRoomList, this.permission.lmPracticeCoinGet, this.permission.lmPracticeDealGet, this.permission.lmPracticeTutelageGet]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        tabClass(type) {
            return type === this.type ? 'game_tab_item_active' : 'game_tab_item'
        },
        changeTab(type) {
            this.type = type
        }
    }
}
</script>
