<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-position="top">
                <span class="head-title">新手保护策略</span>
                <el-form-item label="新手保护策略开关:" prop="reservoir.newbieSwitch" label-width="110px" class="inline-item">
                    <el-switch v-model="form.reservoir.newbieSwitch" />
                </el-form-item>

                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="新手保护局数:" prop="reservoir.newbieWin.l">
                            <InputNumber v-model="form.reservoir.newbieWin.l" range-width="200px" :single-big-input="true" placeholder="0-10" :min-number="0" :max-number="10" clearable />
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="玩家作弊概率（万分比）:" prop="reservoir.newbieWin.r">
                            <InputNumber v-model="form.reservoir.newbieWin.r" range-width="200px" :single-big-input="true" placeholder="0-10000" :min-number="0" :max-number="10000" clearable />
                        </el-form-item>
                    </div>
                </div>
                <span class="head-title">新手房间</span>
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="Points:" prop="newbiePointsRoomIds">
                            <el-select v-model="newbiePointsRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in pointsRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="Pool:" prop="newbiePoolRoomIds">
                            <el-select v-model="newbiePoolRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in poolRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="Deals:" prop="newbieDealsRoomIds">
                            <el-select v-model="newbieDealsRoomIds" multiple placeholder="请选择" size="medium" style="width: 280px" clearable>
                                <el-option v-for="(item, index) in dealsRooms" :key="index" :disabled="!item.baseConfig.enableFlag" :label="getRoomTitle(item)" :value="item.id" />
                            </el-select>
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>

        <div class="footer">
            <IconButton v-permission="[permission.lmGlobalSave]" class="filter-item" size="medium" type="primary" title="保存" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/lm'
import { ROOM_TYPE } from '@/constant/lm'
export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        const checkNewbiePointsRoomIds = (rule, value, callback) => {
            if (this.newbiePointsRoomIds.length === 0) {
                callback(new Error('请选择ePoints房间'))
            }
            callback()
        }
        const checkNewbiePoolRoomIds = (rule, value, callback) => {
            if (this.newbiePoolRoomIds.length === 0) {
                callback(new Error('请选择Pool房间'))
            }
            callback()
        }
        const checkNewbieDealsRoomIds = (rule, value, callback) => {
            if (this.newbieDealsRoomIds.length === 0) {
                callback(new Error('请选择Deals房间'))
            }
            callback()
        }

        return {
            ROOM_TYPE,
            query: { all: true, enableFlag: true },
            form: {
                reservoir: {
                    newbieWin: { l: '', r: '' }
                }
            },
            pointsRooms: [],
            newbiePointsRoomIds: [],
            poolRooms: [],
            newbiePoolRoomIds: [],
            dealsRooms: [],
            newbieDealsRoomIds: [],
            rules: {
                'reservoir.newbieSwitch': [{ required: true, message: '请选择新手保护策略开关', trigger: 'blur' }],
                'reservoir.newbieWin.l': [{ required: true, message: '请配置新手保护局数', trigger: 'blur' }],
                'reservoir.newbieWin.r': [{ required: true, message: '请配置玩家作弊概率', trigger: 'blur' }],
                newbiePointsRoomIds: [{ required: true, validator: checkNewbiePointsRoomIds, trigger: 'blur' }],
                newbiePoolRoomIds: [{ required: true, validator: checkNewbiePoolRoomIds, trigger: 'blur' }],
                newbieDealsRoomIds: [{ required: true, validator: checkNewbieDealsRoomIds, trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.getRoom()
        setTimeout(() => {
            this.toQuery()
        }, 200)
    },

    methods: {
        getRoomTitle(item) {
            let config = item.baseConfig
            let title = ''
            switch (item.roomType) {
                case ROOM_TYPE.POINTS:
                    title = `底注${config.anteCoin}｜${config.deskPlayer}人桌`
                    break
                case ROOM_TYPE.POOL:
                    title = `底注${config.anteCoin}｜${config.deskPlayer}人桌|${config.deskScore}分场`
                    break
                case ROOM_TYPE.DEALS:
                    title = `底注${config.anteCoin}｜${config.gameTurns}局场`
                    break
                default:
                    break
            }
            return title
        },

        getRoom() {
            if (this.checkPermission([this.permission.lmGlobalNewbiePoints])) {
                api.pointsRoomList(this.query).then((rep) => {
                    this.pointsRooms = rep.data
                })
            }
            if (this.checkPermission([this.permission.lmGlobalNewbiePool])) {
                api.poolRoomList(this.query).then((rep) => {
                    this.poolRooms = rep.data
                })
            }
            if (this.checkPermission([this.permission.lmGlobalNewbieDeals])) {
                api.dealsRoomList(this.query).then((rep) => {
                    this.dealsRooms = rep.data
                })
            }
        },
        toQuery() {
            api.lmGlobalGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }

                //处理每个房间的ID
                this.pointsRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbiePointsRoomIds.push(item.id)
                    }
                })

                this.poolRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbiePoolRoomIds.push(item.id)
                    }
                })

                this.dealsRooms.forEach((item) => {
                    if (this.form.reservoir.newbieRoomIds.indexOf(item.id) != -1) {
                        this.newbieDealsRoomIds.push(item.id)
                    }
                })
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    //拼装每个房间的ID
                    this.repData.jsonConfig.reservoir.newbieRoomIds = _.concat(this.newbiePointsRoomIds, this.newbiePoolRoomIds, this.newbieDealsRoomIds)
                    api.lmGlobalSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
