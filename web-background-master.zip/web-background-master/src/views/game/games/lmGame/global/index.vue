<template>
    <div class="game-config-box">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="hpcl">
                <span slot="title">伙牌策略</span>
            </el-menu-item>
            <el-menu-item index="mrfp">
                <span slot="title">默认发牌</span>
            </el-menu-item>
            <el-menu-item index="tgqp">
                <span slot="title">托管弃牌</span>
            </el-menu-item>
            <el-menu-item index="xsbhcl">
                <span slot="title">新手保护策略</span>
            </el-menu-item>
            <el-menu-item index="yjcl">
                <span slot="title">输赢策略</span>
            </el-menu-item>
            <el-menu-item index="szcl">
                <span slot="title">刷子策略</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <PartnerConfig v-if="type === 'hpcl' && configData" :gameType="GAME_TYPE.LM" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmGlobalSave]" />
            <WinConfig v-if="type === 'yjcl' && configData" :gameType="GAME_TYPE.LM" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmGlobalSave]" />
            <BrushConfig v-if="type === 'szcl' && configData" :gameType="GAME_TYPE.LM" :configData="configData" @toSubmit="toSubmit" :savePermission="[permission.lmGlobalSave]" />
            <NewConfig v-if="type === 'xsbhcl'" />
            <DealConfig v-if="type === 'mrfp'" />
            <Trusteeship v-if="type === 'tgqp'" />
        </div>
    </div>
</template>

<script>
import PartnerConfig from '@/views/game/games/roomCommon/global/partner.vue'
import WinConfig from '@/views/game/games/roomCommon/global/win.vue'
import BrushConfig from '@/views/game/games/roomCommon/global/brush.vue'
import NewConfig from './new.vue'
import DealConfig from './deal.vue'
import Trusteeship from './trusteeship.vue'
import Base from '@/views/base'
import * as api from '@/api/game/lm'
import { GAME_TYPE } from '@/constant/game'

export default {
    components: {
        PartnerConfig,
        DealConfig,
        Trusteeship,
        NewConfig,
        WinConfig,
        BrushConfig
    },
    mixins: [Base],
    data() {
        return {
            GAME_TYPE,
            type: 'hpcl',
            configData: null
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        handleSelect(type) {
            this.type = type
            //新手保护策略、默认发牌和托管弃牌  单独处理
            if (['xsbhcl', 'mrfp', 'tgqp'].indexOf(this.type) === -1) {
                this.toQuery()
            }
        },
        //查询
        toQuery() {
            api.lmGlobalGet().then((rep) => {
                this.repData = rep.data
                this.configData = { ...this.repData.jsonConfig }
            })
        },
        //保存
        toSubmit(configData) {
            this.repData.jsonConfig = { ...configData }
            api.lmGlobalSave(this.repData).then((rep) => {
                this.$message.success('保存成功')
            })
        }
    }
}
</script>
