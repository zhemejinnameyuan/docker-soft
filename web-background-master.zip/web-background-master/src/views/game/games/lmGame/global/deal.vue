<template>
    <div class="game-common-config">
        <div v-if="form.jsonConfig" class="config_content no-scrollbar">
            <el-form ref="form" :model="form.jsonConfig" :rules="rules" label-position="top">
                <span class="head-title">默认发牌规则</span>
                <el-form-item label="纯顺子概率:" prop="dealStrategy.pureSequencePercent">
                    <div class="horizontal-container">
                        <div class="item">
                            <InputNumber
                                v-model="form.jsonConfig.dealStrategy.pureSequencePercent[0]"
                                range-width="100px"
                                :text-center="true"
                                placeholder="0-10000"
                                :min-number="0"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item">
                            <InputNumber
                                v-model="form.jsonConfig.dealStrategy.pureSequencePercent[1]"
                                range-width="100px"
                                :text-center="true"
                                placeholder="0-10000"
                                :min-number="0"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item">
                            <InputNumber
                                v-model="form.jsonConfig.dealStrategy.pureSequencePercent[2]"
                                range-width="100px"
                                :text-center="true"
                                placeholder="0-10000"
                                :min-number="0"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                    </div>
                    <span class="text_blue fs-12 mt-10">分别代表发0张、1张、2张纯顺子权重</span>
                </el-form-item>
                <el-form-item label="百搭牌概率:" prop="dealStrategy.jokerPercent">
                    <div class="horizontal-container">
                        <div class="item">
                            <InputNumber
                                v-model="form.jsonConfig.dealStrategy.jokerPercent[0]"
                                range-width="100px"
                                :text-center="true"
                                placeholder="0-10000"
                                :min-number="0"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                        <div class="item">
                            <InputNumber
                                v-model="form.jsonConfig.dealStrategy.jokerPercent[1]"
                                range-width="100px"
                                :text-center="true"
                                placeholder="0-10000"
                                :min-number="0"
                                :max-number="10000"
                                clearable
                            />
                        </div>
                    </div>
                    <span class="text_blue fs-12 mt-10">分别代表发0张、1张百搭牌权重</span>
                </el-form-item>

                <span class="head-title">陪玩手牌分配规则</span>

                <div class="dp-c">
                    <div class="dp-f">
                        <div class="dp-c">
                            <div class="item">
                                <el-table :data="config" class="common_form_table" :row-style="{ height: '40', background: '#F7F7F7' }">
                                    <el-table-column label="牌桌人数" align="center" width="100px">
                                        <template slot-scope="scope">
                                            <div class="dp-f-center">
                                                <div class="mr-10">{{ form.jsonConfig.dealStrategy.handCardPoints[scope.$index].l }}</div>
                                            </div>
                                        </template>
                                    </el-table-column>
                                    <el-table-column label="[Points]玩家拿好牌概率(万分比)" align="center" width="250px">
                                        <template slot-scope="scope">
                                            <div class="dp-f-center">
                                                <InputNumber
                                                    v-model="form.jsonConfig.dealStrategy.handCardPoints[scope.$index].r"
                                                    :rangeWidth="'180px'"
                                                    placeholder=""
                                                    :min-number="0"
                                                    :max-number="10000"
                                                    clearable
                                                />
                                            </div>
                                        </template>
                                    </el-table-column>
									<el-table-column label="[Pool]玩家拿好牌概率(万分比)" align="center" width="250px">
										<template slot-scope="scope">
											<div class="dp-f-center">
												<InputNumber
													v-model="form.jsonConfig.dealStrategy.handCardPool[scope.$index].r"
													:rangeWidth="'180px'"
													placeholder=""
													:min-number="0"
													:max-number="10000"
													clearable
												/>
											</div>
										</template>
									</el-table-column>
									<el-table-column label="[Deals]玩家拿好牌概率(万分比)" align="center" width="250px">
										<template slot-scope="scope">
											<div class="dp-f-center">
												<InputNumber
													v-if="form.jsonConfig.dealStrategy.handCardPoints[scope.$index].l === 2"
													v-model="form.jsonConfig.dealStrategy.handCardDeals"
													:rangeWidth="'180px'"
													placeholder=""
													:min-number="0"
													:max-number="10000"
													clearable
												/>
											</div>
										</template>
									</el-table-column>
                                </el-table>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div v-if="form.jsonConfig.dealStrategy" class="footer">
            <IconButton v-permission="[permission.lmPointsDealSave]" style="width: 120px" class="filter-item" size="medium" type="primary" title="保存" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/lm'
import { checkArr } from '@/utils/filters'
import { range } from '@/utils'

export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {
                jsonConfig: {
                    dealStrategy: {
                        pureSequencePercent: [0, 0, 0],
                        jokerPercent: [0, 0],
						handCardPoints: {},
						handCardPool: {},
						handCardDeals: '',
                    }
                }
            },
            config: [],
            rules: {
                'dealStrategy.pureSequencePercent': [{ required: true, validator: checkArr, message: '请配置纯顺子概率', trigger: 'blur' }],
                'dealStrategy.jokerPercent': [{ required: true, validator: checkArr, message: '请配置百搭牌概率', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.toQuery()
        this.initData()
    },

    methods: {
        initData() {
            this.config = range(2, 6)
            for (let i in this.config) {
                if (this.form.jsonConfig.dealStrategy.handCardPoints[i] === undefined) {
                    this.form.jsonConfig.dealStrategy.handCardPoints[i] = { l: '', r: '' }
                }  if (this.form.jsonConfig.dealStrategy.handCardPool[i] === undefined) {
                    this.form.jsonConfig.dealStrategy.handCardPool[i] = { l: '', r: '' }
                }
            }
        },
        toQuery() {
            api.lmGlobalGet().then((rep) => {
                this.form = rep.data
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    const dealStrategy = this.form.jsonConfig.dealStrategy
                    if (_.sum(dealStrategy.pureSequencePercent) !== 10000) {
                        return this.$message.error('纯顺子概率和应为10000')
                    }
                    if (_.sum(dealStrategy.jokerPercent) !== 10000) {
                        return this.$message.error('百搭牌概率和应为10000')
                    }

                    api.lmGlobalSave(this.form).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
