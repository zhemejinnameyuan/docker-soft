<template>
    <div class="game-common-config">
        <div v-if="form.jsonConfig" class="config_content no-scrollbar">
            <el-form ref="form" :model="form.jsonConfig" :rules="rules" label-width="150px" label-position="top">
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="2人桌自动弃牌轮数:" prop="practiceTutelage.autoDropTurns2">
                            <InputNumber
                                v-model="form.jsonConfig.practiceTutelage.autoDropTurns2"
                                range-width="200px"
                                :single-big-input="true"
                                placeholder="1-10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </el-form-item>
                    </div>

                    <div class="item">
                        <el-form-item label="6人桌自动弃牌轮数:" prop="practiceTutelage.autoDropTurns6">
                            <InputNumber
                                v-model="form.jsonConfig.practiceTutelage.autoDropTurns6"
                                range-width="200px"
                                :single-big-input="true"
                                placeholder="1-10000"
                                :min-number="1"
                                :max-number="10000"
                                clearable
                            />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div v-if="form.jsonConfig" class="footer">
            <IconButton v-permission="[permission.lmPracticeConfigSave]" style="width: 120px" size="medium" type="primary" title="保存" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/lm'

export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {},
            rules: {
                'practiceTutelage.autoDropTurns2': [{ required: true, message: '请输入2人桌自动弃牌轮数', trigger: 'blur' }],
                'practiceTutelage.autoDropTurns6': [{ required: true, message: '请输入6人桌自动弃牌轮数', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.toQuery()
    },

    methods: {
        toQuery() {
            api.lmPracticeConfigGet().then((rep) => {
                this.form = rep.data
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    api.lmPracticeConfigSave(this.form).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
