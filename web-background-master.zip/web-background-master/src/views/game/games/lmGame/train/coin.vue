<template>
    <div class="game-common-config">
        <div v-if="form" class="config_content no-scrollbar">
            <el-form ref="form" :model="form" :rules="rules" label-width="205px" label-position="top">
                <span class="head-title">初始金额</span>
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="初次进入房间金额:" prop="initCoin">
                            <InputNumber v-model="form.initCoin" range-width="200px" :single-big-input="true" :min-number="1" :max-number="9999999" placeholder="1-9999999" clearable />
                        </el-form-item>
                    </div>
                </div>

                <span class="head-title">免充配置</span>
                <div class="horizontal-container">
                    <div class="item">
                        <el-form-item label="Get金额:" prop="getCoin">
                            <InputNumber v-model="form.getCoin" range-width="200px" :single-big-input="true" :min-number="1" :max-number="9999999" placeholder="1-9999999" clearable />
                        </el-form-item>
                    </div>
                    <div class="item">
                        <el-form-item label="Getx2金额:">
                            <InputNumber v-model="form.getCoin * 2" :disabled="true" range-width="200px" :single-big-input="true" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="footer">
            <IconButton v-permission="[permission.tpConfigPracticeSave]" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/lm'

export default {
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            form: {},
            rules: {
                initCoin: [{ required: true, message: '请输入初次进入房间金额', trigger: 'blur' }],
                getCoin: [{ required: true, message: '请输入Get金额', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.toQuery()
    },

    methods: {
        toQuery() {
            api.lmPracticeConfigGet().then((rep) => {
                this.repData = rep.data
                this.form = { ...this.repData.jsonConfig }
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.repData.jsonConfig = { ...this.form }
                    api.lmPracticeConfigSave(this.repData).then((rep) => {
                        this.$message.success('保存成功')
                    })
                }
            })
        }
    }
}
</script>
