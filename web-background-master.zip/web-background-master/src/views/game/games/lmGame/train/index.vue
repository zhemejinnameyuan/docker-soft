<template>
    <div class="game-config-box">
        <el-menu default-active="fjlb" class="menu" @select="handleSelect">
            <el-menu-item v-for="(item, index) in configs" :key="index" v-permission="item.permissions" :index="item.type">
                <span slot="title">{{ item.title }}</span>
            </el-menu-item>
        </el-menu>

        <div class="content">
            <Room v-if="type === 'fjlb'" />
            <Coin v-if="type === 'jjbpz'" />
            <Trusteeship v-if="type === 'tgpz'" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import Room from './room.vue'
import Coin from './coin.vue'
import Trusteeship from './trusteeship.vue'

export default {
    components: {
        Room,
        Coin,
        Trusteeship
    },
    mixins: [Base],
    data() {
        return {
            type: '',
            configs: []
        }
    },
    mounted() {
        this.configs = [
            {
                type: 'fjlb',
                title: '房间列表',
                permissions: [this.permission.lmPracticeRoomList]
            },
            {
                type: 'jjbpz',
                title: '加金币配置',
                permissions: [this.permission.lmPracticeCoinGet]
            },
            {
                type: 'tgpz',
                title: '托管配置',
                permissions: [this.permission.lmPracticeTutelageGet]
            }
        ]
        for (let index = 0; index < this.configs.length; index++) {
            const element = this.configs[index]
            if (this.checkPermission(element.permissions)) {
                this.type = element.type
                break
            }
        }
    },

    methods: {
        handleSelect(type) {
            this.type = type
        }
    }
}
</script>
