<template>
    <div class="pool-record-detail">
        <div id="pool_drawer" class="wrapper_content no-scrollbar">
            <div class="item_title">牌局详情</div>
            <div class="item_bg">
                <el-form>
                    <el-form-item label="时间:">
                        <span class="des_title">{{ info.startTime | filterEmpty }}至{{ info.endTime | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="房间ID:">
                        <span class="des_title">{{ info.roomId | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="牌桌信息:">
                        <span class="des_title">{{ info.anteCoin | filterEmpty }}底注 | {{ getDeskName(info.deskPlayer) | filterEmpty }} | {{ info.deskScore | filterEmpty }}分场</span>
                    </el-form-item>
                    <el-form-item label="Drop扣分:">
                        <span class="des_title">{{ info.drop0Coin | filterEmpty }}/{{ info.drop1Coin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="税率:">
                        <span class="des_title">{{ info.taxPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="拆分比率:">
                        <span class="des_title">D:{{ info.depositedPercent | filterEmpty }}%｜W:{{ info.winningsPercent | filterEmpty }}%</span>
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title">策略详情</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item :label="getArrayValue(STRATEGY_TYPE, info.strategyType) + ':'" v-if="info.strategyType && info.strategyType != '无策略'">
                        <span class="des_title">触发区间:{{ info.strategyConfig | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['WINNER', 'BRUSH'].indexOf(info.strategyType) !== -1">机器人作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                        <span class="des_title ml-20" v-if="['NEWBIE', 'LOSER'].indexOf(info.strategyType) !== -1">玩家作弊概率(万分比):{{ info.strategyPercent | filterEmpty }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div v-if="info.scoreBoards" class="item_title">计分牌</div>
            <el-table v-if="info.scoreBoards" class="item_table" :border="true" :header-row-style="{ height: '30px' }" :row-style="{ height: '30px' }" :cell-style="scoreCell" :data="info.scoreBoards">
                <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="回合">
                    <template slot-scope="scope">
                        <span>{{ scoreRound(scope.row, scope.$index) }}</span>
                    </template>
                </el-table-column>
                <el-table-column v-for="(item, index) in info.scoreBoards[0].scores" :key="index" :show-overflow-tooltip="true" align="center">
                    <template slot="header">
                        <span class="score_name">
                            <svg-icon v-if="item.robot" icon-class="oms_ico_robot" style="font-size: 14px" />
                            <span v-if="item.robot">{{ item.playerId }}</span>
                            <UserIdJump :id="item.playerId" :nickname="item.nickname" v-if="!item.robot" />
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span v-html="scoreContent(scope.row, index)" />
                    </template>
                </el-table-column>
            </el-table>

            <div id="pool_back" class="item_title">牌局回放</div>
            <el-table class="back_table" :span-method="rowSpanMethod" :header-row-style="{ height: '40px' }" :cell-style="backCell" :data="show_rounds">
                <el-table-column :show-overflow-tooltip="true" width="60" align="center" label="回合">
                    <template slot-scope="scope">
                        <span>{{ round }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="80px" align="center" label="类型">
                    <template slot-scope="scope">
                        <span>{{ roundName(scope.row) }}</span>
                    </template>
                </el-table-column>
                <el-table-column width="160px" prop="createTime" label="玩家">
                    <template slot-scope="scope">
                        <div style="align-items: center" class="dp-f">
                            <svg-icon v-if="scope.row.bank" icon-class="oms_lab_zhuangjia" class="z_tip" />
                            <svg-icon v-if="scope.row.robot" icon-class="oms_ico_robot" style="font-size: 18px; margin-right: 8px" />
                            <div v-if="scope.row.drop" class="drop_c">DROP</div>
                            <span v-if="scope.row.robot">{{ scope.row.playerId }}</span>
                            <UserIdJump :id="scope.row.playerId" :nickname="scope.row.nickname" :onlyNickname="true" v-if="!scope.row.robot" />
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" prop="card" label="牌型">
                    <template slot-scope="scope">
                        <template v-if="scope.row.isBank">
                            <div class="card_item" style="padding: 10px 0px">
                                <Card class="card_item_card" :card="scope.row.key" :is-joker="scope.row.joker" />
                                <span v-if="scope.row.bank" class="operate">庄</span>
                            </div>
                        </template>
                        <template v-if="scope.row.isInit">
                            <div class="dp-f" style="padding: 10px 0px">
                                <div class="card_item">
                                    <Card class="card_item_card" :card="scope.row.joker.key" :is-joker="scope.row.joker.joker" />
                                    <span class="operate">小丑牌</span>
                                </div>
                                <div class="card_item">
                                    <Card class="card_item_card" :card="scope.row.open.key" :is-joker="scope.row.open.joker" />
                                    <span class="operate">OPEN牌</span>
                                </div>
                            </div>
                        </template>
                        <template v-if="scope.row.isHand">
                            <div style="padding: 10px 0px">
                                <LmCardGroup :list="scope.row.cards" :hideType="scope.row.stage === 0 && !scope.row.robot" />
                                <span class="operate" v-html="getOperate(scope.row)" />
                                <span class="strategy" v-html="getStrategy(scope.row)" />
                            </div>
                        </template>
                    </template>
                </el-table-column>
            </el-table>
            <el-button v-if="all_rounds.length" type="text" class="more" :loading="loadingMore" @click="loadMore">点击显示更多 ▾</el-button>
        </div>

        <div class="floating">
            <div />
            <div class="dp-c" style="align-items: flex-end">
                <div
                    v-for="(item, index) in rounds"
                    :key="index"
                    class="floating_item"
                    :class="{ active: round === item }"
                    @mouseover="onmouseover(item)"
                    @mouseleave="onmouseleave"
                    @click="scrollTo(item)"
                >
                    {{ getRoundName(index + 1) }}
                </div>
            </div>
            <img class="floating_top" :src="topImg" @click="scrollTo()" />
        </div>
    </div>
</template>

<script>
import Card from '@/components/Card'
import UserIdJump from '@/components/UserIdJump'
import LmCardGroup from '@/components/Card/lmCardGroup.vue'
import * as api from '@/api/game/lm'
import Base from '@/views/base'
import { STRATEGY_TYPE } from '@/constant/game'
import { textColor } from '@/views/base/expand'
const isRound = function (turnsId) {
    return turnsId >= 1 && turnsId <= 100000
}
const isTotalScore = function (turnsId) {
    return turnsId === 100001
}
const isActualWin = function (turnsId) {
    return turnsId === 100002
}
const isTex = function (turnsId) {
    return turnsId === 100003
}
const isSysTemSettlement = function (turnsId) {
    return turnsId === 100004
}
const data_length = 20
export default {
    components: {
        Card,
        LmCardGroup,
        UserIdJump
    },
    mixins: [Base],
    props: {
        flowId: {
            type: Number | String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            STRATEGY_TYPE,
            topImg: require('@/assets/images/oms_ico_top.png'),
            info: {},
            hoverIndex: '', // 鼠标悬浮下标
            round: '', // 当前选中回合
            rounds: [], // 回合列表
            show_rounds: [], // 展示的回合数据
            all_rounds: [], // 全部回合数据
            loadingMore: false,
            row_tag: {}, // 回放合并单元格信息
            playerCount: 0
        }
    },
    computed: {},
    watch: {
        flowId: {
            handler(val) {
                val && this.initData()
            },
            immediate: true
        }
    },
    methods: {
        /** 获取详情 */
        initData() {
            this.rounds = []
            api.poolFlowDetail({ flowId: this.flowId })
                .then((rep) => {
                    this.info = rep.data
                    this.info.scoreBoards.forEach((element) => {
                        if (isRound(element.turnsId)) {
                            this.rounds.push(element.turnsId)
                        }
                    })
                    if (this.rounds.length) {
                        this.round = this.rounds[0]
                        this.getRound()
                    }
                })
                .catch(() => {})
        },
        /** 获取回合回放数据 */
        getRound() {
            this.show_rounds = []
            this.all_rounds = []
            api.poolFlowTurns({ flowId: this.flowId, turnsId: this.round })
                .then((rep) => {
                    const { bankCards, initCards, handCards } = rep.data
                    bankCards.forEach((e) => {
                        e.isBank = true
                    })
                    this.playerCount = bankCards.length
                    var initCard = { isInit: true }
                    initCards.forEach((e) => {
                        if (e.joker) {
                            initCard.joker = e
                        }
                        if (e.open) {
                            initCard.open = e
                        }
                    })
                    handCards.forEach((e) => {
                        e.isHand = true
                    })
                    this.all_rounds = [].concat(bankCards, initCard, handCards)
                    this.filterRowTag()
                    this.loadMore()
                    setTimeout(() => {
                        this.scrollTo(this.round)
                    }, 200)
                })
                .catch(() => {})
        },
        /** 回合回放加载更多 */
        loadMore() {
            if (this.all_rounds.length) {
                this.loadingMore = true
                setTimeout(() => {
                    this.loadingMore = false
                    this.show_rounds = this.show_rounds.concat(this.all_rounds.splice(0, data_length))
                }, 100)
            }
        },
        /** 获取回合回放数据 */
        getRoundName(round) {
            if (round === this.hoverIndex) {
                return `第${round}回合`
            }
            return round
        },
        /** 记分板回合名 */
        scoreRound(row, index) {
            if (isRound(row.turnsId)) {
                if (row.playoff) {
                    return `${index + 1}`
                }
                return index + 1
            } else if (isTotalScore(row.turnsId)) {
                return '总得分'
            } else if (isActualWin(row.turnsId)) {
                return '实际输赢(扣税)'
            } else if (isSysTemSettlement(row.turnsId)) {
                let splitConf = {
                    0: '',
                    1: '[自动拆分]',
                    2: '[手动拆分]'
                }
                return '系统结算输赢(扣税)' + splitConf[row.manualSplit]
            } else if (isTex(row.turnsId)) {
                return '税收收入'
            }
        },
        /** 记分板内容 */
        scoreContent(row, colIndex) {
            let str
            var player = row.scores[colIndex]
            if (!player) {
                return '--'
            }
            if (isRound(row.turnsId)) {
                str = player.handScore
                if (player.drop) str = str + '[Drop]'
                if (player.fakeHu) str = str + '[炸胡]'
                if (player.exit) str = str + '[exit]'
                if (player.hu) str = str + '[胡]'
                if (player.rejoin) str = str + '[重入]'
            } else if (isTotalScore(row.turnsId)) {
                //取奖金或输赢金额-100002
                let tmpScoreBoards = this.info.scoreBoards
                let index = _.findIndex(tmpScoreBoards, function (o) {
                    return isActualWin(o.turnsId)
                })
                let playerBonus = tmpScoreBoards[index].scores[colIndex]
                if (playerBonus.coin > '0') {
                    str = '<div style="background:#1ba2ff;color: #ffffff">' + player.totalScore + '</div>'
                } else {
                    str = player.totalScore
                }
            } else if (isActualWin(row.turnsId)) {
                str = ''
                if (!player.robot) {
                    str = '<span class="' + textColor(player.coin) + '">' + player.coin + '</span>'
                }
            } else if (isSysTemSettlement(row.turnsId)) {
                str = ''
                if (!player.robot) {
                    str = '<span class="' + textColor(player.coin) + '">' + player.coin + '</span>'
                }
            } else if (isTex(row.turnsId)) {
                str = !player.robot ? player.coin : ''
            }
            return str
        },
        roundName(row) {
            if (row.isBank) {
                return '定庄'
            }
            if (row.isInit) {
                return '初始牌'
            }
            if (row.isHand) {
                if (row.stage) {
                    return `第${row.stage}手`
                } else {
                    return '起手牌'
                }
            }
        },
        /** 回放操作 */
        getOperate(row) {
            return this.replaceHtml(row.operate)
        },
        /** 回放策略 */
        getStrategy(row) {
            return this.replaceHtml(row.strategy)
        },
        /** 记分板cell样式 */
        scoreCell({ row, column, rowIndex, columnIndex }) {
            var style = {}
            if (columnIndex === 0) {
                if (isTotalScore(row.turnsId) || isActualWin(row.turnsId) || isSysTemSettlement(row.turnsId) || isTex(row.turnsId)) {
                    style.background = 'rgba(27,162,255,0.10)'
                } else {
                    style.background = '#F7F7F7'
                }
            }
            return style
        },
        /** 回放cell样式 */
        backCell({ row, column, rowIndex, columnIndex }) {
            if (row.stage % 2) {
                return { background: '#F7F7F7' }
            }
            return { background: '#ffffff' }
        },

        /** 行合并 */
        rowSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                if (rowIndex === 0) {
                    return { rowspan: 1000, colspan: 1 }
                } else {
                    return { rowspan: 0, colspan: 0 }
                }
            }
            if (columnIndex === 1) {
                if (row.isBank && this.row_tag.bank) {
                    if (rowIndex === this.row_tag.bank.index) {
                        return { rowspan: this.row_tag.bank.num, colspan: 1 }
                    } else {
                        return { rowspan: 0, colspan: 0 }
                    }
                }
                if (row.isInit && this.row_tag.init) {
                    if (rowIndex === this.row_tag.init.index) {
                        return { rowspan: this.row_tag.init.num, colspan: 1 }
                    } else {
                        return { rowspan: 0, colspan: 0 }
                    }
                }
                if (row.isHand && this.row_tag[row.stage]) {
                    if (rowIndex === this.row_tag[row.stage].index) {
                        return { rowspan: this.row_tag[row.stage].num, colspan: 1 }
                    } else {
                        return { rowspan: 0, colspan: 0 }
                    }
                }
                return { rowspan: 1, colspan: 1 }
            }
        },
        // 筛选行合并标识
        filterRowTag() {
            this.row_tag = {}
            this.all_rounds.forEach((e, i) => {
                if (!this.row_tag.bank && e.isBank) {
                    this.row_tag.bank = {
                        num: this.playerCount,
                        index: i
                    }
                }
                if (!this.row_tag.init && e.isInit) {
                    this.row_tag.init = {
                        num: 1,
                        index: i
                    }
                }
                if (!this.row_tag[e.stage] && e.isHand) {
                    const stage_arr = this.all_rounds.filter((item) => {
                        return item.stage === e.stage
                    })
                    this.row_tag[e.stage] = {
                        num: stage_arr.length,
                        index: i
                    }
                }
            })
        },
        onmouseover(round) {
            this.hoverIndex = round
        },
        onmouseleave() {
            this.hoverIndex = ''
        },
        /** 滚动位置 */
        scrollTo(round) {
            const tag_ele = document.getElementById('pool_back')
            const wrapper = document.getElementById('pool_drawer')
            if (round) {
                if (this.round !== round) {
                    // 回合数变化
                    this.round = round
                    this.getRound()
                }
                wrapper.scrollTo(0, tag_ele.offsetTop)
            } else {
                wrapper.scrollTo(0, 0)
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.pool-record-detail {
    position: relative;
    width: 920px;
    height: 100%;
    .wrapper_content {
        width: 100%;
        height: 100%;
        padding: 20px 50px 20px 30px;
        display: flex;
        flex-direction: column;
        scroll-padding-bottom: 100px;
        overflow-y: scroll;
    }

    .item_title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 500;
    }
    .item_bg {
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 20px 30px;
        margin-top: 10px;
        margin-bottom: 20px;
        ::v-deep .el-form-item__label {
            text-align: left;
        }
    }
    .item_table {
        width: 100%;
        overflow-x: hidden;
        margin-top: 10px;
        margin-bottom: 20px;
        ::v-deep .cell {
            padding: 0px 2px;
        }
        .score_name {
            white-space: nowrap;
            color: #1ba2ff;
            &:hover {
                cursor: pointer;
                text-decoration: underline;
            }
        }
    }
    .des_title {
        font-size: 14px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .el-form-item--small.el-form-item {
        margin-bottom: 0px;
    }
    ::v-deep .el-table--small .el-table__cell {
        padding: 0px !important;
    }
    .el-table {
        flex: none;
    }
    .back_table {
        width: 100%;
        overflow-x: hidden;
        margin-top: 10px;
        ::v-deep .el-table__body-wrapper {
            border: 1px solid #ebeef5;
        }
        ::v-deep th.el-table__cell.is-leaf,
        td.el-table__cell {
            border-bottom: 0px solid #ebeef5;
        }
        ::v-deep td.el-table__cell {
            border-right: 2px solid #ebeef5;
            border-bottom: 2px solid #ebeef5;
        }
        ::v-deep td.el-table__cell:last-child {
            border-right: 0px solid #ebeef5;
        }
        ::v-deep .el-table__row:last-child {
            td.el-table__cell {
                border-bottom: 0px solid #ebeef5;
            }
        }
        .card_item {
            display: flex;
            margin-right: 10px;
            align-items: flex-end;
            &_card {
                width: 50px;
                height: 67px;
                margin-right: 10px;
            }
        }
    }
    .nike_name {
        cursor: pointer;
        font-size: 14px;
        color: #1ba2ff;
        letter-spacing: 0;
        font-weight: 400;
        line-height: initial;
        &:hover {
            text-decoration: underline;
        }
    }
    .z_tip {
        font-size: 17px;
        margin-right: 8px;
    }
    .more {
        font-size: 12px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .floating {
        position: absolute;
        right: 0px;
        top: 0px;
        bottom: 0px;
        min-width: 70px;
        padding: 56px 0px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: flex-end;
        &_item {
            background: #ffffff;
            box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.15);
            border-radius: 100px 0px 0px 100px;
            width: 24px;
            height: 24px;
            font-size: 13px;
            color: #686b6d;
            letter-spacing: 0;
            text-align: center;
            font-weight: 400;
            line-height: 24px;
            text-align: center;
            cursor: pointer;
            margin-top: 8px;
            overflow: hidden;
            white-space: break-spaces;
            animation-duration: 0.2s;
            animation-name: itemnone;
            animation-fill-mode: forwards;
            &:hover {
                animation-duration: 0.3s;
                animation-name: itemhover;
                animation-fill-mode: forwards;
            }
        }
        @keyframes itemhover {
            from {
                width: 24px;
            }
            to {
                width: 70px;
            }
        }
        @keyframes itemnone {
            from {
                width: 70px;
            }
            to {
                width: 24px;
            }
        }
        .active {
            background: #1ba2ff;
            color: white;
        }
        &_top {
            cursor: pointer;
            width: 40px;
            height: 40px;
            margin-right: 5px;
        }
    }
    .operate,
    .strategy {
        font-size: 14px;
        white-space: break-spaces;
    }
    .drop_c {
        width: 70px;
        height: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: absolute;
        right: 0px;
        font-size: 12px;
        top: 0px;
        background-color: chocolate;
        color: white;
    }
}
</style>
