<template>
    <div class="game-common-record no-scrollbar">
        <div class="head-container">
            <el-row>
                <el-select v-model="query.enableFlag" placeholder="状态" size="medium" class="filter-item" style="width: 160px" @change="toQuery">
                    <el-option v-for="item in roomStates" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.deskPlayer" placeholder="牌桌类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in deskTypes" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.anteCoin" placeholder="底注金额" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in anteCoins" :key="item" :label="item" :value="item" />
                </el-select>
                <el-select v-model="query.deskScore" placeholder="计分类型" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option label="101分场" :value="101" />
                    <el-option label="201分场" :value="201" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end" style="margin-top: 10px">
                <IconButton v-permission="[permission.lmPoolRoomAdd]" size="medium" type="primary" icon="oms_ico_add" title="创建房间" @click="toAdd" />
            </el-row>
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%; margin-top: 20px" :height="table_height" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="160px" align="center" label="ID">
                <template slot-scope="scope">
                    <svg-icon v-if="scope.row.newbieRoom && scope.row.baseConfig.enableFlag" icon-class="oms_lab_xin" class="new_tag" />
                    <span>{{ scope.row.id }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="牌桌类型">
                <template slot-scope="scope">
                    <div class="dp-f-center">
                        <span v-for="item in scope.row.baseConfig.deskPlayer" :key="item" class="desk_dot" />
                    </div>
                    <!-- <span>{{ getDeskType(scope.row.baseConfig.deskPlayer) }}</span> -->
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="计分类型">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.deskScore }}分场</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="底注金额">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.anteCoin | filterCion }}</span>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" width="100px" label="Drop处罚" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.drop0Coin }}/{{ scope.row.baseConfig.drop1Coin }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="100px" label="税率" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.baseConfig.taxPercent }}%</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" label="桌子数量" align="center">
                <template slot-scope="scope">
                    <div>混合桌:{{ scope.row.deskCount }}</div>
                    <div>隔离桌:{{ scope.row.ddeskCount }}</div>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="140px" prop="playerCount" align="center" label="玩家/机器人数量">
                <template slot-scope="scope">
                    <div>{{ scope.row.playerCount }}/{{ scope.row.robotCount }}</div>
                    <div>{{ scope.row.dplayerCount }}/{{ scope.row.drobotCount }}</div>
                </template>
            </el-table-column>
            <el-table-column width="120px" align="center" label="状态">
                <template slot-scope="scope">
                    <div class="table_state_switch">
                        <el-switch v-model="scope.row.baseConfig.enableFlag" @change="roomStateChange(scope.row)" :disabled="scope.row.newbieRoom"></el-switch>
                    </div>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" width="100px" prop="updateTime" align="center" label="操作">
                <template slot-scope="scope">
                    <IconButton v-permission="[permission.lmPoolRoomEdit]" type="text" size="medium" style="font-size: 20px" icon="oms_ico_edit" @click="toEdit(scope.row)" />
                </template>
            </el-table-column>
        </el-table>
        <Drawer :title="drawerTitle" :visible.sync="drawer" class="drawer">
            <div class="drawer_content">
                <el-form ref="form" :model="form" :rules="rules" label-width="160px">
                    <span class="drawer_content_title">房间基础配置</span>
                    <div class="item_bg">
                        <el-form-item label="房间开关:" prop="enableFlag">
                            <el-switch v-model="form.enableFlag" />
                        </el-form-item>
                        <el-form-item label="牌桌类型:" prop="deskPlayer">
                            <el-select v-model="form.deskPlayer" size="medium" placeholder="请选择牌桌类型" style="width: 280px">
                                <el-option v-for="item in deskTypes" :key="item.id" :label="item.name" :value="item.id" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="底注金额:" prop="anteCoin">
                            <InputNumber v-model="form.anteCoin" range-width="280px" :precision="2" placeholder="0.01-1000000" :min-number="0.01" :max-number="1000000" clearable />
                            <span class="tips">精确到小数点后2位，玩家输的金额=底注金额</span>
                        </el-form-item>
                        <el-form-item label="101分/201分场:" prop="deskScore">
                            <el-radio-group v-model="form.deskScore">
                                <el-radio :label="101">101分场</el-radio>
                                <el-radio :label="201">201分场</el-radio>
                            </el-radio-group>
                        </el-form-item>
                        <el-form-item label="税率(%):" prop="taxPercent">
                            <InputNumber v-model="form.taxPercent" range-width="280px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                        </el-form-item>
                        <el-form-item label="结算拆分比例:">
                            <el-col :span="10">
                                <el-form-item label="" prop="depositedPercent" style="margin-bottom: 0px">
                                    <div class="dp-f">
                                        <span class="sub_title">D账户(%)</span>
                                        <InputNumber v-model="form.depositedPercent" range-width="100px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                                    </div>
                                    <span class="tips">D账户+W账户=100-平台税率数</span>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="" prop="winningsPercent" style="margin-bottom: 0px">
                                    <div class="dp-f">
                                        <span class="sub_title ml-20">W账户(%)</span>
                                        <InputNumber v-model="form.winningsPercent" range-width="100px" placeholder="0-100" :min-number="0" :max-number="100" clearable />
                                    </div>
                                    <span class="tips" />
                                </el-form-item>
                            </el-col>
                        </el-form-item>
                        <el-form-item label="礼物价格:" prop="giftCoin">
                            <InputNumber v-model="form.giftCoin" :precision="2" range-width="280px" :min-number="0" :max-number="100" placeholder="0-100" clearable />
                        </el-form-item>
                    </div>
                    <span class="drawer_content_title">房间限制</span>
                    <div class="item_bg">
                        <el-form-item label="最小入场金额:" prop="joinMinCoin">
                            <InputNumber v-model="form.joinMinCoin" range-width="280px" placeholder="1-1000000000" :min-number="1" :max-number="1000000000" clearable />
                            <span class="tips">玩家账户余额低于该金额时无法进入房间（且需大于等于底注金额）</span>
                        </el-form-item>
                        <el-form-item label="未摸牌Drop分数:" prop="drop0Coin">
                            <InputNumber v-model="form.drop0Coin" range-width="280px" placeholder="0-80" :min-number="0" :max-number="80" clearable />
                        </el-form-item>
                        <el-form-item label="已摸牌Drop分数:" prop="drop1Coin">
                            <InputNumber v-model="form.drop1Coin" range-width="280px" placeholder="0-80" :min-number="0" :max-number="80" clearable />
                        </el-form-item>
                    </div>
                </el-form>
                <div class="footer">
                    <IconButton class="filter-item" size="medium" type="primary" title="保存" style="width: 120px" @click="toSubmit" />
                </div>
            </div>
        </Drawer>
    </div>
</template>

<script>
import Base from '@/views/base'
import { roomState, roomRank } from '@/constant/game'
import { deskType } from '@/constant/lm'
import Drawer from '@/components/Drawer'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/game/lm'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    page: 1,
    size: 10,
    sort: 'createTime;desc',
    all: true,
    enableFlag: true,
    deskPlayer: null,
    anteCoin: null,
    deskScore: null
}
const defaultRoom = {
    deskPlayer: '', // 牌桌类型
    anteCoin: '', // 底注
    deskScore: '', // 分场
    taxPercent: '', // 税率
    depositedPercent: '', // D账户
    winningsPercent: '', // W账户
    enableFlag: true, // 房间状态
    joinMinCoin: '', // 最小入场金额
    drop0Coin: '', // 未摸牌drop
    drop1Coin: '' // 已摸牌drop
}
export default {
    components: {
        Drawer,
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            roomRanks: Object.values(roomRank),
            deskTypes: Object.values(deskType),
            roomStates: Object.values(roomState),
            anteCoins: [],
            form: {},
            drawer: false,
            drawerType: '',
            drawerTitle: '',
            loading: false,
            query: { ...defaultQuery },
            list: [],
            roomId: undefined,
            newbieRoom: false,
            rules: {
                deskPlayer: [{ required: true, message: '请选择牌桌类型', trigger: 'blur' }],
                anteCoin: [{ required: true, message: '请输入底注金额', trigger: 'blur' }],
                deskScore: [{ required: true, message: '请选择分场', trigger: 'blur' }],
                taxPercent: [{ required: true, message: '请输入税率', trigger: 'blur' }],
                depositedPercent: [{ required: true, message: '请输入D账户拆分比例', trigger: 'blur' }],
                winningsPercent: [{ required: true, message: '请输入W账户拆分比例', trigger: 'blur' }],
                enableFlag: [{ required: true, message: '请选择房间状态', trigger: 'blur' }],
                joinMinCoin: [{ required: true, message: '请输入最小入场金额', trigger: 'blur' }],
                drop0Coin: [{ required: true, message: '请输入未摸牌Drop分数', trigger: 'blur' }],
                drop1Coin: [{ required: true, message: '请输入已摸牌Drop分数', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.fixed_height = 300
        this.toQuery()
    },

    methods: {
        getDeskType(type) {
            return deskType[type].name
        },
        getRoomRank(type) {
            return roomRank[type].name
        },
        getRoomState(type) {
            return roomState[type].name
        },
        toAdd() {
            this.newbieRoom = false
            this.form = { ...defaultRoom }
            this.drawerType = 'add'
            this.drawer = true
            this.drawerTitle = '创建房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        toEdit(row) {
            this.drawerType = 'edit'
            this.roomId = row.id
            this.newbieRoom = row.newbieRoom
            this.form = { ...row.baseConfig }
            this.drawer = true
            this.drawerTitle = '编辑房间'
            this.$refs.form && this.$refs.form.clearValidate()
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery() {
            // 查询房间列表和dz
            if (this.checkPermission([this.permission.lmPoolRoomList])) {
                api.poolRoomList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                    })
                    .catch(() => {})
                api.poolRoomAnte(this.query)
                    .then((rep) => {
                        this.anteCoins = rep.data
                    })
                    .catch(() => {})
            }
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.form.winningsPercent + this.form.depositedPercent + this.form.taxPercent !== 100) {
                        return this.$message.error('请正确设置拆分比例')
                    }
                    if (this.form.joinMinCoin < this.form.anteCoin) {
                        return this.$message.error('请正确设置最小入场金额')
                    }
                    if (this.drawerType === 'add') {
                        api.poolRoomAdd({ baseConfig: this.form })
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间添加成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                    if (this.drawerType === 'edit') {
                        if (this.newbieRoom && !this.form.enableFlag) {
                            return this.$message.error('新手房无法禁用')
                        }
                        var dic = { baseConfig: this.form, id: this.roomId }
                        api.poolRoomEdit(dic)
                            .then((rep) => {
                                this.drawer = false
                                this.$message.success('房间编辑成功')
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                }
            })
        },
        roomStateChange(data) {
            if (!data.baseConfig.enableFlag) {
                confirmRequest(
                    '禁用以后游戏中将不展示该房间，房间内的玩家结束后将全部离开。确定是否禁用？',
                    () => {
                        this.toEnabled(data)
                    },
                    () => {
                        data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                    }
                )
            } else {
                this.toEnabled(data)
            }
        },
        toEnabled(data) {
            api.poolRoomEnableDisable(data)
                .then((res) => {
                    if (data.baseConfig.enableFlag) {
                        this.$message.success('启用成功')
                    } else {
                        this.$message.success('禁用成功')
                    }
                })
                .catch(() => {
                    data.baseConfig.enableFlag = !data.baseConfig.enableFlag
                })
        }
    }
}
</script>
