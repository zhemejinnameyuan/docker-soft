<template>
    <div class="inner_item">
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item label="选择日期:" prop="rechargeRecord" class="big-label">
                <el-date-picker v-model="form.date" type="date" placeholder="选择日期" value-format="yyyy-MM-dd "></el-date-picker>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
export default {
    components: {},
    data() {
        return {
            form: {
                date: ''
            }
        }
    },
    mixins: [Base],
    mounted() {},
    methods: {
        submit() {
            if (!this.form.date) {
                return this.$message.error('请选择时间')
            }
            let params = { day: this.form.date }
            api.handGenerate(params).then((e) => {
                this.$message.success('修改成功')
                this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
