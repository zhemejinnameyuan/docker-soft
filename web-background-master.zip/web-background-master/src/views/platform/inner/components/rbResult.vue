<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item label="蓝牌:">
                <div class="mt-5">
                    <el-select v-model="form.blue_type_1" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.blue_card_1" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.blue_type_2" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.blue_card_2" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>

                <div class="mt-5">
                    <el-select v-model="form.blue_type_3" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.blue_card_3" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
            <el-form-item label="红牌:">
                <div class="mt-5">
                    <el-select v-model="form.red_type_1" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.red_card_1" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.red_type_2" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.red_card_2" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.red_type_3" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.red_card_3" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import { GAME_TYPE } from '@/constant/game'
import { getPokerCardValue } from '@/utils/index'

export default {
    components: {},
    data() {
        return {
            GAME_TYPE,
            card_type: [
                { label: '方片', value: 1 },
                { label: '梅花', value: 2 },
                { label: '红桃', value: 3 },
                { label: '黑桃', value: 4 }
            ],
            card_value: [
                { label: 'A', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: 'J', value: 11 },
                { label: 'Q', value: 12 },
                { label: 'K', value: 13 }
            ],
            form: {
                blue_type_1: '',
                blue_card_1: '',
                blue_type_2: '',
                blue_card_2: '',
                blue_type_3: '',
                blue_card_3: '',
                red_type_1: '',
                red_card_1: '',
                red_type_2: '',
                red_card_2: '',
                red_type_3: '',
                red_card_3: ''
            }
        }
    },
    methods: {
        submit() {
            var a = false
            Object.values(this.form).forEach((e) => {
                if (!e) {
                    a = true
                }
            })
            if (a) {
                return this.$message.error('请选择牌型')
            } else {
                let blue_1 = getPokerCardValue(this.form.blue_type_1, this.form.blue_card_1)
                let blue_2 = getPokerCardValue(this.form.blue_type_2, this.form.blue_card_2)
                let blue_3 = getPokerCardValue(this.form.blue_type_3, this.form.blue_card_3)

                let red_1 = getPokerCardValue(this.form.red_type_1, this.form.red_card_1)
                let red_2 = getPokerCardValue(this.form.red_type_2, this.form.red_card_2)
                let red_3 = getPokerCardValue(this.form.red_type_3, this.form.red_card_3)

                if (blue_1 == blue_2 || blue_1 == blue_3 || blue_2 == blue_3) {
                    return this.$message.error('蓝牌-牌值不能重复')
                }

                if (red_1 == red_2 || red_1 == red_3 || red_2 == red_3) {
                    return this.$message.error('红牌-牌值不能重复')
                }

                let result = {
                    blue: [blue_1, blue_2, blue_3],
                    red: [red_1, red_2, red_3]
                }

                const postData = {
                    gameType: GAME_TYPE.RB,
                    result: Object.values(result)
                }

                api.nextResult(postData).then((e) => {
                    this.$message.success('修改成功')
                    // this.dialogCancel()
                })
            }
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
