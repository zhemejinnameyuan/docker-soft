<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item>
                <template slot="label">
                    <span class="label">开牌</span>
                </template>
                <div>
                    <el-select v-model="form.card_type" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.card_value" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label">翻牌张数</span>
                </template>
                <el-select v-model="form.flipNumber" placeholder="选择牌值" style="width: 200px">
                    <el-option v-for="(f, index) in flipNumber" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
import { range, getPokerCardValue } from '@/utils/index'
import { GAME_TYPE } from '@/constant/game'
export default {
    components: {},
    data() {
        return {
            GAME_TYPE,
            flipNumber: [],
            card_type: [
                { label: '方片', value: 1 },
                { label: '梅花', value: 2 },
                { label: '红桃', value: 3 },
                { label: '黑桃', value: 4 }
            ],
            card_value: [
                { label: 'A', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: 'J', value: 11 },
                { label: 'Q', value: 12 },
                { label: 'K', value: 13 }
            ],
            form: {
                card_type: '',
                card_value: '',
                flipNumber: ''
            }
        }
    },
    mixins: [Base],
    mounted() {
        this.handleFlipNumber()
    },
    methods: {
        handleFlipNumber() {
            let label_color = ''
            const rangeArr = range(1, 49)
            for (const i in rangeArr) {
                label_color = rangeArr[i] % 2 != 0 ? '-(蓝赢)' : '-(红赢)'

                this.flipNumber.push({ label: rangeArr[i] + label_color, value: rangeArr[i] })
            }
        },
        submit() {
            var a = false
            Object.values(this.form).forEach((e) => {
                if (!e) {
                    a = true
                }
            })
            if (a) {
                return this.$message.error('请选择开牌和翻牌张数')
            }

            let openCard = getPokerCardValue(this.form.card_type, this.form.card_value)
            let result = [[openCard], [this.form.flipNumber]]
            const postData = {
                gameType: GAME_TYPE.BAB,
                result: result
            }

            api.nextResult(postData).then((e) => {
                this.$message.success('修改成功')
                // this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
