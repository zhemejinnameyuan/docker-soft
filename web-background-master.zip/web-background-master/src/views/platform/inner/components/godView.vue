<template>
    <div class="inner_item">
        <el-form ref="form" :model="form" label-width="80px" :rules="rules">
            <el-form-item label="玩家ID:" prop="playerId">
                <el-input type="textarea" rows="5" v-model="form.playerId" placeholder="输入玩家ID,多个用英文逗号分隔" clearable />
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'

export default {
    components: {},
    data() {
        return {
            form: {
                playerId: ''
            },
            rules: {
                playerId: [{ required: true, message: '请填写玩家ID', trigger: 'blur' }]
            }
        }
    },
    mounted() {},
    methods: {
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    const playerIdList = this.form.playerId.split(',')
                    const dis = {
                        playerIdList: playerIdList
                    }
                    api.setGameSwitch(dis).then((e) => {
                        this.$message.success('操作成功')
                        this.dialogCancel()
                    })
                }
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
