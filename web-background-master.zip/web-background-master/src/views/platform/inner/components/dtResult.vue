<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item label="龙牌:">
                <el-select v-model="form.dragon_type" placeholder="选择花色" style="width: 100px">
                    <el-option v-for="(f, index) in fs" :key="index" :label="f.label" :value="f.value" />
                </el-select>
                <el-select v-model="form.dragon_card" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                    <el-option v-for="(f, index) in fv" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>
            <el-form-item label="虎牌:">
                <el-select v-model="form.tiger_type" placeholder="选择花色" style="width: 100px">
                    <el-option v-for="(f, index) in fs" :key="index" :label="f.label" :value="f.value" />
                </el-select>
                <el-select v-model="form.tiger_card" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                    <el-option v-for="(f, index) in fv" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import { GAME_TYPE } from '@/constant/game'
import { getPokerCardValue } from '@/utils/index'

export default {
    components: {},
    data() {
        return {
            fs: [
                { label: '方片', value: 1 },
                { label: '梅花', value: 2 },
                { label: '红桃', value: 3 },
                { label: '黑桃', value: 4 }
            ],
            fv: [
                { label: 'A', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: 'J', value: 11 },
                { label: 'Q', value: 12 },
                { label: 'K', value: 13 }
            ],
            form: {
                dragon_type: '',
                dragon_card: '',
                tiger_type: '',
                tiger_card: ''
            }
        }
    },
    methods: {
        submit() {
            var a = false
            Object.values(this.form).forEach((e) => {
                if (!e) {
                    a = true
                }
            })
            if (a) {
                return this.$message.error('请选择牌型')
            } else {
                let dragon = getPokerCardValue(this.form.dragon_type, this.form.dragon_card)
                let tiger = getPokerCardValue(this.form.tiger_type, this.form.tiger_card)

                if (dragon == tiger) {
                    return this.$message.error('牌值不能一样')
                }

                let result = {
                    dragon: [dragon],
                    tiger: [tiger]
                }

                const postData = {
                    gameType: GAME_TYPE.DT,
                    result: Object.values(result)
                }

                api.nextResult(postData).then((e) => {
                    this.$message.success('修改成功')
                    // this.dialogCancel()
                })
            }
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
