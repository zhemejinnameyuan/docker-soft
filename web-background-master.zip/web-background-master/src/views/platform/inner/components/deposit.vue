<template>
    <div class="inner_item">
        <el-form ref="form" :model="form" label-width="150px" :rules="rules">
            <el-form-item label="玩家ID:" prop="playerId">
                <InputNumber v-model="form.playerId" :min-number="1" :max-number="999999999999" placeholder="输入玩家ID" clearable />
            </el-form-item>
            <el-form-item label="充值金币数:" prop="deposit">
                <InputNumber v-model="form.deposit" :min-number="1" :max-number="99999999" placeholder="1-99999999" clearable />
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import InputNumber from '@/components/InputNumber'

export default {
    components: {
        InputNumber
    },
    data() {
        return {
            form: {
                playerId: '',
                deposit: ''
            },
            rules: {
                playerId: [{ required: true, message: '输入玩家ID', trigger: 'blur' }],
                deposit: [{ required: true, message: '输入充值金币', trigger: 'blur' }]
            }
        }
    },
    methods: {
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    api.deposit(this.form).then((e) => {
                        this.$message.success('充值成功')
                        this.dialogCancel()
                    })
                }
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
