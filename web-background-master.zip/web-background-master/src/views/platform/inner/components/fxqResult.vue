<template>
    <div class="inner_item">
        <el-form ref="form" :model="form" class="mt-5 ml-40">
            <el-form-item v-for="(item, userIndex) in userList" :key="userIndex">
                <div class="dp-f">
                    <InputNumber v-model="userList[userIndex].userId" :min-number="1" :placeholder="`玩家ID-` + item.id" range-width="150px" clearable />
                    <el-select v-model="userList[userIndex].number" placeholder="选择点数" style="width: 200px; margin-left: 10px" @change="changeValue(userIndex)">
                        <el-option v-for="(f, index) in numberConf" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import { GAME_TYPE } from '@/constant/game'
import { range } from '@/utils'
export default {
    components: {
        InputNumber
    },
    data() {
        return {
            GAME_TYPE,
            userList: [],
            numberConf: [
                { label: '0-代表清空设置', value: 0 },
                { label: '1', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 }
            ],
            form: {
                number: ''
            }
        }
    },
    mixins: [Base],
    mounted() {
        this.initData()
    },
    methods: {
        changeValue(index) {
            this.$set(this.userList, index, this.userList[index])
        },
        initData() {
            let tmpArr = []
            for (let i in range(1, 4)) {
                tmpArr = []

                tmpArr['id'] = _.add(_.toInteger(i), 1)
                tmpArr['userId'] = ''
                tmpArr['number'] = ''
                this.userList.push(tmpArr)
            }
        },
        submit() {
            const fxqDice = []
            let dice = ''
            for (const i in this.userList) {
                let tmpUserId = this.userList[i].userId
                let dice = this.userList[i].number
                if (tmpUserId) {
                    if (dice === '') {
                        return this.$message.error('请选择玩家ID：' + tmpUserId + '的骰子点数')
                    }

                    fxqDice[i] = {
                        l: tmpUserId,
                        r: dice
                    }
                }
            }
            if (fxqDice.length == 0) {
                return this.$message.error('请至少配置一个用户的骰子点数')
            }

            const postData = {
                gameType: GAME_TYPE.FXQ,
                fxqDice: Object.values(fxqDice)
            }

            api.nextResult(postData).then((e) => {
                this.$message.success('修改成功')
                // this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
