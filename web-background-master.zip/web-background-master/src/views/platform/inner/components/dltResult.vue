<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item label="庄:">
                <div class="mt-5">
                    <el-select v-model="form.banker_type_1" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.banker_card_1" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.banker_type_2" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.banker_card_2" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>

                <div class="mt-5">
                    <el-select v-model="form.banker_type_3" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.banker_card_3" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
            <el-form-item label="闲:">
                <div class="mt-5">
                    <el-select v-model="form.player_type_1" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.player_card_1" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.player_type_2" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.player_card_2" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
                <div class="mt-5">
                    <el-select v-model="form.player_type_3" placeholder="选择花色" style="width: 100px">
                        <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                    <el-select v-model="form.player_card_3" placeholder="选择牌值" style="width: 100px; margin-left: 10px">
                        <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import { GAME_TYPE } from '@/constant/game'
import { getPokerCardValue } from '@/utils/index'

export default {
    components: {},
    data() {
        return {
            GAME_TYPE,
            card_type: [
                { label: '方片', value: 1 },
                { label: '梅花', value: 2 },
                { label: '红桃', value: 3 },
                { label: '黑桃', value: 4 }
            ],
            card_value: [
                { label: 'A', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: 'J', value: 11 },
                { label: 'Q', value: 12 },
                { label: 'K', value: 13 }
            ],
            form: {
                banker_type_1: '',
                banker_card_1: '',
                banker_type_2: '',
                banker_card_2: '',
                banker_type_3: '',
                banker_card_3: '',
                player_type_1: '',
                player_card_1: '',
                player_type_2: '',
                player_card_2: '',
                player_type_3: '',
                player_card_3: ''
            }
        }
    },
    methods: {
        submit() {
            var a = false
            Object.values(this.form).forEach((e) => {
                if (!e) {
                    a = true
                }
            })
            if (a) {
                return this.$message.error('请选择牌型')
            } else {
                let banker_1 = getPokerCardValue(this.form.banker_type_1, this.form.banker_card_1)
                let banker_2 = getPokerCardValue(this.form.banker_type_2, this.form.banker_card_2)
                let banker_3 = getPokerCardValue(this.form.banker_type_3, this.form.banker_card_3)

                let player_1 = getPokerCardValue(this.form.player_type_1, this.form.player_card_1)
                let player_2 = getPokerCardValue(this.form.player_type_2, this.form.player_card_2)
                let player_3 = getPokerCardValue(this.form.player_type_3, this.form.player_card_3)

                if (banker_1 == banker_2 || banker_1 == banker_3 || banker_2 == banker_3) {
                    return this.$message.error('庄-牌值不能重复')
                }

                if (player_1 == player_2 || player_1 == player_3 || player_2 == player_3) {
                    return this.$message.error('闲-牌值不能重复')
                }

                let result = {
                    player: [player_1, player_2, player_3],
                    banker: [banker_1, banker_2, banker_3]
                }

                const postData = {
                    gameType: GAME_TYPE.DLT,
                    result: Object.values(result)
                }

                api.nextResult(postData).then((e) => {
                    this.$message.success('修改成功')
                    // this.dialogCancel()
                })
            }
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>

<div class="dp-f" style="flex-direction: row-reverse">
<el-button type="primary" @click="submit" class="ml-10">确认</el-button>
<el-button type="info" plain @click="dialogCancel">取消</el-button>
</div>
