<template>
    <div class="inner_item">
        <el-form ref="form" :model="form" label-width="120px" class="mt-5">
            <div class="dp-f">
                <el-form-item v-for="(item, userIndex) in userList" :key="userIndex" class="ml-40 dp-f" style="flex-wrap: wrap">
                    <template slot="label">
                        <InputNumber v-model="userList[userIndex].userId" :min-number="1" :placeholder="`玩家ID-` + item.id" range-width="120px" clearable />
                        <div class="dp-c mt-10">
                            <div class="dp-f" style="width: 250px">
                                <el-select v-model="userList[userIndex].cardType[0]" placeholder="选择花色" style="width: 100px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_type" :key="index" :label="f.label" :value="f.value" />
                                </el-select>
                                <el-select v-model="userList[userIndex].cardValue[0]" placeholder="选择牌值" style="width: 100px; margin-left: 5px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                                </el-select>
                            </div>

                            <div class="dp-f mt-5" style="width: 250px">
                                <el-select v-model="userList[userIndex].cardType[1]" placeholder="选择花色" style="width: 100px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_type" :key="index * 2" :label="f.label" :value="f.value" />
                                </el-select>
                                <el-select v-model="userList[userIndex].cardValue[1]" placeholder="选择牌值" style="width: 100px; margin-left: 5px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_value" :key="index * 2" :label="f.label" :value="f.value" />
                                </el-select>
                            </div>

                            <div class="dp-f mt-5" style="width: 250px">
                                <el-select v-model="userList[userIndex].cardType[2]" placeholder="选择花色" style="width: 100px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_type" :key="index * 3" :label="f.label" :value="f.value" />
                                </el-select>
                                <el-select v-model="userList[userIndex].cardValue[2]" placeholder="选择牌值" style="width: 100px; margin-left: 5px" @change="changeValue(userIndex)">
                                    <el-option v-for="(f, index) in card_value" :key="index * 3" :label="f.label" :value="f.value" />
                                </el-select>
                            </div>
                        </div>
                    </template>
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
import { range, getPokerCardValue } from '@/utils/index'
import { GAME_TYPE } from '@/constant/game'
import InputNumber from '@/components/InputNumber'

export default {
    components: {
        InputNumber
    },
    data() {
        return {
            GAME_TYPE,
            userList: [],
            card_type: [
                { label: '方片', value: 1 },
                { label: '梅花', value: 2 },
                { label: '红桃', value: 3 },
                { label: '黑桃', value: 4 }
            ],
            card_value: [
                { label: 'A', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: 'J', value: 11 },
                { label: 'Q', value: 12 },
                { label: 'K', value: 13 }
            ],
            form: {
                card_type: '',
                card_value: ''
            }
        }
    },
    mixins: [Base],
    mounted() {
        this.initData()
    },
    methods: {
        changeValue(index) {
            this.$set(this.userList, index, this.userList[index])
        },
        initData() {
            let tmpArr = []
            for (let i in range(1, 5)) {
                tmpArr = []

                tmpArr['id'] = _.add(_.toInteger(i), 1)
                tmpArr['userId'] = ''
                tmpArr['cardType'] = ['', '', '']
                tmpArr['cardValue'] = ['', '', '']
                this.userList.push(tmpArr)
            }
        },
        submit() {
            const tpHands = []
            let oneCard = ''
            let twoCard = ''
            let threeCard = ''
            for (const i in this.userList) {
                let tmpUserId = this.userList[i].userId
                if (tmpUserId) {
                    if (this.userList[i].cardType[0] == '' || this.userList[i].cardType[1] == '' || this.userList[i].cardType[1] == '') {
                        return this.$message.error('请选择玩家ID：' + tmpUserId + '的牌型')
                    }
                    if (this.userList[i].cardValue[0] == '' || this.userList[i].cardValue[1] == '' || this.userList[i].cardValue[1] == '') {
                        return this.$message.error('请选择玩家ID：' + tmpUserId + '的牌值')
                    }
                    oneCard = getPokerCardValue(this.userList[i].cardType[0], this.userList[i].cardValue[0])
                    twoCard = getPokerCardValue(this.userList[i].cardType[1], this.userList[i].cardValue[1])
                    threeCard = getPokerCardValue(this.userList[i].cardType[2], this.userList[i].cardValue[2])

                    if (oneCard == twoCard || oneCard == threeCard || twoCard == threeCard) {
                        return this.$message.error('玩家ID:' + tmpUserId + '-牌值不能重复')
                    }

                    tpHands[i] = {
                        l: tmpUserId,
                        r: [oneCard, twoCard, threeCard]
                    }
                }
            }
            if (tpHands.length == 0) {
                return this.$message.error('请至少配置一个用户的牌组')
                return false
            }

            const postData = {
                gameType: GAME_TYPE.TP,
                tpHands: Object.values(tpHands)
            }

            api.nextResult(postData).then((e) => {
                this.$message.success('修改成功')
                // this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
<style scoped lang="scss">
.el-input--small .el-input__inner {
    height: 40px;
    line-height: 40px;
}
</style>
