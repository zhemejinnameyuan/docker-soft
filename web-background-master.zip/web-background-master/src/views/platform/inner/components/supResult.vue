<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item>
                <template slot="label">
                    <span class="label">清空修改</span>
                </template>
                <div class="ml-10">
                    <el-switch v-model="form.reset" :active-value="1" :inactive-value="0" />
                </div>
            </el-form-item>

            <el-form-item v-show="form.reset != 1">
                <template slot="label">
                    <span class="label">点数</span>
                </template>
                <div>
                    <el-select v-model="form.number" placeholder="选择点数" style="width: 200px; margin-left: 10px">
                        <el-option v-for="(f, index) in numberConf" :key="index" :label="f.label" :value="f.value" />
                    </el-select>
                </div>
            </el-form-item>
            <el-form-item v-show="form.reset != 1">
                <template slot="label">
                    <span class="label">金骰子</span>
                </template>
                <div class="ml-10">
                    <el-switch v-model="form.isGold" :active-value="1" :inactive-value="0" />
                </div>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
import { GAME_TYPE } from '@/constant/game'
export default {
    components: {},
    data() {
        return {
            GAME_TYPE,
            numberConf: [
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 },
                { label: '7', value: 7 },
                { label: '8', value: 8 },
                { label: '9', value: 9 },
                { label: '10', value: 10 },
                { label: '11', value: 11 },
                { label: '12', value: 12 }
            ],
            form: {
                reset: '',
                number: '',
                isGold: ''
            }
        }
    },
    mixins: [Base],
    mounted() {},
    methods: {
        submit() {
            if (this.form.number === '' && this.form.reset != 1) {
                return this.$message.error('请选择点数')
            }

            let result = [[this.form.number], [this.form.isGold]]
            if (this.form.reset == 1) {
                result = []
            }

            const postData = {
                gameType: GAME_TYPE.SUP,
                result: result
            }

            api.nextResult(postData).then((e) => {
                this.$message.success('修改成功')
                // this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
