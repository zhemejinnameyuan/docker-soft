<template>
    <div class="inner_item">
        <span class="text_red" style="margin-left: 100px; margin-bottom: 10px">下注阶段才会生效</span>
        <el-form ref="form" :model="form" label-width="100px" class="mt-5">
            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('♣️')"></span>
                </template>
                <el-select v-model="form.meihua" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('👑')"></span>
                </template>
                <el-select v-model="form.huangguan" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('♠️')"></span>
                </template>
                <el-select v-model="form.heitao" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('♦️')"></span>
                </template>
                <el-select v-model="form.fangkuai" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('🚩️️')"></span>
                </template>
                <el-select v-model="form.hongqi" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>

            <el-form-item>
                <template slot="label">
                    <span class="label" v-html="replaceHtml('♥️')"></span>
                </template>
                <el-select v-model="form.hongtao" placeholder="选择牌值" style="width: 200px; margin-left: 10px">
                    <el-option v-for="(f, index) in card_value" :key="index" :label="f.label" :value="f.value" />
                </el-select>
            </el-form-item>
        </el-form>
        <div class="dp-f" style="flex-direction: row-reverse">
            <el-button type="primary" @click="submit" class="ml-10">确认</el-button>
            <el-button type="info" plain @click="dialogCancel">取消</el-button>
        </div>
    </div>
</template>
<script>
import * as api from '@/api/inner'
import Base from '@/views/base'
import { GAME_TYPE } from '@/constant/game'
export default {
    components: {},
    data() {
        return {
            GAME_TYPE,
            card_value: [
                { label: '0', value: 0 },
                { label: '1', value: 1 },
                { label: '2', value: 2 },
                { label: '3', value: 3 },
                { label: '4', value: 4 },
                { label: '5', value: 5 },
                { label: '6', value: 6 }
            ],
            form: {
                meihua: '',
                huangguan: '',
                heitao: '',
                fangkuai: '',
                hongqi: '',
                hongtao: ''
            }
        }
    },
    mixins: [Base],
    methods: {
        submit() {
            var a = false
            Object.values(this.form).forEach((e) => {
                if (!e) {
                    a = true
                }
            })

            let result = [[this.form.meihua], [this.form.huangguan], [this.form.heitao], [this.form.fangkuai], [this.form.hongqi], [this.form.hongtao]]

            const postData = {
                gameType: GAME_TYPE.JM,
                result: result
            }

            api.nextResult(postData).then((e) => {
                this.$message.success('修改成功')
                // this.dialogCancel()
            })
        },
        dialogCancel() {
            this.$emit('onclose')
        }
    }
}
</script>
