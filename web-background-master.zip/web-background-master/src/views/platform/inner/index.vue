<template>
    <div class="app-container inner_page">
        <div class="inner-box dp-c">
            <div class="dp-f-center mb-30">
                <div class="top-box-card ml-20 mr-20" v-for="(item, index) in topList" :key="index" :style="getBgImg(item.img)" @click="selectItem(item)">
                    <div class="top-box-card-title ml-30" :style="'color:' + item.color">{{ item.title }}</div>
                </div>
            </div>

            <div style="height: 1px; background: #e3e5eb"></div>
            <div class="game-box">
                <div class="game-box-card mt-30 mr-30" v-for="(item, index) in gameList" :key="index" :style="getBgImg(item.img)" @click="selectItem(item)">
                    <div class="game-box-card-title mt-30">{{ item.title }}</div>
                    <div class="game-box-card-desc">{{ item.desc }}</div>
                </div>
            </div>

            <div style="height: 1px; background: #e3e5eb"></div>
            <div class="game-box">
                <div class="game-box-card mt-30 mr-30" v-for="(item, index) in apiList" :key="index" :style="getBgImg(item.img)" @click="selectItem(item)">
                    <div class="game-box-card-title mt-30">{{ item.title }}</div>
                    <div class="game-box-card-desc">{{ item.desc }}</div>
                </div>
            </div>
        </div>

        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" :title="dialogTitle" :width="dialogWidth">
            <dtResult v-if="type === 'dtResult'" @onclose="dialogCancel" />
            <deposit v-if="type === 'deposit'" @onclose="dialogCancel" />
            <godView v-if="type === 'godView'" @onclose="dialogCancel" />
            <jmResult v-if="type === 'jmResult'" @onclose="dialogCancel" />
            <rbResult v-if="type === 'rbResult'" @onclose="dialogCancel" />
            <babResult v-if="type === 'babResult'" @onclose="dialogCancel" />
            <cszResult v-if="type === 'cszResult'" @onclose="dialogCancel" />
            <dltResult v-if="type === 'dltResult'" @onclose="dialogCancel" />
            <supResult v-if="type === 'supResult'" @onclose="dialogCancel" />
            <tpResult v-if="type === 'tpResult'" @onclose="dialogCancel" />
            <fxqResult v-if="type === 'fxqResult'" @onclose="dialogCancel" />
            <revenueData v-if="type === 'revenueData'" @onclose="dialogCancel" />
        </el-dialog>
    </div>
</template>
<script>
import dtResult from './components/dtResult.vue'
import deposit from './components/deposit.vue'
import godView from './components/godView.vue'
import jmResult from './components/jmResult.vue'
import rbResult from './components/rbResult.vue'
import babResult from './components/babResult.vue'
import cszResult from './components/cszResult.vue'
import dltResult from './components/dltResult.vue'
import supResult from './components/supResult.vue'
import tpResult from './components/tpResult.vue'
import fxqResult from './components/fxqResult.vue'
import revenueData from './runApi/revenueData.vue'
export default {
    name: 'Inner',
    components: {
        dtResult,
        deposit,
        godView,
        jmResult,
        rbResult,
        babResult,
        cszResult,
        dltResult,
        supResult,
        tpResult,
        fxqResult,
        revenueData
    },
    data() {
        return {
            topList: [
                {
                    type: 'deposit',
                    title: '玩家充值',
                    desc: '',
                    img: 'oms_pingtai_recharge.png',
                    color: '#563C84'
                },
                {
                    type: 'godView',
                    title: '上帝视角',
                    desc: '',
                    img: 'oms_pingtai_shangdi.png',
                    color: '#006581'
                }
            ],
            gameList: [
                {
                    type: 'dtResult',
                    title: 'DT',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_dt.png'
                },
                {
                    type: 'jmResult',
                    title: 'JM',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_jm.png'
                },
                {
                    type: 'rbResult',
                    title: 'RB',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_rb.png'
                },
                {
                    type: 'babResult',
                    title: 'BAB',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_bab.png'
                },
                {
                    type: 'cszResult',
                    title: '猜数字',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_csz.png'
                },
                {
                    type: 'dltResult',
                    title: 'DLT',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_dlt.png'
                },
                {
                    type: 'supResult',
                    title: '7UP',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_7up.png'
                },
                {
                    type: 'tpResult',
                    title: 'TP',
                    desc: '修改游戏结果',
                    img: 'oms_pingtai_img_tp.png'
                },
                {
                    type: 'fxqResult',
                    title: '飞行棋',
                    desc: '修改骰子点数',
                    img: 'oms_pingtai_img_fxq.png'
                }
            ],
            apiList: [
                {
                    type: 'revenueData',
                    title: '营收统计',
                    desc: '重跑营收统计',
                    img: 'oms_pingtai_img_yingshoutongji.png'
                }
            ],
            type: '',
            dialogVisible: false,
            dialogTitle: '',
            dialogWidth: '480px'
        }
    },
    methods: {
        selectItem(item) {
            this.type = item.type
            this.dialogTitle = item.title
            this.dialogVisible = true
            if (item.type == 'tpResult') {
                this.dialogWidth = '1300px'
            } else {
                this.dialogWidth = '480px'
            }
        },
        getBgImg(img) {
            if (img) {
                const imgObj = require('@/assets/images/' + img)
                return {
                    background: `url(${imgObj})`,
                    'background-size': '100% 100%'
                }
            }
        },
        dialogCancel() {
            this.dialogVisible = false
            this.type = ''
        }
    }
}
</script>

<style lang="scss" scoped>
.top-box-card {
    width: 320px;
    height: 150px;
    cursor: pointer;
}
.top-box-card-title {
    margin-top: 50px;
    font-family: PingFangSC-Medium;
    font-size: 30px;
    font-weight: 500;
}
.game-box {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
}
.game-box-card {
    width: 280px;
    height: 110px;
    cursor: pointer;
}
.game-box-card-title {
    margin-left: 108px;
    font-family: PingFangSC-Medium;
    font-size: 24px;
    color: #282829;
    line-height: 24px;
    font-weight: 500;
}
.game-box-card-desc {
    margin-left: 108px;
    margin-top: 12px;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    color: #686b6d;
    line-height: 14px;
    font-weight: 400;
}
</style>
