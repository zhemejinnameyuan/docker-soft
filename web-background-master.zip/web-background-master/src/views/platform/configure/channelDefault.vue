<template>
    <div>
        <div class="scroll-content" style="height: 500px; overflow: auto">
            <el-form ref="form" :model="form" :inlin="true" :rules="rules" size="small" label-width="120px" label-position="top">
                <div class="scroll-item">
                    <div class="item-title mb-10">短信通道</div>
                    <div class="item-bg">
                        <div class="dp-f">
                            <div>
                                <el-form-item label="" prop="sms253Dto.provider">
                                    <span class="text_gray mr-10">服务商:</span>
                                    <el-input v-model="form.sms253Dto.provider" placeholder="请输入服务商" show-word-limit style="width: 160px" />
                                </el-form-item>
                            </div>

                            <div class="vertical-line" style="margin: 0 30px 0 30px"></div>
                            <div class="mt-10">
                                <span class="text_gray">状态：</span>
                                <el-switch v-model="form.sms253Dto.state" />
                            </div>
                            <div class="vertical-line" style="margin: 0 30px 0 30px"></div>
                            <div class="mt-5">
                                <span class="text_gray">操作：</span>
                                <span><el-button type="primary" plain @click="querySms" v-permission="[permission.appConfigQuerySmsBalance]">查看余额</el-button></span>
                            </div>
                        </div>

                        <div class="horizontal-line mt-20 mb-20"></div>
                        <div class="dp-f">
                            <div class="dp-c mr-20">
                                <el-form-item label="账号" prop="sms253Dto.account">
                                    <el-input v-model="form.sms253Dto.account" placeholder="请输入账号" style="width: 280px" />
                                </el-form-item>

                                <el-form-item label="密码" prop="sms253Dto.password">
                                    <el-input v-model="form.sms253Dto.password" placeholder="请输入密码" style="width: 280px" />
                                </el-form-item>
                            </div>

                            <div class="ml-40 dp-c">
                                <el-form-item label="接口域名" prop="sms253Dto.apiUrl">
                                    <el-input v-model="form.sms253Dto.domain" placeholder="请输入接口域名" style="width: 280px" />
                                </el-form-item>
                                <el-form-item label="短信模版:" prop="sms253Dto.enTemplate">
                                    <el-input type="textarea" v-model="form.sms253Dto.enTemplate" rows="3" placeholder="请输入短信模版" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">请确保短信模版配置正确，错误配置可导致短信下发失败(短信模版可通过服务商获取)</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="scroll-item mt-20">
                    <div class="item-title mb-10">邮箱</div>
                    <div class="item-bg">
                        <div class="dp-f">
                            <div class="mr-20">
                                <el-form-item label="官方联系邮箱" prop="officialEmail">
                                    <el-input v-model="form.officialEmail" placeholder="请输入邮箱" style="width: 280px" />
                                </el-form-item>
                            </div>

                            <div class="ml-40">
                                <el-form-item label="客服服务邮箱" prop="customerEmail">
                                    <el-input v-model="form.customerEmail" placeholder="请输入邮箱" style="width: 280px" />
                                </el-form-item>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="scroll-item mt-20">
                    <div class="item-title mb-10">域名</div>
                    <div class="item-bg">
                        <div class="item-subtitle mb-20" style="margin-left: -20px">落地页域名</div>
                        <div class="dp-f">
                            <div>
                                <el-form-item label="使用域名:">
                                    <el-input type="textarea" v-model="form.landPageUrls.l" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                            <div class="ml-40">
                                <el-form-item label="备用域名:">
                                    <el-input type="textarea" v-model="form.landPageUrls.r" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                        </div>

                        <div class="item-subtitle mt-20 mb-20" style="margin-left: -20px">h5域名</div>
                        <div class="dp-f">
                            <div>
                                <el-form-item label="使用域名:">
                                    <el-input type="textarea" v-model="form.h5Urls.l" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                            <div class="ml-40">
                                <el-form-item label="备用域名:">
                                    <el-input type="textarea" v-model="form.h5Urls.r" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                        </div>

                        <div class="item-subtitle mt-20 mb-20" style="margin-left: -20px">API域名</div>
                        <div class="dp-f">
                            <div>
                                <el-form-item label="使用域名:">
                                    <el-input type="textarea" v-model="form.apiUrls.l" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                            <div class="ml-40">
                                <el-form-item label="备用域名:">
                                    <el-input type="textarea" v-model="form.apiUrls.r" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                        </div>

                        <div class="item-subtitle mt-20 mb-20" style="margin-left: -20px">资源域名</div>
                        <div class="dp-f">
                            <div>
                                <el-form-item label="使用域名:">
                                    <el-input type="textarea" v-model="form.resUrls.l" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                            <div class="ml-40">
                                <el-form-item label="备用域名:">
                                    <el-input type="textarea" v-model="form.resUrls.r" rows="4" placeholder="请输入域名" style="width: 300px" />
                                </el-form-item>
                                <div class="text_gray fs-12">多个域名以换行分隔</div>
                            </div>
                        </div>
                    </div>
                </div>
            </el-form>
        </div>
        <div class="horizontal-line"></div>
        <div style="width: 80px; margin: 0 auto">
            <el-button type="primary" @click="toSubmit">保存</el-button>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/config'
import Base from '@/views/base'
import { deepClone } from '@/utils'
const defaultConf = {
    landPageUrls: {},
    apiUrls: {},
    h5Urls: {},
    resUrls: {},
    sms253Dto: {
        provider: '',
        account: '',
        password: '',
        state: false,
        enTemplate: '',
        domain: ''
    },
    officialEmail: '',
    customerEmail: ''
}
export default {
    name: 'ChannelDefault',
    props: {
        configInfo: {
            type: Object,
            default: function () {
                return {}
            }
        }
    },
    mixins: [Base],
    data() {
        return {
            contentStyleObj: {
                height: '100px'
            },
            form: {},
            rules: {
                channelName: [
                    { required: true, message: '请输入渠道名称', trigger: 'blur', min: 2, max: 20 },
                    { pattern: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, message: '只能输入中文、字母和数字', trigger: 'blur' }
                ]
            },
            activeName: '0'
        }
    },
    components: {},
    created() {
        this.form = this.handleData(JSON.parse(this.configInfo.configValue))
    },
    methods: {
        handleData(config) {
            config = Object.assign(defaultConf, config)
            config.landPageUrls.l = this.domainJoin(config.landPageUrls.l)
            config.landPageUrls.r = this.domainJoin(config.landPageUrls.r)
            config.h5Urls.l = this.domainJoin(config.h5Urls.l)
            config.h5Urls.r = this.domainJoin(config.h5Urls.r)
            config.apiUrls.l = this.domainJoin(config.apiUrls.l)
            config.apiUrls.r = this.domainJoin(config.apiUrls.r)
            config.resUrls.l = this.domainJoin(config.resUrls.l)
            config.resUrls.r = this.domainJoin(config.resUrls.r)

            return config
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                let config = deepClone(this.form)

                //处理
                config.landPageUrls.l = this.domainSplit(config.landPageUrls.l)
                config.landPageUrls.r = this.domainSplit(config.landPageUrls.r)
                config.h5Urls.l = this.domainSplit(config.h5Urls.l)
                config.h5Urls.r = this.domainSplit(config.h5Urls.r)
                config.apiUrls.l = this.domainSplit(config.apiUrls.l)
                config.apiUrls.r = this.domainSplit(config.apiUrls.r)
                config.resUrls.l = this.domainSplit(config.resUrls.l)
                config.resUrls.r = this.domainSplit(config.resUrls.r)

                this.configInfo.configValue = JSON.stringify(config)
                if (valid) {
                    this.$emit('submit', this.configInfo)
                }
            })
        },
        dialogCancel() {
            this.$emit('onClose')
        },
        toQuery() {
            this.$emit('toQuery')
        },
        domainJoin(urlArr) {
            return urlArr ? _.join(urlArr, '\n') : ''
        },
        domainSplit(urls) {
            console.log(urls)
            return urls ? _.split(urls, '\n') : []
        },
        querySms() {
            let params = {
                smsType: '253',
                channelId: 0
            }
            api.querySmsBalance(params).then((rep) => {
                this.$notify({
                    type: 'success',
                    title: '接口返回信息',
                    message: rep.data
                })
            })
        }
    }
}
</script>

<style scoped lang="scss">
// 取消element原有的input框样式
::v-deep .el-input__inner {
    height: 40px;
    font-size: 16px;
    color: #282829;
}

//隐藏滚动条
::-webkit-scrollbar {
    display: none;
}

.scroll-item {
    min-height: 100px;
}

.horizontal-line {
    display: flex;
    width: 100%;
    height: 1px;
    background: #f0f2f7;
    margin-bottom: 10px;
    margin-top: 10px;
}

.vertical-line {
    display: flex;
    width: 1px;
    height: 16px;
    background: #f0f2f7;
}

.item-title {
    font-family: PingFangSC-Medium;
    font-size: 16px;
    color: #282829;
    line-height: 16px;
    font-weight: 500;
}

.item-title::before {
    display: inline-block;
    content: '';
    width: 4px;
    height: 12px;
    background: #1ba2ff;
    border-radius: 3px;
    margin-right: 10px;
}

.item-subtitle {
    font-family: PingFangSC-Medium;
    font-size: 14px;
    color: #282829;
    line-height: 12px;
    font-weight: 500;
}

.item-bg {
    padding: 30px 40px 30px 40px;
    width: 720px;
    min-height: 100px;
    background: #f9fafb;
    border-radius: 8px;
}
</style>
