<template>
    <div>
        <el-form ref="form" :inline="true" :model="configInfo" :rules="rules" size="small" label-width="140px">
            <el-form-item label="名称" prop="configName">
                <el-input v-model="configInfo.configName" placeholder="请输入1-50个字符" style="width: 480px" />
            </el-form-item>
            <el-form-item label="组" prop="configGroup">
                <el-input v-model="configInfo.configGroup" placeholder="请输入1-50个字符" style="width: 480px" />
            </el-form-item>
            <el-form-item label="参数" prop="configValue">
                <el-input v-model="configInfo.configValue" type="textarea" :rows="15" placeholder="请输入1-500个字符" style="width: 480px" />
            </el-form-item>
            <el-form-item label=" ">
                <el-radio-group v-model="configInfo.enableFlag">
                    <el-radio :label="true">启用</el-radio>
                    <el-radio :label="false">禁用</el-radio>
                </el-radio-group>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div style="width: 150px; margin: 0 auto">
                <el-button type="info" plain @click="close">取消</el-button>
                <el-button type="primary" @click="submit">确认</el-button>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'Edit',
    props: {
        configInfo: {
            type: Object,
            default: function () {
                return {}
            }
        }
    },
    data() {
        return {
            rules: {
                configName: [{ required: true, message: '请输入1-50个字符', trigger: 'blur' }],
                configGroup: [{ required: true, message: '请输入1-50个字符', trigger: 'blur' }],
                configValue: [{ required: true, message: '请输入1-3000个字符', trigger: 'blur' }]
            }
        }
    },
    methods: {
        close() {
            this.$emit('onclose')
        },
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$emit('submit', this.configInfo)
                }
            })
        }
    }
}
</script>
