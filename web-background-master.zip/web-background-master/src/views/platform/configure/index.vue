<template>
    <div class="app-container">
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column :show-overflow-tooltip="true" prop="id" width="80" align="center" label="ID" />
            <el-table-column :show-overflow-tooltip="true" width="170" prop="configName" align="center" label="名称" />
            <el-table-column :show-overflow-tooltip="true" width="120" prop="configGroup" align="center" label="组" />
            <el-table-column :show-overflow-tooltip="true" width="240" prop="configKey" align="center" label="KEY" />
            <el-table-column :show-overflow-tooltip="true" width="240" prop="configValue" align="center" label="参数" />
            <el-table-column :show-overflow-tooltip="true" width="155" prop="enableFlag" align="center" label="启用状态">
                <template slot-scope="scope">
                    <span :class="scope.row.enableFlag ? 'txt_green' : 'txt_red'">{{ scope.row.enableFlag ? '启用' : '禁用' }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="创建时间" />
            <el-table-column :show-overflow-tooltip="true" width="155" prop="updateTime" align="center" label="修改时间" />
            <el-table-column :show-overflow-tooltip="true" width="120" prop="operator" align="center" label="操作人" />
            <el-table-column label="操作" width="150" align="center" fixed="right">
                <template slot-scope="scope">
                    <IconButton v-permission="[permission.appConfigEdit]" class="filter-item" size="medium" type="text" icon="oms_ico_edit" style="font-size: 20px" @click="toEdit(scope.row)" />
                </template>
            </el-table-column>
        </el-table>

        <!-- 表单渲染 -->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" title="配置" width="800px">
            <!--渠道域名全局配置-->
            <ChannelDefault v-if="configInfo.configKey === 'CHANNEL_DEFAULT' && dialogVisible" :configInfo="configInfo" @onclose="dialogCancel" @submit="toSubmit" />
            <Edit v-else :configInfo="configInfo" @onclose="dialogCancel" @submit="toSubmit" />
        </el-dialog>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/config'
import ChannelDefault from './channelDefault'
import Edit from './edit'
export default {
    name: 'Config',
    components: {
        ChannelDefault,
        Edit
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: {
                all: true
            },
            configInfo: {},
            dialogVisible: false,
            rules: {
                configName: [{ required: true, message: '请输入2-50个字符', trigger: 'blur', min: 2, max: 50 }],
                configGroup: [{ required: true, message: '请输入2-50个字符', trigger: 'blur', min: 2, max: 50 }],
                configValue: [{ required: true, message: '请输入2-300个字符', trigger: 'blur', min: 2, max: 3000 }]
            }
        }
    },
    mounted() {
        this.fixed_height = 180
        this.toQuery()
    },
    methods: {
        dialogCancel() {
            this.dialogVisible = false
        },
        toQuery() {
            if (this.checkPermission([this.permission.appConfigList])) {
                this.loading = true
                api.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toSubmit(configData) {
            api.edit(configData)
                .then((rep) => {
                    this.$message.success('操作成功')
                    this.toQuery()
                    this.dialogCancel()
                })
                .catch(() => {})
        },
        toEdit(row) {
            this.configInfo = { ...row }
            this.dialogVisible = true
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.role-span {
    font-weight: bold;
    color: #303133;
    font-size: 15px;
}
.txt_green {
    color: $green;
}
.txt_red {
    color: $red;
}
::v-deep .el-input-number .el-input__inner {
    text-align: left;
}

::v-deep .vue-treeselect__multi-value {
    margin-bottom: 0;
}

::v-deep .vue-treeselect__multi-value-item {
    border: 0;
    padding: 0;
}
</style>
