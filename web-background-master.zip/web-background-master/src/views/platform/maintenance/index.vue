<template>
    <div class="app-container">
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column :show-overflow-tooltip="true" prop="appId" width="80" align="center" label="应用ID" />
                    <el-table-column :show-overflow-tooltip="true" prop="serverName" width="100" align="center" label="服务名称" />
                    <el-table-column :show-overflow-tooltip="true" prop="localIp" width="170" align="center" label="本地IP" />
                    <el-table-column :show-overflow-tooltip="true" prop="pid" width="100" align="center" label="进程ID" />
                    <el-table-column :show-overflow-tooltip="true" prop="bindHttpPort" width="100" align="center" label="Http端口" />
                    <el-table-column :show-overflow-tooltip="true" prop="bindTcpPort" width="100" align="center" label="Tcp端口" />
                    <el-table-column :show-overflow-tooltip="true" prop="websocketAddr" width="300" align="left" label="Ws连接地址">
                        <template slot-scope="scope">
                            <div v-if="scope.row.appId === 6">
                                ws地址-CN:{{ scope.row.cnWebsocketAddr }}
                                <br />
                                ws地址-Other:{{ scope.row.otherWebsocketAddr }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelSize" width="100" align="center" label="Tcp连接数" />
                    <el-table-column :show-overflow-tooltip="true" prop="playerSize" width="100" align="center" label="玩家数" />
                    <el-table-column :show-overflow-tooltip="true" align="center" prop="lastOnlineTime" width="155" label="最后在线时间" />

                    <el-table-column :show-overflow-tooltip="true" align="center" width="100" label="在线状态">
                        <template slot-scope="scope">
                            <span :class="scope.row.online ? 'text_green' : 'text_red'">{{ scope.row.online ? '是' : '否' }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="env" align="center" width="100" label="环境" />

                    <el-table-column v-permission="[permission.maintenanceEdit]" :show-overflow-tooltip="true" align="left" width="140" label="操作" fixed="right">
                        <template slot-scope="scope">
                            <IconButton class="filter-item" size="medium" type="text" icon="oms_ico_xiangqing" style="font-size: 20px" @click="toDtail(scope.row)" />
                            <IconButton v-if="scope.row.appId === 6" class="filter-item" size="medium" type="text" icon="oms_ico_edit" style="font-size: 20px" @click="toEdit(scope.row)" />
                            <IconButton
                                v-if="scope.row.online"
                                class="filter-item"
                                type="text"
                                style="font-size: 20px; color: red"
                                icon="oms_ico_enable"
                                size="medium"
                                @click="toShutDown(scope.row)"
                            />
                            <IconButton class="filter-item" type="text" style="font-size: 20px; color: red" icon="oms_ico_del" size="medium" @click="toDelet(scope.row)" />
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" title="编辑" :width="'550px'">
            <el-form ref="form" :inline="true" :model="dialogObj" :rules="rules" size="small" label-width="180px">
                <el-form-item label="websocket地址-CN:" prop="cnWebsocketAddr">
                    <el-input v-model="dialogObj.cnWebsocketAddr" placeholder="请输入websocket地址" show-word-limit style="width: 280px" />
                </el-form-item>

                <el-form-item label="websocket地址-Other:" prop="otherWebsocketAddr">
                    <el-input v-model="dialogObj.otherWebsocketAddr" placeholder="请输入websocket地址" show-word-limit style="width: 280px" />
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">确认</el-button>
            </div>
        </el-dialog>

        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="runtimeDialogVisible" title="RuntimeInfo" :width="'480px'">
            <code>
                {{ runtimeInfo }}
            </code>
        </el-dialog>
    </div>
</template>

<script>
import Base from '@/views/base'
import * as api from '@/api/maintenance'
import { confirmRequest } from '@/utils'
export default {
    name: 'Serve',
    components: {},
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            dialogObj: {
                websocketAddr: null,
                page: 1,
                size: 10,
                sort: 'createTime;desc'
            },
            dialogVisible: false,
            runtimeDialogVisible: false,

            rules: {
                cnWebsocketAddr: [{ required: true, message: '请输入websocket地址-CN', trigger: 'blur' }],
                otherWebsocketAddr: [{ required: true, message: '请输入websocket地址-Other', trigger: 'blur' }]
            },
            runtimeInfo: null
        }
    },
    mounted() {
        this.fixed_height = 200
        this.toQuery()
    },
    methods: {
        toQuery() {
            if (this.checkPermission([this.permission.maintenanceList])) {
                this.loading = true
                api.list()
                    .then((rep) => {
                        this.list = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toDtail(row) {
            this.runtimeInfo = JSON.stringify(row.runtimeInfo, null, '\t')
            this.runtimeDialogVisible = true
        },
        toEdit(row) {
            this.dialogObj = { ...row }
            delete this.dialogObj.runtimeInfo
            this.dialogVisible = true
        },
        toShutDown(row) {
            confirmRequest('确定是否禁用？', () => {
                const dic = { ...row }
                delete dic.runtimeInfo
                api.shutdown(dic)
                    .then((rep) => {
                        this.$message.success('操作成功')
                        this.toQuery()
                    })
                    .catch(() => {})
            })
        },
        toDelet(row) {
            confirmRequest('确定是否禁用？', () => {
                const dic = { ...row }
                delete dic.runtimeInfo
                api.del(dic)
                    .then((rep) => {
                        this.$message.success('操作成功')
                        this.toQuery()
                    })
                    .catch(() => {})
            })
        },
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    api.updateWebSocketAddr(this.dialogObj)
                        .then((rep) => {
                            this.$message.success('修改成功')
                            this.toQuery()
                            this.dialogCancel()
                        })
                        .catch(() => {
                            this.dialogCancel()
                        })
                }
            })
        },

        dialogCancel() {
            this.dialogVisible = false
            this.runtimeDialogVisible = false
        }
    }
}
</script>
