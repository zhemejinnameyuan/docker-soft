<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-input v-model="query.username" size="medium" clearable placeholder="请输入账号" style="width: 150px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.userType" placeholder="账号类型" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in USER_TYPE_CONF" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.enableFlag" placeholder="状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option :value="true" label="启用" />
                    <el-option :value="false" label="禁用" />
                </el-select>

                <IconButton v-permission="[permission.channelPackageList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>

            <el-row type="flex" justify="end">
                <IconButton v-permission="[permission.userAdd]" class="filter-item" size="medium" type="primary" icon="oms_ico_add" title="添加账号" @click="toAdd" />
            </el-row>
        </div>
        <!--表格渲染-->
        <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%" :height="table_height">
            <el-table-column width="110" prop="id" align="center" label="ID" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="账号" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="账号类型">
                <template slot-scope="scope">
                    <span>{{ getArrayValue(USER_TYPE_NAME, scope.row.userType) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" label="角色" align="center">
                <template slot-scope="scope">
                    <span>{{ scope.row.userType === 'SUPER_ADMIN' ? '超级管理员' : scope.row.roles[0].name }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="250" label="渠道" align="center">
                <template slot-scope="scope">
                    <span>{{ getChannel(scope.row) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" prop="createTime" width="155" align="center" label="创建时间" />
            <el-table-column :show-overflow-tooltip="true" prop="updateTime" width="155" align="center" label="修改时间" />
            <el-table-column width="100" label="状态" align="center" prop="enableFlag">
                <template slot-scope="scope">
                    <div class="table_state_switch">
                        <el-switch v-model="scope.row.enableFlag" @change="toEnabled(scope.row)" :disabled="!checkPermission([permission.userEdit])"></el-switch>
                    </div>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" prop="operator" width="135" align="center" label="操作人" />
            <el-table-column label="操作" width="200" align="center">
                <template slot-scope="scope">
                    <el-tooltip class="item" effect="dark" content="修改" placement="top-start">
                        <IconButton v-permission="[permission.userEdit]" type="text" class="mr-10" size="medium" style="font-size: 20px" icon="oms_ico_edit" @click="toEdit(scope.row)" />
                    </el-tooltip>
                    <el-tooltip class="item" effect="dark" content="删除" placement="top-start">
                        <IconButton
                            v-permission="[permission.userDel]"
                            class="mr-10"
                            type="text"
                            style="font-size: 20px; color: #e60808"
                            icon="oms_ico_del"
                            size="medium"
                            @click="delAccount(scope.row)"
                        />
                    </el-tooltip>

                    <el-tooltip class="item" effect="dark" content="重置密钥" placement="top-start">
                        <IconButton
                            v-permission="[permission.userEdit]"
                            class="mr-10"
                            type="text"
                            style="font-size: 20px; color: #e60808"
                            icon="oms_ico_reset"
                            size="medium"
                            @click="resetSecretKey(scope.row.id)"
                        />
                    </el-tooltip>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

        <!--表单渲染-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="toCancel" :visible.sync="dialogVisible" :title="dialogTitle" width="540px">
            <el-form ref="form" :inline="true" :model="form" :rules="rules" size="small" label-width="100px">
                <el-form-item label="账号类型:">
                    <el-radio-group v-model="form.userType">
                        <el-radio v-for="(item, index) in USER_TYPE_NAME" :key="index" :label="index">{{ item }}</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="账号:" prop="username">
                    <el-input
                        v-model="form.username"
                        style="width: 280px"
                        :disabled="dialogType === 'edit'"
                        minlength="4"
                        maxlength="12"
                        show-word-limit
                        placeholder="请输入4-12位字母和数字"
                        clearable
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                </el-form-item>
                <el-form-item label="重置密码:" prop="showPassword" v-if="dialogType === 'edit'">
                    <el-input
                        v-model="form.showPassword"
                        style="width: 280px"
                        minlength="4"
                        maxlength="12"
                        show-word-limit
                        placeholder="请输入密码,不填写不修改"
                        clearable
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                </el-form-item>

                <el-form-item v-if="form.userType !== 'SUPER_ADMIN'" style="margin-bottom: 20px" label="分配角色:" prop="roles">
                    <el-select v-model="form.roles" style="width: 280px" placeholder="选择角色" clearable filterable>
                        <el-option v-for="item in roles" :key="item.id" :label="item.name" :value="item.id" />
                    </el-select>
                </el-form-item>
                <el-form-item v-if="form.userType !== 'SUPER_ADMIN' && form.userType !== 'CHANNEL_ADMIN' && form.roles" style="margin-bottom: 0" label="分配渠道:" prop="channelId">
                    <el-select v-model="form.channelId" style="width: 280px" placeholder="选择渠道" clearable filterable>
                        <el-option v-for="item in channels" :key="item.id" :label="item.channelName + '(' + item.id + ')'" :value="item.id" />
                    </el-select>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="toCancel">取消</el-button>
                <el-button type="primary" @click="toSubmit">确认</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import User from '@/api/system/user'
import { queryRole } from '@/api/system/role'
import Pagination from '@/components/Pagination'
import Base from '@/views/base'
import { confirmRequest, getChannelList } from '@/utils'
import { USER_TYPE_NAME, USER_TYPE_CONF } from '@/constant/common'
import { rsaEncrypt } from '@/utils/rsaEncrypt'

const defaultForm = {
    page: 1,
    size: 20,
    lastId: null,
    sort: 'createTime;asc',
    username: null,
    enableFlag: null,
    createTime: []
}
export default {
    name: 'User',
    components: { Pagination },
    mixins: [Base],
    data() {
        return {
            USER_TYPE_NAME,
            USER_TYPE_CONF,
            list: [],
            rules: {
                username: [
                    { required: true, message: '请输入账号', trigger: 'blur' },
                    { pattern: /^[a-zA-Z0-9]+$/, message: '只能输入字母和数字', trigger: 'blur' },
                    { min: 4, max: 12, message: '长度在 4 到 12 个字符', trigger: 'blur' }
                ],
                showPassword: [{ min: 6, max: 18, message: '密码长度在 6 到 18 个字符', trigger: 'blur' }],
                roles: [{ required: true, message: '请选择角色', trigger: 'blur' }],
                channelId: [{ required: true, message: '请选择渠道', trigger: 'blur' }]
            },
            loading: false,
            roles: [],
            channels: [],
            query: defaultForm,
            dialogType: '',
            dialogVisible: false,
            form: {
                userType: 'CHANNEL_USER',
                username: '',
                roles: null,
                channelId: null
            },
            total: 0
        }
    },
    computed: {
        dialogTitle() {
            if (this.dialogType === 'add') {
                return '添加账号'
            } else if (this.dialogType === 'edit') {
                return '编辑账号'
            }
            return ''
        }
    },
    created() {},
    mounted() {
        this.fixed_height = 300
        this.getRoles()
        this.getChannels()
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.userList])) {
                this.loading = true
                User.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toCancel() {
            this.dialogVisible = false
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    var data = { ...this.form }
                    if (data.roles) {
                        data.roles = [{ id: data.roles }]
                    }
                    if (data.userType === 'SUPER_ADMIN') {
                        data.roles = []
                        data.channelId = 0
                    }
                    if (data.userType === 'CHANNEL_ADMIN') {
                        data.channelId = 0
                    }
                    if (this.dialogType === 'add') {
                        User.add(data)
                            .then((res) => {
                                this.$message.success('添加成功')
                                this.toCancel()
                                this.toQuery()
                            })
                            .catch(() => {})
                    } else {
                        if (data.showPassword) {
                            data.showPassword = rsaEncrypt(data.showPassword)
                        }
                        User.edit(data)
                            .then((res) => {
                                this.$message.success('修改成功')
                                this.toCancel()
                                this.toQuery()
                            })
                            .catch(() => {})
                    }
                }
            })
        },
        toAdd() {
            this.form = {
                id: null,
                userType: 'CHANNEL_USER',
                username: '',
                roles: null,
                channelId: null
            }
            this.dialogVisible = true
            this.dialogType = 'add'
        },
        toEdit(data) {
            this.form = {
                username: data.username,
                showPassword: null,
                userType: data.userType,
                id: data.id,
                channelId: data.channelId || null,
                roles: data.roles ? data.roles[0].id : null
            }
            this.dialogVisible = true
            this.dialogType = 'edit'
        },
        getRoles() {
            if (this.checkPermission([this.permission.userRoleList])) {
                queryRole({ all: true, page: 1, size: 1000 })
                    .then((res) => {
                        this.roles = res.data
                    })
                    .catch(() => {})
            }
        },
        async getChannels() {
            if (this.checkPermission([this.permission.userChannelList])) {
                this.channels = await getChannelList()
            }
        },
        resetPassword(data) {
            confirmRequest('确定重置登录密码吗？', () => {
                User.resetPassword(data)
                    .then((res) => {
                        data.showPassword = res.data
                        this.$message.success('密码重置成功')
                    })
                    .catch(() => {})
            })
        },
        delAccount(data) {
            confirmRequest('删除用户后，用户将无法正常使用后台功能，确定是否要删除？', () => {
                User.del([data.id])
                    .then((rep) => {
                        this.$message.success('删除成功')
                        this.toQuery()
                    })
                    .catch(() => {})
            })
        },
        resetSecretKey(id) {
            confirmRequest('确定是否要重置吗？', () => {
                User.resetSecretKey({ id: id })
                    .then((rep) => {
                        this.$notify({
                            type: 'success',
                            title: '请复制密钥',
                            message: rep.data,
                            duration: 10000
                        })
                        this.toQuery()
                    })
                    .catch(() => {})
            })
        },
        toEnabled(data) {
            confirmRequest(
                this.getEnabledTitle(data),
                () => {
                    User.edit(data)
                        .then((res) => {
                            if (data.enableFlag) {
                                this.$message.success('启用成功')
                            } else {
                                this.$message.success('禁用成功')
                            }
                        })
                        .catch(() => {
                            data.enableFlag = !data.enableFlag
                        })
                },
                () => {
                    data.enableFlag = !data.enableFlag
                }
            )
        },
        getEnabledTitle(data) {
            if (!data.enableFlag) {
                return '禁用后该用户无法登录，并且无法正常使用后台功能，是否确定禁用该用户？'
            } else {
                return '是否确定启用该用户?'
            }
        },
        getEnabledType(data) {
            if (data.enableFlag) {
                return '禁用'
            } else {
                return '启用'
            }
        },
        getChannel(data) {
            if (!data.channelId) {
                return 'ALL'
            } else {
                if (data.channelId) {
                    return `${data.channelName}(${data.channelId})`
                }
            }
            return '-'
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.txt_green {
    color: $green;
}
.txt_red {
    color: $red;
}
.button_green {
    background: $green;
    border-color: $green;
}
.button_red {
    background: $red;
    border-color: $red;
}
.mr-10 {
    margin-right: 10px;
}
</style>
