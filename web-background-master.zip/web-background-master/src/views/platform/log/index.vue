<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-select v-model="query.desc" placeholder="全部行为" class="filter-item" size="medium" clearable filterable @change="toQuery">
                    <el-option v-for="item in titles" :key="item" :label="item" :value="item" />
                </el-select>
                <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="创建开始日期" end-placeholder="创建结束日期" @change="toQuery" />
                <el-input v-model="query.username" size="medium" clearable placeholder="操作人" style="width: 200px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton v-permission="[permission.syslogList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton v-permission="[permission.syslogList]" class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="100" align="center" label="id" />
                    <el-table-column width="180" prop="logDesc" align="center" label="操作行为" />
                    <el-table-column width="180" prop="browser" align="center" label="浏览器" />
                    <el-table-column width="180" align="center" label="请求id">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.requestId" v-clipboard:success="copySuccess" v-clipboard:error="copyError">{{ scope.row.requestId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" align="center" label="数据">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.requestParam" v-clipboard:success="copySuccess" v-clipboard:error="copyError">{{ scope.row.requestParam }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="创建时间" />
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="username" align="center" label="操作人" />
                </el-table>
                <!--分页组件-->
                <Pagination :page-sizes="[100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import Pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/log'
import Base from '@/views/base'
const defaultQuery = {
    username: '',
    createTime: [],
    sort: 'createTime;desc',
    size: 100,
    desc: '',
    page: 1
}
export default {
    name: 'AccountLog',
    components: {
        Pagination,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            titles: [],
            query: defaultQuery,
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 280
        this.resetQuery()
        this.queryTitles()
    },
    methods: {
        dialogCancel() {
            this.dialogVisible = false
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.syslogList])) {
                this.loading = true
                api.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        queryTitles() {
            api.title()
                .then((rep) => {
                    this.titles = rep.data
                })
                .catch(() => {})
        }
    }
}
</script>
