<script>
import { fenToYuan, yuanToFen, tableSumFixed, range, getArrayValue, getAccountSummary, getStrategyValueTitle, isChannelUser } from '@/utils/index'
import { replaceHtml } from '@/utils/temp'
import { filterEmpty, filterThousandths } from '@/utils/filters'
import { getGames, textColor, getPercentage, getGameName, getDeskName, getPercentageRatio } from './expand'

import checkPermission, { permission } from '@/utils/permission'
import store from '@/store'

export default {
    data() {
        return {
            fixed_height: 0,
            table_height: 0,
            permission,
            disabled: false
        }
    },
    watch: {
        fixed_height: {
            handler(val) {
                setTimeout(() => {
                    this.table_height = document.documentElement.clientHeight - this.fixed_height
                }, 100)
            }
        }
    },

    mounted() {
        this.table_height = document.documentElement.clientHeight - this.fixed_height
        window.addEventListener('resize', this.onresize)
    },
    methods: {
        replaceHtml,
        checkPermission,
        textColor,
        getPercentage,
        getPercentageRatio,
        getGames,
        getGameName,
        getDeskName,
        tableSumFixed,
        getArrayValue,
        range,
        fenToYuan,
        yuanToFen,
        getAccountSummary,
        getStrategyValueTitle,
        isChannelUser,
        filterEmpty,
        filterThousandths,
        onresize() {
            this.table_height = document.documentElement.clientHeight - this.fixed_height
        },
        toHome() {
            window.open('/')
        },
        getUserInfo() {
            return store.getters && store.getters.userInfo
        },
        copySuccess() {
            this.$message.success('复制成功')
        },
        copyError() {
            this.$message.error('复制失败')
        },
        getAvatar(domain, row) {
            if (_.startsWith(row.avatarId, 'http://') || _.startsWith(row.avatarId, 'https://')) {
                return row.avatarId
            } else if (_.toNumber(row.avatarId) == row.avatarId) {
                return `/avatar/head_${row.avatarId}.png`
            } else {
                return domain + row.avatarId
            }
        }
    }
}
</script>
