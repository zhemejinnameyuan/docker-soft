import { GAME_TYPE, deskType, gameConfig } from '@/constant/game'
import { roomType as lmRoomType } from '@/constant/lm'
import { roomType as fxqRoomType } from '@/constant/fxq'
import { isEmpty } from '@/utils/typeof'

/**
 * 获取游戏列表
 * @returns {{path: string, img: string, enable: boolean, name: string, id: number, type: string}[]}
 */
export function getGames() {
    return Object.values(gameConfig)
    // return Object.values(gameConfig).filter((e) => e.enable)
}
/**
 * 数字颜色
 * @param val
 * @returns {string}
 */
export function textColor(val) {
    if (val > 0) {
        return 'text_red'
    }
    if (val < 0) {
        return 'text_green'
    }
    return ''
}

/**
 * 计算百分比
 * @param num
 * @param total
 * @returns {string}
 */
export function getPercentage(num, total) {
    if (isEmpty(num) || isEmpty(total)) {
        return '--'
    }
    if (num == 0 || total == 0) {
        return '0%'
    }
    if (!isEmpty(num) && !isEmpty(total)) {
        var a = ((Math.abs(num) / Math.abs(total)) * 100).toFixed(2) + '%'
        if (num < 0) {
            a = '-' + a
        }
        return a
    }
    return '--'
}

/**
 * 计算环比
 * @param curr
 * @param before
 * @returns {string}
 */
export function getPercentageRatio(curr, before) {
    if (isEmpty(curr) || isEmpty(before)) {
        return '--'
    }
    if (curr !== before) {
        if (curr > 0 && parseInt(before) === 0) {
            return parseInt(curr * 100) + '%'
        }
        if (parseInt(curr) === 0 && before > 0) {
            return '-100%'
        }
        return (((curr - before) / before) * 100).toFixed(2) + '%'
    }
    return '持平'
}

/**
 * 获取游戏名字
 * @param gameType
 * @param roomType
 * @returns {*}
 */
export function getGameName(gameType, roomType) {
    let name
    if (gameConfig[gameType]) {
        name = gameConfig[gameType].name
    }
    if (roomType) {
        switch (gameType) {
            case GAME_TYPE.LM:
                name += `(${lmRoomType[roomType].name})`
                break
            case GAME_TYPE.FXQ:
                name += `(${fxqRoomType[roomType].name})`
                break
            default:
                break
        }
    }
    return name
}

/**
 * 获取牌桌类型
 * @param deskPlayer
 * @returns {*}
 */
export function getDeskName(deskPlayer) {
    if (deskType[deskPlayer]) {
        return deskType[deskPlayer].name
    }
}
