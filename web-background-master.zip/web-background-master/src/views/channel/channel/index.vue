<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-input v-model="query.channelName" size="medium" clearable placeholder="输入渠道名称" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.id" size="medium" clearable placeholder="输入渠道id" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="创建开始日期" end-placeholder="创建结束日期" @change="toQuery" />
                <IconButton v-permission="[permission.channelList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton v-permission="[permission.channelList]" class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end">
                <IconButton v-permission="[permission.channelAdd]" v-exclude-channel-user class="filter-item" size="medium" type="primary" icon="oms_ico_add" title="添加渠道" @click="toAdd" />
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="155" label="渠道ID" align="center" />
                    <el-table-column :show-overflow-tooltip="true" prop="channelName" align="center" label="渠道名称" />
                    <el-table-column :show-overflow-tooltip="true" prop="packageNumber" align="center" label="渠道包数量" />
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="155" align="center" label="创建时间" />
                    <el-table-column :show-overflow-tooltip="true" width="155" align="center" prop="updateTime" label="修改时间" />

                    <el-table-column :show-overflow-tooltip="true" width="155px" prop="operator" label="操作人" align="center" />
                    <el-table-column label="操作" width="200px" align="center" fixed="right">
                        <template slot-scope="scope">
                            <IconButton
                                v-permission="[permission.channelPackageList]"
                                class="filter-item"
                                size="medium"
                                type="text"
                                icon="oms_ico_xiangqing"
                                style="font-size: 20px"
                                @click="toDetail(scope.row)"
                            />
                            <IconButton v-permission="[permission.channelEdit]" class="filter-item" size="medium" type="text" icon="oms_ico_edit" style="font-size: 20px" @click="toEdit(scope.row)" />
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
        <!-- 表单渲染 -->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" title="详情" width="480px">
            <div>
                <el-table v-loading="loading" highlight-current-row style="width: 100%" :data="packages" max-height="500px" border>
                    <el-table-column :show-overflow-tooltip="true" align="center" label="渠道包名称（code）">
                        <template slot-scope="scope">
                            <span>{{ scope.row.name }} ({{ scope.row.code }})</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelBindTime" align="center" label="加入时间" />
                </el-table>
                <pagination v-if="totalDialog" :page-sizes="[10, 20, 50]" :query="queryDialog" :total="totalDialog" @pageChangeHandler="toQueryPackage" />
            </div>
        </el-dialog>

        <Drawer :visible.sync="drawer" :title="drawerType === 'add' ? '添加渠道' : '编辑渠道'">
            <EditConfig v-if="drawer" :id="drawerId" :type="drawerType" @onClose="closeDrawer" @toQuery="toQuery" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/channel'
import EditConfig from './edit'

const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'createTime;desc',
    id: '',
    channelName: '',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Drawer,
        pagination,
        DateRangePicker,
        EditConfig
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: defaultQuery,
            dialogObj: {
                channelName: '',
                id: null
            },
            dialogVisible: false,
            drawer: false,
            drawerType: '',
            drawerId: '',
            total: 0,
            queryDialog: {
                channelId: null,
                page: 1,
                size: 10,
                sort: 'createTime;desc'
            },
            totalDialog: 0,
            packages: []
        }
    },
    mounted() {
        this.fixed_height = 330
        this.resetQuery()
    },
    methods: {
        dialogCancel() {
            this.dialogVisible = false
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.channelList])) {
                this.loading = true
                api.list(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toQueryPackage() {
            this.loading = true
            api.packageList(this.queryDialog)
                .then((rep) => {
                    this.packages = rep.data
                    this.totalDialog = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        toAdd() {
            this.drawer = true
            this.drawerType = 'add'
            this.drawerId = 0
        },

        toDetail(row) {
            this.queryDialog.channelId = row.id
            this.dialogVisible = true
            this.toQueryPackage()
        },
        toEdit(row) {
            this.drawer = true
            this.drawerType = 'edit'
            this.drawerId = row.id
        },
        closeDrawer() {
            this.drawer = false
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.role-span {
    font-weight: bold;
    color: #303133;
    font-size: 15px;
}
</style>

<style rel="stylesheet/scss" lang="scss" scoped>
::v-deep .el-input-number .el-input__inner {
    text-align: left;
}

::v-deep .vue-treeselect__multi-value {
    margin-bottom: 0;
}

::v-deep .vue-treeselect__multi-value-item {
    border: 0;
    padding: 0;
}
::v-deep .el-dialog {
    .el-table {
        .el-table__header {
            thead {
                th {
                    background: #f0f0f0;
                    font-size: 12px;
                    color: #282829;
                    font-weight: 500;
                }
            }
        }
        .el-table__body {
            tbody {
                tr {
                    background: #f7f7f7;
                }
            }
        }
    }
}
</style>
