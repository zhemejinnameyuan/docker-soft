<template>
    <div>
        <el-form ref="form" :inline="true" :model="dialogObj" :rules="rules" size="small" label-width="150px">
            <el-form-item label="选择渠道包" prop="channelId">
                <el-select v-model="dialogObj.channelId" placeholder="渠道" size="small" class="filter-item" clearable>
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
            </el-form-item>
        </el-form>

        <div slot="footer" class="dialog-footer">
            <div style="margin-left: 500px">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">确认</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import ImagePreview from '@/components/ImagePreview'
import { confirmRequest } from '@/utils'
import Base from '@/views/base'
import * as api from '@/api/channel'

export default {
    name: 'Link',
    props: {
        selectsIds: {
            type: Array,
            default: []
        },
        channels: {
            type: Array,
            default: []
        }
    },
    components: {
        ImagePreview
    },
    mixins: [Base],
    data() {
        return {
            dialogObj: {
                channelId: null
            },
            loading: false,
            rules: {
                channelId: [{ required: true, message: '请选择所属渠道', trigger: 'blur' }]
            }
        }
    },
    mounted() {},
    methods: {
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    confirmRequest('关联渠道后则无法更改，确定是否关联？', () => {
                        var dic = {
                            ids: this.selectsIds,
                            channelId: this.dialogObj.channelId
                        }

                        if (this.checkPermission([this.permission.channelPackageEdit])) {
                            api.relationChannel(dic)
                                .then((rep) => {
                                    this.$message.success('关联成功')
                                    this.$emit('toQuery')
                                    this.dialogCancel()
                                })
                                .catch(() => {
                                    this.dialogCancel()
                                })
                        }
                    })
                }
            })
        },
        dialogCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
