<template>
    <div class="app-container">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.channelPackageChannelList]"
                    placeholder="渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 200px"
                    clearable
                    filterable
                    @change="toQuery"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select v-model="query.state" placeholder="启用状态" size="medium" class="filter-item" style="width: 120px" clearable @change="toQuery">
                    <el-option :label="'启用'" :value="7" />
                    <el-option :label="'禁用'" :value="0" />
                </el-select>
                <el-input v-model="query.name" size="medium" clearable placeholder="输入渠道包名称" style="width: 150px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.code" size="medium" clearable placeholder="输入渠道包code" style="width: 150px" class="filter-item" @keyup.enter.native="toQuery" />
                <DateRangePicker v-model="query.createTime" class="filter-item" start-placeholder="创建开始日期" end-placeholder="创建结束日期" @change="toQuery" />
                <IconButton v-permission="[permission.channelPackageList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton v-permission="[permission.channelPackageList]" class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="space-between">
                <el-col :span="12">
                    <el-select v-model="batchType" placeholder="批量操作" size="medium" class="filter-item" style="width: 160px" @change="selectBatch">
                        <el-option :label="'关联渠道'" :value="'link'" />
                        <el-option :label="'启用'" :value="'enable'" />
                        <el-option :label="'禁用'" :value="'disable'" />
                    </el-select>
                    <IconButton
                        v-permission="[permission.channelPackageExport]"
                        class="filter-item export_button"
                        size="medium"
                        type="primary"
                        icon="oms_ico_export"
                        plain
                        title="导出"
                        @click="exportExcel"
                    />
                </el-col>
                <IconButton v-permission="[permission.channelPackageAdd]" class="filter-item" size="medium" type="primary" icon="oms_ico_add" title="添加渠道包" @click="toAdd" />
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table
                    ref="table"
                    v-loading="loading"
                    class="game-table channel_table"
                    highlight-current-row
                    style="width: 100%; border: 1px solid #ebeef5"
                    :height="table_height"
                    :data="list"
                    @selection-change="changeSelect"
                >
                    <el-table-column v-if="fixed" type="selection" width="55" />
                    <el-table-column :show-overflow-tooltip="true" prop="id" width="160" align="center" label="ID" key="id">
                        <template slot-scope="scope">
                            <div class="dp-f" style="height: 60px">
                                <div style="width: 36px">
                                    <div class="sub-tag-green" v-show="scope.row.defaultFlag">官方包</div>
                                </div>
                                <span style="font-size: 14px; margin-top: 18px">{{ scope.row.id }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="name" align="center" label="渠道包名称" />
                    <el-table-column :show-overflow-tooltip="true" width="185" prop="code" align="center" label="渠道包code" />
                    <el-table-column :show-overflow-tooltip="true" width="200" prop="packageName" align="center" label="包名" />
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="description" align="center" label="渠道(ID)">
                        <template slot-scope="scope">
                            <span v-if="scope.row.channelName">{{ scope.row.channelName }}({{ scope.row.channelId }})</span>
                            <span v-else>--</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="100" align="center" label="终端" key="terminal">
                        <template>
                            <div class="terminal">
                                <div>android</div>
                                <div>h5</div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="100" align="center" label="官方包" key="defaultFlag">
                        <template slot-scope="scope">
                            <span :class="scope.row.defaultFlag ? 'txt_green' : ''">{{ scope.row.defaultFlag ? '是' : '否' }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column :show-overflow-tooltip="true" width="100" prop="state" align="center" label="启用状态" key="state">
                        <template slot-scope="scope">
                            <span :class="scope.row.state === 7 ? 'txt_green' : 'txt_red'">{{ scope.row.state === 7 ? '启用' : '禁用' }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="创建时间" key="createTime" />
                    <el-table-column :show-overflow-tooltip="true" width="155" prop="updateTime" align="center" label="修改时间" key="updateTime" />
                    <el-table-column :show-overflow-tooltip="true" width="120" prop="operator" align="center" label="操作人" key="operator" />
                    <el-table-column label="操作" width="200px" align="center" :fixed="fixed" key="op">
                        <template slot-scope="scope">
                            <el-popover v-permission="[permission.channelPackageQRcode]" placement="left-end" width="270" trigger="hover" @show="onshow(scope.row)">
                                <div class="qr-code">
                                    <VueQr v-if="scope.row.id === pId" :correct-level="3" :auto-color="false" color-dark="#000000" :text="getLink(scope.row)" :size="210" :margin="0" />
                                    <span style="margin-top: 20px">请用手机扫描二维码下载</span>
                                </div>
                                <svg-icon slot="reference" icon-class="oms_ico_code" class="opt_btn" />
                            </el-popover>

                            <el-tooltip class="item" effect="dark" content="H5推广地址" placement="top-start">
                                <svg-icon type="text" icon-class="oms_ico_h5" class="opt_btn" @click="toH5Game(scope.row)"></svg-icon>
                            </el-tooltip>

                            <el-tooltip class="item" effect="dark" content="推广包下载地址" placement="top-start">
                                <IconButton
                                    v-permission="[permission.channelPackageCopy]"
                                    v-clipboard:copy="getLink(scope.row)"
                                    v-clipboard:success="copySuccess"
                                    v-clipboard:error="copyError"
                                    class="opt_btn"
                                    size="medium"
                                    type="text"
                                    icon="oms_ico_copy"
                                />
                            </el-tooltip>
                            <el-tooltip class="item" effect="dark" content="编辑" placement="top-start">
                                <svg-icon v-permission="[permission.channelPackageEdit, permission.channelQueryPackageDetail]" icon-class="oms_ico_edit" class="opt_btn" @click="toEdit(scope.row)" />
                            </el-tooltip>
                            <el-tooltip class="item" effect="dark" content="apk下载地址" placement="top-start">
                                <svg-icon v-permission="[permission.channelPackageDowload]" icon-class="oms_ico_download" class="opt_btn" @click="toDown(scope.row)" />
                            </el-tooltip>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[50, 100, 200, 500]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
        <!-- 表单渲染 -->
        <el-dialog append-to-body :close-on-click-modal="false" :visible.sync="dialogVisible" :title="dialogTitle" width="760px" top="80px">
            <!--新增-->
            <Add v-if="dialogVisible && dialogType === 'add'" :channels="channels" @onClose="dialogCancel" @toQuery="toQuery" />
            <!--编辑-->
            <Edit v-if="dialogVisible && dialogType === 'edit'" :id="editId" @onClose="dialogCancel" @toQuery="toQuery" />
            <!--关联-->
            <Link v-if="dialogVisible && dialogType === 'link'" :channels="channels" :selectsIds="selects" @onClose="dialogCancel" @toQuery="toQuery" />
        </el-dialog>
    </div>
</template>

<script>
import Add from './add'
import Link from './link'
import Edit from './edit'
import ImagePreview from '@/components/ImagePreview'
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import InputNumber from '@/components/InputNumber'
import Base from '@/views/base'
import VueQr from 'vue-qr'
import * as api from '@/api/channel'
import FileSaver from 'file-saver'
import { setUrlQuery, urlParamBase64Encode, urlParamBase64Decode } from '@/utils/url'
import * as XLSX from 'xlsx'
import { confirmRequest, getChannelList } from '@/utils'
const defaultQuery = {
    channelId: '',
    sort: ['defaultFlag;desc', 'createTime;desc'],
    state: null,
    createTime: [],
    name: '',
    code: '',
    size: 50,
    page: 0
}

export default {
    name: 'Index',
    components: {
        VueQr,
        pagination,
        InputNumber,
        DateRangePicker,
        ImagePreview,
        Edit,
        Add,
        Link
    },
    mixins: [Base],
    data() {
        return {
            pId: '',
            fixed: 'right',
            selects: [],
            originSelect: [],
            batchType: '',
            channels: [],
            loading: false,
            list: [],
            query: defaultQuery,
            dialogType: '',
            dialogVisible: false,
            dialogTitle: '',
            editId: 0,
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 330
        this.getChannel()
        this.resetQuery()
    },
    methods: {
        onshow(row) {
            this.pId = row.id
        },
        async getChannel() {
            if (this.checkPermission([this.permission.channelPackageChannelList])) {
                this.channels = await getChannelList()
            }
        },
        getLink(row) {
            return row.landPageAddr
        },
        toH5Game(row) {
            if (!row.h5PageAddr) {
                return this.$message.warning('没有下载地址')
            } else {
                let codeEncode = urlParamBase64Encode(row.code)
                let paramsUrl = setUrlQuery(row.h5PageAddr, { g: codeEncode })
                window.open(paramsUrl)
            }
        },
        toDown(row) {
            if (!row.downAddr) {
                return this.$message.warning('没有下载地址')
            } else {
                window.open(row.downAddr)
            }
        },
        dialogCancel() {
            this.dialogVisible = false
            this.dialogTitle = ''
            this.batchType = ''
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.channelPackageList])) {
                this.loading = true
                api.packageList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toAdd() {
            this.dialogType = 'add'
            this.dialogTitle = '添加渠道包'
            this.dialogVisible = true
        },
        toEdit(row) {
            this.editId = row.id
            this.dialogType = 'edit'
            this.dialogTitle = '编辑渠道包'
            this.dialogVisible = true
        },
        exportExcel() {
            if (this.selects.length < 1) {
                return this.$message.error('请选择数据后导出')
            }
            const exportData = []
            this.list.forEach((item) => {
                if (this.selects.indexOf(item.id) !== -1) {
                    exportData.push({
                        appName: item.appName,
                        channelCode: item.code,
                        packName: item.packageName,
                        fbId: item.fbAppid,
                        fbToken: item.fbClientToken,
                        adjustAppCode: item.adjustAppCode,
                        updateHost: item.updateUrls ? item.updateUrls.join(';') : '',
                        apiHost: item.apiUrls ? item.apiUrls.join(';') : ''
                    })
                }
            })

            const header = ['appName', 'channelCode', 'packName', 'fbId', 'fbToken', 'adjustAppCode', 'updateHost', 'apiHost']
            const header_zh = {
                appName: '应用名称(app_name)',
                channelCode: '渠道包code(channel_code)',
                packName: '包名(pack_name)',
                fbId: 'fb应用id(fb_id)',
                fbToken: 'fb应用token(fb_token)',
                adjustAppCode: 'adjustAppCode(adjust_app_code)',
                updateHost: '资源域名(update_host)',
                apiHost: 'Api域名(api_host)'
            }

            this.$nextTick(() => {
                const workbook = XLSX.utils.book_new()
                const worksheet = XLSX.utils.json_to_sheet([header_zh, ...exportData], { header: header, skipHeader: true })

                XLSX.utils.book_append_sheet(workbook, worksheet, 'channel')
                XLSX.writeFile(workbook, '渠道包.xls')
            })
        },
        changeSelect(val) {
            this.originSelect = val
            this.selects = []
            val.forEach((e) => {
                this.selects.push(e.id)
            })
        },
        selectBatch() {
            if (!this.selects.length) {
                this.batchType = ''
                return this.$message.error('请先选择渠道包')
            }
            // 关联
            if (this.batchType === 'link') {
                if (this.isLinkChannel()) {
                    this.batchType = ''
                    return this.$message.error('渠道包已关联渠道不能重复关联')
                }
                // 是否选了已关联渠道的包
                this.dialogType = 'link'
                this.dialogTitle = '关联渠道'
                this.dialogVisible = true
            }
            // 启用
            if (this.batchType === 'enable') {
                const dic = {
                    state: 7,
                    ids: this.selects
                }
                confirmRequest('是否启用该渠道包？', () => {
                    api.enableDisable(dic)
                        .then((rep) => {
                            this.$message.success('操作成功')
                            this.toQuery(true)
                            this.$refs.table.clearSelection()
                            this.batchType = ''
                        })
                        .catch(() => {
                            this.batchType = ''
                        })
                })
            }
            // 禁用
            if (this.batchType === 'disable') {
                const dic = {
                    state: 0,
                    ids: this.selects
                }

                confirmRequest('禁用后该渠道包后，玩家将无法正常登录，是否确定禁用该渠道包？', () => {
                    var dic = {
                        ids: this.selects,
                        channelId: this.dialogObj.channelId
                    }
                    api.enableDisable(dic)
                        .then((rep) => {
                            this.toQuery(true)
                            this.$refs.table.clearSelection()
                            this.batchType = ''
                        })
                        .catch(() => {
                            this.batchType = ''
                        })
                })
            }
        },
        isLinkChannel() {
            var tag = false
            this.originSelect.forEach((item) => {
                if (item.channelId) {
                    tag = true
                }
            })
            return tag
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.role-span {
    font-weight: bold;
    color: #303133;
    font-size: 15px;
}
::v-deep .el-input-number .el-input__inner {
    text-align: left;
}

::v-deep .vue-treeselect__multi-value {
    margin-bottom: 0;
}

::v-deep .vue-treeselect__multi-value-item {
    border: 0;
    padding: 0;
}
.terminal {
    display: flex;
    flex-direction: column;
    align-items: center;
}
.txt_green {
    color: $green;
}
.txt_red {
    color: $red;
}
.export_button {
    background: transparent;
    border: 1px solid $blue !important;
}
.qr-code {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 17px;
    font-size: 14px;
    color: #282829;
    font-weight: 400;
    min-height: 200px;
}
.opt_btn {
    cursor: pointer;
    color: $blue;
    font-size: 20px;
    margin-right: 10px;
}
</style>
