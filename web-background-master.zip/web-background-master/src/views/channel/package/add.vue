<template>
    <div>
        <el-form ref="form" :model="dialogObj" :rules="rules" size="small" label-width="120px">
            <el-form-item label="所属渠道" prop="channelId" v-if="superOrChannelAdmin">
                <el-select v-model="dialogObj.channelId" placeholder="选择所属渠道" size="medium" style="width: 280px">
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
            </el-form-item>
            <el-form-item label="渠道包名称" prop="name">
                <el-input v-model="dialogObj.name" maxlength="12" minlength="2" placeholder="请输入2-12个字" show-word-limit style="width: 280px" clearable />
            </el-form-item>
            <el-form-item label="生成数量" prop="number">
                <InputNumber v-model="dialogObj.number" range-width="280px" placeholder="输入数量1-100个" :min-number="1" :max-number="100" clearable />
            </el-form-item>
        </el-form>

        <div slot="footer" class="dialog-footer">
            <div style="margin-left: 500px">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">确认</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import InputNumber from '@/components/InputNumber'
import Base from '@/views/base'
import * as api from '@/api/channel'

export default {
    name: 'Add',
    props: {
        channels: {
            type: Array,
            default: []
        }
    },
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            superOrChannelAdmin: false,
            dialogObj: {},
            rules: {
                name: [
                    { required: true, message: '请输入渠道包名称', trigger: 'blur', min: 2, max: 12 },
                    { pattern: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, message: '只能输入中文、字母和数字', trigger: 'blur' }
                ],
                number: [{ required: true, message: '请输入生成数量', trigger: 'blur' }],
                channelId: [{ required: true, message: '请选择所属渠道', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.superOrChannelAdmin = this.getUserInfo().superOrChannelAdmin
    },
    methods: {
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.checkPermission([this.permission.channelPackageAdd])) {
                        api.packageAdd(this.dialogObj)
                            .then((rep) => {
                                this.$message.success('添加成功')
                                this.$emit('toQuery')
                                this.dialogCancel()
                            })
                            .catch(() => {
                                this.dialogCancel()
                            })
                    }
                }
            })
        },
        dialogCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
