<template>
    <div>
        <el-form ref="form" :model="dialogObj" :rules="rules" size="small" label-width="120px" style="height: 600px; overflow: auto">
            <div class="item-title mb-10">基本配置</div>
            <el-form-item label="渠道包名称" prop="name">
                <el-input v-model="dialogObj.name" maxlength="12" minlength="2" placeholder="请输入2-12个字" show-word-limit style="width: 280px" clearable />
            </el-form-item>
            <el-form-item label="包名" prop="packageName">
                <el-input v-model="dialogObj.packageName" placeholder="com.xxx.xxx" show-word-limit style="width: 280px" clearable />
            </el-form-item>
            <el-form-item label="下载地址" prop="defaultDownAddr">
                <el-radio-group v-model="dialogObj.defaultDownAddr">
                    <el-radio :label="true">系统默认</el-radio>
                    <el-radio :label="false">自定义</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item v-if="!dialogObj.defaultDownAddr" label="" prop="downAddr" style="padding-left: 120px">
                <el-input v-model="dialogObj.downAddr" placeholder="请输入自定义下载地址" show-word-limit style="width: 280px" clearable />
            </el-form-item>
            <el-form-item label="官方包" v-exclude-channel-user>
                <el-radio-group v-model="dialogObj.defaultFlag">
                    <el-radio :label="true">是</el-radio>
                    <el-radio :label="false">否</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="启用状态">
                <el-radio-group v-model="dialogObj.state">
                    <el-radio :label="7">启用</el-radio>
                    <el-radio :label="0">禁用</el-radio>
                </el-radio-group>
            </el-form-item>

            <div class="item-title mb-10">落地页</div>
            <el-form-item prop="shareText" label="落地页背景图:">
                <UploadImage v-if="showUpload" class="upload-box" :limit="1" :fileSize="2" :existImgList="existImgList" @updateFileList="updateFileList" :width="750" :height="1334" />
            </el-form-item>
            <div class="text_blue ml-40 mt-20 fs-12">图片尺寸750*1334px，支持png、jpg、jpeg格式，大小不超过2M</div>

            <div style="display: flex; width: 100%; height: 1px; background: #f0f2f7; margin-bottom: 10px; margin-top: 10px"></div>
            <div class="item-title mb-10">Facebook授权登录开发者账号</div>
            <el-form-item label="App ID">
                <el-input v-model="dialogObj.configDto.fbAppid" placeholder="请输入AppId" style="width: 280px" clearable />
            </el-form-item>
            <el-form-item label="Client Token">
                <el-input v-model="dialogObj.configDto.fbClientToken" placeholder="请输入Client Token" style="width: 280px" clearable />
            </el-form-item>
            <div>
                <span class="text_blue fs-12 ml-40">H5授权登录：请将复制的链接地址填到Facebook开发者账号后台“有效OAuth跳转URL”一栏</span>
                <el-button class="ml-20" size="mini" type="primary" plain v-clipboard:copy="dialogObj.h5PageAddr" v-clipboard:success="copySuccess">点击复制</el-button>
            </div>

            <div class="mt-20 mb-10">
                <div class="text_blue fs-12 ml-40 mt-10">客户端授权登录：确保Facebook开发者账号后台绑定的包名一致</div>
            </div>

            <div class="item-title mb-10">Adjust</div>
            <el-form-item label="应用识别码">
                <el-input v-model="dialogObj.configDto.adjustAppCode" placeholder="请输入应用识别码" style="width: 280px" clearable />
            </el-form-item>

            <el-form-item label="充值事件">
                <el-input v-model="adjustEvents.recharge.r" placeholder="请输入事件值" style="width: 280px" clearable />
            </el-form-item>

            <div class="item-title mb-10">Firebase</div>
            <el-form-item label="firebase配置参数">
                <div class="dp-f">
                    <el-input type="textarea" rows="9" v-model="dialogObj.configDto.firebaseJson" readonly placeholder="请配置firebase参数 " style="width: 400px" clearable />

                    <div class="dp-c">
                        <el-button type="text" class="ml-10" @click="pasteFirebaseConfig">粘贴配置</el-button>
                        <el-button type="text" @click="dialogObj.configDto.firebaseJson = ''">清空配置</el-button>
                        <el-button type="text" @click="showFirebaseImg = true">查看教程</el-button>
                    </div>
                </div>
                <image-preview
                    v-if="showFirebaseImg"
                    :url-list="[firebaseImg]"
                    :on-close="
                        () => {
                            showFirebaseImg = false
                        }
                    "
                />
            </el-form-item>
        </el-form>

        <div slot="footer" class="dialog-footer">
            <div style="margin-left: 500px">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit">确认</el-button>
            </div>
        </div>
    </div>
</template>

<script>
import firebaseImg from '@/assets/images/firebase.jpg'
import ImagePreview from '@/components/ImagePreview'
import UploadImage from '@/components/UploadImage'
import Base from '@/views/base'
import { validPackageName } from '@/utils/validate'
import * as api from '@/api/channel'

const defaultObj = {
    name: '',
    packageName: '',
    number: null,
    id: null,
    state: null,
    defaultFlag: null,
    defaultDownAddr: true,
    downAddr: null,
    channelId: null,
    configDto: {
        fbAppid: '',
        fbClientToken: ''
    }
}

export default {
    name: 'Edit',
    props: {
        id: {
            type: Number,
            default: 0
        }
    },
    components: {
        ImagePreview,
        UploadImage
    },
    mixins: [Base],
    data() {
        var validPackage = (rule, value, callback) => {
            if (!validPackageName(value)) {
                return callback(new Error(rule.message))
            } else {
                callback()
            }
        }
        return {
            firebaseImg,
            showFirebaseImg: false,
            existImgList: [],
            showUpload: false,
            pId: '',
            fixed: 'right',
            selects: [],
            originSelect: [],
            batchType: '',
            channels: [],
            loading: false,
            exportStatus: false,
            list: [],
            dialogType: '',
            dialogObj: defaultObj,
            total: 0,
            dialogVisible: false,
            adjustEvents: {
                recharge: { l: 1, r: '' }
            },
            rules: {
                name: [
                    { required: true, message: '请输入渠道包名称', trigger: 'blur', min: 2, max: 12 },
                    { pattern: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, message: '只能输入中文、字母和数字', trigger: 'blur' }
                ],
                number: [{ required: true, message: '请输入生成数量', trigger: 'blur' }],
                channelId: [{ required: true, message: '请选择所属渠道', trigger: 'blur' }],
                packageName: [{ validator: validPackage, required: true, message: '请输入正确包名com.xxx.xxx,(xxx最长32位,只能为字母)', trigger: 'blur' }],
                downAddr: [{ required: true, message: '请输入自定义下载地址', trigger: 'blur', min: 1 }]
            }
        }
    },
    created() {
        this.getInfo()
    },
    methods: {
        //处理上传图片回调
        updateFileList(list) {
            this.dialogObj.configDto.landBgImg = list[0]
        },
        getInfo() {
            let params = { id: this.id }
            if (this.checkPermission([this.permission.channelQueryPackageDetail])) {
                api.queryPackageDetail(params).then((rep) => {
                    rep.data.configDto = rep.data.configDto ? rep.data.configDto : defaultObj.configDto

                    //处理adjustEvents事件
                    let adjustEventsArr = rep.data.configDto.adjustEvents
                    if (adjustEventsArr) {
                        for (let i = 0; i < adjustEventsArr.length; i++) {
                            switch (adjustEventsArr[i].l) {
                                case 1:
                                    this.adjustEvents.recharge = adjustEventsArr[i]
                                    break
                            }
                        }
                    }
                    this.dialogObj = rep.data

                    //拼装已经上传的图片
                    if (this.dialogObj.configDto.landBgImg) {
                        this.existImgList = [{ name: this.dialogObj.configDto.landBgImg, domain: rep.domain.file, url: this.dialogObj.configDto.landBgImg }]
                    }
                    this.showUpload = true
                })
            }
        },
        pasteFirebaseConfig() {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.readText().then((clipText) => {
                    this.handleFirebaseJsonConfig(clipText)
                })
            } else {
                this.$prompt('请输入配置', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    if (!value) {
                        return this.$message.error('请粘贴配置')
                    }

                    this.handleFirebaseJsonConfig(value)
                })
            }
        },
        handleFirebaseJsonConfig(clipText) {
            let searchStr = 'const firebaseConfig = {'
            let replaceStr = '({'
            if (!_.startsWith(clipText, searchStr)) {
                return this.$message.error('粘贴内容格式不正确,请参考教程')
            }

            if (!_.endsWith(clipText, ';')) {
                return this.$message.error('粘贴内容格式不正确,请参考教程')
            }
            let config = clipText

            config = _.replace(config, searchStr, replaceStr)
            config = _.replace(config, ';', ')')
            this.dialogObj.configDto.firebaseJson = config
        },
        submit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    //处理充值事件
                    let adjustEventsArr = []
                    adjustEventsArr.push(this.adjustEvents.recharge)
                    this.dialogObj.configDto.adjustEvents = adjustEventsArr
                    if (this.checkPermission([this.permission.channelPackageEdit])) {
                        api.packageEdit(this.dialogObj)
                            .then((rep) => {
                                this.$message.success('修改成功')
                                this.$emit('toQuery')
                                this.dialogCancel()
                            })
                            .catch(() => {
                                this.dialogCancel()
                            })
                    }
                }
            })
        },
        dialogCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
<style scoped lang="scss">
.item-title {
    font-family: PingFangSC-Medium;
    font-size: 16px;
    color: #282829;
    line-height: 16px;
    font-weight: 500;
}

.item-title::before {
    display: inline-block;
    content: '';
    width: 4px;
    height: 12px;
    background: #1ba2ff;
    border-radius: 3px;
    margin-right: 10px;
}
</style>
