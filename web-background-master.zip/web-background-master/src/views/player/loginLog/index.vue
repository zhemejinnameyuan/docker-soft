<template>
    <div class="player-detail-log_container">
        <div class="head-container">
            <el-select
                v-model="query.channelId"
                v-permission="[permission.playerLoginListChannelList]"
                placeholder="渠道"
                size="medium"
                class="filter-item"
                style="width: 160px"
                clearable
                @change="toQuery"
            >
                <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
            </el-select>
            <el-select v-model="query.state" placeholder="全部状态" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                <el-option label="账号登录" :value="1" />
                <el-option label="进入大厅" :value="2" />
                <el-option label="退出大厅" :value="3" />
                <el-option label="异常退出" :value="4" />
            </el-select>
            <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="170" prop="time" align="center" label="时间" />
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="渠道（ID）">
                <template slot-scope="scope">
                    <span>{{ `${scope.row.channelName} (${scope.row.channelId})` }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="160" prop="description" align="center" label="渠道包（ID）">
                <template slot-scope="scope">
                    <span>{{ `${scope.row.channelPackageName} (${scope.row.channelPackageId})` }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="170" prop="model" align="center" label="操作终端">
                <template slot-scope="scope">
                    <span>{{ `${scope.row.model} (${scope.row.terminal})` }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="210" prop="uuid" align="center" label="UUID" />
            <el-table-column :show-overflow-tooltip="true" width="120" prop="network" align="center" label="终端网络" />

            <el-table-column :show-overflow-tooltip="true" width="100" prop="description" align="center" label="状态">
                <template slot-scope="scope">
                    <span>{{ getStateTitle(scope.row.state) }}</span>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[100, 200, 500]" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/player'
import { getChannelList } from '@/utils/index'
const defaultQuery = {
    size: 100,
    page: 1,
    sort: 'time;desc',
    channelId: null,
    playerId: null,
    state: null,
    time: []
}

export default {
    components: {
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            channels: [],
            loading: false,
            list: [],
            query: defaultQuery,
            total: 0
        }
    },
    watch: {
        playerId: {
            handler(val) {
                val && this.resetQuery()
            },
            immediate: true
        }
    },
    mounted() {
        this.fixed_height = 260
        this.getChannel()
    },
    methods: {
        getStateTitle(state) {
            let title = ''
            switch (state) {
                case 1:
                    title = '账号登录'
                    break
                case 2:
                    title = '进入大厅'
                    break
                case 3:
                    title = '退出大厅'
                    break
                case 4:
                    title = '异常退出'
                    break

                default:
                    break
            }
            return title
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.query.playerId = this.playerId
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            // 权限控制
            this.loading = true
            if (this.checkPermission([this.permission.playerLoginList])) {
                api.loginLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        async getChannel() {
            if (this.checkPermission([this.permission.playerLoginListChannelList])) {
                this.channels = await getChannelList()
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail-log_container {
    width: 100%;
    padding: 40px 20px;
    .role-span {
        font-weight: bold;
        color: #303133;
        font-size: 15px;
    }
    ::v-deep .el-table .cell {
        padding: 0px 1px;
    }
}
</style>
