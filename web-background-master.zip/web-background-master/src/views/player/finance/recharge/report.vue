<template>
    <div class="report-data-box" style="width: 900px">
        <div class="item-box">
            <div class="content">
                <div class="item ml-20 mr-10">
                    <div class="dp-f">
                        <span class="item-title">累计充值</span>
                        <el-tooltip class="icon-tips" effect="dark" content="充值成功订单下单金额累计" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 110px" v-autoFontSize="'max'">{{ fenToYuan(dataObj.amountCount) | filterThousandths }}</span>
                </div>
                <div class="item ml-30 mr-20">
                    <div class="dp-f">
                        <span class="item-title-min">总充值笔数</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="充值成功订单总数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 100px" v-autoFontSize="'medium'">{{ dataObj.orderCount | filterThousandths }}</span>
                </div>

                <div class="split-line" />
                <div class="item ml-20 mr-20">
                    <div class="dp-f">
                        <span class="item-title-min">最近一次充值金额</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="最近一次充值成功的订单下单金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-one" style="width: 100px" v-autoFontSize="'medium'">{{ fenToYuan(dataObj.lastOrderAmount) | filterThousandths }}</span>
                </div>
                <div class="item ml-30 mr-20">
                    <div class="dp-f">
                        <span class="item-title-min">单笔最大金额</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="充值成功订单中下单金额最大的金额数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 100px" v-autoFontSize="'medium'">{{ fenToYuan(dataObj.maxOrderAmount) | filterThousandths }}</span>
                </div>
                <div class="item ml-30 mr-20">
                    <div class="dp-f">
                        <span class="item-title-min">单笔最低金额</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="充值成功订单中下单金额最小的金额数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-three" style="width: 100px" v-autoFontSize="'medium'">{{ fenToYuan(dataObj.minOrderAmount) | filterThousandths }}</span>
                </div>

                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 5px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                    <span class="item-title-min mt-5">&nbsp;</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData')
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>
