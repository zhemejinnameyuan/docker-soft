<template>
    <div class="report-data-box ml-20" style="flex-direction: column; margin-top: 40px">
        <BDWReport :playerId="playerId" reportType="total" />
        <PromotionReport :playerId="playerId" reportType="total" />
    </div>
</template>
<script>
import Base from '@/views/base'
import BDWReport from '@/views/player/finance/account/report/bdwReport'
import PromotionReport from '@/views/player/finance/account/report/promotionReport'
export default {
    mixins: [Base],
    components: {
        BDWReport,
        PromotionReport
    },
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        },
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        }
    }
}
</script>
