<template>
    <div class="ml-20 mt-40 tab-pane">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane label="D账户" name="accountD"></el-tab-pane>
            <el-tab-pane label="W账户" name="accountW"></el-tab-pane>
            <el-tab-pane label="B账户" name="accountB"></el-tab-pane>
            <el-tab-pane label="推广兑换账户" name="accountPromotion"></el-tab-pane>
        </el-tabs>

        <AccountD v-if="activeName == 'accountD'" :playerId="playerId" />
        <AccountW v-if="activeName == 'accountW'" :playerId="playerId" />
        <AccountB v-if="activeName == 'accountB'" :playerId="playerId" />
        <AccountPromotion v-if="activeName == 'accountPromotion'" :playerId="playerId" />
    </div>
</template>

<script>
import Base from '@/views/base'
import AccountB from './accountB.vue'
import AccountD from './accountD.vue'
import AccountW from './accountW.vue'
import AccountPromotion from './accountPromotion.vue'

export default {
    name: 'Recharge',
    components: {
        AccountPromotion,
        AccountB,
        AccountD,
        AccountW
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            activeName: 'accountD'
        }
    },
    computed: {},
    mounted() {},
    methods: {}
}
</script>
<style scoped lang="scss">
.tab-pane {
    ::v-deep .el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
        background-color: #1ba2ff !important;
        color: #ffffff !important;
        border-radius: 0px;
    }

    ::v-deep .el-tabs__nav {
        background: #f7f7f7 !important;
    }

    ::v-deep .el-tabs--card > .el-tabs__header {
        border-bottom: 0px !important;
    }

    ::v-deep .el-tabs--card > .el-tabs__header .el-tabs__item {
        text-align: center !important;
        border: 1px solid rgba(220, 223, 230, 1);
        width: 120px !important;
    }
}
</style>
