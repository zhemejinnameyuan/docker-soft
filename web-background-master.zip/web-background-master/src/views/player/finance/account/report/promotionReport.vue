<template>
    <div class="report-data-box" style="flex-direction: column; width: 920px">
        <div v-if="reportType === 'detail'" v-permission="[permission.playerReferAccountStats]" class="item-box">
            <div class="content">
                <div class="item ml-10">
                    <div class="dp-f">
                        <div class="item-title" style="width: 150px">
                            <span>推广总收益</span>
                            <i class="fs-12">(Total Cash)</i>
                        </div>
                        <el-tooltip class="icon-tips" effect="dark" content="玩家的累计推广收益，对应前端推广收益界面的“Total Cash”字段" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 160px" v-autoFontSize="'max'">{{ incomeData.referIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20 mr-10">
                    <div class="dp-f" style="width: 140px">
                        <span class="item-title-min">可兑换金额</span>
                        <el-tooltip class="icon-tips" effect="dark" content="对应前端推广收益界面的“Withdrawable”字段，可兑换金额=推广总收益-累计兑换金额-待结算金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-10" style="width: 90px" v-autoFontSize="'medium'">{{ incomeData.referWithdrawable | filterThousandths }}</span>

                    <span class="item-title-desc mt-10" style="color: #f78114">
                        待结算金额:{{ incomeData.tobeSettlement | filterThousandths }}
                        <el-tooltip class="icon-tips-min" effect="dark" content="处于待结算状态的分红奖励" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </span>
                </div>

                <div class="split-line" />
                <div class="item ml-10">
                    <div class="dp-f">
                        <span class="item-title dp-f">累计兑换</span>
                        <el-tooltip class="icon-tips" effect="dark" content="累计兑换金额=累计兑换到D账户金额+累计退款金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 110px" v-autoFontSize="'max'">
                        {{ _.add(_.toNumber(incomeData.referExchanged), _.toNumber(incomeData.referRefunded)) | filterThousandths }}
                    </span>
                </div>
                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">累计兑换到D账户</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="兑换成功的累计金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 150px" v-autoFontSize="'medium'">{{ incomeData.referExchanged | filterThousandths }}</span>
                </div>
                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">累计退款</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="累计退款=成功退款累计+处理中退款累计" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-three" style="width: 100px" v-autoFontSize="'medium'">{{ incomeData.referRefunded | filterThousandths }}</span>
                </div>
                <div class="item">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 60px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery('income')" />
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div v-if="reportType === 'detail'" v-permission="[permission.playerReferRewardStats]" class="item-box mt-10">
            <div class="content">
                <div class="item ml-10">
                    <div class="dp-f">
                        <span class="item-title">累计分享奖励</span>
                        <el-tooltip class="icon-tips" effect="dark" content="通过Facebook、WhatsApp、Invite Friends方式分享获取的奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 120px" v-autoFontSize="'max'">{{ shareData.totalShareIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title-min">分享待结算</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="处于待结算状态的分享奖励金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 110px" v-autoFontSize="'medium'">{{ shareData.todayShareIncome | filterThousandths }}</span>
                </div>
                <div class="split-line" />
                <div class="item">
                    <div class="dp-f">
                        <span class="item-title dp-f">累计首充奖励</span>
                        <el-tooltip class="icon-tips" effect="dark" content="下级用户首次充值后系统赠送给玩家的奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 110px" v-autoFontSize="'max'">{{ shareData.totalDepositedIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">首充奖励待结算</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="处于待结算状态的首充奖励金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 140px" v-autoFontSize="'medium'">{{ shareData.todayDepositedIncome | filterThousandths }}</span>
                </div>
                <div class="split-line" />
                <div class="item">
                    <div class="dp-f">
                        <span class="item-title dp-f">累计分红</span>
                        <el-tooltip class="icon-tips" effect="dark" content="下级用户下注头系统赠送给玩家的分红奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 90px" v-autoFontSize="'medium'">{{ shareData.totalDivvyIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">分红待结算</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="平台首充奖励总额，首充奖励占比=(首充奖励/推广总奖励)*100%，精确到小数点2位，四舍五入" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 100px" v-autoFontSize="'medium'">{{ shareData.todayDivvyIncome | filterThousandths }}</span>
                </div>

                <div class="item">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 30px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery('share')" />
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div v-if="reportType === 'total'" v-permission="[permission.playerReferAccountStats]" class="item-box" style="width: 900px; margin-top: 0">
            <div class="content">
                <div class="item" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title">推广总收益</span>
                        <el-tooltip class="icon-tips" effect="dark" content="玩家的累计推广收益，对应前端推广收益界面的“Total Cash”字段" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 120px" v-autoFontSize="'max'">{{ incomeData.referIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">可兑换金额</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="对应前端推广收益界面的“Withdrawable”字段，可兑换金额=推广总收益-累计兑换金额-待结算金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 120px" v-autoFontSize="'medium'">{{ incomeData.referWithdrawable | filterThousandths }}</span>
                </div>

                <div class="split-line" />
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">分享奖励</span>
                        <el-tooltip class="icon-tips" effect="dark" content="通过Facebook、WhatsApp、Invite Friends方式分享获取的奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 120px" v-autoFontSize="'medium'">{{ incomeData.referShareIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">首充奖励</span>
                        <el-tooltip class="icon-tips" effect="dark" content="下级用户首次充值后系统赠送给玩家的奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 120px" v-autoFontSize="'medium'">{{ incomeData.referDepositIncome | filterThousandths }}</span>
                </div>
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">分红奖励</span>
                        <el-tooltip class="icon-tips" effect="dark" content="下级用户下注后系统赠送给玩家的分红奖励总额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-three" style="width: 120px" v-autoFontSize="'medium'">{{ incomeData.referBetIncome | filterThousandths }}</span>
                </div>

                <div class="item">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 10px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery('all')" />
                        </span>
                    </div>
                    <span class="item-title-min mt-5">&nbsp;</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import * as api from '@/api/player'

export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        },
        reportType: {
            type: String,
            default: 'detail'
        },
        playerId: {
            type: String,
            default: '0'
        }
    },
    data() {
        return {
            shareData: {},
            incomeData: {},
            loading: false
        }
    },
    created() {
        if (this.reportType === 'detail') {
            this.getShareStatData()
            this.getIncomeStatData()
        } else {
            this.getIncomeStatData()
        }
    },
    methods: {
        //分享奖励数据
        getShareStatData() {
            if (this.checkPermission([this.permission.playerReferRewardStats])) {
                api.financeRewardStats({ playerId: this.playerId })
                    .then((rep) => {
                        this.shareData = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        //推广收益数据
        getIncomeStatData() {
            if (this.checkPermission([this.permission.playerReferAccountStats])) {
                api.referAccountStats({ playerId: this.playerId })
                    .then((rep) => {
                        this.incomeData = rep.data ? rep.data : {}
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },

        toQuery(type) {
            if (!this.loading) {
                if (type === 'share') {
                    this.getShareStatData()
                }
                if (type === 'income' || type === 'all') {
                    this.getIncomeStatData()
                }
            }

            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>
