<template>
    <div class="report-data-box" style="flex-direction: column; width: 900px">
        <div :class="reportType === 'total' ? 'dp-f mb-20' : 'dp-f'" v-if="['dw', 'total'].indexOf(reportType) !== -1" v-permission="[permission.playerFinancialOverviewStats]">
            <div class="text-item dp-c" style="width: 293px">
                <span class="text-item-title">Total Cash</span>
                <span class="text-item-number mt-20">{{ statData.totalCash | filterThousandths }}</span>
            </div>
            <div class="text-item dp-f ml-10" style="width: 293px">
                <div class="chart-item-left dp-c">
                    <span class="text-item-title">Deposited</span>
                    <span class="text-item-number mt-10">{{ statData.deposited | filterThousandths }}</span>
                    <span class="text-item-desc mt-10">{{ getPercentage(statData.deposited, statData.totalCash) }}</span>
                </div>
            </div>
            <div class="text-item dp-f ml-10" style="width: 293px">
                <div class="chart-item-left dp-c" style="width: 263px">
                    <span class="text-item-title">Winnings</span>
                    <span class="text-item-number mt-10">{{ statData.winnings | filterThousandths }}</span>
                    <span class="text-item-desc mt-10">{{ getPercentage(statData.winnings, statData.totalCash) }}</span>
                </div>
                <div>
                    <div class="dp-f">
                        <span class="item-title" style="margin-right: 18px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery('all')" />
                        </span>
                    </div>
                    <span class="item-title-min mt-5">&nbsp;</span>
                </div>
            </div>
        </div>

        <div
            :class="reportType === 'total' ? 'item-box mb-10' : 'item-box'"
            style="width: 900px"
            v-if="['b', 'total'].indexOf(reportType) !== -1"
            v-permission="[permission.playerFinancialOverviewStats]"
        >
            <div class="content">
                <div class="item" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title">Bonus</span>
                        <el-tooltip effect="dark" class="icon-tips" content="玩家当前Bonus账户余额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 120px" v-autoFontSize="'max'">{{ statData.bonus | filterThousandths }}</span>
                </div>
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">当前可兑换金额</span>
                        <el-tooltip effect="dark" class="icon-tips" content="当前玩家可以兑换到D账户的Bonus金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 120px" v-autoFontSize="'medium'">{{ statData.bonusConvertible | filterThousandths }}</span>
                </div>

                <div class="split-line" />
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">最近一次获取金额</span>
                        <el-tooltip effect="dark" class="icon-tips-min" content="指最近一次玩家获取的Bonus金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20" style="width: 120px" v-autoFontSize="'medium'">{{ statData.lastGetAmount | filterThousandths }}</span>
                </div>
                <div class="item ml-20" style="width: 150px">
                    <div class="dp-f">
                        <span class="item-title-min">最近一次兑换金额</span>
                        <el-tooltip effect="dark" class="icon-tips-min" content="指最近一次从Bonus兑换到D账户的Bonus金额" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 120px" v-autoFontSize="'medium'">{{ statData.lastExchangeAmount | filterThousandths }}</span>
                </div>

                <div class="item">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 150px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                    <span class="item-title-min mt-5">&nbsp;</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import * as api from '@/api/player'

export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        },
        reportType: {
            type: String,
            default: 'detail'
        },
        playerId: {
            type: String,
            default: '0'
        }
    },
    data() {
        return {
            chartObj: {},
            statData: {},
            loading: false
        }
    },
    created() {
        this.getStatData()
    },
    mounted() {},
    methods: {
        toQuery() {
            if (!this.loading) {
                this.getStatData()
            }

            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        },
        //获取数据
        getStatData() {
            if (this.checkPermission([this.permission.playerFinancialOverviewStats])) {
                api.financialOverviewStats({ playerId: this.playerId })
                    .then((rep) => {
                        this.statData = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.text-item {
    height: 130px;
    background: #f4f8fe;
    border-radius: 6px;
    padding: 30px 0 0 30px;

    .text-item-title {
        font-family: PingFangSC-Medium;
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        line-height: 16px;
        font-weight: 500;
    }
    .text-item-number {
        font-family: PingFangSC-Medium;
        font-size: 24px;
        color: #f78114;
        letter-spacing: 0;
        line-height: 24px;
        font-weight: 500;
    }
    .text-item-desc {
        font-family: PingFangSC-Regular;
        font-size: 12px;
        color: #686b6d;
        letter-spacing: 0;
        line-height: 12px;
        font-weight: 400;
    }
}
</style>
