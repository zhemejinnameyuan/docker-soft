<template>
    <div class="game-config-box dp-f">
        <el-menu :default-active="type" class="menu" @select="handleSelect">
            <el-menu-item index="cwgl">
                <span slot="title">财务概览</span>
            </el-menu-item>
            <el-menu-item index="zjzhmx" v-permission="[permission.playerAccountDetailList]">
                <span slot="title">资金账户明细</span>
            </el-menu-item>
            <el-menu-item index="tgjlmx" v-permission="[permission.playerReferRewardLog]">
                <span slot="title">推广奖励明细</span>
            </el-menu-item>
            <el-menu-item index="czjl" v-permission="[permission.appRechargeOrderList]">
                <span slot="title">充值记录</span>
            </el-menu-item>
            <el-menu-item index="tgjl" v-permission="[permission.appWithdrawOrderList]">
                <span slot="title">退款记录</span>
            </el-menu-item>
        </el-menu>
        <div class="content finance">
            <Overview v-if="type === 'cwgl'" :playerId="playerId" />
            <Account v-if="type === 'zjzhmx'" :playerId="playerId" />
            <PromotionAward v-if="type === 'tgjlmx'" :playerId="playerId" />
            <Recharge v-if="type === 'czjl'" :playerId="playerId" />
            <Refund v-if="type === 'tgjl'" :playerId="playerId" />
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import Overview from './overview/index'
import Account from './account/index'
import PromotionAward from './promotionAward/index'
import Recharge from './recharge/index'
import Refund from './refund/index'

export default {
    components: {
        Overview,
        Account,
        PromotionAward,
        Recharge,
        Refund
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            type: 'cwgl'
        }
    },
    mounted() {},

    methods: {
        handleSelect(type) {
            this.type = type
        }
    }
}
</script>
