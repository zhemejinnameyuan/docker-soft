<template>
    <div class="ml-20 mt-40" style="width: 980px">
        <PromotionReport :playerId="playerId" reportType="detail" />
        <!--搜索栏-->
        <div class="head-container tab-pane">
            <el-tabs v-model="rewardType" type="card" @tab-click="changeRewardType">
                <el-tab-pane v-for="(item, index) in PROMOTION_REWARD_TYPE" :key="index" :label="item" :name="index"></el-tab-pane>
            </el-tabs>
            <el-row>
                <DateRangePicker v-model="query.time" class="filter-item" @change="toQuery" style="width: 250px" />
                <el-input v-model="query.accountDetailsId" size="medium" clearable placeholder="推广收益账户资金流水" style="width: 200px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 940px" :height="table_height" :data="list">
                    <el-table-column prop="createTime" width="160" align="center" label="时间" />
                    <el-table-column prop="accountDetailsId" width="250" align="center" label="推广收益账户资金流水" />
                    <el-table-column prop="rewardType" width="150" align="center" label="奖励类型">
                        <template slot-scope="scope">
                            {{ getArrayValue(PROMOTION_REWARD_TYPE, scope.row.rewardType) }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="incomeStr" width="150" align="center" label="奖励金额" />
                    <el-table-column prop="state" width="100" align="center" label="状态" />
                    <el-table-column prop="title" width="100" align="center" label="操作">
                        <template slot-scope="scope">
                            <el-button type="text" class="text_underline" size="medium" @click="viewRecord(scope.row)">查看明细</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="viewRecordVisible" title="奖励明细">
            <Record v-if="viewRecordVisible" :recordId="recordId" :rewardType="rewardType" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/player'
import PromotionReport from '@/views/player/finance/account/report/promotionReport.vue'
import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import Record from './record.vue'
import UserIdJump from '@/components/UserIdJump'
import { PROMOTION_REWARD_TYPE } from '@/constant/finance'

const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'time;desc',
    playerId: '',
    accountDetailsId: '',
    rewardType: '',
    time: []
}

export default {
    name: 'PromotionAward',
    components: {
        UserIdJump,
        pagination,
        DateRangePicker,
        PromotionReport,
        Drawer,
        Record
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            PROMOTION_REWARD_TYPE,
            loading: false,
            viewRecordVisible: false,
            recordId: 0,
            list: [],
            rewardType: '100',
            query: {
                size: 20,
                page: 1,
                sort: 'time;desc',
                playerId: '',
                accountDetailsId: '',
                rewardType: '',
                time: []
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 580
        // this.query.time.push(this.$moment().subtract(7, 'days').format('YYYY-MM-DD 00:00:00'))
        // this.query.time.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        changeRewardType() {
            this.toQuery()
        },
        //记录
        viewRecord(row) {
            this.recordId = row.id
            this.viewRecordVisible = true
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toQuery(page) {
            this.query.rewardType = this.rewardType
            this.query.playerId = this.playerId
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.playerReferRewardLog])) {
                this.loading = true
                api.financeRewardRecord(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
<style scoped lang="scss">
.tab-pane {
    ::v-deep .el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
        background-color: #1ba2ff !important;
        color: #ffffff !important;
        border-radius: 0px;
    }

    ::v-deep .el-tabs__nav {
        background: #f7f7f7 !important;
    }

    ::v-deep .el-tabs--card > .el-tabs__header {
        border-bottom: 0px !important;
    }

    ::v-deep .el-tabs--card > .el-tabs__header .el-tabs__item {
        text-align: center !important;
        border: 1px solid rgba(220, 223, 230, 1);
        width: 120px !important;
    }
}
</style>
