<template>
    <div class="ml-20 mt-40" style="width: 980px">
        <Report :data-obj="statData" @queryData="queryData" v-permission="[permission.appWithdrawUserOrderStatistics]" />
        <!--搜索栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" style="width: 250px" />
                <el-input v-model="query.recordId" size="medium" clearable placeholder="记录ID" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.orderId" size="medium" clearable placeholder="平台订单号" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.channelOrderId" size="medium" clearable placeholder="通道订单号" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-model="query.orderState" placeholder="平台状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in REFUND_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <el-select v-model="query.channelOrderState" placeholder="通道状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option v-for="(item, index) in REFUND_CHANNEL_ORDER_STATE" :key="index" :value="index" :label="item" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table
                    ref="table"
                    v-loading="loading"
                    highlight-current-row
                    style="width: 940px"
                    :height="table_height"
                    :data="list"
                    :row-style="{ height: '60px' }"
                    @selection-change="changeSelect"
                >
                    <el-table-column prop="recordId" :show-overflow-tooltip="true" width="120" align="center" label="记录ID">
                        <template slot-scope="scope">
                            <div class="dp-f" style="height: 60px">
                                <div style="width: 36px">
                                    <div class="order-to-error" v-show="scope.row.orderState == 3">置失败</div>
                                </div>
                                <span style="font-size: 14px; margin-top: 18px">{{ scope.row.recordId }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="createTime" width="155" align="center" label="时间" />
                    <el-table-column :show-overflow-tooltip="true" prop="orderId" width="250" align="center" label="平台订单号">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.orderId" v-clipboard:success="copySuccess" v-clipboard:error="copyError">{{ scope.row.orderId }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelOrderId" width="210" align="center" label="通道订单号">
                        <template slot-scope="scope">
                            <span v-clipboard:copy="scope.row.channelOrderId" v-clipboard:success="copySuccess" v-clipboard:error="copyError">
                                {{ scope.row.channelOrderId ? scope.row.channelOrderId : '-' }}
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="refundType" width="120" align="center" label="退款账户">
                        <template slot-scope="scope">
                            <span>{{ getArrayValue(REFUND_ACCOUNT_TYPE, scope.row.refundType) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="productAmount" width="110" align="center" label="下单金额">
                        <template slot-scope="scope">{{ fenToYuan(scope.row.productAmount) | filterThousandths }}</template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="actualAmount" width="110" align="center" label="实际到账金额">
                        <template slot-scope="scope">
                            {{ scope.row.actualAmount ? fenToYuan(scope.row.actualAmount) : '-' | filterThousandths }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="orderState" width="80" align="center" label="平台状态">
                        <template slot-scope="scope">
                            <span :class="`refund-order-state-` + scope.row.orderState">{{ getArrayValue(REFUND_ORDER_STATE, scope.row.orderState) }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelOrderState" width="80" align="center" label="通道状态">
                        <template slot-scope="scope">
                            <span v-if="scope.row.channelOrderState != 0" :class="`refund-channel-order-state-` + scope.row.channelOrderState">
                                {{ getArrayValue(REFUND_CHANNEL_ORDER_STATE, scope.row.channelOrderState) }}
                            </span>
                            <span v-if="scope.row.channelOrderState == 0">--</span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="exceptionContent" width="160" align="center" label="异常状态">
                        <template slot-scope="scope">
                            <span v-if="scope.row.exceptionLabel">
                                {{ scope.row.exceptionContent }}
                            </span>
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" width="80" prop="createTime" align="center" label="操作" fixed="right">
                        <template slot-scope="scope">
                            <IconButton
                                class="filter-item"
                                size="medium"
                                type="text"
                                style="font-size: 20px"
                                icon="oms_ico_xiangqing"
                                @click="toDetail(scope.row)"
                                v-permission="[permission.appWithdrawOrderDetail]"
                            />
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="drawer">
            <Detail :data-info="dataObj" v-if="drawer" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/finance/refund'
import * as playerApi from '@/api/player'
import Report from './report.vue'
import Detail from '@/views/finance/refund/record/detail.vue'

import Base from '@/views/base'
import Drawer from '@/components/Drawer'
import { REFUND_ACCOUNT_TYPE, REFUND_CHANNEL_ORDER_STATE, REFUND_ORDER_STATE } from '@/constant/finance'
import { confirmRequest } from '@/utils'
const defaultQuery = {
    size: 10,
    page: 1,
    sort: 'id;desc',
    recordId: '',
    playerId: '',
    orderId: '',
    channelOrderId: '',
    orderState: '',
    channelOrderState: '',
    createTime: []
}

export default {
    name: 'RechargeRecord',
    components: {
        Drawer,
        Detail,
        pagination,
        DateRangePicker,
        Report
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            REFUND_ORDER_STATE,
            REFUND_CHANNEL_ORDER_STATE,
            REFUND_ACCOUNT_TYPE,
            loading: false,
            drawer: false,
            batchChangeStateIds: {
                pass: [],
                reject: [],
                fail: [],
                tryAgain: [],
                exception: [],
                obsolete: []
            },
            dataObj: {},
            dialogVisible: false,
            dialogTitle: '',
            dialogType: '',
            submitRemarkType: '',
            submitRemarkId: [],
            rejectRecordDataInfo: {},
            list: [],
            statData: {},
            query: {
                size: 10,
                page: 1,
                sort: 'id;desc',
                recordId: '',
                playerId: '',
                orderId: '',
                channelOrderId: '',
                orderState: '',
                channelOrderState: '',
                createTime: []
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 450
        // this.query.createTime.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        // this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
        this.queryData()
    },
    methods: {
        //需要输入备注再执行请求操作
        submitRemark(remark) {
            let params = {}
            switch (this.submitRemarkType) {
                case 'toFail':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: this.getUserInfo().username + `[置失败]` + remark
                    }
                    if (remark.length < 10 || remark.length > 500) {
                        return this.$message.error('请输入原因，长度在10-500字符之间')
                    }
                    api.setFail(params).then((rep) => {
                        this.$message.success('置失败操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
                case 'toReject':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: this.getUserInfo().username + `[驳回]` + remark
                    }
                    api.batchReject(params).then((rep) => {
                        this.$message.success('驳回操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
                case 'toObsolete':
                    params = {
                        orderIdList: this.submitRemarkId,
                        remark: this.getUserInfo().username + `[加入废弃]` + remark
                    }
                    api.obsolete(params).then((rep) => {
                        this.$message.success('加入废弃操作成功')
                        this.dialogVisible = false
                        this.toQuery()
                    })
                    break
            }
        },
        toSuccess(type, id = '') {
            let params = {}
            if (type == 'single') {
                params = {
                    orderIdList: [id],
                    remark: this.getUserInfo().username + '后台通过'
                }
            } else if (type == 'batch') {
                params = {
                    orderIdList: this.batchChangeStateIds.pass,
                    remark: this.getUserInfo().username + '后台通过'
                }
            }
            confirmRequest('确定要通过吗?', () => {
                api.batchPass(params).then((rep) => {
                    this.$message.success('操作成功')
                    this.toQuery()
                })
            })
        },
        toReject(type, id = '') {
            this.submitRemarkType = 'toReject'
            if (type == 'single') {
                this.submitRemarkId = [id]
            } else if (type == 'batch') {
                this.submitRemarkId = this.batchChangeStateIds.reject
            } else {
                this.submitRemarkId = []
            }

            this.dialogTitle = '请输入驳回原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        rejectRecord(row) {
            this.dialogTitle = '驳回记录'
            this.dialogType = 'rejectRecord'
            this.dialogVisible = true

            this.rejectRecordDataInfo = row
        },
        toFail(type, id = '') {
            if (type == 'single') {
                this.submitRemarkId = [id]
            } else if (type == 'batch') {
                this.submitRemarkId = this.batchChangeStateIds.fail
            } else {
                this.submitRemarkId = []
            }
            this.submitRemarkType = 'toFail'
            this.dialogTitle = '请输入置失败原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        toTryAgain(type, id = '') {
            let params = {}
            if (type == 'single') {
                params = {
                    orderIdList: [id],
                    remark: this.getUserInfo().username + '后台重新请求'
                }
            } else if (type == 'batch') {
                params = {
                    orderIdList: this.batchChangeStateIds.tryAgain,
                    remark: this.getUserInfo().username + '后台重新请求'
                }
            }
            confirmRequest('重新向通道发起退款请求，通道会重新执行退款逻辑并返回新的退款状态…？', () => {
                api.requestAgain(params).then((rep) => {
                    this.$message.success('操作成功')
                    this.toQuery()
                })
            })
        },
        toObsolete(type, id = '') {
            if (type == 'single') {
                this.submitRemarkId = [id]
            } else if (type == 'batch') {
                this.submitRemarkId = this.batchChangeStateIds.obsolete
            } else {
                this.submitRemarkId = []
            }

            this.submitRemarkType = 'toObsolete'
            this.dialogTitle = '请输入加入废弃原因'
            this.dialogType = 'toReject'
            this.dialogVisible = true
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.toQuery()
        },
        toDetail(row) {
            this.drawer = true
            this.dataObj = row
        },
        toQuery(page) {
            this.query.playerId = this.playerId
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.playerWithdrawRecordList])) {
                this.loading = true
                playerApi
                    .withdrawList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        //数据统计
        queryData() {
            if (this.checkPermission([this.permission.appWithdrawUserOrderStatistics])) {
                playerApi
                    .userWithdrawOrderStatistics({ playerId: this.playerId })
                    .then((rep) => {
                        this.statData = rep.data
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        changeSelect(val) {
            //初始化
            this.batchChangeStateIds = {
                pass: [],
                reject: [],
                fail: [],
                tryAgain: [],
                obsolete: []
            }
            val.forEach((e) => {
                if (e.channelOrderState == 0 && e.orderState == 0) {
                    this.batchChangeStateIds.pass.push(e.orderId)
                    this.batchChangeStateIds.reject.push(e.orderId)
                    this.batchChangeStateIds.obsolete.push(e.orderId)
                }
                if (e.channelOrderState == 1 && e.orderState == 1) {
                    this.batchChangeStateIds.fail.push(e.orderId)
                }
                if (e.channelOrderState == 0 && e.orderState == 6) {
                    this.batchChangeStateIds.tryAgain.push(e.orderId)
                }
            })
        },
        dialogCancel() {
            this.dialogVisible = false
        }
    }
}
</script>

<style lang="scss" scoped>
//处理记录ID标签
::v-deep .el-table tbody tr {
    td:nth-child(2) .cell {
        padding-left: 0px;
    }
}
::v-deep .el-table .el-table__body-wrapper .el-table__row {
    padding: 0;
}
::v-deep .el-table tbody .el-table__cell {
    padding-top: 0px;
    padding-bottom: 0px;
}
</style>
