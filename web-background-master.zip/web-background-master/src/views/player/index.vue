<template>
    <div class="web-container" style="background: #f7f7f7">
        <div class="container_title">玩家详情</div>
        <el-button class="go-home" @click="toHome">
            <svg-icon icon-class="oms_tab_ico_kongzhitai" style="width: 19px; height: 19px" />
            <span class="go-home-text">回到后台主页</span>
        </el-button>
        <div class="player-detail">
            <div v-permission="[permission.playerDetail]" class="info no-scrollbar">
                <div class="info_card">
                    <div class="info_card_bg">
                        <div class="content">
                            <img class="avater" :src="getAvatar(domain, userInfo)" />
                            <div class="dp_c" style="margin-left: 12px">
                                <span class="name">{{ userInfo.nickname | filterEmpty }}</span>
                                <span class="user_id">ID:{{ userInfo.id | filterEmpty }}</span>
                            </div>
                        </div>
                        <div class="invitation">邀请码：{{ userInfo.code | filterEmpty }}</div>
                        <img class="state_tag" :src="getTag()" />
                    </div>
                </div>
                <div class="info_card_bottom" />
                <el-row v-permission="[permission.appBlacklistBatchAdd, permission.appBlacklistBatchDelByPlayerIds, permission.appBlacklistQueryPlayerBlackState]" style="margin-top: 30px">
                    <el-button type="danger" size="small" style="width: 280px; margin-left: 20px" @click="toAddBlack()">处罚</el-button>
                </el-row>

                <div class="dp-c" style="margin-top: 20px">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">账号状态</div>
                    </div>
                    <div class="line" />
                    <div class="dp-f ml-20 mb-10">
                        <div style="width: 50%">
                            <span class="text_sub">账号状态：</span>
                            <span :class="userInfo.blockFlag ? 'fs-14 text_red' : ' fs-14 text_green'">{{ userInfo.blockFlag ? '封禁' : '正常' }}</span>
                        </div>
                        <div style="width: 50%">
                            <span class="text_sub">刷子状态：</span>
                            <span :class="userInfo.brushState ? 'fs-14 text_red' : ' fs-14 text_green'">{{ userInfo.brushState ? '刷子' : '正常' }}</span>
                        </div>
                    </div>
                    <div class="dp-f ml-20">
                        <div style="width: 50%">
                            <span class="text_sub">推广状态：</span>
                            <span v-if="userInfo.referState === 0">--</span>
                            <span v-if="userInfo.referState !== 0" :class="userInfo.referState === 2 ? 'fs-14 text_red' : ' fs-14 text_green'">{{ userInfo.referState === 2 ? '禁用' : '正常' }}</span>
                        </div>
                        <div style="width: 50%">
                            <span class="text_sub">退款状态：</span>
                            <span :class="userInfo.withdrawBlock ? 'fs-14 text_red' : ' fs-14 text_green'">{{ userInfo.withdrawBlock ? '封禁' : '正常' }}</span>
                        </div>
                    </div>

                    <div class="dp-f ml-20" v-permission="[permission.appBlacklistQueryPlayerBlackState]">
                        <a class="mt-20 fs-14 text_blue" @click="viewBlackInfo">点击显示账号异常信息>></a>
                    </div>
                </div>

                <div class="dp-c mt-30">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">近期动态</div>
                    </div>
                    <div class="line" />
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">最近一次充值：</span>
                        <span class="text_des">{{ userInfo.lastRechargeTime | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">最近一次游戏：</span>
                        <span class="text_des">{{ userInfo.lastGameTime | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px">
                        <span class="text_sub">最近一次退款：</span>
                        <span class="text_des">{{ userInfo.lastWithdrawTime | filterEmpty }}</span>
                    </div>
                </div>

                <div class="dp-c mt-30">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">启动日志</div>
                    </div>
                    <div class="line" />
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">最近一次启动时间：</span>
                        <span class="text_des">{{ userInfo.lastLaunchTime | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">登录IP：</span>
                        <span class="text_des">{{ userInfo.lastLaunchIp | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">大厅版本：</span>
                        <span class="text_des">{{ userInfo.lastLaunchVersion | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">终端网络：</span>
                        <span class="text_des">{{ userInfo.lastLaunchNetwork | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">设备型号：</span>
                        <span class="text_des">{{ userInfo.lastLaunchModel | filterEmpty }}</span>
                    </div>
                    <div style="margin-left: 20px">
                        <span class="text_sub">操作系统：</span>
                        <span class="text_des">{{ userInfo.lastLaunchOs | filterEmpty }}</span>
                    </div>
                </div>

                <div class="dp-c mt-30">
                    <div class="dp-f" style="align-items: flex-end">
                        <div class="tag" />
                        <div class="text_main">渠道信息</div>
                    </div>
                    <div class="line" />
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">渠道：</span>
                        <span class="text_des">{{ userInfo.channelName | filterEmpty }}({{ userInfo.channelId | filterEmpty }})</span>
                    </div>
                    <div style="margin-left: 20px; margin-bottom: 10px">
                        <span class="text_sub">渠道包：</span>
                        <span class="text_des">{{ userInfo.channelPackageName | filterEmpty }}({{ userInfo.channelPackageId | filterEmpty }})</span>
                    </div>
                </div>
            </div>
            <div class="dp-c">
                <div class="game_tab">
                    <div v-permission="[permission.playerDetail]" :class="type === 'userInfo' ? 'game_tab_item_active' : 'game_tab_item'" @click="changeTab('userInfo')" style="width: 140px">
                        概要信息
                    </div>
                    <div v-permission="[permission.playerLoginList]" :class="type === 'login' ? 'game_tab_item_active' : 'game_tab_item'" @click="changeTab('login')" style="width: 140px">
                        登录日志
                    </div>
                    <div v-permission="[permission.playerGameList]" :class="type === 'game' ? 'game_tab_item_active' : 'game_tab_item'" @click="changeTab('game')" style="width: 140px">牌局日志</div>
                    <div
                        v-permission="[permission.playerAccountDetailList, permission.playerReferRewardLog, permission.appRechargeOrderList, permission.appWithdrawOrderList]"
                        :class="type === 'finance' ? 'game_tab_item_active' : 'game_tab_item'"
                        @click="changeTab('finance')"
                        style="width: 140px"
                    >
                        财务管理
                    </div>
                    <div
                        v-permission="[permission.playerReferAccountBelows]"
                        :class="type === 'promotion' ? 'game_tab_item_active' : 'game_tab_item'"
                        @click="changeTab('promotion')"
                        style="width: 140px"
                    >
                        推广记录
                    </div>
                    <div v-permission="[permission.playerAccountBlock]" :class="type === 'block' ? 'game_tab_item_active' : 'game_tab_item'" @click="changeTab('block')" style="width: 140px">
                        违规处罚
                    </div>
                </div>
                <div class="player-detail_content" style="width: 1160px">
                    <UserInfo v-if="type === 'userInfo'" :user-info="userInfo" />
                    <LoginLog v-if="type === 'login'" :player-id="playerId" />
                    <GameLog v-if="type === 'game'" :player-id="playerId" />
                    <Finance v-if="type === 'finance'" :player-id="playerId" />
                    <PromotionLog v-if="type === 'promotion'" :player-id="playerId" />
                    <BlockLog v-if="type === 'block'" :player-id="playerId" />
                </div>
            </div>
        </div>

        <!--异常信息-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="exceptionDialogVisible" title="异常信息" width="680px">
            <BlackInfo v-if="exceptionDialogVisible" @onclose="dialogCancel" :dataInfo="dialogObj" :source="'userInfo'" />
        </el-dialog>

        <!--封禁-->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" title="处罚" width="680px">
            <AddBlack v-if="dialogVisible" @onclose="dialogCancel" :dataInfo="dialogObj" @queryData="toQuery" />
        </el-dialog>
    </div>
</template>

<script>
import UserInfo from './userInfo/index'
import LoginLog from './loginLog/index'
import GameLog from './gameLog/index.vue'
import Finance from './finance/index.vue'
import PromotionLog from './promotionLog/index.vue'
import BlockLog from './blockLog/index.vue'
import Base from '@/views/base'
import * as api from '@/api/player'
import { BLACKLIST_TYPE } from '@/constant/common'
import BlackInfo from '@/views/member/userList/blackInfo'
import AddBlack from '@/views/member/userList/addBlack'

export default {
    name: 'Player',
    components: {
        UserInfo,
        LoginLog,
        GameLog,
        Finance,
        PromotionLog,
        BlockLog,
        BlackInfo,
        AddBlack
    },
    mixins: [Base],
    data() {
        return {
            BLACKLIST_TYPE,
            youke: require('@/assets/images/oms_lab_youke.png'),
            zhuce: require('@/assets/images/oms_lab_zhuce.png'),
            playerId: null,
            userInfo: {},
            exceptionDialogVisible: false,
            dialogVisible: false,
            dialogObj: {},
            type: '',
            domain: ''
        }
    },
    mounted() {
        this.playerId = this.$route.query.id
        if (this.checkPermission([this.permission.playerDetail])) {
            this.type = 'userInfo'
            this.toQuery()
        } else if (this.checkPermission([this.permission.playerGameList])) {
            this.type = 'login'
        } else if (this.checkPermission([this.permission.playerLoginList])) {
            this.type = 'game'
        }
    },
    methods: {
        changeTab(type) {
            this.type = type
        },
        toQuery() {
            api.detail({ playerId: this.playerId })
                .then((rep) => {
                    this.userInfo = rep.data
                    this.domain = rep.domain.file
                })
                .catch(() => {})
        },
        getTag() {
            if (this.userInfo.type) {
                return this.zhuce
            }
            return this.youke
        },
        //查看异常信息
        viewBlackInfo() {
            this.dialogObj = { id: this.userInfo.id }
            this.exceptionDialogVisible = true
        },
        //处罚
        toAddBlack() {
            this.dialogObj = { id: this.userInfo.id }
            this.dialogVisible = true
        },

        dialogCancel() {
            this.exceptionDialogVisible = false
            this.dialogVisible = false
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: row;
    justify-content: center;
    .info {
        width: 320px;
        min-width: 320px;
        height: calc(100vh - 80px);
        overflow-y: scroll;
        background: #ffffff;
        border-left: 1px solid rgba(220, 223, 230, 1);
        border-top: 1px solid rgba(220, 223, 230, 1);
        border-right: 1px solid rgba(220, 223, 230, 1);
        border-radius: 8px 8px 0px 0px;
        margin-right: 20px;
        padding: 40px 0px;
        &_card {
            height: 119px;
            overflow: hidden;
            &_bg {
                position: relative;
                width: 280px;
                height: 129px;
                background: #e2f4ff;
                border: 1px solid rgba(105, 203, 241, 1);
                box-shadow: inset 0px 0px 8px 0px rgba(54, 137, 255, 1);
                margin-left: 20px;
                border-radius: 5px;
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .content {
                display: flex;
                flex: 1;
                align-items: center;
                padding: 0px 10px;
                .avater {
                    width: 45px;
                    height: 45px;
                    border-radius: 50%;
                }
                .name {
                    display: flex;
                    font-size: 16px;
                    color: #282829;
                    letter-spacing: 0.89px;
                    font-weight: 500;
                    margin-bottom: 8px;
                }
                .user_id {
                    display: flex;
                    font-size: 14px;
                    color: #686b6d;
                    letter-spacing: 0.78px;
                    font-weight: 400;
                }
            }
            .invitation {
                display: flex;
                justify-content: center;
                align-items: center;
                padding-bottom: 10px;
                width: 100%;
                height: 38px;
                background: rgba(27, 162, 255, 0.15);
                font-size: 14px;
                color: #1ba2ff;
                letter-spacing: 0.88px;
                font-weight: 500;
            }
            .state_tag {
                position: absolute;
                right: 0px;
                top: 0px;
                width: 48px;
                height: 48px;
            }
        }
        &_crad_bottom {
            margin-top: -6px;
            width: 100%;
            box-shadow: inset 0px -6px 6px -6px #bbbbbb;
            height: 6px;
            z-index: 1;
            position: relative;
        }
        .text_main {
            font-size: 16px;
            color: #282829;
            letter-spacing: 0.89px;
            font-weight: 500;
        }
        .text_sub {
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0;
            font-weight: 400;
        }
        .text_des {
            font-size: 14px;
            color: #282829;
            letter-spacing: 0;
            font-weight: 400;
        }
        .tag {
            width: 16px;
            height: 4px;
            margin-right: 4px;
            background: linear-gradient(-135deg, transparent 3px, #1ba2ff 0) bottom left;
        }
        .line {
            width: 100px;
            height: 1px;
            background-color: #1ba2ff;
            margin-top: 2px;
            margin-bottom: 20px;
        }
    }
    .player-detail_content {
        width: 1060px;
        display: flex;
        height: calc(100vh - 50px - 80px);
        background: #ffffff;
        box-shadow: 0px -6px 10px 0px rgba(0, 0, 0, 0.1);
        border-radius: 4px;
    }
}
</style>
