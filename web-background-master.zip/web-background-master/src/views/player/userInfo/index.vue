<template>
    <div class="player-detail-user_container no-scrollbar">
        <div class="title">基本信息</div>
        <div class="item_bg">
            <div class="item">
                <div>
                    <span class="text_sub">昵称：</span>
                    <span class="text_des">{{ userInfo.nickname | filterEmpty }}</span>
                </div>
                <div>
                    <span class="text_sub">创建IP：</span>
                    <span class="text_des">{{ userInfo.ip | filterEmpty }}</span>
                </div>
                <div>
                    <span class="text_sub">注册IP：</span>
                    <span class="text_des">{{ userInfo.registerIp | filterEmpty }}</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">ID：</span>
                    <span class="text_des">{{ userInfo.id | filterEmpty }}</span>
                </div>
                <div class="dp-f">
                    <span class="text_sub">创建终端：</span>
                    <div class="text_des">
                        <TextHidden :value="filterEmpty(userInfo.network) + ' | ' + filterEmpty(userInfo.model)" style="width: 210px" />
                    </div>
                </div>
                <div class="dp-f">
                    <span class="text_sub">注册终端：</span>
                    <div class="text_des">
                        <TextHidden :value="filterEmpty(userInfo.registerNetwork) + ' | ' + filterEmpty(userInfo.registerModel)" style="width: 210px" />
                    </div>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">创建时间：</span>
                    <span class="text_des">{{ userInfo.createTime | filterEmpty }}</span>
                </div>
                <div>
                    <span class="text_sub">Facebook账号：</span>
                    <span class="text_des" v-if="userInfo.fbId === null && userInfo.fbName === null">未绑定</span>
                    <span class="text_des" v-else>{{ userInfo.fbId }}、{{ userInfo.fbName }}({{ userInfo.fbBindTime }})</span>
                </div>
                <div>
                    <span class="text_sub">注册时间：</span>
                    <span class="text_des">{{ userInfo.registerTime | filterEmpty }}</span>
                </div>
            </div>
        </div>

        <div class="title">渠道信息</div>
        <div class="item_bg">
            <div class="item">
                <div>
                    <span class="text_sub">上级用户：</span>
                    <span class="text_des">{{ userInfo.inviteeNickname | filterEmpty }}({{ userInfo.inviteePlayerId | filterEmpty }})</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">所属渠道：</span>
                    <span class="text_des">{{ userInfo.channelName | filterEmpty }}({{ userInfo.channelId | filterEmpty }})</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">所属渠道包：</span>
                    <span class="text_des">{{ userInfo.channelPackageName | filterEmpty }}({{ userInfo.channelPackageId | filterEmpty }})</span>
                </div>
            </div>
        </div>

        <div class="title">推广信息</div>
        <div class="item_bg">
            <div class="item">
                <div>
                    <span class="text_sub">邀请码：</span>
                    <span class="text_des">{{ userInfo.code | filterEmpty }}</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">推广人数：</span>
                    <span class="text_des">{{ userInfo.referCount | filterEmpty }}</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">累计推广收益：</span>
                    <span class="text_des">{{ userInfo.referIncome | filterThousandths }}</span>
                </div>
            </div>
        </div>

        <div class="title">资产信息</div>
        <div class="item_bg">
            <div class="item">
                <div>
                    <span class="text_sub">TotalCash：</span>
                    <span class="text_des">{{ userInfo.totalCash | filterEmpty }}</span>
                </div>
                <div>
                    <span class="text_sub">Bonus：</span>
                    <span class="text_des">{{ userInfo.bonus | filterEmpty }}</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">Deposited：</span>
                    <span class="text_des">{{ userInfo.deposited | filterEmpty }}</span>
                </div>
                <div>
                    <span class="text_sub">Withdrawable：</span>
                    <span class="text_des">{{ userInfo.withDrawable | filterEmpty }}</span>
                </div>
            </div>
            <div class="item">
                <div>
                    <span class="text_sub">Winnings：</span>
                    <span class="text_des">{{ userInfo.winnings | filterEmpty }}</span>
                </div>
                <div v-if="userInfo.rechargeCallback > 0">
                    <span class="text_sub">充值追回欠款：</span>
                    <span class="text_red">{{ fenToYuan(userInfo.rechargeCallback) | filterEmpty }}</span>
                </div>
            </div>
        </div>

        <div class="title">游戏信息</div>
        <div class="item_bg">
            <div class="item">
                <div>
                    <span class="text_sub">总输赢：</span>
                    <span class="text_des">{{ fenToYuan(userInfo.winLoseCoin) | filterThousandths }}</span>
                </div>
            </div>

            <div class="item">
                <div>
                    <span class="text_sub">总场次：</span>
                    <span class="text_des">
                        {{ userInfo.gameRound | filterThousandths }}场 / 胜{{ getPercentage(userInfo.winRound, userInfo.gameRound) }}负{{ getPercentage(userInfo.loseRound, userInfo.gameRound) }}
                    </span>
                </div>
            </div>

            <div class="item">
                <div>
                    <span class="text_sub">总时长：</span>
                    <span class="text_des">{{ userInfo.onlineTime | filterEmpty }}分钟</span>
                </div>
            </div>
        </div>

        <div class="mb-30">
            <el-table :data="userInfo.gameDataDtoList" style="width: 100%">
                <el-table-column prop="gameType" align="center" label="游戏名称" width="150">
                    <template slot-scope="scope">
                        {{ getGameName(scope.row.gameType) }}
                    </template>
                </el-table-column>
                <el-table-column prop="gameRound" align="center" label="场次" width="200">
                    <template slot-scope="scope">
                        {{ scope.row.gameRound | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column prop="name" align="center" label="累计输赢" width="200">
                    <template slot-scope="scope">
                        <span :class="scope.row.winLoseCoin > 0 ? 'text_red' : 'text_green'">{{ fenToYuan(scope.row.winLoseCoin) | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column align="center" prop="lastGameTime" label="最近一次游戏时间" width="180" />
                <el-table-column prop="tags" align="center" label="标签">
                    <template slot-scope="scope">
                        {{ getTagsName(scope.row.tags) }}
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import { STRATEGY_TYPE } from '@/constant/game'
import { getArrayValue } from '@/utils'
import TextHidden from '@/components/TextHidden'
export default {
    components: {
        TextHidden
    },
    mixins: [Base],
    data() {
        return {
            STRATEGY_TYPE
        }
    },
    props: {
        userInfo: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    mounted() {},
    methods: {
        getTagsName(tags) {
            let name = []
            if (tags) {
                tags.forEach(function (value) {
                    let tmpName = getArrayValue(STRATEGY_TYPE, value).replace('策略', '')
                    name.push(tmpName)
                })
            }

            return name.join('、')
        }
    }
}
</script>
<style lang="scss" scoped>
.player-detail-user_container {
    padding: 40px 40px 0px 40px;
    width: 100%;
    display: flex;
    flex-direction: column;
    overflow-y: scroll;
    .title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0.89px;
        font-weight: 500;
        margin-bottom: 10px;
    }
    .item_bg {
        background: #f7f7f7;
        border-radius: 4px;
        padding: 20px 30px;
        display: flex;
        margin-bottom: 30px;
        .item {
            width: 300px;
            height: 100%;
            display: flex;
            flex-direction: column;
            div:not(:last-child) {
                margin-bottom: 10px;
            }
        }
        .text_sub {
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0.78px;
            font-weight: 400;
        }
        .text_des {
            font-size: 14px;
            color: #282829;
            letter-spacing: 0.78px;
            font-weight: 400;
        }
    }
}

.game-result-header {
    height: 30px;
    line-height: 30px;
    font-family: PingFangSC-Medium;
    font-size: 12px;
    color: #282829;
    text-align: center;
    font-weight: 500;
    background: #f6f8f9;
    div {
        width: 260px;
    }
}
.game-result-list {
    width: 260px;
    text-align: center;
}
.game-result-detail {
    background: #f3f5fd;
    padding: 10px;
    min-height: 70px;
}
</style>
