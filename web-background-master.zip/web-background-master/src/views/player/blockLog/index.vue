<template>
    <div class="player-detail-log_container">
        <div class="head-container">
            <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" style="width: 250px" />
            <el-select v-model="query.operateType" placeholder="操作类型" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                <el-option v-for="(item, index) in BLOCK_TYPE_CONF" :key="index" :value="index" :label="item" />
            </el-select>
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="时间" />
            <el-table-column :show-overflow-tooltip="true" width="200" prop="operateType" align="center" label="操作类型">
                <template slot-scope="scope">
                    <span :class="scope.row.operateType % 2 == 1 ? 'text_red' : 'text_green'">
                        {{ getArrayValue(BLOCK_TYPE_CONF, scope.row.operateType) }}
                    </span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" prop="operator" align="center" label="操作人" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="operator" align="center" label="操作来源">
                <template slot-scope="scope">
                    <span>
                        {{ scope.row.channelId ? `渠道(${scope.row.channelId})` : '平台' }}
                    </span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" prop="reason" align="center" label="原因" />
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[10, 20, 50]" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/player'
import { BLOCK_TYPE_CONF } from '@/constant/common'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'createTime;desc',
    playerId: null,
    operateType: null,
    createTime: []
}

export default {
    components: {
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            BLOCK_TYPE_CONF,
            loading: false,
            list: [],
            query: defaultQuery,
            total: 0
        }
    },
    watch: {
        playerId: {
            handler(val) {
                val && this.resetQuery()
            },
            immediate: true
        }
    },
    mounted() {
        this.fixed_height = 280
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.query.playerId = this.playerId
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            if (this.checkPermission([this.permission.playerAccountBlock])) {
                api.accountBlock(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail-log_container {
    width: 100%;
    padding: 40px 20px;
    .role-span {
        font-weight: bold;
        color: #303133;
        font-size: 15px;
    }
    ::v-deep .el-table .cell {
        padding: 0px 1px;
    }
}
</style>
