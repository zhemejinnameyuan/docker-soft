<template>
    <div class="player-detail-log_container finance">
        <div class="head-container">
            <label class="label_title">绑定时间</label>
            <DateRangePicker v-model="query.referBindTime" class="filter-item" style="width: 250px" @change="toQuery" />
            <el-input v-model="query.belowPlayerId" size="medium" clearable placeholder="下级玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
            <el-input v-model="query.code" size="medium" clearable placeholder="请输入邀请码" style="width: 140px" class="filter-item" @keyup.enter.native="toQuery" />
            <el-select v-model="query.referState" placeholder="推广状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                <el-option v-for="(item, index) in PROMOTION_STATE" :key="index" :value="index" :label="item" />
            </el-select>
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column prop="referBindTime" width="150" align="center" label="绑定时间" />
            <el-table-column prop="loginTime" width="150" align="center" label="最近活跃时间" />
            <el-table-column prop="id" width="90" align="center" label="下级玩家ID">
                <template slot-scope="scope">
                    <UserIdJump :id="scope.row.id" />
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" prop="code" width="120" align="center" label="邀请码" />
            <el-table-column width="188" prop="content" align="center" label="渠道" v-if="!isChannelUser()">
                <template slot-scope="scope">
                    <div>{{ scope.row.channelName }}({{ scope.row.channelId }})</div>
                    <div>{{ scope.row.channelPackageName }}({{ scope.row.channelPackageId }})</div>
                </template>
            </el-table-column>
            <el-table-column prop="referGameRound" width="100" align="center" label="累计场次">
                <template slot="header">
                    <span>
                        累计场次
                        <el-tooltip class="item" effect="dark" content="玩家总游戏场次/绑定推广关系后的游戏场次" placement="top">
                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                        </el-tooltip>
                    </span>
                </template>
                <template slot-scope="scope">{{ scope.row.gameRound | filterThousandths }} / {{ scope.row.referGameRound | filterThousandths }}</template>
            </el-table-column>
            <el-table-column prop="content" align="center" label="投注金额/分红">
                <template slot-scope="scope">
                    <div>{{ scope.row.referBet | filterThousandths }} / {{ scope.row.referBetDivvy | filterThousandths }}</div>
                </template>
            </el-table-column>
            <el-table-column width="80" prop="referDepositDivvy" align="center" label="首充奖励">
                <template slot-scope="scope">
                    {{ scope.row.referDepositDivvy | filterThousandths }}
                </template>
            </el-table-column>
            <el-table-column width="70" prop="referState" align="center" label="推广状态">
                <template slot-scope="scope">
                    <span class="fs-14" :class="scope.row.referState == 1 ? 'text_green' : 'text_red'" @click="viewBan(scope.row.id)">
                        {{ getArrayValue(PROMOTION_STATE, scope.row.referState) }}
                    </span>
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[10, 20, 50]" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import * as api from '@/api/player'
import { PROMOTION_STATE } from '@/constant/promotion'
const defaultQuery = {
    size: 20,
    page: 1,
    sort: 'referBindTime;desc',
    playerId: '',
    code: '',
    belowPlayerId: '',
    referBindTime: []
}

export default {
    components: {
        pagination,
        DateRangePicker,
        UserIdJump
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            PROMOTION_STATE,
            dataObj: {},
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'referBindTime;desc',
                playerId: '',
                code: '',
                belowPlayerId: '',
                referBindTime: []
            },
            total: 0
        }
    },
    watch: {
        playerId: {
            handler(val) {
                val && this.resetQuery()
            },
            immediate: true
        }
    },
    mounted() {
        this.fixed_height = 280
    },
    methods: {
        resetQuery() {
            this.query = { ...defaultQuery }
            this.query.playerId = this.playerId
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.query.playerId = this.playerId
            this.loading = true
            if (this.checkPermission([this.permission.playerReferAccountBelows])) {
                api.referAccountBelows(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail-log_container {
    width: 100%;
    padding: 40px 20px;
    .role-span {
        font-weight: bold;
        color: #303133;
        font-size: 15px;
    }
    ::v-deep .el-table .cell {
        padding: 0px 1px;
    }
}
</style>
