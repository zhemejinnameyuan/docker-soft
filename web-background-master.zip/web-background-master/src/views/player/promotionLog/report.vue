<template>
    <div class="report-data-box">
        <div class="item-box" style="margin-left: 170px; width: 800px; margin-top: -30px">
            <div class="content">
                <div class="item mr-10">
                    <div class="dp-f">
                        <span class="item-title">推广总人数</span>
                        <el-tooltip class="icon-tips" effect="dark" content="绑定玩家为推广用户的下级玩家总人数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-max mt-20" style="width: 100px" v-autoFontSize="'max'">0</span>
                </div>
                <div class="split-line" />
                <div class="item ml-10">
                    <div class="dp-f">
                        <span class="item-title-min">注册用户数</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="推广用户中用户类型为注册玩家的总人数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-one" style="width: 80px" v-autoFontSize="'medium'">0</span>
                </div>
                <div class="item ml-40 mr-10">
                    <div class="dp-f">
                        <span class="item-title-min dp-f">游客用户数</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="推广用户中用户类型为游客玩家的总人数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 80px" v-autoFontSize="'medium'">0</span>
                </div>
                <div class="split-line" />
                <div class="item ml-10">
                    <div class="dp-f">
                        <span class="item-title-min">付费用户数</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="推广用户中有过成功充值行为的玩家总人数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-one" style="width: 80px" v-autoFontSize="'medium'">0</span>
                </div>
                <div class="item ml-40">
                    <div class="dp-f">
                        <span class="item-title-min">非付费用户数</span>
                        <el-tooltip class="icon-tips-min" effect="dark" content="推广用户中无成功充值行为的玩家总人数" placement="right">
                            <svg-icon icon-class="oms_ico_query" />
                        </el-tooltip>
                    </div>
                    <span class="item-number-medium mt-20 color-num-two" style="width: 80px" v-autoFontSize="'medium'">0</span>
                </div>
                <div class="item ml-40">
                    <div class="dp-f">
                        <span class="item-title" style="margin-left: 20px; margin-top: -10px">
                            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
                        </span>
                    </div>
                    <span class="item-title-min mt-5">&nbsp;</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        }
    }
}
</script>
