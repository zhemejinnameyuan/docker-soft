<template>
    <div class="player-detail-game-log_container">
        <div class="head-container">
            <el-select v-model="query.gameType" placeholder="游戏名称" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                <el-option v-for="item in games" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
            <el-input v-model="query.flowId" size="medium" clearable placeholder="输入牌局流水号" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
            <DateRangePicker v-model="query.endTime" class="filter-item" @change="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
        </div>
        <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
            <el-table-column prop="endTime" width="160" align="center" label="结算时间" />
            <el-table-column width="120" align="center" label="牌局流水">
                <template slot-scope="scope">
                    <span class="flow-id" @click="toFlowDetail(scope.row)">{{ scope.row.flowId }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="130" align="center" label="游戏名称">
                <template slot-scope="scope">
                    <span>{{ getGameName(scope.row.gameType, scope.row.roomType) }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="80" align="center" label="桌子类型">
                <template slot-scope="scope">
                    <span v-if="scope.row.deskPlayer != 100">{{ scope.row.deskPlayer }}人桌</span>
                    <span v-if="scope.row.deskPlayer == 100">百人桌</span>
                </template>
            </el-table-column>

            <el-table-column :show-overflow-tooltip="true" width="200" prop="bet" align="center" label="下注/底注">
                <template slot-scope="scope">
                    <span v-if="!scope.row.anteCoin" v-html="getBetsStr(scope.row.gameType, scope.row.betsStr)"></span>
                    <span v-if="scope.row.anteCoin" v-html="scope.row.anteCoin"></span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="150" align="center" label="牌局结果">
                <template slot-scope="scope">
                    <span v-html="replaceHtml(scope.row.result)" />
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="100" prop="resultWin" align="center" label="系统结算金额" />
            <el-table-column :show-overflow-tooltip="true" width="110" align="center" label="实际输赢金额">
                <template slot-scope="scope">
                    <span :class="textColor(scope.row.actualWin)">{{ scope.row.actualWin }}</span>
                </template>
            </el-table-column>
            <el-table-column :show-overflow-tooltip="true" width="100" prop="tax" align="center" label="抽税金额" />
            <el-table-column :show-overflow-tooltip="true" width="80" align="center" label="操作" fixed="right">
                <template slot-scope="scope">
                    <IconButton class="filter-item" size="medium" type="text" icon="oms_ico_xiangqing" style="font-size: 20px" @click="toDetail(scope.row)" />
                </template>
            </el-table-column>
        </el-table>
        <!--分页组件-->
        <pagination v-if="total" :page-sizes="[100, 200, 500]" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

        <!-- 详情 -->
        <Drawer :visible.sync="detail_drawer">
            <Detail v-if="detail_drawer" :info="info" />
        </Drawer>

        <!-- 流水详情 -->

        <Drawer :visible.sync="flow_detail_drawer">
            <DtDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.DT" :flow-id="info.flowId" />
            <PointsDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.LM && info.roomType === LM_ROOM_TYPE.POINTS" :flow-id="info.flowId" />
            <PoolDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.LM && info.roomType === LM_ROOM_TYPE.POOL" :flow-id="info.flowId" />
            <DealsDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.LM && info.roomType === LM_ROOM_TYPE.DEALS" :flow-id="info.flowId" />
            <JmDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.JM" :flow-id="info.flowId" />
            <RbDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.RB" :flow-id="info.flowId" />
            <BabDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.BAB" :flow-id="info.flowId" />
            <CszDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.CSZ" :flow-id="info.flowId" />
            <SupDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.SUP" :flow-id="info.flowId" />
            <DltDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.DLT" :flow-id="info.flowId" />
            <TpDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.TP" :flow-id="info.flowId" />

            <FxqClassicDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.FXQ && info.roomType === FXQ_ROOM_TYPE.CLASSIC" :flow-id="info.flowId" />
            <FxqQuickDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.FXQ && info.roomType === FXQ_ROOM_TYPE.QUICK" :flow-id="info.flowId" />
            <FxqMasterDetail v-if="flow_detail_drawer && info.gameType === GAME_TYPE.FXQ && info.roomType === FXQ_ROOM_TYPE.MASTER" :flow-id="info.flowId" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import Drawer from '@/components/Drawer'
import Detail from './detail.vue'
import DtDetail from '@/views/game/games/dtGame/dt/record/detail.vue'
import PointsDetail from '@/views/game/games/lmGame/points/record/detail.vue'
import PoolDetail from '@/views/game/games/lmGame/pool/record/detail.vue'
import DealsDetail from '@/views/game/games/lmGame/deals/record/detail.vue'
import JmDetail from '@/views/game/games/jmGame/jm/record/detail.vue'
import RbDetail from '@/views/game/games/rbGame/rb/record/detail.vue'
import BabDetail from '@/views/game/games/babGame/bab/record/detail.vue'
import CszDetail from '@/views/game/games/cszGame/csz/record/detail.vue'
import SupDetail from '@/views/game/games/supGame/sup/record/detail.vue'
import DltDetail from '@/views/game/games/dltGame/dlt/record/detail.vue'
import TpDetail from '@/views/game/games/tpGame/tp/record/detail.vue'
import FxqClassicDetail from '@/views/game/games/fxqGame/classic/record/detail.vue'
import FxqQuickDetail from '@/views/game/games/fxqGame/quick/record/detail.vue'
import FxqMasterDetail from '@/views/game/games/fxqGame/master/record/detail.vue'

import Base from '@/views/base'
import { GAME_TYPE, BAIREN_POS_CONF } from '@/constant/game'
import { ROOM_TYPE as LM_ROOM_TYPE } from '@/constant/lm'
import { ROOM_TYPE as FXQ_ROOM_TYPE } from '@/constant/fxq'

import * as api from '@/api/player'
const defaultQuery = {
    size: 100,
    page: 1,
    sort: 'endTime;desc',
    gameType: '',
    flowId: null,
    time: []
}
export default {
    components: {
        Drawer,
        pagination,
        DateRangePicker,
        Detail,
        DtDetail,
        PointsDetail,
        PoolDetail,
        DealsDetail,
        JmDetail,
        RbDetail,
        BabDetail,
        CszDetail,
        SupDetail,
        DltDetail,
        TpDetail,
        FxqClassicDetail,
        FxqQuickDetail,
        FxqMasterDetail
    },
    mixins: [Base],
    props: {
        playerId: {
            type: String,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            GAME_TYPE,
            LM_ROOM_TYPE,
            BAIREN_POS_CONF,
            FXQ_ROOM_TYPE,
            games: [],
            flow_detail_drawer: false,
            detail_drawer: false,
            loading: false,
            list: [],
            query: defaultQuery,
            info: null,
            total: 0
        }
    },
    watch: {
        playerId: {
            handler(val) {
                val && this.resetQuery()
            },
            immediate: true
        }
    },
    mounted() {
        this.games = this.getGames()
        this.fixed_height = 260
    },
    methods: {
        //处理下注结果-百人类
        getBetsStr(gameType, betsStr) {
            let str = ''
            let posConf = []
            switch (gameType) {
                case GAME_TYPE.DT:
                case GAME_TYPE.JM:
                case GAME_TYPE.RB:
                case GAME_TYPE.BAB:
                case GAME_TYPE.CSZ:
                case GAME_TYPE.DLT:
                case GAME_TYPE.SUP:
                    posConf = BAIREN_POS_CONF[gameType]
                    for (const j in betsStr) {
                        let bet = betsStr[j].y
                        let win = betsStr[j].z
                        let pos = betsStr[j].x
                        if (bet > 0.0) {
                            //只显示下注的区域
                            str += '<div>' + this.replaceHtml(posConf[pos]) + '下注:' + bet + ',输赢:' + win + '</div>'
                        }
                    }
                    break
            }
            return str
        },
        toFlowDetail(row) {
            this.info = row
            this.flow_detail_drawer = true
        },
        toDetail(row) {
            this.info = row
            this.detail_drawer = true
        },
        resetQuery() {
            this.query = { ...defaultQuery }
            this.query.playerId = this.playerId
            this.toQuery()
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            if (this.checkPermission([this.permission.playerGameList])) {
                api.gameLog(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.player-detail-game-log_container {
    width: 100%;
    padding: 40px 20px;
    .flow-id {
        font-size: 14px;
        color: #1ba2ff;
        text-align: center;
        font-weight: 400;
        cursor: pointer;
    }
    ::v-deep .el-table .cell {
        padding: 0px 1px;
    }
}
</style>
