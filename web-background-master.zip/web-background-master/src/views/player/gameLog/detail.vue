<template>
    <div v-if="info" class="player-record-detail">
        <div class="wrapper_content no-scrollbar">
            <div class="item_title">牌局信息</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item label="所属游戏:">
                        <span class="des_title">{{ getGameName(info.gameType, info.roomType) | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="牌局时间:">
                        <span class="des_title">{{ info.startTime | filterEmpty }}至{{ info.endTime | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="牌局流水:">
                        <span class="des_title">{{ info.flowId | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="下注/底注:">
                        <span class="des_title" v-if="!info.anteCoin" v-html="handleGameTotalBet(info.betsStr)" />
                        <span class="des_title" v-if="info.anteCoin" v-html="replaceReturn(info.anteCoin, '&ensp;&ensp;&ensp;|&ensp;&ensp;&ensp;')" />
                    </el-form-item>
                    <el-form-item label="桌子类型:">
                        <span class="des_title">{{ getDeskName(info.deskPlayer) | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="牌局结果:">
                        <span class="des_title" v-html="replaceReturn(info.result, '&ensp;&ensp;&ensp;&ensp;&ensp;')" />
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title">结算信息</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item label="结算时间:">
                        <span class="des_title">{{ info.endTime | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="系统结算金额:">
                        <span class="des_title" :class="textColor(info.resultWin)">{{ info.resultWin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="实际输赢金额:">
                        <span class="des_title" :class="textColor(info.actualWin)">{{ info.actualWin | filterEmpty }}</span>
                    </el-form-item>
                    <el-form-item label="当前税率:">
                        <span class="des_title">{{ info.taxPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="抽税金额:">
                        <span class="des_title">{{ info.tax | filterEmpty }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title">资金账户</div>
            <div class="item_bg">
                <el-form label-width="120px">
                    <el-form-item label="账户拆分比例:">
                        <span class="des_title">D:{{ info.depositedPercent | filterEmpty }}%｜W:{{ info.winningsPercent | filterEmpty }}%</span>
                    </el-form-item>
                    <el-form-item label="Deposited:">
                        <span class="des_title">
                            <span style="color: #e60808">{{ info.actualDeposited | filterEmpty }}</span>
                            <span v-if="info.actualDepositedReturn > 0">+{{ info.actualDepositedReturn | filterEmpty }}</span>
                            [账户金额由
                            <span style="color: #1ba2ff">{{ info.lastDeposited | filterEmpty }}</span>
                            变更为
                            <span style="color: #1ba2ff">{{ info.currDeposited | filterEmpty }}</span>
                            ]
                        </span>
                    </el-form-item>
                    <el-form-item label="Winnings:">
                        <span class="des_title">
                            <span style="color: #e60808">{{ info.actualWinnings | filterEmpty }}</span>
                            [账户金额由
                            <span style="color: #1ba2ff">{{ info.lastWinnings | filterEmpty }}</span>
                            变更为
                            <span style="color: #1ba2ff">{{ info.currWinnings | filterEmpty }}</span>
                            ]
                        </span>
                    </el-form-item>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
export default {
    components: {},
    mixins: [Base],
    props: {
        info: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {}
    },
    computed: {},
    watch: {},
    methods: {
        handleGameTotalBet(betsStr) {
            let total = 0
            for (const j in betsStr) {
                total += parseFloat(betsStr[j].y)
            }
            return total.toFixed(2)
        },
        replaceReturn(txt, str = '') {
            if (txt) {
                txt = txt.replace(/<br\/>/g, str)
                return this.replaceHtml(txt)
            }
            return '--'
        }
    }
}
</script>

<style lang="scss" scoped>
.player-record-detail {
    position: relative;
    width: 660px;
    height: 100%;
    .wrapper_content {
        width: 100%;
        height: 100%;
        padding: 20px 30px;
        display: flex;
        flex-direction: column;
        overflow-y: scroll;
    }

    .item_title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 500;
    }
    .item_bg {
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 20px 0px;
        margin-top: 10px;
        margin-bottom: 20px;
    }
    .des_title {
        font-size: 14px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .el-form-item--small.el-form-item {
        margin-bottom: 0px;
    }
}
</style>
