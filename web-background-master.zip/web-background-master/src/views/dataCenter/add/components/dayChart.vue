<template>
    <div class="add_charts">
        <el-row class="head-container">
            <el-date-picker v-model="query.date" :clearable="false" value-format="yyyy-MM-dd" type="date" size="medium" class="filter-item" style="width: 160px" placeholder="选择日期" />
            <el-select v-model="query.playerType" placeholder="玩家类型" size="medium" class="filter-item" style="width: 160px" @change="initChart">
                <el-option v-for="item in userTypes" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
            <el-select
                v-model="query.channelId"
                v-permission="[permission.statsChannelList]"
                placeholder="全部渠道"
                size="medium"
                class="filter-item"
                style="width: 160px"
                clearable
                @change="changeChannel"
            >
                <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
            </el-select>
            <el-select
                v-model="query.channelPackageId"
                v-permission="[permission.statsChannelPackageList]"
                :placeholder="channelPackages.length ? '全部渠道包' : '无数据'"
                remote
                filterable
                size="medium"
                class="filter-item"
                style="width: 160px"
                :remote-method="getChannelPackage"
                clearable
                @visible-change="showChannelPackage"
                @change="toQuery"
            >
                <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
            <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
            </el-select>
            <el-select v-model="query.version" placeholder="全部版本" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                <el-option v-for="item in versions" :key="item" :label="item" :value="item" />
            </el-select>

            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
        </el-row>
        <div id="chart" class="add_chart" />
    </div>
</template>
<script>
import Base from '@/views/base'
import { userTypeConfig, terminalConfig, USER_TYPE } from '@/constant/game'
import * as api_channel from '@/api/channel'
import * as api from '@/api/statistics'
import * as echarts from 'echarts'
import { deepClone } from '@/utils/object'
import { getPackageList } from '@/utils'
const defaultChartQuery = {
    playerType: 0,
    date: '',
    channelId: undefined,
    channelPackageId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {},
    mixins: [Base],
    props: {
        channels: {
            type: Array,
            default: function () {
                return []
            }
        },
        versions: {
            type: Array,
            default: function () {
                return []
            }
        }
    },
    data() {
        return {
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: {},
            channelPackages: [],
            chartObj: undefined,
            myChart: undefined
        }
    },
    mounted() {
        this.resetQuery()
        this.getChannelPackage()
    },
    methods: {
        initChart() {
            if (!this.myChart) {
                this.myChart = echarts.init(document.getElementById('chart'))
            }
            // 指定图表的配置项和数据
            var option = {
                grid: {
                    top: '50',
                    left: '10',
                    right: '10',
                    bottom: '10',
                    containLabel: true
                },
                color: ['#3DEAED', '#D9DADF'],
                title: {
                    text: '每日新增'
                },
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        magicType: {
                            type: ['bar', 'line'],
                            title: {
                                line: '切换为折线图',
                                bar: '切换为柱状图'
                            }
                        }
                    }
                },
                legend: [
                    {
                        left: 140,
                        data: ['今日新增', '昨日新增']
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: this.chartObj.time,
                        axisLine: {
                            // symbol: ['none', 'arrow'], // 两端都显示箭头
                            // symbolOffset: [0, 8], // 箭头距离两端的距离,可为负数
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {
                    axisLine: {
                        // symbol: ['none', 'arrow'], // 两端都显示箭头
                        // symbolOffset: [0, 8], // 箭头距离两端的距离,可为负数
                        lineStyle: {
                            color: '#A1A4A7'
                        }
                    }
                },
                series: [
                    {
                        name: '今日新增',
                        type: 'bar',
                        barGap: '15%',
                        barWidth: '15',
                        data: this.query.playerType == USER_TYPE.GUEST ? this.chartObj.currTourist : this.chartObj.currRegister
                    },
                    {
                        name: '昨日新增',
                        type: 'bar',
                        barGap: '15%',
                        barWidth: '15',
                        data: this.query.playerType == USER_TYPE.GUEST ? this.chartObj.beforeTourist : this.chartObj.beforeRegister
                    }
                ]
            }

            // 使用刚指定的配置项和数据显示图表。
            this.myChart.setOption(option)
        },
        /** 查询渠道包列表 */
        changeChannel() {
            this.query.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage()
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        async getChannelPackage(name) {
            if (this.checkPermission([this.permission.statsChannelPackageList])) {
                this.channelPackages = await getPackageList(this.query.channelId, name)
            } else {
                this.channelPackages = []
            }
        },

        resetQuery() {
            this.query = deepClone(defaultChartQuery)
            var today = new Date().format('yyyy-MM-dd')
            this.query.date = today
            this.toQuery()
        },
        toQuery() {
            var dic = deepClone(this.query)
            dic.date = [dic.date, dic.date]
            if (this.checkPermission([this.permission.statsNewDay])) {
                api.statsNewDayChart(dic)
                    .then((rep) => {
                        this.chartObj = rep.data
                        this.initChart()
                    })
                    .catch(() => {})
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.data_center_day {
    .add_charts {
        margin-top: 20px;
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 30px;
    }
    .add_chart {
        margin-top: 30px;
        width: 100%;
        height: 350px;
    }
    .add_table {
        margin-top: 40px;
    }
    .red_label {
        font-size: 14px;
        line-height: 14px;
        color: #ff5050;
        text-align: center;
        font-weight: 400;
    }
    .green_label {
        font-size: 14px;
        line-height: 14px;
        color: #56d970;
        text-align: center;
        font-weight: 400;
    }
    .prens {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .trend {
        font-size: 10px;
        line-height: 14px;
        margin-right: 5px;
    }
}
</style>
