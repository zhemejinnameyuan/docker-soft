<template>
    <div v-show="show" class="data_center_month">
        <MonthChart v-if="show" :channels="channels" :versions="versions" />

        <div class="add_table">
            <el-row class="head-container" style="margin-left: 30px">
                <DateRangePicker
                    v-model="query.date"
                    class="filter-item"
                    type="monthrange"
                    :picker-options="pickerOptions"
                    value-format="yyyy-MM-dd"
                    :default-time="[]"
                    start-placeholder="开始月份"
                    end-placeholder="结束月份"
                    :clearable="false"
                    @change="toQuery"
                />

                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.statsChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 160px"
                    clearable
                    @change="changeChannel"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select
                    v-model="query.channelPackageId"
                    v-permission="[permission.statsChannelPackageList]"
                    :placeholder="channelPackages.length ? '全部渠道包' : '无数据'"
                    remote
                    filterable
                    size="medium"
                    class="filter-item"
                    :remote-method="getChannelPackage"
                    style="width: 160px"
                    clearable
                    @visible-change="showChannelPackage"
                    @change="toQuery"
                >
                    <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.version" placeholder="全部版本" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in versions" :key="item" :label="item" :value="item" />
                </el-select>

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-table ref="table" v-sticky="{ top: 116, parent: '.data_center_add' }" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :data="tableList">
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="time" align="center" label="日期" />
                <el-table-column :show-overflow-tooltip="true" width="200px" prop="packageNumber" align="center">
                    <template slot="header">
                        <span>
                            月新增
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="新下载安装的用户根据ID去重后的数据(1、老用户转换成注册用户不计入月新增统计中；2、一个新下载的用户以游客身份登录后，当月在成为注册用户，月新增计为1)"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.curr | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" prop="createTime" align="center">
                    <template slot="header">
                        <span>
                            注册月新增
                            <el-tooltip class="item" effect="dark" content="当月下载安装的注册用户+早期安装当月注册的用户" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.currRegister | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" prop="updateTime" align="center">
                    <template slot="header">
                        <span>
                            游客月新增
                            <el-tooltip class="item" effect="dark" content="当月下载安装以游客身份登录的用户+早期安装当月首次以游客登录的用户" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.currTourist | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" align="center">
                    <template slot="header">
                        <span>
                            注册转换率
                            <el-tooltip class="item" effect="dark" content="注册转换率=注册月新增/月新增*100%(注册转换率可能会超过100%)" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.currRegister, scope.row.curr) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" label="" align="center">
                    <template slot="header">
                        <span>
                            注册新增环比
                            <el-tooltip class="item" effect="dark" content="注册新增环比=(当月注册月新增-上月注册月新增)/上月注册月新增*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <div class="prens">
                            <svg-icon class="trend" :icon-class="getIcon(scope.row.currRegister, scope.row.beforeRegister)" />
                            <span :class="getPColor(scope.row.currRegister, scope.row.beforeRegister)">
                                {{ getPercentageRatio(scope.row.currRegister, scope.row.beforeRegister) }}
                            </span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" label="游客新增环比" align="center">
                    <template slot="header">
                        <span>
                            游客新增环比
                            <el-tooltip class="item" effect="dark" content="游客新增环比=(当月游客月新增-上月游客月新增)/上月游客月新增*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <div class="prens">
                            <svg-icon class="trend" :icon-class="getIcon(scope.row.currTourist, scope.row.beforeTourist)" />
                            <span :class="getPColor(scope.row.currTourist, scope.row.beforeTourist)">
                                {{ getPercentageRatio(scope.row.currTourist, scope.row.beforeTourist) }}
                            </span>
                        </div>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import { calendarMonthShortcuts } from '@/utils/shortcuts'
import pagination from '@/components/Pagination'
import { userTypeConfig, terminalConfig } from '@/constant/game'
import * as api_channel from '@/api/channel'
import * as api from '@/api/statistics'
import { deepClone } from '@/utils/object'
import MonthChart from './monthChart.vue'
import { getChannelList, getPackageList } from '@/utils'
const defaultTableQuery = {
    page: 1,
    size: 10,
    sort: 'id;desc',
    all: false,
    date: [],
    channelId: undefined,
    channelPackageId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {
        pagination,
        DateRangePicker,
        MonthChart
    },
    mixins: [Base],
    props: {
        show: {
            type: Boolean,
            default: function () {
                return false
            }
        }
    },
    data() {
        return {
            pickerOptions: { shortcuts: calendarMonthShortcuts },
            loading: false,
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: defaultTableQuery,
            channels: [],
            total: 0,
            channelPackages: [],
            versions: [],
            tableList: []
        }
    },
    mounted() {
        this.getVersion()
        this.getChannel()
        this.resetQuery()
    },
    methods: {
        async getChannel() {
            if (this.checkPermission([this.permission.statsChannelList])) {
                this.channels = await getChannelList()
            }
        },
        getVersion() {
            api.statsVersions()
                .then((rep) => {
                    this.versions = rep.data
                })
                .catch(() => {})
        },
        /** 查询渠道包列表 */
        changeChannel() {
            this.query.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage()
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        async getChannelPackage(name) {
            if (this.checkPermission([this.permission.statsChannelPackageList])) {
                this.channelPackages = await getPackageList(this.query.channelId, name)
            } else {
                this.channelPackages = []
            }
        },
        resetQuery() {
            this.query = deepClone(defaultTableQuery)
            var end = new Date()
            var start = new Date()
            start = start.setMonth(start.getMonth() - 6)
            end = end.setMonth(end.getMonth() - 1)
            start = new Date(start).format('yyyy-MM-dd')
            end = new Date(end).format('yyyy-MM-dd')
            this.query.date = [start, end]
            this.toQuery()
        },
        toQuery(tag) {
            if (!tag) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.statsNewMonth])) {
                this.loading = true
                api.statsNewMonthTable(this.query)
                    .then((rep) => {
                        this.tableList = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        getIcon(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'oms_ico_shangsheng'
            } else if (val < 0) {
                return 'oms_ico_xiajiang'
            }
            return ''
        },
        getPColor(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'red_label'
            } else if (val < 0) {
                return 'green_label'
            }
            return ''
        }
    }
}
</script>

<style lang="scss" scoped>
.data_center_month {
    .add_charts {
        margin-top: 20px;
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 30px;
    }
    .add_chart {
        margin-top: 30px;
        width: 100%;
        height: 350px;
    }
    .add_table {
        margin-top: 40px;
    }
    .red_label {
        font-size: 14px;
        line-height: 14px;
        color: #ff5050;
        text-align: center;
        font-weight: 400;
    }
    .green_label {
        font-size: 14px;
        line-height: 14px;
        color: #56d970;
        text-align: center;
        font-weight: 400;
    }
    .prens {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .trend {
        font-size: 10px;
        line-height: 14px;
        margin-right: 5px;
    }
}
</style>
