<template>
    <div class="app-container data_center_active">
        <IconButton
            v-permission="[permission.statsActiveDay]"
            class="filter-item"
            size="medium"
            style="width: 110px"
            :type="isSelectType('day')"
            :plain="isSelectPlain('day')"
            title="日活跃"
            @click="changeType('day')"
        />
        <IconButton
            v-permission="[permission.statsActiveMonth]"
            class="filter-item"
            size="medium"
            style="width: 110px"
            :type="isSelectType('month')"
            :plain="isSelectPlain('month')"
            title="月活跃"
            @click="changeType('month')"
        />
        <Day v-permission="[permission.statsActiveDay]" :show="type == 'day'" />
        <Month v-permission="[permission.statsActiveMonth]" :show="type == 'month'" />
    </div>
</template>
<script>
import Base from '@/views/base'
import Day from './components/day.vue'
import Month from './components/month.vue'
export default {
    name: 'DataActive',
    components: {
        Day,
        Month
    },
    mixins: [Base],
    data() {
        return {
            type: ''
        }
    },
    mounted() {
        if (this.checkPermission([this.permission.statsActiveDay])) {
            this.type = 'day'
        } else if (this.checkPermission([this.permission.statsActiveMonth])) {
            this.type = 'month'
        }
    },
    methods: {
        isSelectType(type) {
            return this.type === type ? 'primary' : 'info'
        },
        isSelectPlain(type) {
            return this.type !== type
        },
        changeType(type) {
            this.type = type
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.data_center_active {
    height: calc(100vh - #{$navBarHeught} - #{$tagBarHeight});
    overflow-y: scroll;
    .add_charts {
        margin-top: 20px;
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 30px;
    }
    .add_chart {
        margin-top: 30px;
        width: 100%;
        height: 350px;
    }
    .add_table {
        margin-top: 40px;
    }
}
</style>
