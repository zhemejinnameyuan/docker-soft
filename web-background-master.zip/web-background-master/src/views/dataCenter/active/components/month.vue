<template>
    <div v-show="show" class="data_center_month">
        <MonthChart v-if="show" :channels="channels" :versions="versions" />

        <div class="add_table">
            <el-row class="head-container" style="margin-left: 30px">
                <DateRangePicker
                    v-model="query.date"
                    class="filter-item"
                    type="monthrange"
                    :picker-options="pickerOptions"
                    value-format="yyyy-MM-dd"
                    :default-time="[]"
                    start-placeholder="开始月份"
                    end-placeholder="结束月份"
                    @change="toQuery"
                />

                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.statsChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 160px"
                    clearable
                    @change="changeChannel"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select
                    v-model="query.channelPackageId"
                    v-permission="[permission.statsChannelPackageList]"
                    :placeholder="channelPackages.length ? '全部渠道包' : '无数据'"
                    remote
                    filterable
                    size="medium"
                    class="filter-item"
                    :remote-method="getChannelPackage"
                    style="width: 160px"
                    clearable
                    @visible-change="showChannelPackage"
                    @change="toQuery"
                >
                    <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.version" placeholder="全部版本" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in versions" :key="item" :label="item" :value="item" />
                </el-select>

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-table
                ref="table"
                v-sticky="{ top: 116, parent: '.data_center_active' }"
                v-loading="loading"
                :span-method="rowSpanMethod"
                class="game-table"
                highlight-current-row
                style="width: 100%"
                :data="list"
                :cell-class-name="tableRowClassName"
                @cell-mouse-leave="cellMouseLeave"
                @cell-mouse-enter="cellMouseEnter"
            >
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="time" align="center" label="日期" />

                <el-table-column :show-overflow-tooltip="true" width="180px" prop="packageNumber" align="center">
                    <template slot="header">
                        <span>
                            活跃类型
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="启动活跃：启动应用就计入1次活跃；游戏活跃：需要在游戏中有过真实游戏行为，如旁观身份将不计入游戏活跃，在牌桌游戏中，牌桌开启就计游戏活跃。"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.type == 1 ? '启动活跃' : '游戏活跃' }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="packageNumber" align="center">
                    <template slot="header">
                        <span>
                            月活数
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="需要根据用户ID去重，同一个ID用户，当月以游客身份启动/游戏，后再以注册用户启动/游戏，则当月启动/游戏活跃计为1"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.curr | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="createTime" align="center">
                    <template slot="header">
                        <span>
                            注册月活
                            <el-tooltip class="item" effect="dark" content="用户以注册身份当月启动/游戏后注册月活计为1，同一用户当月多次只计为1" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.currRegister | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="updateTime" align="center">
                    <template slot="header">
                        <span>
                            游客月活
                            <el-tooltip class="item" effect="dark" content="用户以游客身份当月启动/游戏后游客月活计为1，同一用户当月多次只计为1" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.currTourist | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center">
                    <template slot="header">
                        <span>
                            注册月活率
                            <el-tooltip class="item" effect="dark" content="注册月活率=注册月活/月活跃*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.currRegister, scope.row.curr) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center">
                    <template slot="header">
                        <span>
                            游客月活率
                            <el-tooltip class="item" effect="dark" content="游客月活率=游客月活/月活跃*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.currTourist, scope.row.curr) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center">
                    <template slot="header">
                        <span>
                            注册月活环比
                            <el-tooltip class="item" effect="dark" content="注册月活环比=(当月注册月活-上月注册月活)/上月注册月活*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <div class="prens">
                            <svg-icon class="trend" :icon-class="getIcon(scope.row.currRegister, scope.row.beforeRegister)" />
                            <span :class="getPColor(scope.row.currRegister, scope.row.beforeRegister)">
                                {{ getPercentageRatio(scope.row.currRegister, scope.row.beforeRegister) }}
                            </span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" align="center">
                    <template slot="header">
                        <span>
                            游客月活环比
                            <el-tooltip class="item" effect="dark" content="游客月活环比=(当月游客月活-昨月游客日活)/上月游客月活*100%" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <div class="prens">
                            <svg-icon class="trend" :icon-class="getIcon(scope.row.currTourist, scope.row.beforeTourist)" />
                            <span :class="getPColor(scope.row.currTourist, scope.row.beforeTourist)">
                                {{ getPercentageRatio(scope.row.currTourist, scope.row.beforeTourist) }}
                            </span>
                        </div>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import { calendarMonthShortcuts } from '@/utils/shortcuts'
import pagination from '@/components/Pagination'
import { userTypeConfig, terminalConfig } from '@/constant/game'
import * as api_channel from '@/api/channel'
import * as api from '@/api/statistics'
import { deepClone } from '@/utils/object'
import MonthChart from './monthChart.vue'
import { getChannelList, getPackageList } from '@/utils'
const defaultTableQuery = {
    page: 1,
    size: 10,
    sort: 'id;desc',
    all: false,
    date: [],
    channelId: undefined,
    channelPackageId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {
        pagination,
        DateRangePicker,
        MonthChart
    },
    mixins: [Base],
    props: {
        show: {
            type: Boolean,
            default: function () {
                return false
            }
        }
    },
    data() {
        return {
            pickerOptions: { shortcuts: calendarMonthShortcuts },
            loading: false,
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: defaultTableQuery,
            channels: [],
            total: 0,
            channelPackages: [],
            versions: [],
            list: [],
            rowIndex: '-1',
            orderIndexArr: [],
            hoverOrderArr: []
        }
    },
    mounted() {
        this.getVersion()
        this.getChannel()
        this.resetQuery()
        this.getChannelPackage()
    },
    methods: {
        // 按日期分组
        getOrderNumber() {
            const OrderObj = {}
            this.list.forEach((element, index) => {
                element.rowIndex = index
                if (OrderObj[element.time]) {
                    OrderObj[element.time].push(index)
                } else {
                    OrderObj[element.time] = []
                    OrderObj[element.time].push(index)
                }
            })
            for (const k in OrderObj) {
                if (OrderObj[k].length > 1) {
                    this.orderIndexArr.push(OrderObj[k])
                }
            }
        },
        // 处理类名
        tableRowClassName({ rowIndex }) {
            const arr = this.hoverOrderArr
            for (let i = 0; i < arr.length; i++) {
                if (rowIndex === arr[i]) {
                    return 'hovered-row'
                }
            }
        },
        // 单元格 hover 进入
        cellMouseEnter(row, column, cell, event) {
            this.rowIndex = row.rowIndex
            this.hoverOrderArr = []
            this.orderIndexArr.forEach((element) => {
                if (element.indexOf(this.rowIndex) >= 0) {
                    this.hoverOrderArr = element
                }
            })
        },
        // 单元格 hover 退出
        cellMouseLeave() {
            this.rowIndex = '-1'
            this.hoverOrderArr = []
        },
        rowSpanMethod({ row, column, rowIndex, columnIndex }) {
            if (columnIndex === 0) {
                if (rowIndex % 2 === 0) {
                    return [2, 1]
                } else {
                    return [0, 0]
                }
            }
            return [1, 1]
        },
        async getChannel() {
            if (this.checkPermission([this.permission.statsChannelList])) {
                this.channels = await getChannelList()
            }
        },
        getVersion() {
            if (this.checkPermission([this.permission.statsVersions])) {
                api.statsVersions()
                    .then((rep) => {
                        this.versions = rep.data
                    })
                    .catch(() => {})
            }
        },
        /** 查询渠道列表 */
        changeChannel() {
            this.query.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage()
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        async getChannelPackage(name) {
            if (this.checkPermission([this.permission.statsChannelPackageList])) {
                this.channelPackages = await getPackageList(this.query.channelId, name)
            } else {
                this.channelPackages = []
            }
        },
        resetQuery() {
            this.query = deepClone(defaultTableQuery)
            var end = new Date()
            var start = new Date()
            start = start.setMonth(start.getMonth() - 6)
            end = end.setMonth(end.getMonth() - 1)
            start = new Date(start).format('yyyy-MM-dd')
            end = new Date(end).format('yyyy-MM-dd')
            this.query.date = [start, end]
            this.toQuery()
        },
        toQuery(tag) {
            if (!tag) {
                this.query.page = 1
            }
            this.loading = true
            if (this.checkPermission([this.permission.statsActiveMonth])) {
                api.statsActiveMonthTable(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.getOrderNumber()
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        getIcon(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'oms_ico_shangsheng'
            } else if (val < 0) {
                return 'oms_ico_xiajiang'
            }
            return ''
        },
        getPColor(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'red_label'
            } else if (val < 0) {
                return 'green_label'
            }
            return ''
        }
    }
}
</script>
<style scoped lang="scss">
.el-table .hovered-row {
    background: #f5f7fa;
}
</style>
<style lang="scss" scoped>
.data_center_month {
    ::v-deep .cell {
        padding-left: 0px;
        padding-right: 0px;
    }
    .add_charts {
        margin-top: 20px;
        width: 100%;
        background: #f7f7f7;
        border-radius: 4px;
        padding: 30px;
    }
    .add_chart {
        margin-top: 30px;
        width: 100%;
        height: 350px;
    }
    .add_table {
        margin-top: 40px;
    }
    .red_label {
        font-size: 14px;
        line-height: 14px;
        color: #ff5050;
        text-align: center;
        font-weight: 400;
    }
    .green_label {
        font-size: 14px;
        line-height: 14px;
        color: #56d970;
        text-align: center;
        font-weight: 400;
    }
    .prens {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .trend {
        font-size: 10px;
        line-height: 14px;
        margin-right: 5px;
    }
}
</style>
