<template>
    <div class="app-container data_center_retention">
        <el-radio-group v-model="type" size="medium">
            <el-radio-button label="day" v-permission="[permission.statsRetainDay]">日留存</el-radio-button>
            <el-radio-button label="week" v-permission="[permission.statsRetainWeek]">周留存</el-radio-button>
            <el-radio-button label="month" v-permission="[permission.statsRetainMonth]">月留存</el-radio-button>
        </el-radio-group>
        <Day v-if="type == 'day'" v-permission="[permission.statsRetainDay]" />
        <Week v-if="type == 'week'" v-permission="[permission.statsRetainWeek]" />
        <Month v-if="type == 'month'" v-permission="[permission.statsRetainMonth]" />
    </div>
</template>
<script>
import Base from '@/views/base'
import Day from './components/day.vue'
import Month from './components/month.vue'
import Week from './components/week.vue'
export default {
    name: 'DataRetention',
    components: {
        Day,
        Month,
        Week
    },
    mixins: [Base],
    data() {
        return {
            type: ''
        }
    },
    mounted() {
        if (this.checkPermission([this.permission.statsRetainDay])) {
            this.type = 'day'
        } else if (this.checkPermission([this.permission.statsRetainWeek])) {
            this.type = 'week'
        } else if (this.checkPermission([this.permission.statsRetainMonth])) {
            this.type = 'month'
        }
    }
}
</script>

<style lang="scss" scoped>
.data_center_retention {
}
::v-deep .el-radio-button__inner {
    width: 120px;
    height: 40px;
    line-height: initial;
    background: #f7f7f7;
    font-size: 16px !important;
    font-weight: 500;
    padding: 8px 20px !important;
}
</style>
