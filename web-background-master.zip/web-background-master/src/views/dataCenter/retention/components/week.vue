<template>
    <div class="data_retention_week">
        <div class="retention_day head-container">
            <el-row>
                <WeekRangePicker v-model="query.date" class="filter-item" start-placeholder="开始周" end-placeholder="结束周" @change="toQuery" />
                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.statsChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 160px"
                    clearable
                    @change="changeChannel"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select
                    v-model="query.channelPackageId"
                    v-permission="[permission.statsChannelPackageList]"
                    :placeholder="channelPackages.length ? '全部渠道包' : '无数据'"
                    remote
                    filterable
                    size="medium"
                    class="filter-item"
                    :remote-method="getChannelPackage"
                    style="width: 160px"
                    clearable
                    @visible-change="showChannelPackage"
                    @change="toQuery"
                >
                    <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.version" placeholder="全部版本" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in versions" :key="item" :label="item" :value="item" />
                </el-select>

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>

        <div class="retention_table">
            <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row :height="table_height" style="width: 100%" :data="list">
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center" label="日期">
                    <template slot-scope="scope">
                        <span v-html="scope.row.time" />
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="220px" prop="packageNumber" align="center">
                    <template slot="header">
                        <span>
                            周新增
                            <el-tooltip class="item" effect="dark" content="周新增：指当周新下载安装的用户，需要根据用户ID去重" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        {{ scope.row.currNew | filterThousandths }}
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px">
                    <template slot="header">
                        <span>
                            次周
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="次周留存=当周新增中第1周启动的用户/当周新增*100%，其它留存数据指当周新增的用户，在N周后的那周内有过启动行为的统计"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span class="bg_p_1 bg_p">{{ filterTableCell(scope.row.retain1, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第2周">
                    <template slot-scope="scope">
                        <span class="bg_p_2 bg_p">{{ filterTableCell(scope.row.retain2, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第3周">
                    <template slot-scope="scope">
                        <span class="bg_p_3 bg_p">{{ filterTableCell(scope.row.retain3, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第4周">
                    <template slot-scope="scope">
                        <span class="bg_p_4 bg_p">{{ filterTableCell(scope.row.retain4, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第5周">
                    <template slot-scope="scope">
                        <span class="bg_p_5 bg_p">{{ filterTableCell(scope.row.retain5, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第6周">
                    <template slot-scope="scope">
                        <span class="bg_p_6 bg_p">{{ filterTableCell(scope.row.retain6, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第7周">
                    <template slot-scope="scope">
                        <span class="bg_p_7 bg_p">{{ filterTableCell(scope.row.retain7, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" label="第8周">
                    <template slot-scope="scope">
                        <span class="bg_p_8 bg_p">{{ filterTableCell(scope.row.retain8, scope.row.currNew) }}</span>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import WeekRangePicker from '@/components/WeekRangePicker'
import pagination from '@/components/Pagination'
import { userTypeConfig, terminalConfig } from '@/constant/game'
import * as api_channel from '@/api/channel'
import * as api from '@/api/statistics'
import { assign, deepClone } from '@/utils/object'
import { isEmpty } from '@/utils/typeof'
import { getChannelList, getPackageList } from '@/utils'
const defaultTableQuery = {
    page: 1,
    size: 10,
    sort: 'id;desc',
    all: false,
    date: [],
    channelId: undefined,
    channelPackageId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {
        pagination,
        WeekRangePicker
    },
    mixins: [Base],

    data() {
        return {
            loading: false,
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: defaultTableQuery,
            channels: [],
            total: 0,
            channelPackages: [],
            versions: [],
            list: []
        }
    },
    computed: {},

    mounted() {
        this.fixed_height = 350
        this.getVersion()
        this.getChannel()
        this.resetQuery()
        this.getChannelPackage()
    },
    methods: {
        filterTableCell(val, total) {
            if (isEmpty(val)) {
                return '--'
            } else {
                return `${this.getPercentage(val, total)}[${val}]`
            }
        },
        async getChannel() {
            if (this.checkPermission([this.permission.statsChannelList])) {
                this.channels = await getChannelList()
            }
        },
        getVersion() {
            api.statsVersions()
                .then((rep) => {
                    this.versions = rep.data
                })
                .catch(() => {})
        },
        /** 查询渠道列表 */
        changeChannel() {
            this.query.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage()
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        async getChannelPackage(name) {
            if (this.checkPermission([this.permission.statsChannelPackageList])) {
                this.channelPackages = await getPackageList(this.query.channelId, name)
            } else {
                this.channelPackages = []
            }
        },
        resetQuery() {
            this.query = deepClone(defaultTableQuery)
            var start = new Date().daysAgo(56)
            var end = new Date().daysAgo(7)
            this.query.date = [start, end]
            this.toQuery()
        },
        toQuery(tag) {
            if (!tag) {
                this.query.page = 1
            }
            this.loading = true
            var times = []
            this.query.date.forEach((element) => {
                times.push(element.format('yyyy-MM-dd'))
            })
            if (this.checkPermission([this.permission.statsRetainWeek])) {
                api.statsRetainWeekTable(assign(deepClone(this.query), { date: times }))
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.data_retention_week {
    .retention_day {
        margin-top: 30px;
        width: 100%;
    }
    .retention_table {
        width: fit-content;
        margin-top: 30px;
    }
    .bg_p {
        padding: 0px 9px;
        width: 80px;
        height: 30px;
        display: flex;
        align-items: center;
        font-size: 12px;
        color: #ffffff;
        font-weight: 400;
    }
    .bg_p_1 {
        background: #0078c3;
    }
    .bg_p_2 {
        background: #0089d7;
    }
    .bg_p_3 {
        background: #009ced;
    }
    .bg_p_4 {
        background: #00aafc;
    }
    .bg_p_5 {
        background: #00b8fc;
    }
    .bg_p_6 {
        background: #00c4fe;
    }
    .bg_p_7 {
        background: #64d7fe;
    }
    .bg_p_8 {
        background: #96ecff;
    }
}
</style>
