<template>
    <div class="data_channel_package_active">
        <div class="channel_package_active head-container">
            <el-row>
                <DateRangePicker
                    v-model="query.date"
                    :picker-options="pickerOptions"
                    class="filter-item"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :value-format="'yyyy-MM-dd'"
                    :clearable="false"
                    @change="toQuery"
                />
                <el-select v-model="query.channelId" v-permission="[permission.statsChannelList]" placeholder="全部渠道" size="medium" class="filter-item" style="width: 160px" @change="changeChannel">
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select
                    v-model="query.channelPackageId"
                    v-permission="[permission.statsChannelPackageList]"
                    placeholder="全部渠道包"
                    remote
                    filterable
                    size="medium"
                    class="filter-item"
                    :remote-method="getChannelPackage"
                    style="width: 160px"
                    @visible-change="showChannelPackage"
                    @change="toQuery"
                >
                    <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select v-model="query.version" placeholder="全部版本" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in versions" :key="item" :label="item" :value="item" />
                </el-select>

                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end">
                <IconButton class="filter-item export_button" size="medium" type="primary" icon="oms_ico_export" plain title="导出" @click="exportExcel" />
            </el-row>
        </div>

        <div class="channel_table">
            <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row :height="table_height" style="width: 100%" :data="list">
                <el-table-column :show-overflow-tooltip="true" width="120px" prop="time" align="center" label="日期" />
                <el-table-column :show-overflow-tooltip="true" width="150px" align="center" label="渠道(ID)">
                    <template slot-scope="scope">
                        <span>{{ scope.row.channelName | filterEmpty }}({{ scope.row.channelId | filterEmpty }})</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="150px" align="center" label="渠道包(ID)">
                    <template slot-scope="scope">
                        <span>{{ scope.row.channelPackageName | filterEmpty }}({{ scope.row.channelPackageId | filterEmpty }})</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center">
                    <template slot="header">
                        <span>
                            新增(游客/注册)
                            <el-tooltip class="item" effect="dark" content="新增注册：之前下载安装的用户，在当日注册后，也会计入新增注册统计中" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ scope.row.newTourist | filterThousandths }}/{{ scope.row.newRegister | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center" label="启动活跃(游客/注册)">
                    <template slot-scope="scope">
                        <span>{{ scope.row.activeTouristLaunch | filterThousandths }}/{{ scope.row.activeRegisterLaunch | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" align="center" label="游戏活跃(游客/注册)">
                    <template slot-scope="scope">
                        <span>{{ scope.row.activeTouristGame | filterThousandths }}/{{ scope.row.activeRegisterGame | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="次留">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain1, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="2日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain2, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="3日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain3, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="4日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain4, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="5日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain5, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="6日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain6, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="7日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain7, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100px" align="center" label="15日留存">
                    <template slot-scope="scope">
                        <span>{{ getPercentage(scope.row.retain15, scope.row.newDistinct) }}</span>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import pagination from '@/components/Pagination'
import { userTypeConfig, terminalConfig } from '@/constant/game'
import * as api_channel from '@/api/channel'
import * as api from '@/api/statistics'
import * as XLSX from 'xlsx'
import FileSaver from 'file-saver'
import { deepClone } from '@/utils/object'
import { getChannelList, getPackageList } from '@/utils'
const defaultTableQuery = {
    page: 1,
    size: 10,
    sort: 'id;desc',
    all: false,
    date: [],
    channelId: undefined,
    channelPackageId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {
        pagination,
        DateRangePicker
    },
    mixins: [Base],

    data() {
        return {
            pickerMinDate: '',
            pickerOptions: {
                onPick: (obj) => {
                    this.pickerMinDate = new Date(obj.minDate).getTime()
                },
                disabledDate: (time) => {
                    if (this.pickerMinDate) {
                        const day = 30 * 1000 * 24 * 3600
                        const maxTime = this.pickerMinDate + day
                        const minTime = this.pickerMinDate - day
                        return time.getTime() >= maxTime || time.getTime() <= minTime
                    }
                }
            },
            loading: false,
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: defaultTableQuery,
            channels: [],
            channelPackages: [],
            versions: [],
            total: 0,
            list: []
        }
    },
    computed: {},

    mounted() {
        this.fixed_height = 400
        var start = new Date().daysAgo(15).format('yyyy-MM-dd')
        var end = new Date().daysAgo(1).format('yyyy-MM-dd')
        this.query.date = [start, end]
        this.getVersion()
        this.getChannel()
    },
    methods: {
        getVersion() {
            api.statsVersions()
                .then((rep) => {
                    this.versions = rep.data
                })
                .catch(() => {})
        },

        setPackage() {
            if (this.channelPackages.length) {
                this.query.channelPackageId = this.channelPackages[0].id
                this.toQuery()
            }
        },

        async getChannel() {
            this.channels = await getChannelList()

            if (this.channels.length) {
                this.query.channelId = this.channels[0].id
                this.getChannelPackage(null, true)
            }
        },

        /** 查询渠道包列表 */
        changeChannel() {
            this.query.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage(null, true)
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        /**
         * init 是否需要设置默认包
         */
        async getChannelPackage(name, init) {
            if (this.checkPermission([this.permission.statsChannelPackageList])) {
                this.channelPackages = await getPackageList(this.query.channelId, name)
                init && this.setPackage()
            } else {
                this.channelPackages = []
            }
        },
        exportExcel() {
            this.$nextTick(() => {
                var wb = XLSX.utils.table_to_book(document.querySelector('.channel_table'))
                var wbout = XLSX.write(wb, {
                    bookType: 'xlsx',
                    bookSST: true,
                    type: 'array'
                })
                try {
                    FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), '渠道包新增活跃留存' + '.xlsx')
                } catch (e) {
                    if (typeof console !== 'undefined') console.log(e, wbout)
                }
                return wbout
            })
        },
        resetQuery() {
            this.query = deepClone(defaultTableQuery)
            var start = new Date().daysAgo(15).format('yyyy-MM-dd')
            var end = new Date().daysAgo(1).format('yyyy-MM-dd')
            this.query.date = [start, end]
            if (this.channels.length) {
                this.query.channelId = this.channels[0].id
                this.getChannelPackage(null, true)
            }
        },
        toQuery(tag) {
            if (!tag) {
                this.query.page = 1
            }
            if (!this.query.channelId || !this.query.channelPackageId) return

            if (this.checkPermission([this.permission.statsChannelPackage])) {
                this.loading = true
                api.statsStatsChannelPackage(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.data_channel_package_active {
    .channel_package_active {
        margin-top: 30px;
        width: 100%;
    }
    .channel_table {
        margin-top: 10px;
    }
}
.export_button {
    background: transparent;
    border: 1px solid $blue !important;
    margin-right: 20px;
}
</style>
