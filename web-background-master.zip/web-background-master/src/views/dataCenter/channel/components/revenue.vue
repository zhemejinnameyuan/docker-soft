<template>
    <div class="data_channel_revenue">
        <div class="channel_revenue head-container">
            <el-row>
                <DateRangePicker v-model="query.date" class="filter-item" :value-format="'yyyy-MM-dd'" :clearable="false" @change="toQuery" />
                <el-select v-model="query.userType" placeholder="全部用户" size="medium" class="filter-item" style="width: 160px" @change="toQuery" clearable>
                    <el-option v-for="item in userTypes" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <el-select
                    v-model="query.channelId"
                    v-permission="[permission.statsChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 160px"
                    clearable
                    @change="toQuery"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select v-model="query.terminal" placeholder="全部终端" size="medium" class="filter-item" style="width: 160px" clearable @change="toQuery">
                    <el-option v-for="item in terminals" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
            <el-row type="flex" justify="end">
                <IconButton class="export_button" size="medium" type="primary" icon="oms_ico_export" plain title="导出" @click="exportExcel" />
            </el-row>
        </div>

        <div class="channel_revenue_table">
            <el-table ref="table" v-loading="loading" class="game-table" :height="table_height" highlight-current-row style="width: 100%" :data="list">
                <el-table-column :show-overflow-tooltip="true" prop="day" width="120px" align="center" label="日期" />
                <el-table-column :show-overflow-tooltip="true" prop="terminal" width="120px" align="center" label="终端">
                    <template slot-scope="scope">
                        <span>{{ getArrayValue(terminalConfig, scope.row.terminal).name }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="120px" align="center" label="玩家类型">
                    <template slot-scope="scope">
                        <span>{{ getArrayValue(userTypeConfig, scope.row.userType).name }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="180px" prop="packageNumber" align="center" label="渠道(ID)">
                    <template slot-scope="scope">
                        <span>{{ scope.row.channelName }}({{ scope.row.channelId }})</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" align="center">
                    <template slot="header">
                        <span>
                            充值人数/新增充值人数
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="充值人数：指当天有充值行为充值成功的人数，根据ID去重；新增充值人数：新增充值人数：指当日新增用户，且当天有过成功充值行为的人数"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ scope.row.rechargeNum | filterThousandths }}/{{ scope.row.newRechargeNum | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" align="center">
                    <template slot="header">
                        <span>
                            充值金额/新增充值金额
                            <el-tooltip class="item" effect="dark" content="指当日充值成功的金额统计" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ fenToYuan(scope.row.rechargeAmount) | filterThousandths }} / {{ fenToYuan(scope.row.newRechargeAmount) | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200px" align="center">
                    <template slot="header">
                        <span>
                            付费率/新用户/老用户
                            <el-tooltip
                                class="item"
                                effect="dark"
                                content="付费率=当日充值总人数/当日活跃用户数*100%；新用户付费率=新增充值人数/当日新增人数*100%；老用户付费率=(当日充值人数-当日新增充值人数)/当日充值人数*100%"
                                placement="top"
                            >
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ scope.row.payRate }}% / {{ scope.row.newPayRate }}% /{{ scope.row.oldPayRate }}%</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140px" align="center">
                    <template slot="header">
                        <span>
                            ARRPU
                            <el-tooltip class="item" effect="dark" content="ARRPU：平均每付费用户收入=当日充值金额/当日充值人数" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ fenToYuan(scope.row.arrpu) | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140px" align="center">
                    <template slot="header">
                        <span>
                            ARPU
                            <el-tooltip class="item" effect="dark" content="ARPU：平均用户收入=当日充值金额/当日活跃人数" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ fenToYuan(scope.row.arpu) | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140px" align="center">
                    <template slot="header">
                        <span>
                            退款人数
                            <el-tooltip class="item" effect="dark" content="指当日有退款行为且平台账户已完成退款金额扣除的人数" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ scope.row.withdrawUserNum | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140px" align="center">
                    <template slot="header">
                        <span>
                            退款金额
                            <el-tooltip class="item" effect="dark" content="指当日有退款行为且平台账户已完成退款金额扣除的总退款金额数" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ fenToYuan(scope.row.withdrawAmount) | filterThousandths }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="140px" align="center">
                    <template slot="header">
                        <span>
                            净收入
                            <el-tooltip class="item" effect="dark" content="净收入=当日充值金额-当日退款金额" placement="top">
                                <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                            </el-tooltip>
                        </span>
                    </template>
                    <template slot-scope="scope">
                        <span>{{ fenToYuan(scope.row.netIncome) | filterThousandths }}</span>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import DateRangePicker from '@/components/DateRangePicker'
import pagination from '@/components/Pagination'
import { userTypeConfig, terminalConfig } from '@/constant/game'
import * as api from '@/api/statistics'
import * as XLSX from 'xlsx'
import FileSaver from 'file-saver'
import { deepClone } from '@/utils/object'
import { getChannelList } from '@/utils'
const defaultTableQuery = {
    page: 1,
    size: 10,
    sort: 'id;desc',
    all: false,
    date: [],
    userType: null,
    channelId: undefined,
    terminal: undefined,
    version: undefined
}
export default {
    components: {
        pagination,
        DateRangePicker
    },
    mixins: [Base],

    data() {
        return {
            terminalConfig,
            userTypeConfig,
            loading: false,
            userTypes: Object.values(userTypeConfig),
            terminals: Object.values(terminalConfig),
            query: defaultTableQuery,
            channels: [],
            total: 0,
            list: []
        }
    },
    computed: {},

    mounted() {
        this.fixed_height = 370
        this.getChannel()
        this.resetQuery()
    },
    methods: {
        async getChannel() {
            if (this.checkPermission([this.permission.statsChannelList])) {
                this.channels = await getChannelList()
            }
        },
        exportExcel() {
            this.$nextTick(() => {
                var wb = XLSX.utils.table_to_book(document.querySelector('.channel_revenue_table'))
                var wbout = XLSX.write(wb, {
                    bookType: 'xlsx',
                    bookSST: true,
                    type: 'array'
                })
                try {
                    FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), '渠道营收统计' + '.xlsx')
                } catch (e) {
                    if (typeof console !== 'undefined') console.log(e, wbout)
                }
                return wbout
            })
        },
        resetQuery() {
            this.query = deepClone(defaultTableQuery)
            var start = new Date().daysAgo(15).format('yyyy-MM-dd')
            var end = new Date().daysAgo(1).format('yyyy-MM-dd')
            this.query.date = [start, end]
            this.toQuery()
        },
        toQuery(tag) {
            if (!tag) {
                this.query.page = 1
            }
            let params = { ...this.query }
            params.channelId = params.channelId ? _.toNumber(params.channelId) : 0
            params.channelPackageId = params.channelPackageId ? _.toNumber(params.channelPackageId) : 0

            if (this.checkPermission([this.permission.statsChannelRevenue])) {
                this.loading = true
                api.statsChannelRevenue(params)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/variables.scss';
.data_channel_revenue {
    .channel_revenue {
        margin-top: 30px;
        width: 100%;
    }
    .channel_table {
        margin-top: 20px;
    }
}
.export_button {
    background: transparent;
    border: 1px solid $blue !important;
}
</style>
