<template>
    <div class="app-container data_center_channel">
        <el-radio-group v-model="type" size="medium">
            <el-radio-button label="active" v-permission="[permission.statsChannel]">新增活跃留存</el-radio-button>
            <el-radio-button label="revenue" v-permission="[permission.statsChannelRevenue]">营收统计</el-radio-button>
        </el-radio-group>
        <Active v-if="type == 'active'" v-permission="[permission.statsChannel]" />
        <Revenue v-if="type == 'revenue'" v-permission="[permission.statsChannelRevenue]" />
    </div>
</template>
<script>
import Base from '@/views/base'
import Active from './components/active.vue'
import Revenue from './components/revenue.vue'
export default {
    name: 'DataChannel',
    components: {
        Active,
        Revenue
    },
    mixins: [Base],
    data() {
        return {
            type: ''
        }
    },
    mounted() {
        if (this.checkPermission([this.permission.statsChannel])) {
            this.type = 'active'
        } else if (this.checkPermission([this.permission.statsChannelRevenue])) {
            this.type = 'revenue'
        }
    }
}
</script>

<style lang="scss" scoped>
.data_center_channel {
}
::v-deep .el-radio-button__inner {
    width: 160px;
    height: 40px;
    line-height: initial;
    background: #f7f7f7;
    font-size: 16px !important;
    font-weight: 500;
    padding: 8px 20px !important;
}
</style>
