<template>
    <div class="login" :style="'background-image:url(' + Background + ');'">
        <div class="login-div">
            <el-form ref="loginForm" :model="loginForm" :rules="loginRules" label-position="left" label-width="0px" class="login-form">
                <div style="text-align: center">
                    <div class="title">管理后台</div>
                </div>
                <el-form-item prop="username">
                    <el-input v-model="loginForm.username" maxlength="32" type="text" auto-complete="off" placeholder="输入账号" />
                </el-form-item>
                <el-form-item prop="password">
                    <el-input v-model="loginForm.password" maxlength="64" type="password" auto-complete="off" placeholder="输入密码" show-password @keyup.enter.native="handleLogin" />
                </el-form-item>
                <el-form-item prop="code">
                    <el-input v-model="loginForm.code" maxlength="6" auto-complete="off" placeholder="输入验证码" @keyup.enter.native="handleLogin" />
                </el-form-item>
                <el-form-item style="width: 100%">
                    <el-button
                        :loading="loading"
                        size="medium"
                        style="width: 100%; height: 60px; border-radius: 8px; background-color: #1ba2ff; font-size: 20px; font-weight: 500"
                        @click.native.prevent="handleLogin"
                    >
                        <span v-if="!loading" style="color: #ffffff">登 录</span>
                        <span v-else style="color: #5c8eea">登 录 中...</span>
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
        <!--  底部  -->
        <div v-if="$store.state.settings.showFooter" id="el-login-footer">
            <span v-html="$store.state.settings.footerTxt" />
            <a href="#" target="_blank">{{ $store.state.settings.caseNumber }}</a>
        </div>
    </div>
</template>

<script>
import Background from '@/assets/images/background.png'
import { rsaEncrypt } from '@/utils/rsaEncrypt'

export default {
    name: 'Login',
    data() {
        return {
            Background: Background,
            captchaImg: '',
            cookiePass: '',
            loginForm: {
                username: '',
                password: '',
                rememberMe: false,
                code: '',
                key: ''
            },
            loginRules: {
                username: [{ required: true, trigger: 'blur', message: '账号不能为空' }],
                password: [{ required: true, trigger: 'blur', message: '密码不能为空' }],
                code: [{ required: true, trigger: 'change', message: '验证码不能为空' }]
            },
            loading: false,
            redirect: undefined
        }
    },
    watch: {
        $route: {
            handler: function (route) {
                this.redirect = route.query && route.query.redirect
            },
            immediate: true
        }
    },
    created() {},
    methods: {
        handleLogin() {
            this.$refs.loginForm.validate((valid) => {
                const loginInfo = {
                    username: this.loginForm.username,
                    password: this.loginForm.password,
                    rememberMe: this.loginForm.rememberMe,
                    code: this.loginForm.code,
                    key: this.loginForm.key
                }
                if (loginInfo.password !== this.cookiePass) {
                    loginInfo.password = rsaEncrypt(loginInfo.password)
                }
                if (valid) {
                    this.loading = true

                    this.$store
                        .dispatch('Login', loginInfo)
                        .then(() => {
                            this.loading = false
                            this.$router
                                .push({ path: this.redirect || '/' })
                                .then(() => {})
                                .catch(() => {})
                        })
                        .catch((e) => {
                            this.loading = false
                        })
                } else {
                    return false
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.login {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    background-size: cover;
    color: #333333;
    .login-div {
        margin-left: 58%;
    }

    .title {
        height: 72px;
        line-height: 72px;
        text-align: center;
        font-size: 50px;
        color: #000000;
        font-weight: 500;
        margin-bottom: 60px;
    }

    .login-form {
        border-radius: 24px;
        width: 450px;
        .el-form-item {
            margin-bottom: 0px;
        }
        .el-input {
            width: 450px;
            height: 60px;
            font-size: 18px;
            margin-bottom: 48px;

            ::v-deep input {
                height: 60px;
            }
            ::v-deep .el-input__inner {
                border: 1px solid rgba(140, 186, 255, 1);
                background: #f7f7f7;
                border-radius: 8px;
            }
        }
    }
}
</style>
