<template>
    <div class="home_pay">
        <!--工具栏-->
        <div class="head">
            <div class="head_left">
                <span class="line" />
                <span class="title">付费情况</span>
                <span class="des">每10分钟刷新一次数据</span>
            </div>
            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" @click="toQuery" />
        </div>
        <div class="splite_line" />
        <div class="dp-c mt-30">
            <div class="pay_top dp-c">
                <div class="dp-f">
                    <div class="dp-c" style="width: 200px">
                        <span class="max_title">累计付费人数</span>
                        <span class="max_number mt-10">{{ dataObj.rechargeNum | filterThousandths }}</span>
                    </div>
                    <div class="dp-c ml-20" style="width: 200px">
                        <span class="max_title">累计付费金额</span>
                        <span class="max_number mt-10">{{ fenToYuan(dataObj.rechargeAmount) | filterThousandths }}</span>
                    </div>
                </div>

                <div class="dp-f mt-30">
                    <div class="dp-c" style="width: 200px">
                        <span class="min_title">ARPU(每用户平均收益)</span>
                        <span class="min_number mt-10">{{ fenToYuan(dataObj.arpu) | filterThousandths }}</span>
                    </div>
                    <div class="dp-c ml-20" style="width: 200px">
                        <span class="min_title">ARPPU（付费用户平均收入）</span>
                        <span class="min_number mt-10">{{ fenToYuan(dataObj.arrpu) | filterThousandths }}</span>
                    </div>
                </div>
            </div>

            <div class="pay_bottom dp-f">
                <div id="pay-user-chart" style="width: 230px; height: 330px"></div>
                <div class="ml-30" id="pay-terminal-chart" style="width: 230px; height: 330px"></div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import * as echarts from 'echarts'
import { TERMINAL_TYPE } from '@/constant/game'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            payUserChart: '',
            payTerminalChart: ''
        }
    },
    mounted() {
        this.initUserChart()
        this.initTerminalChart()
    },
    updated() {
        this.initUserChart()
        this.initTerminalChart()
    },
    methods: {
        toQuery() {
            this.$emit('queryData')
        },
        initUserChart() {
            if (!this.payUserChart) {
                this.payUserChart = echarts.init(document.getElementById('pay-user-chart'))
            }
            // 指定图表的配置项和数据
            const option = {
                title: {
                    text: '付费用户占比',
                    left: '25%',
                    top: '90%'
                },
                color: ['#F7CF05', '#02E3CD'],
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    top: '43%',
                    left: 'center',
                    selectedMode: true,
                    itemWidth: 12,
                    itemHeight: 12,
                    borderRadius: 10
                },
                series: [
                    {
                        name: '付费用户占比',
                        type: 'pie',
                        radius: ['50%', '80%'],
                        avoidLabelOverlap: false,
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: this.dataObj.rechargeNum, name: '付费用户' },
                            { value: this.dataObj.notRechargeNum, name: '未付费用户' }
                        ]
                    }
                ]
            }
            this.payUserChart.setOption(option)
        },
        initTerminalChart() {
            if (!this.payTerminalChart) {
                this.payTerminalChart = echarts.init(document.getElementById('pay-terminal-chart'))
            }
            let androidData = 0
            let h5Data = 0
            let terminalUserNum = this.dataObj.terminalUserNum

            if (terminalUserNum) {
                for (let i = 0; i < terminalUserNum.length; i++) {
                    let num = terminalUserNum[i]['rechargeNum']
                    switch (terminalUserNum[i]['terminal']) {
                        case TERMINAL_TYPE.ANDROID:
                            androidData = num
                            break
                        case TERMINAL_TYPE.H5:
                            h5Data = num
                            break
                    }
                }
            }

            // 指定图表的配置项和数据
            const option = {
                title: {
                    text: '付费终端占比',
                    left: '25%',
                    top: '90%'
                },
                color: ['#3E7FFF', '#FF9823'],
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    top: '43%',
                    left: 'center',
                    selectedMode: true,
                    itemWidth: 12,
                    itemHeight: 12
                },
                series: [
                    {
                        name: '付费终端占比',
                        type: 'pie',
                        radius: ['50%', '80%'],
                        avoidLabelOverlap: false,
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: androidData, name: '安卓用户' },
                            { value: h5Data, name: 'H5用户' }
                        ]
                    }
                ]
            }
            this.payTerminalChart.setOption(option)
        }
    }
}
</script>

<style lang="scss" scoped>
.home_pay {
    width: 950px;
    background: #ffffff;
    border-radius: 4px;
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    .head {
        width: 100%;
        height: 49px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0px 34px 0px 10px;
        .head_left {
            display: flex;
            align-items: center;
            .line {
                display: flex;
                height: 16px;
                width: 4px;
                background: #1bc843;
                border-radius: 3px;
            }
            .title {
                font-size: 16px;
                color: #282829;
                letter-spacing: 0;
                text-align: center;
                font-weight: 500;
                margin-left: 16px;
            }
            .des {
                height: 22px;
                padding: 0px 10px;
                background: #f0f2f7;
                border-radius: 11px;
                margin-left: 10px;
                font-size: 10px;
                color: #a1a4a7;
                letter-spacing: 0;
                text-align: center;
                font-weight: 400;
                line-height: 22px;
            }
        }
        .refresh {
            font-size: 20px;
        }
    }
    .splite_line {
        display: flex;
        width: 520px;
        height: 1px;
        background: #f0f2f7;
    }

    .pay_top {
        padding: 20px 40px 20px 40px;
        background: rgba(34, 221, 77, 0.08);
        border-radius: 4px;
        height: 190px;
        width: 510px;

        .max_title {
            font-family: PingFangSC-Medium;
            font-size: 16px;
            color: #282829;
            letter-spacing: 0;
            font-weight: 500;
        }
        .max_number {
            font-family: PingFangSC-Medium;
            font-size: 24px;
            color: #1bc843;
            letter-spacing: 0;
            font-weight: 500;
        }
        .min_title {
            font-family: PingFangSC-Regular;
            font-size: 14px;
            color: #282829;
            letter-spacing: 0;
            font-weight: 400;
        }
        .min_number {
            font-family: PingFangSC-Medium;
            font-size: 16px;
            color: #1bc843;
            letter-spacing: 0;
            font-weight: 500;
        }
    }

    .pay_bottom {
        height: 330px;
        width: 510px;
    }
}
</style>
