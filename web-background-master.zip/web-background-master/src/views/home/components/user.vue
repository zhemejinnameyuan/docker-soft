<template>
    <div class="home_user">
        <!--工具栏-->
        <div class="head">
            <div class="head_left">
                <span class="line" />
                <span class="title">用户总数</span>
                <span class="des">截止到昨天23:59:59的用户汇总数据，次日凌晨3点出统计结果</span>
            </div>
            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
        </div>
        <div class="splite_line" />
        <div class="user_content">
            <div class="user_content_frist">
                <div class="user_add">
                    <div class="dp_r">
                        <span class="user_title">总用户数</span>
                    </div>
                    <span class="user_title_max mt-10">{{ dataObj.totalUser | filterThousandths }}</span>
                </div>
            </div>
            <div class="user_content_last">
                <div class="user_add">
                    <div class="dp_r">
                        <span class="user_title">总设备数</span>
                        <el-tooltip class="item" effect="dark" content="总设备数=用户列表终端去重汇总+安装未进入大厅用户(未生成用户ID，用户列表无该数据)" placement="right">
                            <svg-icon icon-class="oms_ico_query" style="font-size: 14px; margin-left: 6px; cursor: pointer" />
                        </el-tooltip>
                    </div>
                    <span class="user_title_max mt-10">{{ dataObj.totalDevice | filterThousandths }}</span>
                </div>
                <div class="user_line" />
                <div class="user_add">
                    <span class="user_title_min">注册用户</span>
                    <span class="user_title_mid mt-5">{{ dataObj.totalRegister | filterThousandths }}</span>
                    <span class="user_title_des mt-5">注册占比：{{ getPercentage(dataObj.totalRegister, dataObj.totalUser) }}</span>
                </div>
                <div class="user_add">
                    <span class="user_title_min">
                        游客用户
                        <el-tooltip
                            class="item"
                            effect="dark"
                            content="游客用户=用户列表中真实的游客数(若游客用户从列表删除，将不计入统计，游客每日新增明细汇总会大于游客用户数，每日明细中会存在游客转注册用户情况)"
                            placement="right"
                        >
                            <svg-icon icon-class="oms_ico_query" style="font-size: 14px; margin-left: 6px; cursor: pointer" />
                        </el-tooltip>
                    </span>
                    <span class="user_title_mid mt-5" style="color: #686b6d">{{ dataObj.totalTourist | filterThousandths }}</span>
                    <span class="user_title_des mt-5">游客占比：{{ getPercentage(dataObj.totalTourist, dataObj.totalUser) }}</span>
                </div>
                <div class="user_line" />
                <div class="user_add">
                    <span class="user_title_min">安卓用户</span>
                    <span class="user_title_mid mt-5">{{ dataObj.totalAndroid | filterThousandths }}</span>
                    <span class="user_title_des mt-5">安卓占比：{{ getPercentage(dataObj.totalAndroid, dataObj.totalUser) }}</span>
                </div>
                <div class="user_add">
                    <span class="user_title_min">H5用户</span>
                    <span class="user_title_mid mt-5" style="color: #686b6d">{{ dataObj.totalH5 | filterThousandths }}</span>
                    <span class="user_title_des mt-5">H5占比：{{ getPercentage(dataObj.totalH5, dataObj.totalUser) }}</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        }
    }
}
</script>

<style lang="scss" scoped>
.home_user {
    width: 950px;
    background: #ffffff;
    border-radius: 4px;
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    .head {
        width: 100%;
        height: 49px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0px 34px 0px 10px;
        .head_left {
            display: flex;
            align-items: center;
            .line {
                display: flex;
                height: 16px;
                width: 4px;
                background: #ffb900;
                border-radius: 3px;
            }
            .title {
                font-size: 16px;
                color: #282829;
                letter-spacing: 0;
                text-align: center;
                font-weight: 500;
                margin-left: 16px;
            }
            .des {
                height: 22px;
                padding: 0px 10px;
                background: #f0f2f7;
                border-radius: 11px;
                margin-left: 10px;
                font-size: 10px;
                color: #a1a4a7;
                letter-spacing: 0;
                text-align: center;
                font-weight: 400;
                line-height: 22px;
            }
        }
        .refresh {
            font-size: 20px;
        }
    }
    .splite_line {
        display: flex;
        width: 890px;
        height: 1px;
        background: #f0f2f7;
    }
    .user_content {
        width: 100%;
        display: flex;
        padding: 20px 30px 30px 30px;
        justify-content: space-between;
        .user_content_frist {
            width: 170px;
            height: 110px;
            background: rgba(255, 199, 0, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 20px;
        }
        .user_content_last {
            width: 710px;
            height: 110px;
            background: rgba(255, 199, 0, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 20px;
        }
    }
    .user_add {
        display: flex;
        flex-direction: column;
    }
    .dp_r {
        display: flex;
        align-items: center;
    }
    .user_title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        text-align: center;
        font-weight: 500;
    }

    .user_title_des {
        font-size: 12px;
        color: #686b6d;
        letter-spacing: 0;
        font-weight: 400;
    }
    .user_title_max {
        font-size: 24px;
        color: #ffb900;
        letter-spacing: 0;
        line-height: 28px;
        font-weight: 500;
    }
    .user_title_mid {
        font-size: 18px;
        color: #d8a51c;
        letter-spacing: 0;
        font-weight: 500;
    }
    .user_title_min {
        font-size: 14px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .user_line {
        width: 1px;
        height: 44px;
        background: rgba(255, 185, 0, 0.3);
    }
}
</style>
