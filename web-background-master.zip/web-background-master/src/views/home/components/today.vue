<template>
    <div class="home_today">
        <!--工具栏-->
        <div class="head">
            <div class="head_left">
                <span class="line" />
                <span class="title">每日概览</span>
                <span class="des">截止到昨天23:59:59的用户汇总数据，次日凌晨3点出统计结果</span>
            </div>
            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
        </div>
        <div class="splite_line" />
        <div class="today_content">
            <div class="today_content_frist">
                <div class="today_add" style="width: 124px">
                    <div class="dp_r">
                        <span class="today_title">昨日新增</span>
                    </div>
                    <span class="today_title_max mt-5">{{ dataObj.currNew | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon v-if="getMm(dataObj.currNew, dataObj.beforeNew)" class="trend" :icon-class="getIcon(dataObj.currNew, dataObj.beforeNew)" />
                        <span class="today_title_min" :class="getPColor(dataObj.currNew, dataObj.beforeNew)">
                            {{ getPercentageRatio(dataObj.currNew, dataObj.beforeNew) }}
                        </span>
                    </span>
                </div>
                <div class="today_line" />
                <div class="today_add" style="margin-left: 20px; width: 100px">
                    <span class="today_title_min">注册新增</span>
                    <span class="today_title_mid mt-5">{{ dataObj.currNewRegister | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon v-if="getMm(dataObj.currNewRegister, dataObj.beforeNewRegister)" class="trend" :icon-class="getIcon(dataObj.currNewRegister, dataObj.beforeNewRegister)" />
                        <span class="today_title_min" :class="getPColor(dataObj.currNewRegister, dataObj.beforeNewRegister)">
                            {{ getPercentageRatio(dataObj.currNewRegister, dataObj.beforeNewRegister) }}
                        </span>
                    </span>
                </div>
                <div class="today_add">
                    <span class="today_title_min">游客新增</span>
                    <span class="today_title_mid mt-5" style="color: #686b6d">{{ dataObj.currNewTourist | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon v-if="getMm(dataObj.currNewTourist, dataObj.beforeNewTourist)" class="trend" :icon-class="getIcon(dataObj.currNewTourist, dataObj.beforeNewTourist)" />
                        <span class="today_title_min" :class="getPColor(dataObj.currNewTourist, dataObj.beforeNewTourist)">
                            {{ getPercentageRatio(dataObj.currNewTourist, dataObj.beforeNewTourist) }}
                        </span>
                    </span>
                </div>
            </div>
            <div class="today_content_frist">
                <div class="today_add" style="width: 124px">
                    <div class="dp_r">
                        <span class="today_title">昨日日活</span>
                    </div>
                    <span class="today_title_max mt-5">{{ dataObj.currActive | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon v-if="getMm(dataObj.currActive, dataObj.beforeActive)" class="trend" :icon-class="getIcon(dataObj.currActive, dataObj.beforeActive)" />
                        <span class="today_title_min" :class="getPColor(dataObj.currActive, dataObj.beforeActive)">
                            {{ getPercentageRatio(dataObj.currActive, dataObj.beforeActive) }}
                        </span>
                    </span>
                </div>
                <div class="today_line" />
                <div class="today_add" style="margin-left: 20px; width: 100px">
                    <span class="today_title_min">注册活跃</span>
                    <span class="today_title_mid mt-5">{{ dataObj.currActiveRegister | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon
                            v-if="getMm(dataObj.currActiveRegister, dataObj.beforeActiveRegister)"
                            class="trend"
                            :icon-class="getIcon(dataObj.currActiveRegister, dataObj.beforeActiveRegister)"
                        />
                        <span :class="getPColor(dataObj.currActiveRegister, dataObj.beforeActiveRegister)" class="today_title_min">
                            {{ getPercentageRatio(dataObj.currActiveRegister, dataObj.beforeActiveRegister) }}
                        </span>
                    </span>
                </div>
                <div class="today_add">
                    <span class="today_title_min">游客活跃</span>
                    <span class="today_title_mid mt-5" style="color: #686b6d">{{ dataObj.currActiveTourist | filterThousandths }}</span>
                    <span class="dp_r mt-5">
                        <svg-icon v-if="getMm(dataObj.currActiveTourist, dataObj.beforeActiveTourist)" class="trend" :icon-class="getIcon(dataObj.currActiveTourist, dataObj.beforeActiveTourist)" />
                        <span :class="getPColor(dataObj.currActiveTourist, dataObj.beforeActiveTourist)" class="today_title_min">
                            {{ getPercentageRatio(dataObj.currActiveTourist, dataObj.beforeActiveTourist) }}
                        </span>
                    </span>
                </div>
            </div>
            <div class="today_content_last">
                <div class="today_add">
                    <div class="dp_r">
                        <span class="today_title">前日次留</span>
                        <svg-icon class="trend" :icon-class="getcclIcon(dataObj)" />
                    </div>
                    <span class="today_title_max mt-10">
                        <span :class="getcclColor(dataObj)">{{ getPercentage(dataObj.beforeRetain1, dataObj.beforeNew) }}</span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import { isEmpty } from '@/utils/typeof'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        },

        getMm(val1, val2) {
            const val = val1 - val2
            return val !== 0
        },
        getIcon(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'oms_ico_shangsheng'
            } else if (val < 0) {
                return 'oms_ico_xiajiang'
            }
            return ''
        },
        getPColor(val1, val2) {
            const val = val1 - val2
            if (val > 0) {
                return 'red_label'
            } else if (val < 0) {
                return 'green_label'
            }
            return ''
        },
        getccl(dataObj) {
            var { beforeRetain1, beforeBeforeRetain1, beforeNew, beforeBeforeNew } = dataObj
            if (isEmpty(beforeRetain1) || isEmpty(beforeNew) || isEmpty(beforeBeforeRetain1) || isEmpty(beforeBeforeNew)) {
                return null
            }
            var b
            if (beforeRetain1 === 0 || beforeNew === 0) {
                b = 0
            } else {
                b = beforeRetain1 / beforeNew
            }

            var bb
            if (beforeBeforeRetain1 === 0 || beforeBeforeNew === 0) {
                bb = 0
            } else {
                bb = beforeBeforeRetain1 / beforeBeforeNew
            }

            return ((b - bb) * 100).toFixed(2)
        },
        getcclColor(dataObj) {
            var val = this.getccl(dataObj)
            if (val > 0) {
                return 'red_label'
            } else if (val < 0) {
                return 'green_label'
            }
            return ''
        },
        getcclIcon(dataObj) {
            var val = this.getccl(dataObj)
            if (val > 0) {
                return 'oms_ico_shangsheng'
            } else if (val < 0) {
                return 'oms_ico_xiajiang'
            }
            return ''
        }
    }
}
</script>

<style lang="scss" scoped>
.home_today {
    width: 950px;
    background: #ffffff;
    border-radius: 4px;
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    .head {
        width: 100%;
        height: 49px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0px 34px 0px 10px;
        .head_left {
            display: flex;
            align-items: center;
            .line {
                display: flex;
                height: 16px;
                width: 4px;
                background: #1ba2ff;
                border-radius: 3px;
            }
            .title {
                font-size: 16px;
                color: #282829;
                letter-spacing: 0;
                text-align: center;
                font-weight: 500;
                margin-left: 16px;
            }
            .des {
                height: 22px;
                padding: 0px 10px;
                background: #f0f2f7;
                border-radius: 11px;
                margin-left: 10px;
                font-size: 10px;
                color: #a1a4a7;
                letter-spacing: 0;
                text-align: center;
                font-weight: 400;
                line-height: 22px;
            }
        }
        .refresh {
            font-size: 20px;
        }
    }
    .splite_line {
        display: flex;
        width: 890px;
        height: 1px;
        background: #f0f2f7;
    }
    .today_content {
        width: 100%;
        display: flex;
        padding: 20px 30px 30px 30px;
        justify-content: space-between;
        .today_content_frist {
            width: 360px;
            height: 110px;
            background: rgba(27, 162, 255, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            padding: 20px 20px;
        }
        .today_content_last {
            width: 150px;
            height: 110px;
            background: rgba(27, 162, 255, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 20px;
        }
    }
    .today_add {
        display: flex;
        flex-direction: column;
    }
    .dp_r {
        display: flex;
        align-items: center;
    }
    .today_title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        text-align: center;
        font-weight: 500;
        margin-right: 3px;
    }

    .today_title_red {
        font-size: 12px;
        line-height: 12px;
        color: #ff5050;
        letter-spacing: 0;
        font-weight: 400;
        margin-left: 3px;
    }
    .today_title_green {
        font-size: 12px;
        line-height: 12px;
        color: #56d970;
        letter-spacing: 0;
        font-weight: 400;
        margin-left: 3px;
    }
    .today_title_max {
        font-size: 24px;
        color: #1ba2ff;
        letter-spacing: 0;
        line-height: 28px;
        height: 28px;
        font-weight: 500;
    }
    .today_title_mid {
        font-size: 18px;
        color: #1a82c9;
        letter-spacing: 0;
        font-weight: 500;
    }
    .today_title_min {
        font-size: 14px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .today_line {
        width: 1px;
        height: 44px;
        background: rgba(27, 162, 255, 0.2);
    }
    .trend {
        font-size: 10px;
        line-height: 10px;
    }
    .red_label {
        color: #ff5050;
    }
    .green_label {
        color: #56d970;
    }
}
</style>
