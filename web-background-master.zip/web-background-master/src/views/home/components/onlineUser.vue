<template>
    <div class="home_online_user">
        <!--工具栏-->
        <div class="head">
            <div class="head_left">
                <span class="line" />
                <span class="title">在线用户数</span>
                <span class="des">每10分钟刷新一次数据</span>
            </div>
            <IconButton class="refresh" size="medium" type="text" icon="oms_ico_reset" :loading="loading" @click="toQuery" />
        </div>
        <div class="splite_line" />
        <div class="online_user_content">
            <div class="online_user_content_frist">
                <div class="online_user_add">
                    <div class="dp_r">
                        <span class="online_user_title">实时在线用户</span>
                    </div>
                    <span class="online_user_title_max mt-10">{{ dataObj.onlineUser | filterThousandths }}</span>
                </div>
            </div>
            <div class="online_user_content_last">
                <div class="online_user_add">
                    <div class="dp_r">
                        <span class="online_user_title">注册用户</span>
                    </div>
                    <span class="online_user_title_max mt-10">{{ dataObj.onlineRegister | filterThousandths }}</span>
                </div>
                <div class="online_user_line" />
                <div class="online_user_add">
                    <span class="online_user_title_min">安卓</span>
                    <span class="online_user_title_mid mt-5">{{ dataObj.onlineRegisterAndroid | filterThousandths }}</span>
                    <span class="online_user_title_des mt-5">安卓占比：{{ getPercentage(dataObj.onlineRegisterAndroid, dataObj.onlineRegister) }}</span>
                </div>
                <div class="online_user_add">
                    <span class="online_user_title_min">H5</span>
                    <span class="online_user_title_mid mt-5" style="color: #686b6d">{{ dataObj.onlineRegisterH5 | filterThousandths }}</span>
                    <span class="online_user_title_des mt-5">H5占比：{{ getPercentage(dataObj.onlineRegisterH5, dataObj.onlineRegister) }}</span>
                </div>
                <div class="online_user_line" />
                <div class="online_user_add">
                    <div class="dp_r">
                        <span class="online_user_title">游客用户</span>
                    </div>
                    <span class="online_user_title_max mt-10">{{ dataObj.onlineTourist | filterThousandths }}</span>
                </div>
                <div class="online_user_add">
                    <span class="online_user_title_min">安卓</span>
                    <span class="online_user_title_mid mt-5">{{ dataObj.onlineTouristAndroid | filterThousandths }}</span>
                    <span class="online_user_title_des mt-5">安卓占比：{{ getPercentage(dataObj.onlineTouristAndroid, dataObj.onlineTourist) }}</span>
                </div>
                <div class="online_user_add">
                    <span class="online_user_title_min">H5</span>
                    <span class="online_user_title_mid mt-5" style="color: #686b6d">{{ dataObj.onlineTouristH5 | filterThousandths }}</span>
                    <span class="online_user_title_des mt-5">H5占比：{{ getPercentage(dataObj.onlineTouristH5, dataObj.onlineTourist) }}</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
export default {
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            ad: undefined,
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 1000)
            this.$emit('queryData')
        }
    }
}
</script>

<style lang="scss" scoped>
.home_online_user {
    width: 950px;
    background: #ffffff;
    border-radius: 4px;
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    .head {
        width: 100%;
        height: 49px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0px 34px 0px 10px;
        .head_left {
            display: flex;
            align-items: center;
            .line {
                display: flex;
                height: 16px;
                width: 4px;
                background: #fb8316;
                border-radius: 3px;
            }
            .title {
                font-size: 16px;
                color: #282829;
                letter-spacing: 0;
                text-align: center;
                font-weight: 500;
                margin-left: 16px;
            }
            .des {
                height: 22px;
                padding: 0px 10px;
                background: #f0f2f7;
                border-radius: 11px;
                margin-left: 10px;
                font-size: 10px;
                color: #a1a4a7;
                letter-spacing: 0;
                text-align: center;
                font-weight: 400;
                line-height: 22px;
            }
        }
        .refresh {
            font-size: 20px;
        }
    }
    .splite_line {
        display: flex;
        width: 890px;
        height: 1px;
        background: #f0f2f7;
    }
    .online_user_content {
        width: 100%;
        display: flex;
        padding: 20px 30px 30px 30px;
        justify-content: space-between;
        .online_user_content_frist {
            width: 170px;
            height: 110px;
            background: rgba(255, 80, 41, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 20px;
        }
        .online_user_content_last {
            width: 710px;
            height: 110px;
            background: rgba(255, 80, 41, 0.08);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 20px;
        }
    }
    .online_user_add {
        display: flex;
        flex-direction: column;
    }
    .dp_r {
        display: flex;
        align-items: center;
    }
    .online_user_title {
        font-size: 16px;
        color: #282829;
        letter-spacing: 0;
        text-align: center;
        font-weight: 500;
    }

    .online_user_title_des {
        font-size: 12px;
        color: #686b6d;
        letter-spacing: 0;
        font-weight: 400;
    }
    .online_user_title_max {
        font-size: 24px;
        color: #fb8316;
        letter-spacing: 0;
        line-height: 28px;
        font-weight: 500;
    }
    .online_user_title_mid {
        font-size: 18px;
        color: #d37f32;
        letter-spacing: 0;
        font-weight: 500;
    }
    .online_user_title_min {
        font-size: 14px;
        color: #282829;
        letter-spacing: 0;
        font-weight: 400;
    }
    .online_user_line {
        width: 1px;
        height: 44px;
        background: rgba(255, 185, 0, 0.3);
    }
}
</style>
