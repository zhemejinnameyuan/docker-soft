<template>
    <div class="app-container home_bg">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <el-select
                    v-model="channelId"
                    v-permission="[permission.overviewChannelList]"
                    placeholder="全部渠道"
                    size="medium"
                    class="filter-item"
                    style="width: 160px"
                    clearable
                    @change="changeChannel"
                >
                    <el-option v-for="item in channels" :key="item.id" :label="item.channelName" :value="item.id" />
                </el-select>
                <el-select
                    v-model="channelPackageId"
                    v-permission="[permission.overviewChannelPackageList]"
                    placeholder="全部渠道包"
                    remote
                    filterable
                    size="medium"
                    class="filter-item"
                    :remote-method="getChannelPackage"
                    style="width: 160px"
                    clearable
                    @visible-change="showChannelPackage"
                    @change="toQuery"
                >
                    <el-option v-for="item in channelPackages" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="resetQuery" />
            </el-row>
        </div>
        <div class="home_f">
            <div class="home_f_left">
                <Today :data-obj="todayObj" @queryData="toQueryToday" />
                <User :data-obj="userObj" @queryData="toQueryUser" />
                <OnlineUser :data-obj="onlineObj" @queryData="toQueryOnline" />
            </div>
            <Pay class="home_f_right" :data-obj="payObj" @queryData="toPayData(false)" v-if="payShow" />
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import * as api from '@/api/statistics'
import Today from './components/today.vue'
import User from './components/user.vue'
import OnlineUser from './components/onlineUser.vue'
import Pay from './components/pay.vue'
import { getChannelList, getPackageList } from '@/utils'
export default {
    name: 'Home',
    components: {
        Today,
        User,
        OnlineUser,
        Pay
    },
    mixins: [Base],
    data() {
        return {
            channelId: '',
            channelPackageId: '',
            channels: [],
            channelPackages: [],
            todayObj: {},
            userObj: {},
            onlineObj: {},
            payObj: {},
            payShow: false
        }
    },
    mounted() {
        this.getChannel()
        this.resetQuery()
    },
    methods: {
        /** 查询渠道列表 */
        async getChannel() {
            if (this.checkPermission([this.permission.overviewChannelList])) {
                this.channels = await getChannelList()
            }
        },
        /** 查询渠道包列表 */
        changeChannel() {
            this.channelPackageId = ''
            this.channelPackages = []
            this.getChannelPackage()
        },
        showChannelPackage(show) {
            if (show) {
                this.channelPackages = []
                this.getChannelPackage()
            }
        },
        async getChannelPackage(name) {
            if (this.checkPermission([this.permission.overviewChannelPackageList])) {
                this.channelPackages = await getPackageList(this.channelId, name)
            } else {
                this.channelPackages = []
            }
        },
        resetQuery() {
            this.channelId = ''
            this.channelPackageId = ''
            this.toQuery()
        },
        toQuery() {
            this.toQueryToday()
            this.toQueryUser()
            this.toQueryOnline()
            this.toPayData()
        },
        toQueryToday() {
            if (this.checkPermission([this.permission.statsOverview])) {
                api.statsStatsOverviewDay({ channelId: this.channelId, channelPackageId: this.channelPackageId })
                    .then((rep) => {
                        this.todayObj = rep.data
                    })
                    .catch(() => {})
            }
        },
        toQueryUser() {
            if (this.checkPermission([this.permission.statsOverview])) {
                api.statsStatsOverviewUser({ channelId: this.channelId, channelPackageId: this.channelPackageId })
                    .then((rep) => {
                        this.userObj = rep.data
                    })
                    .catch(() => {})
            }
        },
        toQueryOnline() {
            if (this.checkPermission([this.permission.statsOverview])) {
                api.statsStatsOverviewOnline({ channelId: this.channelId, channelPackageId: this.channelPackageId })
                    .then((rep) => {
                        this.onlineObj = rep.data
                    })
                    .catch(() => {})
            }
        },
        toPayData(isCache = true) {
            if (this.checkPermission([this.permission.statsOverview])) {
                // this.payShow = false
                let params = {
                    isCache: isCache,
                    channelId: _.toNumber(this.channelId),
                    packageId: _.toNumber(this.channelPackageId)
                }
                api.statsStatsOverviewRevenue(params)
                    .then((rep) => {
                        this.payObj = rep.data
                        this.payShow = true
                    })
                    .catch(() => {})
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.home_bg {
    background: #f5f5f5;
    overflow-x: scroll;
    .home_f {
        display: flex;
        flex-direction: row;
        .home_f_left {
            width: 950px;
            margin-right: 20px;
        }
        .home_f_right {
            min-width: 600px;
            max-width: 600px;
            height: 670px;
        }
    }

    .home_tip {
        padding: 20px 30px;
        width: 100%;
        background: #ffffff;
        border-radius: 4px;
        display: flex;
        flex-direction: column;
        span:nth-child(1) {
            font-size: 16px;
            color: #282829;
            letter-spacing: 0;
            line-height: 20px;
            font-weight: 500;
            margin-bottom: 10px;
        }
        span:nth-child(2) {
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0;
            line-height: 26px;
            font-weight: 400;
        }
        span:nth-child(3) {
            padding-left: 20px;
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0;
            line-height: 26px;
            font-weight: 400;
        }
        span:nth-child(4) {
            padding-left: 20px;
            font-size: 14px;
            color: #686b6d;
            letter-spacing: 0;
            line-height: 26px;
            font-weight: 400;
        }
    }
}
</style>
