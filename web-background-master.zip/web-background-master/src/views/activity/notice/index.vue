<template>
    <div class="app-container finance">
        <el-tabs v-model="noticeType" type="card" @tab-click="changeNoticeType">
            <el-tab-pane v-for="(item, index) in NOTICE_TYPE_CONF" :key="index" :label="item" :name="index"></el-tab-pane>
        </el-tabs>
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.text" size="medium" clearable placeholder="公告标题或内容" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-select v-if="noticeType !== '3'" v-model="query.enable" placeholder="状态" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option :value="true" label="开启" />
                    <el-option :value="false" label="关闭" />
                </el-select>
                <IconButton v-permission="[permission.noticeList]" class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>

            <el-row type="flex">
                <el-col :span="20">
                    <IconButton
                        v-permission="[permission.noticeAdd]"
                        class="filter-item"
                        size="small"
                        type="primary"
                        icon="oms_ico_add"
                        :title="'添加' + getArrayValue(NOTICE_TYPE_CONF, noticeType)"
                        @click="toAdd"
                    />

                    <span class="fs-12 text_red" v-if="noticeType !== '3'">*为确保{{ getArrayValue(NOTICE_TYPE_CONF, noticeType) }}信息有效展示，建议提前一天配置(客户端需要提前将数据拉取到本地)</span>
                </el-col>
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column key="id" prop="id" width="120" align="center" label="ID">
                        <template slot-scope="scope">
                            <div class="dp-f" style="height: 60px">
                                <div style="width: 36px">
                                    <div class="order-to-success" v-show="scope.row.state == 1 && noticeType !== '3'">已开启</div>
                                </div>
                                <span style="font-size: 14px; margin-top: 18px">{{ scope.row.id }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column key="createTime" width="180" prop="createTime" align="center" label="创建时间" />
                    <el-table-column :show-overflow-tooltip="true" key="title" width="200" prop="title" align="center" label="标题" v-if="noticeType !== '2'" />
                    <el-table-column :show-overflow-tooltip="true" key="content" :width="noticeType == '2' ? 650 : 450" prop="content" align="left" label="公告内容" />
                    <el-table-column key="operator" width="200" prop="operator" align="center" label="创建人" />
                    <el-table-column width="150" key="terminal" prop="terminal" align="center" label="发送至终端">
                        <template slot-scope="scope">
                            <div class="terminal">
                                {{ getTerminal(scope.row.terminal).join('、') }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="state" key="state" width="100" align="center" label="状态" v-if="noticeType !== '3'">
                        <template slot-scope="scope">
                            <div class="table_state_switch">
                                <el-switch v-model="scope.row.state" @change="stateChange(scope.row)" :active-value="1" :inactive-value="0"></el-switch>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="expired" key="expired" width="100" align="center" label="状态" v-if="noticeType === '3'">
                        <template slot-scope="scope">
                            <span :class="scope.row.expired ? 'text_red' : 'text_green'">{{ scope.row.expired ? '失效' : '生效' }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" key="operation" width="200" prop="operation" align="left">
                        <template slot-scope="scope">
                            <IconButton
                                v-if="noticeType !== '3'"
                                v-permission="[permission.noticeEdit]"
                                class="filter-item"
                                size="medium"
                                type="text"
                                icon="oms_ico_edit"
                                style="font-size: 20px"
                                @click="toEdit(scope.row)"
                            />

                            <el-button v-if="noticeType === '3'" type="text" @click="toDetail(scope.row)">详情</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
        <!-- 表单渲染 -->
        <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogVisible" :title="dialogTitle" width="580px">
            <el-form ref="form" :inline="true" :model="dialogObj" :rules="rules" size="small" label-width="150px" label-position="left">
                <el-form-item label="公告标题:" prop="title" v-if="noticeType !== '2'">
                    <el-input
                        v-model="dialogObj.title"
                        maxlength="40"
                        minlength="2"
                        placeholder="请输入2-40个字符"
                        show-word-limit
                        style="width: 320px"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                </el-form-item>

                <el-form-item label="公告内容:" prop="content">
                    <el-input
                        v-model="dialogObj.content"
                        maxlength="500"
                        minlength="2"
                        rows="7"
                        type="textarea"
                        placeholder="请输入2-500个字符"
                        show-word-limit
                        style="width: 320px"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    />
                </el-form-item>
                <el-form-item label="状态" prop="state">
                    <el-radio-group
                        v-model="dialogObj.state"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    >
                        <el-radio :label="1">开启</el-radio>
                        <el-radio :label="0">关闭</el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="发送至终端" prop="terminal">
                    <el-checkbox-group
                        v-model="dialogObj.terminal"
                        @change="
                            () => {
                                $forceUpdate()
                            }
                        "
                    >
                        <el-checkbox label="Android" />
                        <el-checkbox label="H5" />
                    </el-checkbox-group>
                </el-form-item>

                <el-form-item label="失效时间:" prop="expireDays" class="big-label" v-if="noticeType === '3'">
                    <div class="dp-f">
                        <InputNumber v-model="dialogObj.expireDays" :min-number="1" :max-number="9999" placeholder="请输入天数" range-width="180px" :text-center="true" clearable />
                        <span class="text_blue fs-12 mt-5 ml-10">天后</span>
                    </div>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="info" plain @click="dialogCancel">取消</el-button>
                <el-button type="primary" @click="submit" :loading="submitLoading">确认</el-button>
            </div>
        </el-dialog>

        <el-dialog :visible.sync="dialogDetail" :title="dialogDetailTitle" width="750px">
            <div class="dp-c" style="width: 700px; padding: 20px">
                <div class="fs-18" style="color: black">{{ dialogObj.title }}</div>
                <div class="mt-10 dp-f text_gray">
                    <div>{{ dialogObj.operator }}</div>
                    <div class="ml-20">{{ dialogObj.createTime }}</div>
                    <div class="ml-20">发送至:{{ getTerminal(dialogObj.terminal).join('、') }}</div>
                    <div class="ml-20">
                        状态:
                        <span :class="dialogObj.expired ? 'text_red' : 'text_green'">{{ dialogObj.expired ? '失效' : '生效' }}</span>
                        失效时间:{{ dialogObj.expireTime ? dialogObj.expireTime : '永久' }}
                    </div>
                </div>
                <div class="mt-20" style="text-indent: 25px">
                    {{ dialogObj.content }}
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import InputNumber from '@/components/InputNumber'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/activity'
import { NOTICE_TYPE_CONF } from '@/constant/common'

import Base from '@/views/base'
import { checkArr } from '@/utils/filters'
import { confirmRequest } from '@/utils'
const defaultDialogObj = {
    size: 20,
    page: 1,
    sort: ['state;desc', 'createTime;desc'],
    createTime: [],
    noticeType: '',
    text: '',
    enable: ''
}
export default {
    name: 'Notice',
    components: {
        InputNumber,
        pagination,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        var checkText = (rule, value, callback) => {
            if (!value || !value.trim().length || !value.length) {
                return callback(new Error(rule.message))
            } else {
                callback()
            }
        }
        return {
            NOTICE_TYPE_CONF,
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: ['state;desc', 'createTime;desc'],
                createTime: [],
                noticeType: '',
                text: '',
                enable: true
            },
            total: 0,
            dialogType: '',
            noticeType: '1',
            dialogObj: {},
            dialogDetail: false,
            dialogVisible: false,
            submitLoading: false,
            dialogDetailTitle: '',
            rules: {
                terminal: [{ required: true, validator: checkArr, message: '请选中终端', trigger: 'blur' }],
                expireDays: [{ required: true, message: '请输入失效时间', trigger: 'blur' }],
                title: [
                    { required: true, message: '请输入标题', trigger: 'blur', min: 2, max: 40 },
                    { required: true, validator: checkText, message: '请输入标题', trigger: 'blur' }
                ],
                content: [
                    { required: true, message: '请输入内容', trigger: 'blur', min: 2, max: 500 },
                    { required: true, validator: checkText, message: '请输入内容', trigger: 'blur' }
                ]
            }
        }
    },
    computed: {
        dialogTitle() {
            if (this.dialogType === 'add') {
                return '添加公告'
            } else {
                return '编辑公告'
            }
        }
    },
    mounted() {
        this.fixed_height = 380
        // this.query.createTime.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        // this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        stateChange(data) {
            let title = ''
            switch (this.noticeType) {
                case '1':
                    title = data.state === 0 ? '关闭后，玩家进入登录页时将不再弹公告信息.确认关闭该公告吗？' : '同一时间只能开启一个登录公告.开启后将关闭另一个公告，确认开启吗？'
                    break
                case '2':
                    title = data.state === 0 ? '关闭后，将不再展示该跑马灯公告信息.确认关闭该公告吗？' : '确认开启吗？'
                    break
            }

            confirmRequest(
                title,
                () => {
                    api.noticeState(data)
                        .then((rep) => {
                            this.$message.success('操作成功')
                            this.toQuery()
                        })
                        .catch(() => {
                            data.state = data.state === 1 ? 0 : 1
                        })
                },
                () => {
                    data.state = data.state === 1 ? 0 : 1
                }
            )
        },
        changeNoticeType() {
            //重置搜索条件
            this.query.text = ''
            if (this.noticeType === '3') {
                this.query.enable = true
                this.query.sort = 'id;desc'
            } else {
                this.query.sort = ['state;desc', 'createTime;desc']
                this.query.enable = true
            }
            this.toQuery()
        },
        getTerminal(val) {
            return this.handleTerminalArr(val)
        },
        dialogCancel() {
            this.dialogVisible = false
        },
        toQuery(page) {
            this.query.noticeType = this.noticeType
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.noticeList])) {
                this.loading = true
                api.noticeList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },

        submit() {
            this.submitLoading = true
            setTimeout(() => {
                this.submitLoading = false
            }, 1000)

            let dic = { ...this.dialogObj }
            dic.terminal = this.toTwo(this.dialogObj.terminal)
            dic.noticeType = this.noticeType
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (dic.terminal === 0) {
                        return this.$message.error('请至少选择一个终端')
                    }

                    if (this.dialogType === 'add') {
                        api.noticeAdd(dic)
                            .then((rep) => {
                                this.$message.success('添加成功')
                                this.dialogCancel()
                                this.toQuery(true)
                            })
                            .catch(() => {
                                this.dialogCancel()
                            })
                    } else {
                        api.noticeEdit(dic)
                            .then((rep) => {
                                this.$message.success('修改成功')
                                this.dialogCancel()
                                this.toQuery(true)
                            })
                            .catch(() => {
                                this.dialogCancel()
                            })
                    }
                }
            })
        },
        handleTerminalArr(num) {
            const FLAG_H5 = 1 // 001
            const FLAG_Adr = 2 // 010
            const newArr = []
            if (num & FLAG_Adr) {
                newArr.push('Android')
            }
            if (num & FLAG_H5) {
                newArr.push('H5')
            }
            return newArr
        },
        toTwo(arr) {
            let a = [0]
            if (arr.includes('Android')) {
                a.push(1)
            } else {
                a.push(0)
            }
            if (arr.includes('H5')) {
                a.push(1)
            } else {
                a.push(0)
            }
            const b = a.join('')
            return parseInt(b, 2)
        },
        toAdd() {
            this.dialogObj = { ...defaultDialogObj }
            this.dialogObj.state = 1
            this.dialogObj.terminal = this.handleTerminalArr(3)
            this.dialogType = 'add'
            this.dialogVisible = true
        },
        toEdit(row) {
            this.dialogObj = {
                terminal: this.handleTerminalArr(row.terminal),
                id: row.id,
                title: row.title,
                content: row.content,
                state: row.state
            }
            this.dialogType = 'edit'
            this.dialogVisible = true
        },
        toDetail(row) {
            this.dialogDetailTitle = '公告详情'
            this.dialogDetail = true
            this.dialogObj = row
        }
    }
}
</script>
