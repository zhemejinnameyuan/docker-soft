<template>
    <div>
        <div class="config_container">
            <div>
                <div class="config_header">
                    <div class="config_title">充值广播配置</div>
                </div>
                <div class="config_setting" style="height: 220px">
                    <el-form ref="rechargeForm" :model="rechargeData" :rules="rechargeRules" onsubmit="return false">
                        <el-col :span="8">
                            <el-form-item label="开关" prop="enableFlag">
                                <el-switch v-model="rechargeData.enableFlag"></el-switch>
                            </el-form-item>
                            <label class="label_title">{{ rechargeData.enableFlag ? '当前为开启状态，大厅和游戏内将出现充值广播信息' : '当前为关闭状态，大厅和游戏内将不再出现充值广播信息' }}</label>
                        </el-col>
                        <el-col :span="10" style="background-color: #f7f7f7; padding: 40px" v-show="rechargeData.enableFlag">
                            <el-form-item label="触发条件:" prop="triggerVar">
                                <label class="label_title mr-5">玩家充值金额>=:</label>
                                <div style="display: inline-block; width: 160px">
                                    <InputNumber v-model="rechargeData.triggerVar" :min-number="0" :max-number="100000" rangeWidth="150px" placeholder="请输入金额0-100000"></InputNumber>
                                </div>
                            </el-form-item>
                        </el-col>
                        <el-col :span="4" style="padding: 40px 40px 40px 100px">
                            <el-form-item>
                                <el-button type="primary" @click="onSubmit('recharge')" v-permission="[permission.appBroadcastEdit]">保存</el-button>
                            </el-form-item>
                        </el-col>
                    </el-form>
                </div>
            </div>

            <div>
                <div class="config_header">
                    <div class="config_title">退款广播配置</div>
                </div>
                <div class="config_setting" style="height: 220px">
                    <el-form ref="refundForm" :model="refundData" :rules="refundRules" onsubmit="return false">
                        <el-col :span="8">
                            <el-form-item label="开关" prop="enableFlag">
                                <el-switch v-model="refundData.enableFlag"></el-switch>
                            </el-form-item>
                            <label class="label_title">{{ refundData.enableFlag ? '当前为开启状态，大厅和游戏内将出现退款广播信息' : '当前为关闭状态，大厅和游戏内将不再出现退款广播信息' }}</label>
                        </el-col>
                        <el-col :span="10" style="background-color: #f7f7f7; padding: 40px" v-show="refundData.enableFlag">
                            <el-form-item label="触发条件:" prop="triggerVar">
                                <label class="label_title mr-5">玩家退款金额>=:</label>
                                <div style="display: inline-block; width: 160px">
                                    <InputNumber v-model="refundData.triggerVar" :min-number="0" :max-number="100000" rangeWidth="150px" placeholder="请输入金额0-100000"></InputNumber>
                                </div>
                            </el-form-item>
                        </el-col>
                        <el-col :span="4" style="padding: 40px 40px 40px 100px">
                            <el-form-item>
                                <el-button type="primary" @click="onSubmit('refund')" v-permission="[permission.appBroadcastEdit]">保存</el-button>
                            </el-form-item>
                        </el-col>
                    </el-form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/activity'
import Base from '@/views/base'

export default {
    name: 'FirstRecharge',
    components: { InputNumber },
    mixins: [Base],
    data() {
        return {
            rechargeData: {},
            refundData: {},
            switchConfMessage: '',
            rechargeRules: {
                enableFlag: [{ required: true, message: '请选择充值广播开关', trigger: 'blur' }],
                triggerVar: [{ required: true, message: '请输入玩家充值金额', trigger: 'blur' }]
            },
            refundRules: {
                enableFlag: [{ required: true, message: '请选择退款广播开关', trigger: 'blur' }],
                triggerVar: [{ required: true, message: '请输入玩家退款金额', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.onQuery()
    },
    methods: {
        onQuery() {
            if (this.checkPermission([this.permission.appBroadcastRechargeWithdraw])) {
                api.broadcastRechargeWithdraw().then((rep) => {
                    for (let i in rep.data) {
                        if (rep.data[i]['id'] === 201) {
                            this.rechargeData = rep.data[i]
                        }
                        if (rep.data[i]['id'] === 202) {
                            this.refundData = rep.data[i]
                        }
                    }
                })
            }
        },
        onSubmit(type) {
            if (type === 'recharge') {
                this.$refs.rechargeForm.validate((valid) => {
                    if (valid) {
                        api.broadcastEdit(this.rechargeData).then((rep) => {
                            this.$message.success('充值保存成功')
                        })
                    }
                })
            } else if (type === 'refund') {
                this.$refs.refundForm.validate((valid) => {
                    if (valid) {
                        api.broadcastEdit(this.refundData).then((rep) => {
                            this.$message.success('退款保存成功')
                        })
                    }
                })
            }
        }
    }
}
</script>
