<template>
    <div>
        <!--表格-->
        <el-row>
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="250" align="center" label="游戏名称">
                        <template slot-scope="scope">{{ getGameName(scope.row.id) }}({{ scope.row.typeDesc }})</template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelName" width="250" align="center" label="游戏类型">
                        <template slot-scope="scope">
                            {{ scope.row.gameType ? '百人' : '房间' }}
                        </template>
                    </el-table-column>
                    <el-table-column :show-overflow-tooltip="true" prop="channelKey" width="250" align="center" label="触发条件">
                        <template slot-scope="scope">
                            赢钱>=
                            <span class="text_blue">{{ scope.row.triggerVar | filterThousandths }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column width="150" align="center" label="广播状态">
                        <template slot-scope="scope">
                            <div class="table_state_switch">
                                <el-switch v-model="scope.row.enableFlag" @change="stateChange(scope.row)"></el-switch>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作" width="300" align="center">
                        <template slot-scope="scope">
                            <el-button v-permission="[permission.appBroadcastEdit]" type="text" @click="toEdit(scope.row)">修改触发条件</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-row>

        <el-dialog title="修改触发条件" :visible.sync="dialogTableVisible" width="600px" center :before-close="dialogCancel">
            <div class="no-scrollbar" style="height: 150px">
                <el-form label-width="140px" :model="formInfo" ref="formInfo" :rules="rules" inline :inline="true" label-position="left" onsubmit="return false">
                    <div class="item_bg">
                        <el-form-item label="玩家赢钱金额>=:" prop="triggerVar">
                            <InputNumber v-model="formInfo.triggerVar" size="medium" :min-number="0" :max-number="100000000" placeholder="0-100000000" style="width: 180px" clearable />
                        </el-form-item>
                    </div>
                </el-form>

                <span slot="footer" class="mt-40 dialog-footer dp-f-center">
                    <el-button type="primary" @click="onSubmit">保存</el-button>
                </span>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/activity'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { confirmRequest } from '@/utils'
import InputNumber from '@/components/InputNumber'

const defaultQuery = {
    size: 100,
    page: 1,
    sort: 'id;asc'
}

export default {
    name: 'ChannelManage',
    components: {
        InputNumber,
        pagination,
        DateRangePicker,
        Drawer
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            dialogTableVisible: false,
            drawer: false,
            list: [],
            formInfo: {},
            query: {
                size: 100,
                page: 1,
                sort: 'id;asc'
            },
            rules: {
                triggerVar: [{ required: true, message: '请输入玩家赢钱金额', trigger: 'blur' }]
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 350
        this.toQuery()
    },
    methods: {
        stateChange(data) {
            let title = ''
            if (data.enableFlag) {
                title = '确定要开启吗?'
            } else {
                title = '确定要关闭吗？'
            }
            confirmRequest(
                title,
                () => {
                    api.broadcastEdit(data)
                        .then((rep) => {
                            this.$message.success('操作成功')
                            this.toQuery()
                        })
                        .catch(() => {
                            data.enableFlag = !data.enableFlag
                        })
                },
                () => {
                    data.enableFlag = !data.enableFlag
                }
            )
        },
        toEdit(row) {
            this.dialogTableVisible = true
            this.formInfo = row
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            if (this.checkPermission([this.permission.appBroadcastGame])) {
                api.broadcastGame(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        onSubmit() {
            this.$refs.formInfo.validate((valid) => {
                if (valid) {
                    if (this.checkPermission([this.permission.appBroadcastEdit])) {
                        api.broadcastEdit(this.formInfo).then((rep) => {
                            this.$message.success('保存成功')
                            this.dialogTableVisible = false
                            this.toQuery()
                        })
                    }
                }
            })
        },
        closeDrawer() {
            this.drawer = false
            this.toQuery()
        },
        dialogCancel() {
            this.dialogTableVisible = false
            this.toQuery()
        }
    }
}
</script>
