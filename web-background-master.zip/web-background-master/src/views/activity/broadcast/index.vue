<template>
    <div class="app-container finance">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane v-for="(item, index) in tabList" :key="index" :label="item.title" :name="item.type"></el-tab-pane>
        </el-tabs>

        <RechargeAndRefund v-if="activeName == 'rechargeAndRefund'" />
        <Game v-if="activeName == 'game'" />
    </div>
</template>

<script>
import Base from '@/views/base'
import Game from './game'
import RechargeAndRefund from './rechargeAndRefund'

export default {
    name: 'Broadcast',
    components: {
        Game,
        RechargeAndRefund
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'activeName',
            config: [],
            tabList: []
        }
    },
    computed: {},
    mounted() {
        this.config = [
            {
                type: 'rechargeAndRefund',
                title: '充值/退款',
                permissions: [this.permission.appBroadcastRechargeWithdraw]
            },
            {
                type: 'game',
                title: '游戏',
                permissions: [this.permission.appBroadcastGame]
            }
        ]
        for (let index = 0; index < this.config.length; index++) {
            const element = this.config[index]
            if (this.checkPermission(element.permissions)) {
                this.tabList.push(element)
            }
        }
        if (this.tabList) {
            this.activeName = this.tabList[0].type
        }
    },
    methods: {
        changeTabActiveName(activeName) {
            this.activeName = activeName
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss">
.el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
    background-color: #1ba2ff;
    color: #ffffff;
}
.el-tabs__nav {
    background-color: #ffffff;
}
.el-tabs--card > .el-tabs__header {
    border-bottom: 0px;
}
.el-tabs--card > .el-tabs__header .el-tabs__item {
    border-bottom: 1px solid #e4e7ed;
}

.el-form-item--small .el-form-item__label {
    line-height: 45px;
}
.config_container {
    margin-top: 30px;
    width: 100%;
    background-color: #ffffff;
}

.config_header {
    width: 100%;
    background: rgba(27, 162, 255, 0.1);
    height: 60px;
    margin: auto;
    color: #282829;
    letter-spacing: 0;
    font-weight: 400;
}

.config_title {
    font-size: 18px;
    color: #282829;
    font-weight: 500;
    line-height: 60px;
    margin-left: 20px;
}

.config_setting {
    padding: 40px;
    white-space: nowrap;
}
</style>
