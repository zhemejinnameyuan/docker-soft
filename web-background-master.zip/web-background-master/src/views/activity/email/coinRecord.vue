<template>
    <div class="finance">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <el-input v-model="query.businessId" size="medium" clearable placeholder="邮件ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="playerId" width="150" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column prop="businessId" align="center" label="邮件ID" />
                    <el-table-column prop="id" align="center" label="资金明细" />
                    <el-table-column prop="createTime" align="center" label="领取时间" />
                    <el-table-column prop="amount" align="center" label="领取金额">
                        <template slot-scope="scope">
                            {{ fenToYuan(scope.row.amount) | filterThousandths }}
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import UserIdJump from '@/components/UserIdJump'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/activity'

import Base from '@/views/base'
export default {
    name: 'SendRecord',
    components: {
        pagination,
        UserIdJump,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                playerId: '',
                businessId: ''
            },
            total: 0
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 335

        // this.query.createTime.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        // this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.mailAccountDetailList])) {
                this.loading = true
                api.mailAccountDetailList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>
