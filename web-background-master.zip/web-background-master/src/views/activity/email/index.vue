<template>
    <div class="app-container finance">
        <el-tabs v-model="activeName" type="card">
            <el-tab-pane v-for="(item, index) in tabList" :key="index" :label="item.title" :name="item.type"></el-tab-pane>
        </el-tabs>

        <Send v-if="activeName === 'send'" />
        <SendRecord v-if="activeName === 'sendRecord'" />
        <CoinRecord v-if="activeName === 'coinRecord'" />
    </div>
</template>

<script>
import Send from './send'
import SendRecord from './sendRecord'
import CoinRecord from './coinRecord'
import Base from '@/views/base'
export default {
    name: 'Email',
    components: {
        Send,
        SendRecord,
        CoinRecord
    },
    mixins: [Base],
    data() {
        return {
            activeName: 'send',
            config: [],
            tabList: []
        }
    },
    mounted() {
        this.config = [
            {
                type: 'send',
                title: '发送邮件',
                permissions: [this.permission.mailAdd]
            },
            {
                type: 'sendRecord',
                title: '邮件记录',
                permissions: [this.permission.mailList]
            },
            {
                type: 'coinRecord',
                title: '金币领取明细',
                permissions: [this.permission.mailAccountDetailList]
            }
        ]
        for (let index = 0; index < this.config.length; index++) {
            const element = this.config[index]
            if (this.checkPermission(element.permissions)) {
                this.tabList.push(element)
            }
        }
        if (this.tabList) {
            this.activeName = this.tabList[0].type
        }
    }
}
</script>
