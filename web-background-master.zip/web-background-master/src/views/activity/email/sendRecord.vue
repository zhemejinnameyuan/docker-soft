<template>
    <div class="finance">
        <!--工具栏-->
        <div class="head-container">
            <el-row>
                <DateRangePicker v-model="query.createTime" class="filter-item" @change="toQuery" />
                <el-select v-model="query.coin" placeholder="是否赠送金币" size="medium" class="filter-item" style="width: 140px" clearable @change="toQuery">
                    <el-option :value="true" label="开启" />
                    <el-option :value="false" label="关闭" />
                </el-select>
                <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
            </el-row>
        </div>
        <el-row>
            <!--渠道管理-->
            <el-col style="margin-bottom: 10px">
                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="id" width="80" align="center" label="ID" />
                    <el-table-column width="160" prop="createTime" align="center" label="发送时间" />
                    <el-table-column :show-overflow-tooltip="true" width="150" prop="title" align="center" label="标题" />
                    <el-table-column :show-overflow-tooltip="true" width="300" prop="content" align="center" label="邮件内容" />
                    <el-table-column width="100" prop="coin" align="center" label="赠送金币">
                        <template slot-scope="scope">
                            {{ scope.row.coin === 0 ? '无' : scope.row.coin }}
                        </template>
                    </el-table-column>
                    <el-table-column width="160" prop="coinExpired" align="center" label="金币失效时间">
                        <template slot-scope="scope">
                            {{ scope.row.expireTime === null ? '无' : scope.row.expireTime }}
                        </template>
                    </el-table-column>
                    <el-table-column width="200" prop="operator" align="center" label="发送玩家">
                        <template slot-scope="scope">
                            {{ scope.row.playerIds }}
                        </template>
                    </el-table-column>
                    <el-table-column width="100" prop="operator" align="center" label="金币状态">
                        <template slot-scope="scope">
                            <span :class="scope.row.expired ? 'text_red' : 'text_green'">{{ scope.row.expired ? '失效' : '有效' }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column label="操作" align="center">
                        <template slot-scope="scope">
                            <el-button type="text" @click="toDetail(scope.row)">详情</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </el-col>
        </el-row>

        <Drawer :visible.sync="drawer">
            <Detail :dataInfo="dataObj" v-if="drawer" />
        </Drawer>
    </div>
</template>

<script>
import pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Detail from './detail'
import DateRangePicker from '@/components/DateRangePicker'
import * as api from '@/api/activity'

import Base from '@/views/base'
export default {
    name: 'SendRecord',
    components: {
        pagination,
        DateRangePicker,
        Drawer,
        Detail
    },
    mixins: [Base],
    data() {
        return {
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                text: '',
                enable: ''
            },
            total: 0,
            dataObj: {},
            drawer: false
        }
    },
    computed: {},
    mounted() {
        this.fixed_height = 335
        // this.query.createTime.push(this.$moment().subtract(6, 'days').format('YYYY-MM-DD 00:00:00'))
        // this.query.createTime.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.mailList])) {
                this.loading = true
                api.mailList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        toDetail(row) {
            this.drawer = true
            this.dataObj = row
        }
    }
}
</script>
