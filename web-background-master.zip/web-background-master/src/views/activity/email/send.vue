<template>
    <div class="no-scrollbar" style="width: 900px">
        <el-form label-width="140px" :model="formInfo" ref="formInfo" :rules="rules" label-position="left">
            <el-form-item label="邮件标题:" prop="title">
                <el-input v-model="formInfo.title" size="medium" maxlength="50" minlength="2" placeholder="请输入邮件标题" show-word-limit style="width: 500px" clearable />
            </el-form-item>
            <el-form-item label="邮件内容:" prop="content">
                <el-input type="textarea" rows="6" placeholder="请输入邮件内容" v-model="formInfo.content" maxlength="500" show-word-limit class="text_area" style="width: 500px"></el-input>
            </el-form-item>
            <el-form-item label="玩家ID:" prop="playerIds">
                <div>
                    <el-input
                        type="textarea"
                        rows="6"
                        placeholder="请输入玩家ID，多个玩家以逗号隔开"
                        maxlength="220"
                        show-word-limit
                        v-model="formInfo.playerIds"
                        class="text_area"
                        style="width: 500px"
                    ></el-input>
                </div>
                <div>
                    <span class="text_blue fs-12 mt-5">多个玩家以英文逗号隔开，最多支持20个玩家</span>
                </div>
            </el-form-item>

            <el-form-item label="赠送金币:" prop="coin">
                <InputNumber v-model="formInfo.coin" :min-number="0" :max-number="1000" placeholder="0-1000" range-width="180px" :text-center="true" clearable />
                <div>
                    <span class="text_blue fs-12 mt-5">默认为0，填0代表无金币赠送，赠送的金币只会到玩家D账户，取值0～1000</span>
                </div>
            </el-form-item>

            <el-form-item label="金币失效时间:" prop="expireDays" class="big-label">
                <div class="dp-f">
                    <InputNumber v-model="formInfo.expireDays" :min-number="1" :max-number="9999" placeholder="请输入天数" range-width="180px" :text-center="true" clearable />
                    <span class="text_blue fs-12 mt-5 ml-10">天后</span>
                </div>
            </el-form-item>
        </el-form>
        <div style="margin-left: 40%; margin-top: 50px">
            <el-button type="primary" @click="submit" :loading="submitLoading">保存</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
import InputNumber from '@/components/InputNumber'
import * as api from '@/api/activity'
export default {
    name: 'Send',
    components: {
        InputNumber
    },
    mixins: [Base],
    data() {
        return {
            formInfo: {
                coin: 0
            },
            submitLoading: false,
            rules: {
                title: [{ required: true, trigger: 'blur', message: '请输入邮件标题' }],
                content: [{ required: true, trigger: 'blur', message: '请输入邮件内容' }],
                playerIds: [{ required: true, trigger: 'blur', message: '请输入玩家ID' }],
                coin: [{ required: true, trigger: 'blur', message: '请输入赠送金币' }],
                expireDays: [{ required: true, trigger: 'blur', message: '请输入金币失效时间' }]
            }
        }
    },
    mounted() {},
    created() {},
    methods: {
        submit() {
            this.submitLoading = true
            setTimeout(() => {
                this.submitLoading = false
            }, 1000)

            this.$refs.formInfo.validate((valid) => {
                if (valid) {
                    let playerIds = this.formInfo.playerIds.split(',')
                    for (let i in playerIds) {
                        if (isNaN(_.toNumber(playerIds[i])) || playerIds[i] <= 0 || playerIds[i] > 9999999999) {
                            return this.$message.error('玩家ID有误')
                        }
                    }
                    api.mailAdd(this.formInfo).then((rep) => {
                        this.$message.success('发送成功')
                        this.formInfo = { coin: 0 }
                    })
                }
            })
        }
    }
}
</script>
