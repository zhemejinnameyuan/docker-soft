<template>
    <div class="common-drawer-table-detail no-scrollbar" style="width: 860px">
        <div class="dp-f">
            <div :class="dataInfo.expired ? 'order-state-title order-state-error' : ' order-state-title order-state-success'">金币状态: {{ dataInfo.expired ? '已失效' : '生效中' }}</div>

            <div class="text_gray fs-14 mt-10 ml-20">
                {{ dataInfo.createTime }}
                <span class="ml-5">{{ dataInfo.operator }}</span>
                <span class="ml-5">[创建邮件]</span>
            </div>
        </div>
        <div style="width: 800px">
            <div class="item_title mt-10 mb-10">邮件信息</div>
            <div class="item_bg">
                <el-form label-width="120px" label-position="left">
                    <div class="item_rows">
                        <div class="item_rows_left">
                            <el-form-item label="邮件ID:">
                                <span class="des_title">{{ dataInfo.id }}</span>
                            </el-form-item>
                        </div>
                        <div class="item_rows_right">
                            <el-form-item label="邮件标题:">
                                <span class="des_title">{{ dataInfo.title }}</span>
                            </el-form-item>
                        </div>
                    </div>

                    <div class="item_rows">
                        <div class="item_rows_left">
                            <el-form-item label="赠送金币:">
                                <span class="des_title">{{ dataInfo.coin === 0 ? '无' : dataInfo.coin }}</span>
                            </el-form-item>
                        </div>
                        <div class="item_rows_right">
                            <el-form-item label="金币失效时间:">
                                <span class="des_title">{{ dataInfo.expireTime === null ? '无' : dataInfo.expireTime }}</span>
                            </el-form-item>
                        </div>
                    </div>

                    <el-form-item label="发送玩家:">
                        <span class="des_title">{{ dataInfo.playerIds }}</span>
                    </el-form-item>

                    <el-form-item label="邮件内容:">
                        <span class="des_title">{{ dataInfo.content }}</span>
                    </el-form-item>
                </el-form>
            </div>

            <div class="item_title mb-10">领取记录</div>

            <div>
                <div class="head-container">
                    <el-row>
                        <el-input v-model="query.playerId" size="medium" clearable placeholder="玩家ID" style="width: 160px" class="filter-item" @keyup.enter.native="toQuery" />
                        <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="toQuery" />
                    </el-row>
                </div>

                <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :height="table_height" :data="list">
                    <el-table-column prop="playerId" width="200" align="center" label="玩家ID">
                        <template slot-scope="scope">
                            <UserIdJump :id="scope.row.playerId" />
                        </template>
                    </el-table-column>
                    <el-table-column width="200" prop="createTime" align="center" label="领取时间" />
                    <el-table-column prop="amount" align="center" label="领取金额">
                        <template slot-scope="scope">
                            {{ fenToYuan(scope.row.amount) | filterThousandths }}
                        </template>
                    </el-table-column>
                </el-table>
                <!--分页组件-->
                <pagination v-if="total" :page-sizes="[10, 20, 50]" :query="query" :total="total" @pageChangeHandler="toQuery(true)" />
            </div>
        </div>
    </div>
</template>

<script>
import UserIdJump from '@/components/UserIdJump'
import pagination from '@/components/Pagination'
import Base from '@/views/base'
import * as api from '@/api/activity'

export default {
    mixins: [Base],
    components: {
        UserIdJump,
        pagination
    },
    props: {
        dataInfo: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            loading: false,
            list: [],
            query: {
                size: 20,
                page: 1,
                sort: 'createTime;desc',
                createTime: [],
                playerId: '',
                businessId: ''
            },
            total: 0
        }
    },
    mounted() {
        this.fixed_height = 450
    },
    created() {
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            this.query.businessId = this.dataInfo.id
            if (!page) {
                this.query.page = 1
            }
            if (this.checkPermission([this.permission.mailAccountDetailList])) {
                this.loading = true
                api.mailAccountDetailList(this.query)
                    .then((rep) => {
                        this.list = rep.data
                        this.total = rep.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.common-drawer-table-detail {
    .item_rows {
        width: 100%;
        display: flex;

        &_left {
            width: 50%;
        }

        &_right {
            width: 50%;
        }
    }
}
</style>
