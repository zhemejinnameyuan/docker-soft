<template>
    <div>
        <el-upload
            ref="uploadImage"
            action="#"
            :http-request="urlUploadHandle"
            :before-upload="beforeUpload"
            :on-error="handleError"
            :on-exceed="handleExceed"
            :on-remove="handleRemove"
            list-type="picture-card"
            :multiple="multiple"
            :limit="limit"
            :file-list="fileList"
            :accept="accept"
        >
            <i slot="default" class="el-icon-plus"></i>
            <div slot="file" slot-scope="{ file }">
                <img :src="file.domain + file.url" v-if="file.domain" width="80px" height="80px" />
                <span class="el-upload-list__item-actions">
                    <span class="el-upload-list__item-preview" @click="onPreview(file)">
                        <i class="el-icon-zoom-in"></i>
                    </span>
                    <span class="el-upload-list__item-delete" @click="handleRemove(file)">
                        <i class="el-icon-delete"></i>
                    </span>
                </span>
            </div>
        </el-upload>

        <image-preview
            v-if="dialogVisible"
            :url-list="[dialogImageUrl]"
            :on-close="
                () => {
                    dialogVisible = false
                }
            "
        />
    </div>
</template>

<script>
import * as api from '@/api/public'
import ImagePreview from '@/components/ImagePreview'
export default {
    name: 'UploadImage',
    props: {
        fileSize: {
            type: Number,
            default: 2
        },
        fileExt: {
            type: Array,
            default() {
                return ['image/jpeg', 'image/jpg', 'image/png']
            }
        },
        limit: {
            type: Number,
            default: 1
        },
        multiple: {
            type: Boolean,
            default: false
        },
        accept: {
            type: String,
            default: '.png,.jpg,.jpeg'
        },
        width: {
            type: Number,
            default: 0
        },
        height: {
            type: Number,
            default: 0
        },
        //已经上传的图片，用于渲染
        existImgList: {
            type: Array,
            default() {
                return []
            }
        }
    },
    data() {
        return {
            dialogImageUrl: '',
            dialogVisible: false,
            fileList: []
        }
    },
    components: {
        ImagePreview
    },
    mounted() {
        this.fileList = this.existImgList
    },
    methods: {
        //上传处理
        urlUploadHandle(options) {
            let _this = this
            let { file } = options
            api.getUploadUrl({ filename: file.name }).then(function (response) {
                let url = response.data.l //上传地址
                let path = response.data.r //相对路径
                let domain = response.domain.file
                // 发送 put 请求
                let header = { 'Content-Type': file.type }
                api.putFile(url, file, header).then(function (res) {
                    if (res.status === 200) {
                        let tmp = { name: file.name, url: path, domain: domain }
                        //单文件覆盖，多文件追加
                        if (_this.limit > 1) {
                            _this.fileList.push(tmp)
                        } else {
                            _this.fileList = [tmp]
                        }
                        _this.updateFileList(_this.fileList)
                    } else {
                        this.$message.error('上传失败！')
                    }
                })
            })
        },
        //移除
        handleRemove(file, fileList) {
            if (file && file.status == 'success') {
                let fileListTmp = this.fileList
                for (let i = 0; i < fileListTmp.length; i++) {
                    if (file.name === fileListTmp[i].name) {
                        fileListTmp.splice(i, 1)
                        break
                    }
                }
                this.updateFileList(fileListTmp)
            }
        },
        //错误
        handleError() {
            return this.$message.error('上传失败，服务器错误')
        },
        //上传前操作
        beforeUpload(file) {
            const that = this
            return new Promise(function (resolve, reject) {
                if (that.fileExt.indexOf(file.type) === -1) {
                    that.$message.error('文件格式不正确!只支持以下格式：' + that.fileExt.join(','))
                    reject(false)
                }
                if (file.size / 1024 / 1024 > that.fileSize) {
                    that.$message.error('文件大小不能超过' + that.fileSize + 'MB!')
                    reject(false)
                }
                if (that.width > 0 && that.height > 0) {
                    const reader = new FileReader()
                    reader.readAsDataURL(file)
                    reader.onload = function (evt) {
                        const replaceSrc = evt.target.result
                        const imageObj = new Image()
                        imageObj.src = replaceSrc
                        imageObj.onload = function () {
                            if (that.width != imageObj.width || that.height != imageObj.height) {
                                that.$message.error('图片尺寸不符合,应为' + that.width + '*' + that.height + 'px')
                                reject(false)
                            }
                            resolve(true)
                        }
                    }
                } else {
                    resolve(true)
                }
            })
        },
        //处理上传数量限制
        handleExceed(files, fileList) {
            if (this.limit > 1) {
                return this.$message.error('最多只能上传' + this.limit + '文件')
            } else {
                //单文件覆盖
                this.beforeUpload(files[0]).then(() => {
                    this.$set(fileList[0], 'raw', files[0])
                    this.$set(fileList[0], 'name', files[0].name)
                    this.$refs.uploadImage.clearFiles()
                    this.$refs.uploadImage.handleStart(files[0])
                    this.$refs.uploadImage.submit()
                })
            }
        },
        //预览图片
        onPreview(file) {
            this.dialogImageUrl = file.domain + file.url
            this.dialogVisible = true
        },
        //处理上传文件列表
        updateFileList(fileList) {
            this.fileList = fileList
            let imgList = []
            for (let i in fileList) {
                imgList[i] = fileList[i].url
            }
            //更新文件回调
            this.$emit('updateFileList', imgList)
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .el-upload--picture-card {
    width: 80px;
    height: 80px;
    line-height: 80px;
}

::v-deep .el-upload--picture-card {
    width: 80px;
    height: 80px;
    line-height: 80px;
}

::v-deep .el-upload-list--picture-card .el-upload-list__item {
    width: 80px;
    height: 80px;
}
//优化上传后闪烁
::v-deep .el-upload-list__item.is-ready {
    display: none;
}
</style>
