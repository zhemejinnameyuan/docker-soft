<template>
    <div class="lm_card">
        <div v-for="(item, index) in list" :key="index" class="lm_card_group">
            <Card v-for="(card, i) in item.group" :key="i" :card="card.key" :is-joker="card.joker" class="lm_card_group_item" />
            <div v-if="item.type && !hideType" :class="getColor(item)">
                {{ getType(item) }}
            </div>
        </div>
    </div>
</template>
<script>
import Card from '@/components/Card'
export default {
    components: {
        Card
    },
    props: {
        list: {
            type: Array,
            default: function () {
                return null
            }
        },
        hideType: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {}
    },
    computed: {},
    methods: {
        getColor(item) {
            var class_str = 'lm_card_group_bingo '
            switch (item.tip) {
                case 0: // 第一个同花顺 （绿色）
                case 1: // 第二个顺子 （绿色）
                case 2: // 当有一个同花顺和一个顺子后，剩余的非同花的顺子 （绿色）
                case 3: // 当有一个同花顺和一个顺子后的 豹子组合 （绿色）
                case 4: // 当有一个同花顺和一个顺子后，剩余的同花顺
                    class_str += 'lm_card_group_green'
                    break
                case 5: // 当没有同花顺，但组合是非纯顺子或豹子 （黄色）
                case 6: // 当有一个同花顺，但组合是豹子（黄色）
                    class_str += 'lm_card_group_yellow'
                    break
                case 7: // 无效组合 （红色）
                    class_str += 'lm_card_group_red'
                    break
                default: // 散牌
                    break
            }
            return class_str
        },
        getType(item) {
            switch (item.type) {
                case 1:
                    return '无效'
                case 2:
                    return '豹子'
                case 3:
                    return '非纯顺子'
                case 4:
                    return '纯顺子'
                default:
                    return '散牌'
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.lm_card {
    display: flex;
    align-items: center;
    &_group {
        position: relative;
        display: flex;
        margin-right: 7px;
        &_item {
            width: 50px;
            height: 67px;
            &:not(:first-child) {
                margin-left: -33px;
            }
        }
        &_bingo {
            position: absolute;
            left: 0px;
            right: 0px;
            bottom: 0px;
            height: 20px;
            box-shadow: inset 0px -1px 0px 0px rgba(89, 255, 175, 1);
            box-shadow: 0px -1px 3px 0px rgba(0, 0, 0, 0.2);
            border-radius: 0px 0px 4px 4px;
            font-size: 14px;
            color: white;
            line-height: initial;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 500;
        }
        &_green {
            background: #3bcc71;
        }
        &_yellow {
            background: #fabb32;
        }
        &_red {
            background: #ff3e2e;
        }
    }
}
</style>
