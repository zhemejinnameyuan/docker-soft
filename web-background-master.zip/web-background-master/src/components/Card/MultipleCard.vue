<template>
    <div class="multiple_card">
        <div v-for="(item, index) in list" :key="index" class="multiple_card_group">
            <Card :card="item" class="multiple_card_group_item" />
        </div>
    </div>
</template>
<script>
import Card from '@/components/Card'
export default {
    components: {
        Card
    },
    props: {
        list: {
            type: Array,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {}
    },
    computed: {},
    mounted() {},
    methods: {}
}
</script>

<style lang="scss" scoped>
.multiple_card {
    display: flex;
    align-items: center;
    &_group {
        position: relative;
        display: flex;
        margin-right: 7px;
        &_item {
            width: 45px;
            height: 60px;
        }
        &:not(:first-child) {
            margin-left: -33px;
        }
    }
}
</style>
