<template>
    <div v-if="card" class="card">
        <img class="card_bg" :src="getCardBg()" />
        <img v-if="!isBack && cardType != 5" class="card_color" :src="getCardColor()" />
        <img v-if="!isBack && cardType != 5" class="card_value" :src="getCardValue()" />
        <img v-if="!isBack && cardType == 5" class="card_color" :src="getJokerColor()" />
    </div>
</template>
<script>
export default {
    props: {
        card: {
            type: [Number, String],
            default: null
        },
        isBack: {
            type: Boolean,
            default: false
        },
        isJoker: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {}
    },
    computed: {
        /** 获取花色 */
        cardType() {
            if (this.card) {
                return (this.card || this.card) >> 4
            } else {
                return null
            }
        },
        /** 获取牌面值 */
        cardValue() {
            if (this.card) {
                return (this.card || this.card) & 0x0f
            } else {
                return null
            }
        }
    },
    methods: {
        getCardBg() {
            var imgObj
            if (this.isJoker) {
                imgObj = require('@/assets/images/card/card_front_yellow.png')
            } else if (this.isBack) {
                imgObj = require('@/assets/images/card/card_back.png')
            } else {
                imgObj = require('@/assets/images/card/card_front.png')
            }
            return imgObj
        },
        getCardColor() {
            var imgObj = require(`@/assets/images/card/color_${this.cardType}.png`)
            return imgObj
        },
        getCardValue() {
            var imgObj = require(`@/assets/images/card/card_${this.cardType % 2}_${this.cardValue.toString(16)}.png`)
            return imgObj
        },

        getJokerColor() {
            var imgObj = require(`@/assets/images/card/card_${this.cardType}_${this.cardValue.toString(16)}.png`)
            return imgObj
        }
    }
}
</script>

<style lang="scss" scoped>
.card {
    position: relative;
    &_bg {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 100%;
        height: 100%;
    }
    &_color {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 100%;
        height: 100%;
    }
    &_value {
        position: absolute;
        top: 5%;
        left: 5%;
        width: 30%;
        height: 25%;
    }
}
</style>
