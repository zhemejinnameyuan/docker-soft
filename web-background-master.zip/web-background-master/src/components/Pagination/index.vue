<!--分页-->
<template>
    <el-pagination
        :page-size.sync="query.size"
        :total="total"
        :current-page.sync="query.page"
        style="margin-top: 8px"
        layout="total, prev, pager, next, sizes,jumper"
        :page-sizes="pageSizes"
        background
        @size-change="pageChangeHandler"
        @current-change="pageChangeHandler"
    />
</template>
<script>
export default {
    props: {
        query: {
            type: Object,
            default: null
        },
        pageSizes: {
            type: Array,
            default: function () {
                return [10, 20, 50]
            }
        },
        total: {
            type: Number,
            default: function () {
                return 0
            }
        }
    },
    methods: {
        pageChangeHandler() {
            this.$emit('pageChangeHandler')
        }
    }
}
</script>
<style lang="scss" scoped>
::v-deep .el-select {
    input {
        background: #ffffff;
    }
}
</style>
