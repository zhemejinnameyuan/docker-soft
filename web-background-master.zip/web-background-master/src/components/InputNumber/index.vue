<template>
    <div>
        <div class="input-number-range" :style="{ width: rangeWidth }" :class="{ 'is-disabled': disabled }">
            <div class="flex">
                <div :class="getClassName()">
                    <el-input
                        ref="input_from"
                        v-model="userInputForm"
                        :size="size"
                        :clearable="clearable"
                        :style="{ width: rangeWidth }"
                        :disabled="disabled"
                        :placeholder="placeholder"
                        @blur="handleBlurFrom"
                        @focus="handleFocusFrom"
                        @input="handleInputFrom"
                        @change="handleInputChangeFrom"
                    />
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'InputNumber',

    props: {
        size: {
            type: String,
            default: 'medium'
        },
        clearable: {
            type: Boolean,
            default: false
        },
        placeholder: {
            type: String,
            default: '请输入'
        },
        minNumber: {
            type: Number,
            default: 0
        },
        maxNumber: {
            type: Number,
            default: 999999999999
        },
        rangeWidth: {
            type: String,
            default: '200px'
        },
        value: { required: true },

        // 是否禁用
        disabled: {
            type: Boolean,
            default: false
        },
        // 是否是单个大输入框
        singleBigInput: {
            type: Boolean,
            default: false
        },
        // 居中对齐
        textCenter: {
            type: Boolean,
            default: false
        },
        // 精度参数
        precision: {
            type: Number,
            default: 0,
            validator(val) {
                return val >= 0 && val === parseInt(val, 10)
            }
        }
    },

    data() {
        return {
            userInputForm: null
        }
    },

    watch: {
        value: {
            immediate: true,
            handler(value) {
                if (this.precision !== undefined) {
                    if (typeof value === 'number') {
                        this.userInputForm = value
                    } else if (value) {
                        this.userInputForm = parseFloat(value)
                    } else {
                        this.userInputForm = null
                    }
                }
            }
        }
    },

    methods: {
        getClassName() {
            let classArr = ['form']
            if (this.singleBigInput) {
                classArr.push('single-big-input')
            }
            if (this.textCenter) {
                classArr.push('center-input')
            }
            return classArr
        },
        // 根据精度保留数字
        toPrecision(num, precision) {
            if (precision === undefined) precision = 0
            return parseFloat(Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision))
        },

        handleBlurFrom(event) {
            this.$emit('blurfrom', event)
        },

        handleFocusFrom(event) {
            this.$emit('focusfrom', event)
        },

        handleInputFrom(value) {
            this.$emit('inputfrom', value)
            // this.userInputFrom = value
        },

        // from输入框change事件
        handleInputChangeFrom(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.userInputForm = null
                this.$emit('input', null)
                this.$emit('changefrom', null)
                return
            }

            // 初始化数字精度
            this.userInputForm = this.setPrecisionValue(value)

            this.userInputForm = this.userInputForm < this.minNumber ? this.minNumber : this.userInputForm
            this.userInputForm = this.userInputForm > this.maxNumber ? this.maxNumber : this.userInputForm

            this.$emit('input', this.userInputForm)
            this.$emit('changefrom', this.userInputForm)
        },
        // 设置成精度数字
        setPrecisionValue(value) {
            if (this.precision !== undefined) {
                const val = this.toPrecision(value, this.precision)
                return val
            }
            return null
        }
    }
}
</script>
<style lang="scss" scoped>
// 取消element原有的input框样式
::v-deep .el-input__inner {
    height: 40px;
    font-size: 16px;
    color: #282829;
}
//居中对齐
.center-input {
    ::v-deep .el-input__inner {
        text-align: center;
        color: #282829;
    }
}

//大输入框
.single-big-input {
    ::v-deep .el-input__inner {
        width: 200px;
        height: 60px;
        font-size: 20px;
        text-align: center;
    }
}
.input-number-range {
    background-color: #fff;
}
.flex {
    display: flex;
    flex-direction: row;
    width: 100%;
    justify-content: center;
    align-items: center;
    .center {
        margin: 1px 8px 0px 8px;
    }
}
.is-disabled {
    background-color: #eef0f6;
    border-color: #e4e7ed;
    color: #c0c4cc;
    cursor: not-allowed;
}
</style>
