<template>
    <div>
        <el-button class="go-home" @click="goHome">
            <svg-icon icon-class="oms_tab_ico_kongzhitai" style="width: 19px; height: 19px" />
            <span class="go-home-text">回到后台主页</span>
        </el-button>
    </div>
</template>

<script>
export default {
    methods: {
        goHome() {
            window.open('/')
        }
    }
}
</script>
