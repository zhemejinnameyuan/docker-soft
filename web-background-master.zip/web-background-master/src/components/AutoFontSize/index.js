import Vue from 'vue'

/**
 *字体大小超出宽度缩放
 */
const handleFontSizeFunction = (el, binding) => {
    let fontSize = 12
    switch (binding.value) {
        case 'max':
            //游戏-数据统计-大号字体
            fontSize = 24
            break
        case 'medium':
            //游戏-数据统计-中号字体
            fontSize = 18
            break
        case 'finance-max':
            //财务管理-数据统计-大号字体
            fontSize = 20
            break
        case 'finance-medium':
            //财务管理-数据统计-中号字体
            fontSize = 16
    }
    const tmp = el.offsetWidth / el.scrollWidth
    const newFontSize = Math.floor(fontSize * tmp)
    // 设置新的字体大小
    el.style.fontSize = newFontSize + 'px'
}
Vue.directive('autoFontSize', {
    inserted: handleFontSizeFunction,
    update: handleFontSizeFunction,
    componentUpdated: handleFontSizeFunction
})
