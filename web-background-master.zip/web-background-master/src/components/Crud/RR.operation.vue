<!--搜索与重置-->
<template>
    <span>
        <IconButton class="filter-item" size="medium" type="primary" icon="oms_ico_search" title="搜索" @click="crud.toQuery" />
        <IconButton v-if="crud.optShow.reset" class="filter-item" size="medium" type="primary" icon="oms_ico_reset" plain title="重置" @click="crud.resetQuery()" />
    </span>
</template>
<script>
import { crud } from '@crud/crud'
export default {
    mixins: [crud()],
    props: {
        itemClass: {
            type: String,
            required: false,
            default: ''
        }
    }
}
</script>
