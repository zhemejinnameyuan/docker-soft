<template>
    <a :href="'/player?id=' + id" target="_blank" :title="id" class="player-id">
        <i v-if="!onlyNickname">
            {{ id }}
            <i v-if="nickname">({{ nickname }})</i>
        </i>
        <i v-if="onlyNickname">{{ nickname }}</i>
        <i v-if="onlyUserId">{{ id }}</i>
    </a>
</template>

<script>
export default {
    name: 'UserIdJump',
    props: {
        id: {
            type: Number | String,
            default: 0
        },
        nickname: {
            type: String,
            default: ''
        },
        onlyNickname: {
            type: Boolean,
            default: false
        },
        onlyUserId: {
            type: Boolean,
            default: false
        }
    },
    methods: {}
}
</script>
