import request from '@/utils/request'
/**
 *  修改游戏结果
 */
export function nextResult(data) {
    return request({
        url: '/api/admin/inner/nextResult',
        method: 'post',
        data
    })
}
/**
 *  玩家充值
 */
export function deposit(data) {
    return request({
        url: '/api/admin/inner/deposit',
        method: 'post',
        data
    })
}

/**
 * 给用户开启上帝视角
 */
export function setGameSwitch(data) {
    return request({
        url: '/api/admin/inner/setGameSwitch',
        method: 'post',
        data
    })
}

/**
 * 手动生成营收统计
 */
export function handGenerate(params) {
    return request({
        url: '/api/admin/stats/overview/revenue/handGenerate',
        method: 'get',
        params
    })
}
