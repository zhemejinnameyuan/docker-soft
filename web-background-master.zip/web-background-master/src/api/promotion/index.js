import request from '@/utils/request'

/**
 * 推广用户管理列表
 */
export function list(params) {
    return request({
        url: '/api/admin/notice/list',
        method: 'get',
        params
    })
}

/**
 * 推广管理-保存配置
 */
export function configSave(data) {
    return request({
        url: '/api/admin/app-refer/config/save',
        method: 'post',
        data
    })
}

/**
 * 推广管理-推广账户封禁/解封
 */
export function accountBlock(data) {
    return request({
        url: '/api/admin/app-refer/account/block',
        method: 'post',
        data
    })
}

/**
 * 推广管理-兑换记录
 */
export function withdrawLog(params) {
    return request({
        url: '/api/admin/app-refer/withdraw/log',
        method: 'get',
        params
    })
}

/**
 * 推广管理-分享记录
 */
export function shareLog(params) {
    return request({
        url: '/api/admin/app-refer/share/log',
        method: 'get',
        params
    })
}

/**
 * 推广管理-首充奖励
 */
export function depositLog(params) {
    return request({
        url: '/api/admin/app-refer/deposit/log',
        method: 'get',
        params
    })
}

/**
 * 推广管理-查询配置
 */
export function configQuery(params) {
    return request({
        url: '/api/admin/app-refer/config/query',
        method: 'get',
        params
    })
}

/**
 * 推广管理-投注分红
 */
export function betLog(params) {
    return request({
        url: '/api/admin/app-refer/bet/log',
        method: 'get',
        params
    })
}

/**
 * 推广管理-推广账户查询
 */
export function accountList(params) {
    return request({
        url: '/api/admin/app-refer/account/list',
        method: 'get',
        params
    })
}

/**
 * 推广管理-推广账户明细
 */
export function accountDetail(params) {
    return request({
        url: '/api/admin/app-refer/account/detail',
        method: 'get',
        params
    })
}

/**
 * 推广管理-推广账户封禁记录
 */
export function accountBlockRecord(params) {
    return request({
        url: '/api/admin/app-refer/account/blockRecord',
        method: 'get',
        params
    })
}

/**
 * 推广管理-推广账户下级玩家
 */
export function accountBelows(params) {
    return request({
        url: '/api/admin/app-refer/account/belows',
        method: 'get',
        params
    })
}
