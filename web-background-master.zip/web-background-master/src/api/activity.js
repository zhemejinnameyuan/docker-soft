import request from '@/utils/request'

/**
 * 公告上下架
 */
export function noticeState(data) {
    return request({
        url: '/api/admin/notice/state',
        method: 'post',
        data
    })
}

/**
 * 编辑公告
 */
export function noticeEdit(data) {
    return request({
        url: '/api/admin/notice/edit',
        method: 'post',
        data
    })
}

/**
 * 删除公告
 */
export function noticeDel(data) {
    return request({
        url: '/api/admin/notice/del',
        method: 'post',
        data
    })
}

/**
 * 添加公告
 */
export function noticeAdd(data) {
    return request({
        url: '/api/admin/notice/add',
        method: 'post',
        data
    })
}
/**
 * 查询公告
 */
export function noticeList(params) {
    return request({
        url: '/api/admin/notice/list',
        method: 'get',
        params
    })
}

/**
 * 发送邮件
 */
export function mailAdd(data) {
    return request({
        url: '/api/admin/mail/add',
        method: 'post',
        data
    })
}

/**
 * 邮件记录
 */
export function mailList(params) {
    return request({
        url: '/api/admin/mail/list',
        method: 'get',
        params
    })
}

/**
 * 金币领取明细
 */
export function mailAccountDetailList(params) {
    return request({
        url: '/api/admin/mail/accountDetailList',
        method: 'get',
        params
    })
}

/**
 *  编辑配置
 */
export function broadcastEdit(data) {
    return request({
        url: '/api/admin/app-broadcast/edit',
        method: 'post',
        data
    })
}

/**
 * 查询充值退款配置
 */
export function broadcastRechargeWithdraw(params) {
    return request({
        url: '/api/admin/app-broadcast/rechargeWithdraw',
        method: 'get',
        params
    })
}

/**
 * 查询游戏配置
 */
export function broadcastGame(params) {
    return request({
        url: '/api/admin/app-broadcast/game',
        method: 'get',
        params
    })
}
