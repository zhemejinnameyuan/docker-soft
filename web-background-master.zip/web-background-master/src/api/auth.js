import request from '@/utils/request'

export function login(username, password, code, key) {
    return request({
        url: '/api/admin/auth/login',
        method: 'post',
        data: {
            username,
            password,
            code,
            key
        }
    })
}

export function userInfo() {
    return request({
        url: '/api/admin/auth/userInfo',
        method: 'get'
    })
}

export function logout() {
    return request({
        url: '/api/admin/auth/logout',
        method: 'post'
    })
}
