import request from '@/utils/request'

// 保存充值小贴士配置
export function saveTipsConfig(data) {
    return request({
        url: '/api/admin/app-recharge/saveTipsConfig',
        method: 'post',
        data
    })
}

// 保存充值配置
export function saveConfig(data) {
    return request({
        url: '/api/admin/app-recharge/saveConfig',
        method: 'post',
        data
    })
}

// 查询充值小贴士配置
export function queryTipsConfig(params) {
    return request({
        url: '/api/admin/app-recharge/queryTipsConfig',
        method: 'get',
        params
    })
}

// 查询充值配置
export function queryConfig(params) {
    return request({
        url: '/api/admin/app-recharge/queryConfig',
        method: 'get',
        params
    })
}

// 查询充值订单
export function orderList(params) {
    return request({
        url: '/api/admin/app-recharge/orderList',
        method: 'get',
        params
    })
}

// 查询充值订单详情
export function orderDetail(params) {
    return request({
        url: '/api/admin/app-recharge/orderDetail',
        method: 'get',
        params
    })
}

// 查询充值通道
export function channelList(params) {
    return request({
        url: '/api/admin/app-recharge/channelList',
        method: 'get',
        params
    })
}

// 数据统计
export function orderStatistics(params) {
    return request({
        url: '/api/admin/app-recharge/orderStatistics',
        method: 'get',
        params
    })
}

// 意见反馈列表
export function feedbackList(params) {
    return request({
        url: '/api/admin/app-recharge/feedbackList',
        method: 'get',
        params
    })
}

// 订单置成功
export function setSuccess(data) {
    return request({
        url: '/api/admin/app-recharge/setSuccess',
        method: 'post',
        data
    })
}

// 订单置失败
export function setFail(data) {
    return request({
        url: '/api/admin/app-recharge/setFail',
        method: 'post',
        data
    })
}

// 保存充值通道
export function saveChannel(data) {
    return request({
        url: '/api/admin/app-recharge/saveChannel',
        method: 'post',
        data
    })
}

// 批量修改充值通道状态
export function batchChangeChannelState(data) {
    return request({
        url: '/api/admin/app-recharge/batchChangeChannelState',
        method: 'post',
        data
    })
}

// 支付通道统计
export function channelStatistics(params) {
    return request({
        url: '/api/admin/app-recharge/channelStatistics',
        method: 'get',
        params
    })
}
