import request from '@/utils/request'

// 财务管理-资金账户明细
export function financeAccountDetailList(params) {
    return request({
        url: '/api/admin/finance/accountDetailList',
        method: 'get',
        params
    })
}

// 财务管理-推广奖励
export function financeRewardRecord(params) {
    return request({
        url: '/api/admin/finance/rewardRecord',
        method: 'get',
        params
    })
}

// 财务管理-推广奖励明细
export function financeRewardLog(params) {
    return request({
        url: '/api/admin/finance/rewardLog',
        method: 'get',
        params
    })
}

// 财务管理-推广奖励统计
export function financeRewardStats(params) {
    return request({
        url: '/api/admin/finance/rewardStats',
        method: 'get',
        params
    })
}

// 财务管理-礼物收益记录
export function financeGiftList(params) {
    return request({
        url: '/api/admin/finance/giftIncomeLog',
        method: 'get',
        params
    })
}

// 财务管理-礼物收益统计
export function financeGiftStats(params) {
    return request({
        url: '/api/admin/finance/statsGift',
        method: 'get',
        params
    })
}
