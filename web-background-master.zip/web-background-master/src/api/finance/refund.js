import request from '@/utils/request'

// 保存退款小贴士配置
export function saveTipsConfig(data) {
    return request({
        url: '/api/admin/app-withdraw/saveTipsConfig',
        method: 'post',
        data
    })
}

// 保存退款小贴士配置
export function saveConfig(data) {
    return request({
        url: '/api/admin/app-withdraw/saveConfig',
        method: 'post',
        data
    })
}

// 查询退款小贴士配置
export function queryTipsConfig(params) {
    return request({
        url: '/api/admin/app-withdraw/queryTipsConfig',
        method: 'get',
        params
    })
}

// 查询退款配置
export function queryConfig(params) {
    return request({
        url: '/api/admin/app-withdraw/queryConfig',
        method: 'get',
        params
    })
}

// 查询退款订单
export function orderList(params) {
    return request({
        url: '/api/admin/app-withdraw/orderList',
        method: 'get',
        params
    })
}

// 查询退款订单详情
export function orderDetail(params) {
    return request({
        url: '/api/admin/app-withdraw/orderDetail',
        method: 'get',
        params
    })
}

// 查询订单详情
export function orderStatistics(params) {
    return request({
        url: '/api/admin/app-withdraw/orderStatistics',
        method: 'get',
        params
    })
}

// 查询退款通道
export function channelList(params) {
    return request({
        url: '/api/admin/app-withdraw/channelList',
        method: 'get',
        params
    })
}

// 异常订单列表
export function exceptionList(params) {
    return request({
        url: '/api/admin/app-withdraw/exceptionList',
        method: 'get',
        params
    })
}

// 废弃订单列表
export function obsoleteList(params) {
    return request({
        url: '/api/admin/app-withdraw/obsoleteList',
        method: 'get',
        params
    })
}

// 意见反馈列表
export function feedbackList(params) {
    return request({
        url: '/api/admin/app-withdraw/feedbackList',
        method: 'get',
        params
    })
}

// 退款订单批量通过
export function batchPass(data) {
    return request({
        url: '/api/admin/app-withdraw/batchPass',
        method: 'post',
        data
    })
}

// 退款订单批量驳回
export function batchReject(data) {
    return request({
        url: '/api/admin/app-withdraw/batchReject',
        method: 'post',
        data
    })
}
// 退款订单重新请求
export function requestAgain(data) {
    return request({
        url: '/api/admin/app-withdraw/requestAgain',
        method: 'post',
        data
    })
}

// 退款订单置失败
export function setFail(data) {
    return request({
        url: '/api/admin/app-withdraw/setFail',
        method: 'post',
        data
    })
}

// 退款订单作废
export function obsolete(data) {
    return request({
        url: '/api/admin/app-withdraw/obsolete',
        method: 'post',
        data
    })
}

// 退款通道每日额度信息
export function withdrawChannelStatistics(params) {
    return request({
        url: '/api/admin/app-withdraw/withdrawChannelStatistics',
        method: 'get',
        params
    })
}

// 恢复退款作废订单
export function obsoleteCallback(data) {
    return request({
        url: '/api/admin/app-withdraw/obsoleteCallback',
        method: 'post',
        data
    })
}
