import request from '@/utils/request'
import axios from 'axios'
import settings from '@/settings'

/**
 * 上传文件-根据文件名称获取上传地址和访问相对路径
 */
export function getUploadUrl(params) {
    return request({
        url: '/api/admin/upload/uploadUrl',
        method: 'get',
        params
    })
}

/**
 * 上传文件
 * @param url
 * @param data
 * @param header
 */
export function putFile(url, data, header) {
    return axios.request({
        url: url,
        method: 'put',
        data: data,
        header: header
    })
}
