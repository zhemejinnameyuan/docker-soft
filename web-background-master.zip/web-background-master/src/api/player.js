import request from '@/utils/request'

/**
 * 加入移除黑名单
 */
export function block(data) {
    return request({
        url: '/api/admin/player/block',
        method: 'post',
        data
    })
}

/**
 * 查询玩家列表
 */
export function list(params) {
    return request({
        url: '/api/admin/player/list',
        method: 'get',
        params
    })
}

/**
 * 查询玩家详情
 */
export function detail(params) {
    return request({
        url: '/api/admin/player/detail',
        method: 'get',
        params
    })
}

/**
 * 查询短信日志
 */
export function captcha(params) {
    return request({
        url: '/api/admin/player/captcha',
        method: 'get',
        params
    })
}

/**
 * 查询玩家游戏日志
 */
export function gameLog(params) {
    return request({
        url: '/api/admin/player/gameLog',
        method: 'get',
        params
    })
}

/**
 * 查询玩家游戏日志
 */
export function loginLog(params) {
    return request({
        url: '/api/admin/player/loginLog',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-推广记录
 */
export function referAccountBelows(params) {
    return request({
        url: '/api/admin/player/referAccountBelows',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-资金账户明细
 */
export function accountDetailList(params) {
    return request({
        url: '/api/admin/player/accountDetailList',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-推广奖励
 */
export function financeRewardRecord(params) {
    return request({
        url: '/api/admin/player/referRewardRecord',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-推广奖励明细
 */
export function financeRewardLog(params) {
    return request({
        url: '/api/admin/player/referRewardLog',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-推广奖励统计
 */
export function financeRewardStats(params) {
    return request({
        url: '/api/admin/player/referRewardStats',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-推广账户统计
 */
export function referAccountStats(params) {
    return request({
        url: '/api/admin/player/referAccountStats',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-违规处罚
 */
export function accountBlock(params) {
    return request({
        url: '/api/admin/player/accountBlock',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-财务管理-充值记录
 */
export function rechargeList(params) {
    return request({
        url: '/api/admin/player/rechargeList',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-财务管理-玩家充值订单统计
 */
export function userRechargeOrderStatistics(params) {
    return request({
        url: '/api/admin/app-recharge/userOrderStatistics',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-财务管理-退款记录
 */
export function withdrawList(params) {
    return request({
        url: '/api/admin/player/withdrawList',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-财务管理-玩家退款订单统计
 */
export function userWithdrawOrderStatistics(params) {
    return request({
        url: '/api/admin/app-withdraw/userOrderStatistics',
        method: 'get',
        params
    })
}

/**
 * 玩家详情-财务概览
 */
export function financialOverviewStats(params) {
    return request({
        url: '/api/admin/player/financialOverviewStats',
        method: 'get',
        params
    })
}

/**
 * 黑名单-编辑
 */
export function blackEdit(data) {
    return request({
        url: '/api/admin/app-blacklist/edit',
        method: 'post',
        data
    })
}

/**
 * 黑名单-批量删除
 */
export function blackBatchDel(data) {
    return request({
        url: '/api/admin/app-blacklist/batchDel',
        method: 'post',
        data
    })
}

/**
 * 黑名单-批量删除-根据用户ID
 */
export function batchDelByPlayerIds(data) {
    return request({
        url: '/api/admin/app-blacklist/batchDelByPlayerIds',
        method: 'post',
        data
    })
}

/**
 * 黑名单-批量新增
 */
export function blackBatchAdd(data) {
    return request({
        url: '/api/admin/app-blacklist/batchAdd',
        method: 'post',
        data
    })
}

/**
 * 黑名单-查询单个用户状态
 */
export function blackQueryOne(params) {
    return request({
        url: '/api/admin/app-blacklist/queryPlayerBlackState',
        method: 'get',
        params
    })
}

/**
 * 黑名单-查询列表
 */
export function blackQueryList(params) {
    return request({
        url: '/api/admin/app-blacklist/queryList',
        method: 'get',
        params
    })
}
