import request from '@/utils/request'

export function queryUserMenu() {
    return request({
        url: '/api/admin/menu/queryUserMenu',
        method: 'get'
    })
}

export function queryMenu(params) {
    return request({
        url: '/api/admin/menu/queryMenu',
        method: 'get',
        params
    })
}

export function add(data) {
    return request({
        url: '/api/admin/menu/add',
        method: 'post',
        data
    })
}

export function edit(data) {
    return request({
        url: '/api/admin/menu/edit',
        method: 'post',
        data
    })
}

export function del(ids) {
    return request({
        url: '/api/admin/menu/del',
        method: 'post',
        data: ids
    })
}

export default {
    queryUserMenu,
    queryMenu,
    add,
    edit,
    del
}
