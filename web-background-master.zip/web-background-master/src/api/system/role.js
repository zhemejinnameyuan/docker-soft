import request from '@/utils/request'

export function queryRole(params) {
    return request({
        url: '/api/admin/role/queryRole',
        method: 'get',
        params
    })
}

export function add(data) {
    return request({
        url: '/api/admin/role/add',
        method: 'post',
        data
    })
}

export function edit(data) {
    return request({
        url: '/api/admin/role/edit',
        method: 'post',
        data
    })
}

export function del(ids) {
    return request({
        url: '/api/admin/role/del',
        method: 'post',
        data: ids
    })
}

export function relationMenu(data) {
    return request({
        url: '/api/admin/role/relationMenu',
        method: 'post',
        data
    })
}

export default {
    queryRole,
    add,
    edit,
    del,
    relationMenu
}
