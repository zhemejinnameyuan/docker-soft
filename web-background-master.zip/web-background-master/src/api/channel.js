import request from '@/utils/request'

export function relationChannel(data) {
    return request({
        url: '/api/admin/channel/package/relationChannel',
        method: 'post',
        data
    })
}
export function enableDisable(data) {
    return request({
        url: '/api/admin/channel/package/enableDisable',
        method: 'post',
        data
    })
}

export function packageEdit(data) {
    return request({
        url: '/api/admin/channel/package/edit',
        method: 'post',
        data
    })
}

export function packageAdd(data) {
    return request({
        url: '/api/admin/channel/package/add',
        method: 'post',
        data
    })
}

export function edit(data) {
    return request({
        url: '/api/admin/channel/edit',
        method: 'post',
        data
    })
}

export function add(data) {
    return request({
        url: '/api/admin/channel/add',
        method: 'post',
        data
    })
}

export function packageList(params) {
    return request({
        url: '/api/admin/channel/package/list',
        method: 'get',
        params
    })
}

export function list(params) {
    return request({
        url: '/api/admin/channel/list',
        method: 'get',
        params
    })
}

//渠道详情
export function queryDetail(params) {
    return request({
        url: '/api/admin/channel/queryDetail',
        method: 'get',
        params
    })
}

//渠道包详情
export function queryPackageDetail(params) {
    return request({
        url: '/api/admin/channel/queryPackageDetail',
        method: 'get',
        params
    })
}
