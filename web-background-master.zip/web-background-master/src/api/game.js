import request from '@/utils/request'

/**
 *  查询机器人列表
 */
export function robotList(params) {
    return request({
        url: '/api/admin/robot/list',
        method: 'get',
        params
    })
}

/**
 *  查询游戏房间配置
 */
export function gameConfigList(params) {
    return request({
        url: '/api/admin/game-config/list',
        method: 'get',
        params
    })
}

/**
 *  保存游戏房间配置
 */
export function saveGameConfig(data) {
    return request({
        url: '/api/admin/game-config/save',
        method: 'post',
        data
    })
}
