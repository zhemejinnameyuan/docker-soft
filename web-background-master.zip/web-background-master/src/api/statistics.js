import request from '@/utils/request'

// 应用版本(stats:versions) /api/admin/stats/versions
export function statsVersions(params) {
    return request({
        url: '/api/admin/stats/versions',
        method: 'get',
        params
    })
}
// 统计概览-用户总数(stats:overview) /api/admin/stats/overview/user
export function statsStatsOverviewUser(params) {
    return request({
        url: '/api/admin/stats/overview/user',
        method: 'get',
        params
    })
}
// 统计概览-在线用户数(stats:overview) /api/admin/stats/overview/online
export function statsStatsOverviewOnline(params) {
    return request({
        url: '/api/admin/stats/overview/online',
        method: 'get',
        params
    })
}
// 统计概览-付费情况
export function statsStatsOverviewRevenue(params) {
    return request({
        url: '/api/admin/stats/overview/revenue',
        method: 'get',
        params
    })
}
// 统计概览-每日概览(stats:overview) /api/admin/stats/overview/day
export function statsStatsOverviewDay(params) {
    return request({
        url: '/api/admin/stats/overview/day',
        method: 'get',
        params
    })
}
// 月新增表(stats:new:month) /api/admin/stats/new/month/table
export function statsNewMonthTable(params) {
    return request({
        url: '/api/admin/stats/new/month/table',
        method: 'get',
        params
    })
}
// 月新增图(stats:new:month) /api/admin/stats/new/month/chart
export function statsNewMonthChart(params) {
    return request({
        url: '/api/admin/stats/new/month/chart',
        method: 'get',
        params
    })
}
// 日新增表(stats:new:day) /api/admin/stats/new/day/table
export function statsNewDayTable(params) {
    return request({
        url: '/api/admin/stats/new/day/table',
        method: 'get',
        params
    })
}
// 日新增图(stats:new:day) /api/admin/stats/new/day/chart
export function statsNewDayChart(params) {
    return request({
        url: '/api/admin/stats/new/day/chart',
        method: 'get',
        params
    })
}
// 月活跃表(stats:active:month) /api/admin/stats/active/month/table
export function statsActiveMonthTable(params) {
    return request({
        url: '/api/admin/stats/active/month/table',
        method: 'get',
        params
    })
}
// 月活跃图(stats:active:month) /api/admin/stats/active/month/chart
export function statsActiveMonthChart(params) {
    return request({
        url: '/api/admin/stats/active/month/chart',
        method: 'get',
        params
    })
}
// 日活跃表(stats:active:day) /api/admin/stats/active/day/table
export function statsActiveDayTable(params) {
    return request({
        url: '/api/admin/stats/active/day/table',
        method: 'get',
        params
    })
}
// 日活跃图(stats:active:day) /api/admin/stats/active/day/chart
export function statsActiveDayChart(params) {
    return request({
        url: '/api/admin/stats/active/day/chart',
        method: 'get',
        params
    })
}

// 日留存表(stats:retain:day) /api/admin/stats/retain/day/table
export function statsRetainDayTable(params) {
    return request({
        url: '/api/admin/stats/retain/day/table',
        method: 'get',
        params
    })
}
// 周留存表(stats:retain:week) /api/admin/stats/retain/week/table
export function statsRetainWeekTable(params) {
    return request({
        url: '/api/admin/stats/retain/week/table',
        method: 'get',
        params
    })
}
// 月留存表(stats:retain:month) /api/admin/stats/retain/month/table
export function statsRetainMonthTable(params) {
    return request({
        url: '/api/admin/stats/retain/month/table',
        method: 'get',
        params
    })
}

// 渠道统计(stats:channel) /api/admin/stats/channel
export function statsStatsChannel(params) {
    return request({
        url: '/api/admin/stats/channel',
        method: 'get',
        params
    })
}

// 渠道统计-营收统计
export function statsChannelRevenue(params) {
    return request({
        url: '/api/admin/stats/channel/revenue',
        method: 'get',
        params
    })
}

// 渠道包统计(stats:channel:package) /api/admin/stats/channel/package
export function statsStatsChannelPackage(params) {
    return request({
        url: '/api/admin/stats/channel/package',
        method: 'get',
        params
    })
}

// 渠道包统计-营收统计
export function statsChannelPackageRevenue(params) {
    return request({
        url: '/api/admin/stats/channel/package/revenue',
        method: 'get',
        params
    })
}
