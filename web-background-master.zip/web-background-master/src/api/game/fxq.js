import request from '@/utils/request'

// Fxq-保存机器人配置(fxq:robot:save) /api/admin/fxq/robot/save
export function fxqRobotSave(data) {
    return request({
        url: '/api/admin/fxq/robot/save',
        method: 'post',
        data
    })
}
// Fxq-Quick-启用/禁用房间(fxq:quick:room:enableDisable) /api/admin/fxq/quick/room/enableDisable
export function fxqQuickRoomEnableDisable(data) {
    return request({
        url: '/api/admin/fxq/quick/room/enableDisable',
        method: 'post',
        data
    })
}
// Fxq-Quick-编辑房间(fxq:quick:room:edit) /api/admin/fxq/quick/room/edit
export function fxqQuickRoomEdit(data) {
    return request({
        url: '/api/admin/fxq/quick/room/edit',
        method: 'post',
        data
    })
}
// Fxq-Quick-创建房间(fxq:quick:room:add) /api/admin/fxq/quick/room/add
export function fxqQuickRoomAdd(data) {
    return request({
        url: '/api/admin/fxq/quick/room/add',
        method: 'post',
        data
    })
}

// Fxq-Master-启用/禁用房间(fxq:master:room:enableDisable) /api/admin/fxq/master/room/enableDisable
export function fxqMasterRoomEnableDisable(data) {
    return request({
        url: '/api/admin/fxq/master/room/enableDisable',
        method: 'post',
        data
    })
}
// Fxq-Master-编辑房间(fxq:master:room:edit) /api/admin/fxq/master/room/edit
export function fxqMasterRoomEdit(data) {
    return request({
        url: '/api/admin/fxq/master/room/edit',
        method: 'post',
        data
    })
}
// Fxq-Master-创建房间(fxq:master:room:add) /api/admin/fxq/master/room/add
export function fxqMasterRoomAdd(data) {
    return request({
        url: '/api/admin/fxq/master/room/add',
        method: 'post',
        data
    })
}
// Fxq-保存全局配置(fxq:global:save) /api/admin/fxq/global/save
export function fxqGlobalSave(data) {
    return request({
        url: '/api/admin/fxq/global/save',
        method: 'post',
        data
    })
}
// Fxq-Classic-启用/禁用房间(fxq:points:classic:enableDisable) /api/admin/fxq/classic/room/enableDisable
export function fxqClassicRoomEnableDisable(data) {
    return request({
        url: '/api/admin/fxq/classic/room/enableDisable',
        method: 'post',
        data
    })
}
// Fxq-Classic-编辑房间(fxq:classic:room:edit) /api/admin/fxq/classic/room/edit
export function fxqClassicRoomEdit(data) {
    return request({
        url: '/api/admin/fxq/classic/room/edit',
        method: 'post',
        data
    })
}
// Fxq-Classic-创建房间(fxq:classic:room:add) /api/admin/fxq/classic/room/add
export function fxqClassicRoomAdd(data) {
    return request({
        url: '/api/admin/fxq/classic/room/add',
        method: 'post',
        data
    })
}

// Fxq-查询机器人配置(fxq:robot:get) /api/admin/fxq/robot/get
export function fxqRobotGet(params) {
    return request({
        url: '/api/admin/fxq/robot/get',
        method: 'get',
        params
    })
}
// Fxq-Quick-房间列表(fxq:quick:room:list || fxq:global:newbie:quick) /api/admin/fxq/quick/room/list
export function fxqQuickRoomList(params) {
    return request({
        url: '/api/admin/fxq/quick/room/list',
        method: 'get',
        params
    })
}
// Fxq-Quick-房间底注(fxq:quick:room:list)  /api/admin/fxq/quick/room/ante
export function fxqQuickRoomAnte(params) {
    return request({
        url: '/api/admin/fxq/quick/room/ante',
        method: 'get',
        params
    })
}

// Fxq-Quick-牌局详情-回放日志(fxq:quick:flow:detail)  /api/admin/fxq/quick/flow/turns
export function fxqQuickFlowTurns(params) {
    return request({
        url: '/api/admin/fxq/quick/flow/turns',
        method: 'get',
        params
    })
}
// Fxq-Quick-牌局统计(fxq:quick:flow:list) /api/admin/fxq/quick/flow/stats
export function fxqQuickFlowStats(params) {
    return request({
        url: '/api/admin/fxq/quick/flow/stats',
        method: 'get',
        params
    })
}
// Fxq-Quick-牌局记录(fxq:quick:flow:list) /api/admin/fxq/quick/flow/list
export function fxqQuickFlowList(params) {
    return request({
        url: '/api/admin/fxq/quick/flow/list',
        method: 'get',
        params
    })
}
// Fxq-Quick-牌局详情(fxq:quick:flow:detail) /api/admin/fxq/quick/flow/detail
export function fxqQuickFlowDetail(params) {
    return request({
        url: '/api/admin/fxq/quick/flow/detail',
        method: 'get',
        params
    })
}

// Fxq-Quick-策略记录
export function fxqQuickReservoirLog(params) {
    return request({
        url: '/api/admin/fxq/quick/reservoir/log',
        method: 'get',
        params
    })
}

// Fxq-Master-房间列表(fxq:master:room:list || fxq:global:newbie:master) /api/admin/fxq/master/room/list
export function fxqMasterRoomList(params) {
    return request({
        url: '/api/admin/fxq/master/room/list',
        method: 'get',
        params
    })
}
// Fxq-Master-房间底注(fxq:master:room:list) /api/admin/fxq/master/room/ante
export function fxqMasterRoomAnte(params) {
    return request({
        url: '/api/admin/fxq/master/room/ante',
        method: 'get',
        params
    })
}

// Fxq-Master-牌局详情-回合日志(fxq:master:flow:detail) /api/admin/fxq/master/flow/turns
export function fxqMasterFlowTurns(params) {
    return request({
        url: '/api/admin/fxq/master/flow/turns',
        method: 'get',
        params
    })
}
// Fxq-Master-牌局统计(fxq:master:flow:list) /api/admin/fxq/master/flow/stats
export function fxqMasterFlowStats(params) {
    return request({
        url: '/api/admin/fxq/master/flow/stats',
        method: 'get',
        params
    })
}
// Fxq-Master-牌局记录(fxq:master:flow:list) /api/admin/fxq/master/flow/list
export function fxqMasterFlowList(params) {
    return request({
        url: '/api/admin/fxq/master/flow/list',
        method: 'get',
        params
    })
}
// Fxq-Master-牌局详情(fxq:master:flow:detail) /api/admin/fxq/master/flow/detail
export function fxqMasterFlowDetail(params) {
    return request({
        url: '/api/admin/fxq/master/flow/detail',
        method: 'get',
        params
    })
}

// Fxq-Master-策略记录
export function fxqMasterReservoirLog(params) {
    return request({
        url: '/api/admin/fxq/master/reservoir/log',
        method: 'get',
        params
    })
}

// Fxq-全局配置(fxq:global:get) /api/admin/fxq/global/get
export function fxqGlobalGet(params) {
    return request({
        url: '/api/admin/fxq/global/get',
        method: 'get',
        params
    })
}
// Fxq-Classic-房间列表(fxq:classic:room:list || fxq:global:newbie:classic) /api/admin/fxq/classic/room/list
export function fxqClassicRoomList(params) {
    return request({
        url: '/api/admin/fxq/classic/room/list',
        method: 'get',
        params
    })
}
// Fxq-Classic-房间底注(fxq:classic:room:list) /api/admin/fxq/classic/room/ante
export function fxqClassicRoomAnte(params) {
    return request({
        url: '/api/admin/fxq/classic/room/ante',
        method: 'get',
        params
    })
}

// Fxq-Classic-牌局详情-回放日志(fxq:classic:flow:detail) /api/admin/fxq/classic/flow/turns
export function fxqClassicFlowTurns(params) {
    return request({
        url: '/api/admin/fxq/classic/flow/turns',
        method: 'get',
        params
    })
}
// Fxq-Classic-牌局统计(fxq:classic:flow:list) /api/admin/fxq/classic/flow/stats
export function fxqClassicFlowStats(params) {
    return request({
        url: '/api/admin/fxq/classic/flow/stats',
        method: 'get',
        params
    })
}
// Fxq-Classic-牌局记录(fxq:classic:flow:list)  /api/admin/fxq/classic/flow/list
export function fxqClassicFlowList(params) {
    return request({
        url: '/api/admin/fxq/classic/flow/list',
        method: 'get',
        params
    })
}
// Fxq-Classic-牌局详情(fxq:classic:flow:detail) /api/admin/fxq/classic/flow/detail
export function fxqClassicFlowDetail(params) {
    return request({
        url: '/api/admin/fxq/classic/flow/detail',
        method: 'get',
        params
    })
}

// Fxq-Classic-策略记录
export function fxqClassicReservoirLog(params) {
    return request({
        url: '/api/admin/fxq/classic/reservoir/log',
        method: 'get',
        params
    })
}
