import request from '@/utils/request'

// 保存机器人配置(rb:robot:save) /api/admin/rb/saveRobotConfig
export function rbSaveRobotConfig(data) {
    return request({
        url: '/api/admin/rb/saveRobotConfig',
        method: 'post',
        data
    })
}
// rb-启用/禁用房间(rb:room:enableDisable) /api/admin/rb/room/enableDisable
export function rbRoomEnableDisable(data) {
    return request({
        url: '/api/admin/rb/room/enableDisable',
        method: 'post',
        data
    })
}
// rb-编辑房间(rb:room:edit) /api/admin/rb/room/edit
export function rbRoomEdit(data) {
    return request({
        url: '/api/admin/rb/room/edit',
        method: 'post',
        data
    })
}
// rb-创建房间(rb:room:add) /api/admin/rb/room/add
export function rbRoomAdd(data) {
    return request({
        url: '/api/admin/rb/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(rb:global:save) /api/admin/rb/global/save
export function rbGlobalSave(data) {
    return request({
        url: '/api/admin/rb/global/save',
        method: 'post',
        data
    })
}
// rb-房间列表(rb:room:list) /api/admin/rb/room/list
export function rbRoomList(params) {
    return request({
        url: '/api/admin/rb/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(rb:global:get) /api/admin/rb/global/get
export function rbGlobalGet(params) {
    return request({
        url: '/api/admin/rb/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(rb:robot:get) /api/admin/rb/getRobotConfig
export function rbGetRobotConfig(params) {
    return request({
        url: '/api/admin/rb/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(rb:flow:list) /api/admin/rb/flow/stats
export function rbFlowStats(params) {
    return request({
        url: '/api/admin/rb/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(rb:flow:list) /api/admin/rb/flow/list
export function rbFlowList(params) {
    return request({
        url: '/api/admin/rb/flow/list',
        method: 'get',
        params
    })
}
// 牌局详情(rb:flow:detail) /api/admin/rb/flow/detail
export function rbFlowDetail(params) {
    return request({
        url: '/api/admin/rb/flow/detail',
        method: 'get',
        params
    })
}
// rb下注币种（rb:room:list）
export function rbBetCoins(params) {
    return request({
        url: '/api/admin/rb/bet/coins',
        method: 'get',
        params
    })
}
// rb-查询蓄水池(rb:reservoir:log) /api/admin/rb/reservoir/log
export function rbReservoirLog(params) {
    return request({
        url: '/api/admin/rb/reservoir/log',
        method: 'get',
        params
    })
}
