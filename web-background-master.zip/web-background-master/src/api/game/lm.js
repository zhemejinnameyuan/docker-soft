import request from '@/utils/request'

// Points-房间列表(rummy:points:room:list) /api/admin/rummy/points/room/list
export function pointsRoomList(params) {
    return request({
        url: '/api/admin/rummy/points/room/list',
        method: 'get',
        params
    })
}

// Points-房间底注(rummy:points:room:list) /api/admin/rummy/points/room/ante
export function pointsRoomAnte(params) {
    return request({
        url: '/api/admin/rummy/points/room/ante',
        method: 'get',
        params
    })
}

// 练习场-启用/禁用房间(rummy:practice:room:enableDisable) /api/admin/rummy/practice/room/enableDisable
export function practiceRoomEnableDisable(data) {
    return request({
        url: '/api/admin/rummy/practice/room/enableDisable',
        method: 'post',
        data
    })
}

// 练习场-编辑房间(rummy:practice:room:edit) /api/admin/rummy/practice/room/edit
export function practiceRoomEdit(data) {
    return request({
        url: '/api/admin/rummy/practice/room/edit',
        method: 'post',
        data
    })
}

// 练习场-创建房间(rummy:practice:room:add) /api/admin/rummy/practice/room/add
export function practiceRoomAdd(data) {
    return request({
        url: '/api/admin/rummy/practice/room/add',
        method: 'post',
        data
    })
}

// Pool-启用/禁用房间(rummy:pool:room:enableDisable) /api/admin/rummy/pool/room/enableDisable
export function poolRoomEnableDisable(data) {
    return request({
        url: '/api/admin/rummy/pool/room/enableDisable',
        method: 'post',
        data
    })
}

// Pool-编辑房间(rummy:pool:room:edit) /api/admin/rummy/pool/room/edit
export function poolRoomEdit(data) {
    return request({
        url: '/api/admin/rummy/pool/room/edit',
        method: 'post',
        data
    })
}

// Pool-创建房间(rummy:pool:room:add) /api/admin/rummy/pool/room/add
export function poolRoomAdd(data) {
    return request({
        url: '/api/admin/rummy/pool/room/add',
        method: 'post',
        data
    })
}

// Points-启用/禁用房间(rummy:points:room:enableDisable) /api/admin/rummy/points/room/enableDisable
export function pointsRoomEnableDisable(data) {
    return request({
        url: '/api/admin/rummy/points/room/enableDisable',
        method: 'post',
        data
    })
}

// Points-编辑房间(rummy:points:room:edit) /api/admin/rummy/points/room/edit
export function pointsRoomEdit(data) {
    return request({
        url: '/api/admin/rummy/points/room/edit',
        method: 'post',
        data
    })
}

// Points-创建房间(rummy:points:room:add) /api/admin/rummy/points/room/add
export function pointsRoomAdd(data) {
    return request({
        url: '/api/admin/rummy/points/room/add',
        method: 'post',
        data
    })
}

// Deals-启用/禁用房间(rummy:deals:room:enableDisable) /api/admin/rummy/deals/room/enableDisable
export function dealsRoomEnableDisable(data) {
    return request({
        url: '/api/admin/rummy/deals/room/enableDisable',
        method: 'post',
        data
    })
}

// Deals-编辑房间(rummy:deals:room:edit) /api/admin/rummy/deals/room/edit
export function dealsRoomEdit(data) {
    return request({
        url: '/api/admin/rummy/deals/room/edit',
        method: 'post',
        data
    })
}

// Deals-创建房间(rummy:deals:room:add) /api/admin/rummy/deals/room/add
export function dealsRoomAdd(data) {
    return request({
        url: '/api/admin/rummy/deals/room/add',
        method: 'post',
        data
    })
}

// 练习场-房间列表(rummy:practice:room:list) /api/admin/rummy/practice/room/list
export function practiceRoomList(params) {
    return request({
        url: '/api/admin/rummy/practice/room/list',
        method: 'get',
        params
    })
}

// 练习场-房间底注(rummy:practice:room:list) /api/admin/rummy/practice/room/ante
export function practiceRoomAnte(params) {
    return request({
        url: '/api/admin/rummy/practice/room/ante',
        method: 'get',
        params
    })
}

// Pool-房间列表(rummy:pool:room:list) /api/admin/rummy/pool/room/list
export function poolRoomList(params) {
    return request({
        url: '/api/admin/rummy/pool/room/list',
        method: 'get',
        params
    })
}

// Pool-房间底注(rummy:pool:room:list) /api/admin/rummy/pool/room/ante
export function poolRoomAnte(params) {
    return request({
        url: '/api/admin/rummy/pool/room/ante',
        method: 'get',
        params
    })
}

// Deals-房间列表(rummy:deals:room:list) /api/admin/rummy/deals/room/list
export function dealsRoomList(params) {
    return request({
        url: '/api/admin/rummy/deals/room/list',
        method: 'get',
        params
    })
}

// Deals-策略记录
export function dealsReservoirLog(params) {
    return request({
        url: '/api/admin/rummy/deals/reservoir/log',
        method: 'get',
        params
    })
}

// Deals-房间底注(rummy:deals:room:list) /api/admin/rummy/deals/room/ante
export function dealsRoomAnte(params) {
    return request({
        url: '/api/admin/rummy/deals/room/ante',
        method: 'get',
        params
    })
}

// Points-牌局统计(rummy:points:flow:list) /api/admin/rummy/points/flow/stats
export function pointsFlowStats(params) {
    return request({
        url: '/api/admin/rummy/points/flow/stats',
        method: 'get',
        params
    })
}

// Points-牌局记录(rummy:points:flow:list) /api/admin/rummy/points/flow/list
export function pointsFlowList(params) {
    return request({
        url: '/api/admin/rummy/points/flow/list',
        method: 'get',
        params
    })
}

// Points-策略记录
export function pointsReservoirLog(params) {
    return request({
        url: '/api/admin/rummy/points/reservoir/log',
        method: 'get',
        params
    })
}

// Points-牌局详情(rummy:points:flow:detail) /api/admin/rummy/points/flow/detail
export function pointsFlowDetail(params) {
    return request({
        url: '/api/admin/rummy/points/flow/detail',
        method: 'get',
        params
    })
}

// Points-牌局详情回合日志(rummy:points:flow:detail)  /api/admin/rummy/points/flow/turns
export function pointsFlowTurns(params) {
    return request({
        url: '/api/admin/rummy/points/flow/turns',
        method: 'get',
        params
    })
}

// Pool-牌局统计(rummy:pool:flow:list) /api/admin/rummy/pool/flow/stats
export function poolFlowStats(params) {
    return request({
        url: '/api/admin/rummy/pool/flow/stats',
        method: 'get',
        params
    })
}

// Pool-牌局记录(rummy:pool:flow:list) /api/admin/rummy/pool/flow/list
export function poolFlowList(params) {
    return request({
        url: '/api/admin/rummy/pool/flow/list',
        method: 'get',
        params
    })
}

// Pool-策略记录
export function poolReservoirLog(params) {
    return request({
        url: '/api/admin/rummy/pool/reservoir/log',
        method: 'get',
        params
    })
}

// Pool-牌局详情(rummy:pool:flow:detail) /api/admin/rummy/pool/flow/detail
export function poolFlowDetail(params) {
    return request({
        url: '/api/admin/rummy/pool/flow/detail',
        method: 'get',
        params
    })
}

// Pool-牌局详情回合日志(rummy:pool:flow:detail)  /api/admin/rummy/pool/flow/turns
export function poolFlowTurns(params) {
    return request({
        url: '/api/admin/rummy/pool/flow/turns',
        method: 'get',
        params
    })
}

// Deals-牌局统计(rummy:deals:flow:list) /api/admin/rummy/deals/flow/stats
export function dealsFlowStats(params) {
    return request({
        url: '/api/admin/rummy/deals/flow/stats',
        method: 'get',
        params
    })
}

// Deals-牌局记录(rummy:deals:flow:list) /api/admin/rummy/deals/flow/list
export function dealsFlowList(params) {
    return request({
        url: '/api/admin/rummy/deals/flow/list',
        method: 'get',
        params
    })
}

// Deals-牌局详情(rummy:deals:flow:detail) /api/admin/rummy/deals/flow/detail
export function dealsFlowDetail(params) {
    return request({
        url: '/api/admin/rummy/deals/flow/detail',
        method: 'get',
        params
    })
}

// Deals-牌局详情回合日志(rummy:deals:flow:detail)  /api/admin/rummy/deals/flow/turns
export function dealsFlowTurns(params) {
    return request({
        url: '/api/admin/rummy/deals/flow/turns',
        method: 'get',
        params
    })
}

// 查询全局配置
export function lmGlobalGet(params) {
    return request({
        url: '/api/admin/rummy/global/get',
        method: 'get',
        params
    })
}

// 保存全局配置
export function lmGlobalSave(data) {
    return request({
        url: '/api/admin/rummy/global/save',
        method: 'post',
        data
    })
}

// 查询练习场配置
export function lmPracticeConfigGet(params) {
    return request({
        url: '/api/admin/rummy/config/practice/get',
        method: 'get',
        params
    })
}

// 保存练习场配置
export function lmPracticeConfigSave(data) {
    return request({
        url: '/api/admin/rummy/config/practice/save',
        method: 'post',
        data
    })
}

// 保存机器人配置(rummy:robot:save) /api/admin/rummy/robot/save
export function robotSave(data) {
    return request({
        url: '/api/admin/rummy/robot/save',
        method: 'post',
        data
    })
}

// 查询机器人配置(rummy:robot:get) /api/admin/rummy/robot/get
export function robotGet(params) {
    return request({
        url: '/api/admin/rummy/robot/get',
        method: 'get',
        params
    })
}
