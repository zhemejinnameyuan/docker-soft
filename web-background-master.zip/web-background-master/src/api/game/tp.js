import request from '@/utils/request'

// 保存机器人配置(tp:robot:save) /api/admin/tp/saveRobotConfig
export function tpSaveRobotConfig(data) {
    return request({
        url: '/api/admin/tp/robot/save',
        method: 'post',
        data
    })
}
// tp-启用/禁用房间(tp:room:enableDisable) /api/admin/tp/room/enableDisable
export function tpRoomEnableDisable(data) {
    return request({
        url: '/api/admin/tp/room/enableDisable',
        method: 'post',
        data
    })
}
// tp-编辑房间(tp:room:edit) /api/admin/tp/room/edit
export function tpRoomEdit(data) {
    return request({
        url: '/api/admin/tp/room/edit',
        method: 'post',
        data
    })
}
// tp-创建房间(tp:room:add) /api/admin/tp/room/add
export function tpRoomAdd(data) {
    return request({
        url: '/api/admin/tp/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(tp:global:save)
export function tpGlobalSave(data) {
    return request({
        url: '/api/admin/tp/global/save',
        method: 'post',
        data
    })
}
// tp-房间列表(tp:room:list) /api/admin/tp/room/list
export function tpRoomList(params) {
    return request({
        url: '/api/admin/tp/room/list',
        method: 'get',
        params
    })
}
// TP-练习场房间底注(tp:room:ante) /api/admin/tp/room/ante
export function tpRoomAnte(data) {
    return request({
        url: '/api/admin/tp/room/ante',
        method: 'get',
        data
    })
}
// 查询全局配置(tp:global:get) /api/admin/tp/global/get
export function tpGlobalGet(params) {
    return request({
        url: '/api/admin/tp/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(tp:robot:get) /api/admin/tp/getRobotConfig
export function tpGetRobotConfig(params) {
    return request({
        url: '/api/admin/tp/robot/get',
        method: 'get',
        params
    })
}
// 牌局统计(tp:flow:list) /api/admin/tp/flow/stats
export function tpFlowStats(params) {
    return request({
        url: '/api/admin/tp/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(tp:flow:list) /api/admin/tp/flow/list
export function tpFlowList(params) {
    return request({
        url: '/api/admin/tp/flow/list',
        method: 'get',
        params
    })
}
//  策略记录
export function tpReservoirLog(params) {
    return request({
        url: '/api/admin/tp/reservoir/log',
        method: 'get',
        params
    })
}

// 牌局详情(tp:flow:detail) /api/admin/tp/flow/detail
export function tpFlowDetail(params) {
    return request({
        url: '/api/admin/tp/flow/detail',
        method: 'get',
        params
    })
}
// 牌局详情(tp:flow:detail) /api/admin/tp/flow/turns
export function tpFlowTurns(params) {
    return request({
        url: '/api/admin/tp/flow/turns',
        method: 'get',
        params
    })
}
// TP-练习场-查询配置(tp:config:practice:get) /api/admin/tp/config/practice/get
export function tpPracticeGlobalGet(params) {
    return request({
        url: '/api/admin/tp/config/practice/get ',
        method: 'get',
        params
    })
}
// TP-练习场-保存配置(tp:config:practice:save)
export function tpPracticeGlobalSave(data) {
    return request({
        url: '/api/admin/tp/config/practice/save',
        method: 'post',
        data
    })
}
// tp-练习场-房间列表(tp:room:practice:list) /api/admin/tp/room/practice/list
export function tpPracticeRoomList(params) {
    return request({
        url: '/api/admin/tp/room/practice/list',
        method: 'get',
        params
    })
}
// tp-练习场-启用/禁用房间(tp:room:practice:enableDisable) /api/admin/tp/room/practice/enableDisable
export function tpPracticeRoomEnableDisable(data) {
    return request({
        url: '/api/admin/tp/room/practice/enableDisable',
        method: 'post',
        data
    })
}
// TP-练习场房间底注(tp:room:practice:ante) /api/admin/tp/room/practice/ante
export function tpPracticeRoomAnte(data) {
    return request({
        url: '/api/admin/tp/room/practice/ante',
        method: 'get',
        data
    })
}
// tp-练习场-编辑房间(tp:room:practice:edit) /api/admin/tp/room/practice/edit
export function tpPracticeRoomEdit(data) {
    return request({
        url: '/api/admin/tp/room/practice/edit',
        method: 'post',
        data
    })
}
// tp-练习场-创建房间(tp:room:practice:add) /api/admin/tp/room/practice/add
export function tpPracticeRoomAdd(data) {
    return request({
        url: '/api/admin/tp/room/practice/add',
        method: 'post',
        data
    })
}
