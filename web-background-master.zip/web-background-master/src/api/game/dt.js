import request from '@/utils/request'

// 保存机器人配置(dt:robot:save) /api/admin/dt/saveRobotConfig
export function dtSaveRobotConfig(data) {
    return request({
        url: '/api/admin/dt/saveRobotConfig',
        method: 'post',
        data
    })
}
// DT-启用/禁用房间(dt:room:enableDisable) /api/admin/dt/room/enableDisable
export function dtRoomEnableDisable(data) {
    return request({
        url: '/api/admin/dt/room/enableDisable',
        method: 'post',
        data
    })
}
// DT-编辑房间(dt:room:edit) /api/admin/dt/room/edit
export function dtRoomEdit(data) {
    return request({
        url: '/api/admin/dt/room/edit',
        method: 'post',
        data
    })
}

// DT-创建房间(dt:room:add) /api/admin/dt/room/add
export function dtRoomAdd(data) {
    return request({
        url: '/api/admin/dt/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(dt:global:save) /api/admin/dt/global/save
export function dtGlobalSave(data) {
    return request({
        url: '/api/admin/dt/global/save',
        method: 'post',
        data
    })
}

// DT-房间列表(dt:room:list) /api/admin/dt/room/list
export function dtRoomList(params) {
    return request({
        url: '/api/admin/dt/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(dt:global:get) /api/admin/dt/global/get
export function dtGlobalGet(params) {
    return request({
        url: '/api/admin/dt/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(dt:robot:get) /api/admin/dt/getRobotConfig
export function dtGetRobotConfig(params) {
    return request({
        url: '/api/admin/dt/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(dt:flow:list) /api/admin/dt/flow/stats
export function dtFlowStats(params) {
    return request({
        url: '/api/admin/dt/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(dt:flow:list) /api/admin/dt/flow/list
export function dtFlowList(params) {
    return request({
        url: '/api/admin/dt/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(dt:flow:detail) /api/admin/dt/flow/detail
export function dtFlowDetail(params) {
    return request({
        url: '/api/admin/dt/flow/detail',
        method: 'get',
        params
    })
}

// dt下注币种（dt:room:list）
export function dtBetCoins(params) {
    return request({
        url: '/api/admin/dt/bet/coins',
        method: 'get',
        params
    })
}

// DT-查询蓄水池(dt:reservoir:log) /api/admin/dt/reservoir/log
export function dtReservoirLog(params) {
    return request({
        url: '/api/admin/dt/reservoir/log',
        method: 'get',
        params
    })
}
