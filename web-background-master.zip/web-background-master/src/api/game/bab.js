import request from '@/utils/request'

// 保存机器人配置(bab:robot:save) /api/admin/bab/saveRobotConfig
export function babSaveRobotConfig(data) {
    return request({
        url: '/api/admin/bab/saveRobotConfig',
        method: 'post',
        data
    })
}
// bab-启用/禁用房间(bab:room:enableDisable) /api/admin/bab/room/enableDisable
export function babRoomEnableDisable(data) {
    return request({
        url: '/api/admin/bab/room/enableDisable',
        method: 'post',
        data
    })
}
// bab-编辑房间(bab:room:edit) /api/admin/bab/room/edit
export function babRoomEdit(data) {
    return request({
        url: '/api/admin/bab/room/edit',
        method: 'post',
        data
    })
}

// bab-创建房间(bab:room:add) /api/admin/bab/room/add
export function babRoomAdd(data) {
    return request({
        url: '/api/admin/bab/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(bab:global:save) /api/admin/bab/global/save
export function babGlobalSave(data) {
    return request({
        url: '/api/admin/bab/global/save',
        method: 'post',
        data
    })
}

// bab-房间列表(bab:room:list) /api/admin/bab/room/list
export function babRoomList(params) {
    return request({
        url: '/api/admin/bab/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(bab:global:get) /api/admin/bab/global/get
export function babGlobalGet(params) {
    return request({
        url: '/api/admin/bab/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(bab:robot:get) /api/admin/bab/getRobotConfig
export function babGetRobotConfig(params) {
    return request({
        url: '/api/admin/bab/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(bab:flow:list) /api/admin/bab/flow/stats
export function babFlowStats(params) {
    return request({
        url: '/api/admin/bab/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(bab:flow:list) /api/admin/bab/flow/list
export function babFlowList(params) {
    return request({
        url: '/api/admin/bab/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(bab:flow:detail) /api/admin/bab/flow/detail
export function babFlowDetail(params) {
    return request({
        url: '/api/admin/bab/flow/detail',
        method: 'get',
        params
    })
}

// bab下注币种（bab:room:list）
export function babBetCoins(params) {
    return request({
        url: '/api/admin/bab/bet/coins',
        method: 'get',
        params
    })
}

// bab-查询蓄水池(bab:reservoir:log) /api/admin/bab/reservoir/log
export function babReservoirLog(params) {
    return request({
        url: '/api/admin/bab/reservoir/log',
        method: 'get',
        params
    })
}
