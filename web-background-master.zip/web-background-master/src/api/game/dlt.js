import request from '@/utils/request'

// 保存机器人配置(dlt:robot:save) /api/admin/dlt/saveRobotConfig
export function dltSaveRobotConfig(data) {
    return request({
        url: '/api/admin/dlt/saveRobotConfig',
        method: 'post',
        data
    })
}
// dlt-启用/禁用房间(dlt:room:enableDisable) /api/admin/dlt/room/enableDisable
export function dltRoomEnableDisable(data) {
    return request({
        url: '/api/admin/dlt/room/enableDisable',
        method: 'post',
        data
    })
}
// dlt-编辑房间(dlt:room:edit) /api/admin/dlt/room/edit
export function dltRoomEdit(data) {
    return request({
        url: '/api/admin/dlt/room/edit',
        method: 'post',
        data
    })
}

// dlt-创建房间(dlt:room:add) /api/admin/dlt/room/add
export function dltRoomAdd(data) {
    return request({
        url: '/api/admin/dlt/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(dlt:global:save) /api/admin/dlt/global/save
export function dltGlobalSave(data) {
    return request({
        url: '/api/admin/dlt/global/save',
        method: 'post',
        data
    })
}

// dlt-房间列表(dlt:room:list) /api/admin/dlt/room/list
export function dltRoomList(params) {
    return request({
        url: '/api/admin/dlt/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(dlt:global:get) /api/admin/dlt/global/get
export function dltGlobalGet(params) {
    return request({
        url: '/api/admin/dlt/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(dlt:robot:get) /api/admin/dlt/getRobotConfig
export function dltGetRobotConfig(params) {
    return request({
        url: '/api/admin/dlt/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(dlt:flow:list) /api/admin/dlt/flow/stats
export function dltFlowStats(params) {
    return request({
        url: '/api/admin/dlt/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(dlt:flow:list) /api/admin/dlt/flow/list
export function dltFlowList(params) {
    return request({
        url: '/api/admin/dlt/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(dlt:flow:detail) /api/admin/dlt/flow/detail
export function dltFlowDetail(params) {
    return request({
        url: '/api/admin/dlt/flow/detail',
        method: 'get',
        params
    })
}

// dlt下注币种（dlt:room:list）
export function dltBetCoins(params) {
    return request({
        url: '/api/admin/dlt/bet/coins',
        method: 'get',
        params
    })
}

// dlt-查询蓄水池(dlt:reservoir:log) /api/admin/dlt/reservoir/log
export function dltReservoirLog(params) {
    return request({
        url: '/api/admin/dlt/reservoir/log',
        method: 'get',
        params
    })
}
