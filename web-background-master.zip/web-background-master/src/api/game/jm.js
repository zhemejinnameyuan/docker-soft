import request from '@/utils/request'

// 保存机器人配置(jm:robot:save) /api/admin/jm/saveRobotConfig
export function jmSaveRobotConfig(data) {
    return request({
        url: '/api/admin/jm/saveRobotConfig',
        method: 'post',
        data
    })
}
// jm-启用/禁用房间(jm:room:enableDisable) /api/admin/jm/room/enableDisable
export function jmRoomEnableDisable(data) {
    return request({
        url: '/api/admin/jm/room/enableDisable',
        method: 'post',
        data
    })
}
// jm-编辑房间(jm:room:edit) /api/admin/jm/room/edit
export function jmRoomEdit(data) {
    return request({
        url: '/api/admin/jm/room/edit',
        method: 'post',
        data
    })
}

// jm-创建房间(jm:room:add) /api/admin/jm/room/add
export function jmRoomAdd(data) {
    return request({
        url: '/api/admin/jm/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(jm:global:save) /api/admin/jm/global/save
export function jmGlobalSave(data) {
    return request({
        url: '/api/admin/jm/global/save',
        method: 'post',
        data
    })
}

// jm-房间列表(jm:room:list) /api/admin/jm/room/list
export function jmRoomList(params) {
    return request({
        url: '/api/admin/jm/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(jm:global:get) /api/admin/jm/global/get
export function jmGlobalGet(params) {
    return request({
        url: '/api/admin/jm/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(jm:robot:get) /api/admin/jm/getRobotConfig
export function jmGetRobotConfig(params) {
    return request({
        url: '/api/admin/jm/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(jm:flow:list) /api/admin/jm/flow/stats
export function jmFlowStats(params) {
    return request({
        url: '/api/admin/jm/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(jm:flow:list) /api/admin/jm/flow/list
export function jmFlowList(params) {
    return request({
        url: '/api/admin/jm/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(jm:flow:detail) /api/admin/jm/flow/detail
export function jmFlowDetail(params) {
    return request({
        url: '/api/admin/jm/flow/detail',
        method: 'get',
        params
    })
}

// jm下注币种（jm:room:list）
export function jmBetCoins(params) {
    return request({
        url: '/api/admin/jm/bet/coins',
        method: 'get',
        params
    })
}

// jm-查询蓄水池(jm:reservoir:log) /api/admin/jm/reservoir/log
export function jmReservoirLog(params) {
    return request({
        url: '/api/admin/jm/reservoir/log',
        method: 'get',
        params
    })
}
