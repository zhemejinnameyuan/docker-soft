import request from '@/utils/request'

// 保存机器人配置(csz:robot:save) /api/admin/csz/saveRobotConfig
export function cszSaveRobotConfig(data) {
    return request({
        url: '/api/admin/csz/saveRobotConfig',
        method: 'post',
        data
    })
}
// csz-启用/禁用房间(csz:room:enableDisable) /api/admin/csz/room/enableDisable
export function cszRoomEnableDisable(data) {
    return request({
        url: '/api/admin/csz/room/enableDisable',
        method: 'post',
        data
    })
}
// csz-编辑房间(csz:room:edit) /api/admin/csz/room/edit
export function cszRoomEdit(data) {
    return request({
        url: '/api/admin/csz/room/edit',
        method: 'post',
        data
    })
}

// csz-创建房间(csz:room:add) /api/admin/csz/room/add
export function cszRoomAdd(data) {
    return request({
        url: '/api/admin/csz/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(csz:global:save) /api/admin/csz/global/save
export function cszGlobalSave(data) {
    return request({
        url: '/api/admin/csz/global/save',
        method: 'post',
        data
    })
}

// csz-房间列表(csz:room:list) /api/admin/csz/room/list
export function cszRoomList(params) {
    return request({
        url: '/api/admin/csz/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(csz:global:get) /api/admin/csz/global/get
export function cszGlobalGet(params) {
    return request({
        url: '/api/admin/csz/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(csz:robot:get) /api/admin/csz/getRobotConfig
export function cszGetRobotConfig(params) {
    return request({
        url: '/api/admin/csz/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(csz:flow:list) /api/admin/csz/flow/stats
export function cszFlowStats(params) {
    return request({
        url: '/api/admin/csz/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(csz:flow:list) /api/admin/csz/flow/list
export function cszFlowList(params) {
    return request({
        url: '/api/admin/csz/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(csz:flow:detail) /api/admin/csz/flow/detail
export function cszFlowDetail(params) {
    return request({
        url: '/api/admin/csz/flow/detail',
        method: 'get',
        params
    })
}

// csz下注币种（csz:room:list）
export function cszBetCoins(params) {
    return request({
        url: '/api/admin/csz/bet/coins',
        method: 'get',
        params
    })
}

// csz-查询蓄水池(csz:reservoir:log) /api/admin/csz/reservoir/log
export function cszReservoirLog(params) {
    return request({
        url: '/api/admin/csz/reservoir/log',
        method: 'get',
        params
    })
}
