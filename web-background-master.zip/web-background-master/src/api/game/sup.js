import request from '@/utils/request'

// 保存机器人配置(sup:robot:save) /api/admin/7up/saveRobotConfig
export function supSaveRobotConfig(data) {
    return request({
        url: '/api/admin/7up/saveRobotConfig',
        method: 'post',
        data
    })
}
// sup-启用/禁用房间(sup:room:enableDisable) /api/admin/7up/room/enableDisable
export function supRoomEnableDisable(data) {
    return request({
        url: '/api/admin/7up/room/enableDisable',
        method: 'post',
        data
    })
}
// sup-编辑房间(sup:room:edit) /api/admin/7up/room/edit
export function supRoomEdit(data) {
    return request({
        url: '/api/admin/7up/room/edit',
        method: 'post',
        data
    })
}

// sup-创建房间(sup:room:add) /api/admin/7up/room/add
export function supRoomAdd(data) {
    return request({
        url: '/api/admin/7up/room/add',
        method: 'post',
        data
    })
}
// 保存全局配置(sup:global:save) /api/admin/7up/global/save
export function supGlobalSave(data) {
    return request({
        url: '/api/admin/7up/global/save',
        method: 'post',
        data
    })
}

// sup-房间列表(sup:room:list) /api/admin/7up/room/list
export function supRoomList(params) {
    return request({
        url: '/api/admin/7up/room/list',
        method: 'get',
        params
    })
}
// 查询全局配置(sup:global:get) /api/admin/7up/global/get
export function supGlobalGet(params) {
    return request({
        url: '/api/admin/7up/global/get',
        method: 'get',
        params
    })
}
// 查询机器人配置(sup:robot:get) /api/admin/7up/getRobotConfig
export function supGetRobotConfig(params) {
    return request({
        url: '/api/admin/7up/getRobotConfig',
        method: 'get',
        params
    })
}
// 牌局统计(sup:flow:list) /api/admin/7up/flow/stats
export function supFlowStats(params) {
    return request({
        url: '/api/admin/7up/flow/stats',
        method: 'get',
        params
    })
}
// 牌局记录(sup:flow:list) /api/admin/7up/flow/list
export function supFlowList(params) {
    return request({
        url: '/api/admin/7up/flow/list',
        method: 'get',
        params
    })
}

// 牌局详情(sup:flow:detail) /api/admin/7up/flow/detail
export function supFlowDetail(params) {
    return request({
        url: '/api/admin/7up/flow/detail',
        method: 'get',
        params
    })
}

// sup下注币种（sup:room:list）
export function supBetCoins(params) {
    return request({
        url: '/api/admin/7up/bet/coins',
        method: 'get',
        params
    })
}

// sup-查询蓄水池(sup:reservoir:log) /api/admin/7up/reservoir/log
export function supReservoirLog(params) {
    return request({
        url: '/api/admin/7up/reservoir/log',
        method: 'get',
        params
    })
}
