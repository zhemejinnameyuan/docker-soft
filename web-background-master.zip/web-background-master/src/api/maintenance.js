import request from '@/utils/request'

/**
 * 修改ws地址
 */
export function updateWebSocketAddr(data) {
    return request({
        url: '/api/admin/maintenance/updateWebSocketAddr',
        method: 'post',
        data
    })
}

/**
 * 查询系统系统服务
 */
export function list(params) {
    return request({
        url: '/api/admin/maintenance/list',
        method: 'get',
        params
    })
}

/**
 * 停服
 */
export function shutdown(data) {
    return request({
        url: '/api/admin/maintenance/shutdown',
        method: 'post',
        data
    })
}

/**
 * 删除
 */
export function del(data) {
    return request({
        url: '/api/admin/maintenance/del',
        method: 'post',
        data
    })
}
