/** 房间类型 */
export const ROOM_TYPE = {
    CLASSIC: 4,
    QUICK: 5,
    MASTER: 6
}

/** 房间类型 */
export const roomType = {
    [ROOM_TYPE.CLASSIC]: {
        name: 'Classic',
        id: ROOM_TYPE.CLASSIC
    },
    [ROOM_TYPE.QUICK]: {
        name: 'Quick',
        id: ROOM_TYPE.QUICK
    },
    [ROOM_TYPE.MASTER]: {
        name: 'Master',
        id: ROOM_TYPE.MASTER
    }
}

/** 牌桌类型 */
export const DESK_TYPE = {
    TWO: 2,
    FOUR: 4
}

export const deskType = {
    [DESK_TYPE.TWO]: {
        name: '2人桌',
        id: DESK_TYPE.TWO
    },
    [DESK_TYPE.FOUR]: {
        name: '4人桌',
        id: DESK_TYPE.FOUR
    }
}

export const level = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
