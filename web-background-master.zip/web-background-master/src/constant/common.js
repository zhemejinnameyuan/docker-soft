/**
 * 黑名单类型
 * @desc 1-加入账号黑名单 2-解除账号黑名单 3-加入推广黑名单 4-解除推广黑名单 5-加入退款黑名单 6-解除退款黑名单
 */
export const BLOCK_TYPE = {
    ADD_ACCOUNT: 1,
    REMOVE_ACCOUNT: 2,
    ADD_PROMOTION: 3,
    REMOVE_PROMOTION: 4,
    ADD_REFUND: 5,
    REMOVE_REFUND: 6,
    ADD_BRUSH: 7,
    REMOVE_BRUSH: 8
}
/**
 * 黑名单类型
 */
export const BLOCK_TYPE_CONF = {
    [BLOCK_TYPE.ADD_ACCOUNT]: '账号封禁',
    [BLOCK_TYPE.REMOVE_ACCOUNT]: '解除账号封禁',
    [BLOCK_TYPE.ADD_PROMOTION]: '推广封禁',
    [BLOCK_TYPE.REMOVE_PROMOTION]: '解除推广封禁',
    [BLOCK_TYPE.ADD_REFUND]: '加入退款黑名单',
    [BLOCK_TYPE.REMOVE_REFUND]: '移除退款黑名单',
    [BLOCK_TYPE.ADD_BRUSH]: '加入刷子',
    [BLOCK_TYPE.REMOVE_BRUSH]: '移除刷子'
}

/**
 * 公告类型
 * @desc 1-登录 2-跑马灯 3-邮件
 */
export const NOTICE_TYPE = {
    LOGIN: 1,
    MARQUEE: 2,
    EMAIL: 3
}
/**
 * 公告类型
 */
export const NOTICE_TYPE_CONF = {
    [NOTICE_TYPE.LOGIN]: '登录公告',
    [NOTICE_TYPE.MARQUEE]: '跑马灯公告',
    [NOTICE_TYPE.EMAIL]: '邮件公告'
}

/**
 * 黑名单类型
 * @desc 1-刷子 2-登陆黑名单 3-退款 4-推广
 */
export const BLACKLIST_TYPE = {
    BRUSH: 1,
    LOGIN: 2,
    REFUND: 3,
    PROMOTION: 4
}

/**
 * 黑名单子类型
 */
export const BLACKLIST_SUB_TYPE = {
    PLAYER_ID: 1,
    PHONE: 2,
    BANK: 3,
    IFSC: 4,
    // IMEI: 5,
    // IMSI: 6,
    UUID: 7,
    IP: 8,
    EMAIL: 9
}

/**
 * 黑名单子类型
 */
export const BLACKLIST_SUB_TYPE_CONF = {
    [BLACKLIST_SUB_TYPE.PLAYER_ID]: '玩家ID',
    [BLACKLIST_SUB_TYPE.PHONE]: '手机号码',
    [BLACKLIST_SUB_TYPE.BANK]: '银行卡号',
    [BLACKLIST_SUB_TYPE.IFSC]: 'IFSC',
    // [BLACKLIST_SUB_TYPE.IMEI]: 'IMEI',
    // [BLACKLIST_SUB_TYPE.IMSI]: 'IMSI',
    [BLACKLIST_SUB_TYPE.UUID]: 'UUID',
    [BLACKLIST_SUB_TYPE.IP]: 'IP',
    [BLACKLIST_SUB_TYPE.EMAIL]: 'Email'
}
/**
 * 后台账号类型
 */
export const USER_TYPE_NAME = {
    CHANNEL_USER: '渠道账号',
    CHANNEL_ADMIN: '渠道管理账号',
    SUPER_ADMIN: '超级管理员'
}

/**
 * 后台菜单-用户类型
 */
export const USER_TYPE = {
    ADMIN_USER: 1,
    CHANNEL_ADMIN_USER: 2,
    CHANNEL_USER: 4
}
/**
 * 后台菜单-用户类型
 */
export const USER_TYPE_CONF = {
    [USER_TYPE.ADMIN_USER]: '超级管理员',
    [USER_TYPE.CHANNEL_ADMIN_USER]: '渠道管理账号',
    [USER_TYPE.CHANNEL_USER]: '渠道账号'
}
