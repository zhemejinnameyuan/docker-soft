// 推广管理-兑换记录-状态
export const PROMOTION_WITHDRAW_STATE = {
    0: '待发放',
    1: '已发放',
    2: '发放失败'
}

// 推广管理-分享方式
export const PROMOTION_SHARE_TYPE = {
    1: 'Facebook',
    2: 'WhatsApp',
    4: 'Invite Friends'
}

// 推广管理-奖励方式
export const PROMOTION_REWARD_WAY = {
    1: '分享到Facebook',
    2: '分享到WhatsApp',
    4: '系统分享',
    101: '首充奖励',
    102: '投注分红'
}

// 推广管理-推广状态
export const PROMOTION_STATE = {
    1: '正常',
    2: '封禁'
}
