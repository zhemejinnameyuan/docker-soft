/** 房间类型 */
export const ROOM_TYPE = {
    POINTS: 1,
    POOL: 2,
    DEALS: 3
}

/** 房间类型 */
export const roomType = {
    [ROOM_TYPE.POINTS]: {
        name: 'Points',
        id: ROOM_TYPE.POINTS
    },
    [ROOM_TYPE.POOL]: {
        name: 'Pool',
        id: ROOM_TYPE.POOL
    },
    [ROOM_TYPE.DEALS]: {
        name: 'Deals',
        id: ROOM_TYPE.DEALS
    }
}

/** 牌桌类型 */
export const DESK_TYPE = {
    TWO: 2,
    SIX: 6
}

export const deskType = {
    [DESK_TYPE.TWO]: {
        name: '2人桌',
        id: DESK_TYPE.TWO
    },
    [DESK_TYPE.SIX]: {
        name: '6人桌',
        id: DESK_TYPE.SIX
    }
}
