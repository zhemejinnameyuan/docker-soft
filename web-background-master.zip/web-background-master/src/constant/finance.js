// 充值明细-通道订单状态
export const RECHARGE_CHANNEL_ORDER_STATE = {
    // 0: '默认值',
    1: '成功',
    2: '失败',
    3: '等待支付'
}

// 充值明细-订单状态
export const RECHARGE_ORDER_STATE = {
    // 0: '未提交',
    1: '已提交',
    2: '提交失败',
    3: '成功',
    4: '置成功 ',
    5: '置失败'
}

// 充值明细-充值类型
export const RECHARGE_PAY_TYPE = {
    1: '收银台',
    2: '活动'
}
// 充值明细-充值方式
export const RECHARGE_PAYMENT_METHOD = {
    1: 'UPI'
}
//充值和退款 通道-通道状态
export const RECHARGE_CHANNEL_STATE = {
    1: '开启',
    2: '关闭'
}
//充值和退款-通道类型
export const RECHARGE_CHANNEL_LABEL = {
    1: '平台通道',
    2: '渠道自有'
}
//充值通道-充值支持金额类型
export const RECHARGE_CHANNEL_PAY_SUPPORT_TYPE = {
    1: '区间金额',
    2: '固定金额'
}

//充值意见反馈-处理状态
export const RECHARGE_FEEDBACK_FLAG = {
    // 0: '无反馈',
    1: '待处理',
    2: '已处理'
}

// 退款明细-退款账户类型
export const REFUND_ACCOUNT_TYPE = {
    1: 'W账户',
    2: '推广兑换账户'
}

// 退款明细-平台订单状态
export const REFUND_ORDER_STATE = {
    0: '待审核',
    1: '成功',
    2: '失败',
    3: '置失败',
    4: '已驳回',
    5: '未提交',
    6: '提交失败',
    7: '已提交',
    8: '已作废'
}
// 退款明细-渠道订单状态
export const REFUND_CHANNEL_ORDER_STATE = {
    // 0: '默认值',
    1: '成功',
    2: '失败',
    3: '处理中'
}

//退款意见反馈-处理状态
export const REFUND_FEEDBACK_FLAG = {
    // 0: '无反馈',
    1: '待处理',
    2: '已处理'
}

// 退款明细-退款方式
export const REFUND_PAYMENT_METHOD = {
    1: 'IFSC'
}

/**
 * 账户明细类型
 */
export const ACCOUNT_RECORD_TYPE = {
    D: 1,
    W: 2,
    B: 3,
    PROMOTION: 4
}

/**
 * 账户明细-业务类型
 */
export const ACCOUNT_BUSINESS_TYPE = {
    1: '游戏',
    2: '充值',
    3: '退款',
    4: '赠送礼物',
    5: '兑换',
    6: '活动',
    7: '结算'
}

/**
 * 账户明细-业务细分类型List 含下标
 */
export const ACCOUNT_SUB_TYPE_LIST = {
    1: {
        100: '游戏输',
        101: '游戏赢',
        102: '游戏输B账户兑换扣除',
        103: '游戏输B币可兑换添加'
    },
    2: {
        200: '充值',
        201: '充值赠送',
        202: '每日奖金卡活动的充值',
        203: '回归礼活动的充值',
        204: '优惠券充值',
        205: '后台手动',
        206: '后台邮件',
        207: '充值追回'
    },
    3: {
        300: '退款扣除',
        301: '退款返回'
    },
    4: {
        400: '赠送礼物'
    },
    5: {
        500: 'B币兑换D账户添加',
        501: '推广收益兑换D账户添加',
        502: '推广收益兑换账户扣除',
        503: 'B币兑换账户扣除'
    },

    6: {
        600: '绑定手机活动',
        601: '领取每日奖金',
        602: '领取回归礼奖金'
    },
    7: {
        700: '结算'
    }
}
/**
 * 账户明细-业务细分类型不含下标
 */
export const ACCOUNT_SUB_TYPE = Object.assign(
    {},
    ACCOUNT_SUB_TYPE_LIST[1],
    ACCOUNT_SUB_TYPE_LIST[2],
    ACCOUNT_SUB_TYPE_LIST[3],
    ACCOUNT_SUB_TYPE_LIST[4],
    ACCOUNT_SUB_TYPE_LIST[5],
    ACCOUNT_SUB_TYPE_LIST[6],
    ACCOUNT_SUB_TYPE_LIST[7]
)

/**
 * 账户明细-游戏房间类型
 */
export const ACCOUNT_GAME_ROOM_TYPE = {
    0: 'DT',
    1: 'Rummy(Points)',
    2: 'Rummy(Pool)',
    3: 'Rummy(Deals)',
    4: 'Fxq(Classic)',
    5: 'Fxq(Quick)',
    6: 'Fxq(Master)',
    7: 'JM',
    8: 'BAB',
    9: 'DLT',
    10: 'CSZ',
    11: 'RB',
    12: '7UP',
    13: 'TP'
}

/**
 * B账户明细的账户类型
 */
export const ACCOUNT_B_TYPE = {
    1: 'B账户',
    2: '可兑换账户'
}

/**
 * 推广奖励-奖励类型
 */
export const PROMOTION_REWARD_TYPE = {
    100: '分享奖励',
    101: '首充奖励',
    102: '下级分红'
}
