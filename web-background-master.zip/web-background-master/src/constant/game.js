import { DESK_TYPE as LM_DESK_TYPE, deskType as lmDeskType } from './lm'
/** 游戏 */
export const GAME_TYPE = {
    DT: 1,
    LM: 2,
    FXQ: 3,
    JM: 4,
    BAB: 5,
    DLT: 6,
    CSZ: 7,
    RB: 8,
    SUP: 9,
    TP: 10
}

export const gameConfig = {
    [GAME_TYPE.DT]: {
        name: 'DT',
        id: GAME_TYPE.DT,
        type: 'lhd',
        img: 'oms_player_img_dt.png',
        path: '/dtGame'
    },
    [GAME_TYPE.LM]: {
        name: 'LM',
        id: GAME_TYPE.LM,
        type: 'rummy',
        img: 'oms_player_img_lm.png',
        path: '/lmGame'
    },
    [GAME_TYPE.FXQ]: {
        name: 'FXQ',
        id: GAME_TYPE.FXQ,
        type: 'fxq',
        img: 'oms_player_img_feixingqi.png',
        path: '/fxqGame'
    },
    [GAME_TYPE.JM]: {
        name: 'JM',
        id: GAME_TYPE.JM,
        type: 'jm',
        img: 'oms_player_img_jm.png',
        path: '/jmGame'
    },
    [GAME_TYPE.TP]: {
        name: 'TP',
        id: GAME_TYPE.TP,
        type: 'tp',
        img: 'oms_player_img_tp.png',
        path: '/tpGame'
    },
    [GAME_TYPE.RB]: {
        name: 'RB',
        id: GAME_TYPE.RB,
        type: 'rb',
        img: 'oms_player_img_rb.png',
        path: '/rbGame'
    },
    [GAME_TYPE.BAB]: {
        name: 'BAB',
        id: GAME_TYPE.BAB,
        type: 'bab',
        img: 'oms_player_img_bab.png',
        path: '/babGame'
    },
    [GAME_TYPE.DLT]: {
        name: 'DLT',
        id: GAME_TYPE.DLT,
        type: 'dlt',
        img: 'oms_player_img_dlt.png',
        path: '/dltGame'
    },
    [GAME_TYPE.CSZ]: {
        name: '猜数字',
        id: GAME_TYPE.CSZ,
        type: 'csz',
        img: 'oms_player_img_caishuzi.png',
        path: '/cszGame'
    },
    [GAME_TYPE.SUP]: {
        name: '7UP',
        id: GAME_TYPE.SUP,
        type: '7up',
        img: 'oms_player_img_7up.png',
        path: '/supGame'
    }
}

/** 终端 */
export const TERMINAL_TYPE = {
    H5: 1,
    ANDROID: 2
}

export const terminalConfig = {
    [TERMINAL_TYPE.ANDROID]: {
        name: 'android',
        id: TERMINAL_TYPE.ANDROID
    },
    [TERMINAL_TYPE.H5]: {
        name: 'h5',
        id: TERMINAL_TYPE.H5
    }
}

/** 用户 */
export const USER_TYPE = {
    GUEST: 0,
    USER: 1
}
export const userTypeConfig = {
    [USER_TYPE.GUEST]: {
        name: '游客',
        id: USER_TYPE.GUEST
    },
    [USER_TYPE.USER]: {
        name: '注册',
        id: USER_TYPE.USER
    }
}

/** 重置周期 */
export const resetCycle = [
    {
        name: '24小时',
        id: 1440
    },
    {
        name: '12小时',
        id: 720
    },
    {
        name: '6小时',
        id: 360
    },
    {
        name: '1小时',
        id: 60
    },
    {
        name: '30分钟',
        id: 30
    }
]
/** 房间状态 */
export const ROOM_STATE = {
    ENABLE: true,
    DISABLED: false
}
export const roomState = {
    [ROOM_STATE.ENABLE]: {
        name: '启用',
        id: ROOM_STATE.ENABLE
    },
    [ROOM_STATE.DISABLED]: {
        name: '禁用',
        id: ROOM_STATE.DISABLED
    }
}

/** 牌桌类型 */
export const DESK_TYPE = {
    ...LM_DESK_TYPE,
    HUNDRED: 100
}

export const deskType = {
    ...lmDeskType,
    [DESK_TYPE.HUNDRED]: {
        name: '百人桌',
        id: DESK_TYPE.HUNDRED
    }
}

// /** 游戏标签 */
// export const TAG_STATE = {
//     NEW: 1,
//     HOT: 2
// }
// export const tagType = {
//     [TAG_STATE.NEW]: {
//         name: 'new',
//         id: TAG_STATE.NEW
//     },
//     [TAG_STATE.HOT]: {
//         name: 'hot',
//         id: TAG_STATE.HOT
//     }
// }

/** 房间等级 */
export const ROOM_RANK = {
    LOW: 1,
    MID: 2,
    HIGH: 3
}

export const roomRank = {
    [ROOM_RANK.LOW]: {
        name: 'Low',
        id: ROOM_RANK.LOW
    },
    [ROOM_RANK.MID]: {
        name: 'Mid',
        id: ROOM_RANK.MID
    },
    [ROOM_RANK.HIGH]: {
        name: 'High',
        id: ROOM_RANK.HIGH
    }
}

// 策略类型
export const STRATEGY_TYPE = {
    NEWBIE: '新手策略',
    WINNER: '赢家策略',
    LOSER: '输家策略',
    BRUSH: '刷子策略'
}

/**
 * 百人房间位置配置
 * @type {{[p: string]: string[], [p: number]: string[], "[GAME_TYPE.RB]": string[]}}
 */
export const BAIREN_POS_CONF = {
    [GAME_TYPE.DT]: ['龙', '虎', '和'],
    [GAME_TYPE.JM]: ['♣️️', '👑', '♠️', '♦️', '🚩', '♥️'],
    [GAME_TYPE.RB]: ['蓝', '红', '对子', '同花', '顺子', '同花顺', '豹子'],
    [GAME_TYPE.BAB]: ['蓝', '红', '1-5', '6-10', '11-15', '16-25', '26-30', '31-35', '36-40', '40以上'],
    [GAME_TYPE.CSZ]: ['绿', '紫', '红', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
    [GAME_TYPE.DLT]: ['闲', '和', '庄', '闲对', '庄对'],
    [GAME_TYPE.SUP]: ['2-6', '7', '8-12', '金骰子']
}

BAIREN_POS_CONF[GAME_TYPE.BAB][-1] = '庄'
BAIREN_POS_CONF[GAME_TYPE.CSZ][-1] = '庄'
