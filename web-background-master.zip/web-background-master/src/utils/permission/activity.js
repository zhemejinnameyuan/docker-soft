//活动模块
export const activityPermission = {
    //公告
    noticeList: 'notice:list', // 公告列表查询
    noticeAdd: 'notice:add', // 公告添加
    noticeEdit: 'notice:edit', // 公告编辑
    noticeDel: 'notice:del', // 公告删除

    //邮件
    mailAdd: 'mail:add', //发送邮件
    mailList: 'mail:list', //邮件记录
    mailAccountDetailList: 'mail:account-detail:list', //金币领取明细

    //广播
    appBroadcastEdit: 'app-broadcast:edit', //广播管理-编辑配置
    appBroadcastRechargeWithdraw: 'app-broadcast:rechargeWithdraw', //广播管理-查询充值退款配置
    appBroadcastGame: 'app-broadcast:game' //广播管理-查询游戏配置
}
