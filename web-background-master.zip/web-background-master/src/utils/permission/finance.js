export const financePermission = {
    // 充值
    appRechargeSetSuccess: 'app-recharge:setSuccess', //  订单置成功
    appRechargeSetFail: 'app-recharge:setFail', //  订单置失败
    appRechargeSaveTipsConfig: 'app-recharge:saveTipsConfig', //  保存充值小贴士配置
    appRechargeSaveConfig: 'app-recharge:saveConfig', //  保存充值配置
    appRechargeSaveChannel: 'app-recharge:saveChannel', //  保存支付通道
    appRechargeBatchChangeChannelState: 'app-recharge:batchChangeChannelState', //  批量修改支付通道状态
    appRechargeQueryTipsConfig: 'app-recharge:queryTipsConfig', //  查询充值小贴士配置
    appRechargeQueryConfig: 'app-recharge:queryConfig', //  查询充值配置
    appRechargeOrderStatistics: 'app-recharge:orderStatistics', //  查询充值订单统计
    appRechargeOrderList: 'app-recharge:orderList', //  查询充值订单
    appRechargeOrderDetail: 'app-recharge:orderDetail', //  查询充值订单详情
    appRechargeFeedbackList: 'app-recharge:feedbackList', //  意见反馈列表
    appRechargeChannelStatistics: 'app-recharge:channelStatistics', //  查询支付通道统计
    appRechargeChannelList: 'app-recharge:channelList', //  查询充值通道

    // 退款
    appWithdrawSetFail: 'app-withdraw:setFail', //  订单置失败
    appWithdrawSaveTipsConfig: 'app-withdraw:saveTipsConfig', //  保存退款小贴士配置
    appWithdrawSaveConfig: 'app-withdraw:saveConfig', //  保存退款配置
    appWithdrawRequestAgain: 'app-withdraw:requestAgain', //  订单重新请求
    appWithdrawBatchReject: 'app-withdraw:batchReject', //  订单批量驳回
    appWithdrawBatchPass: 'app-withdraw:batchPass', //  订单批量通过
    appWithdrawQueryTipsConfig: 'app-withdraw:queryTipsConfig', //  查询退款小贴士配置
    appWithdrawQueryConfig: 'app-withdraw:queryConfig', //  查询退款配置
    appWithdrawOrderStatistics: 'app-withdraw:orderStatistics', //  查询退款订单统计
    appWithdrawOrderList: 'app-withdraw:orderList', //  查询退款订单
    appWithdrawOrderDetail: 'app-withdraw:orderDetail', //  查询退款订单明细
    appWithdrawFeedbackList: 'app-withdraw:feedbackList', //  意见反馈列表
    appWithdrawExceptionList: 'app-withdraw:exceptionList', //  异常订单列表
    appWithdrawObsolete: 'app-withdraw:obsolete', //  退款订单作废
    appWithdrawObsoleteList: 'app-withdraw:obsoleteList', //  废弃订单列表
    appWithdrawObsoleteCallback: 'app-withdraw:obsoleteCallback', //  废弃订单-恢复
    appWithdrawChannelList: 'app-withdraw:channelList', //  查询退款通道
    appWithdrawWithdrawChannelStatistics: 'app-withdraw:withdrawChannelStatistics', //  退款通道每日额度信息

    // 账户明细
    financeAccountDetailList: 'finance:account-detail:list', //  资金账户明细-财务模块

    //礼物收益
    financeGiftStats: 'finance:stats-gift-income:log', //  财务管理-礼物收益统计
    financeGiftIncomeLog: 'finance:gift-income:log', // 财务管理-礼物收益记录

    //推广奖励
    financeReferRewardStats: 'finance:refer-reward:stats', //  财务管理-推广奖励统计
    financeReferRewardRecord: 'finance:refer-reward:record', // 财务管理-推广奖励
    financeReferRewardLog: 'finance:refer-reward:log' //  财务管理-推广奖励明细
}
