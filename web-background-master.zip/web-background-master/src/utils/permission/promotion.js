export const promotionPermission = {
    // 推广管理
    appReferConfigSave: 'app-refer:config:save', //  保存配置
    appReferWithdrawLog: 'app-refer:withdraw:log', //  兑换记录
    appReferShareLog: 'app-refer:share:log', //  分享记录
    appReferDepositLog: 'app-refer:deposit:log', //  首充奖励
    appReferConfigQuery: 'app-refer:config:query', //  查询配置
    appReferBetLog: 'app-refer:bet:log', //  投注分红
    appReferAccountList: 'app-refer:account:list', //  推广账户查询
    appReferAccountDetail: 'app-refer:account:detail', //  推广账户明细
    appReferAccountBlockRecord: 'app-refer:account:blockRecord', //  推广账户封禁记录
    appReferAccountBelows: 'app-refer:account:belows' //  推广账户下级玩家
}
