export const playerPermission = {
    //玩家管理
    playerList: 'player:list', // 玩家列表查询
    playerEdit: 'player:edit', // 玩家编辑
    playerChannelList: 'player:channel:list', // 玩家列表下查询渠道列表
    playerDetail: 'player:detail', // 玩家详情
    playerDetailEdit: 'player:detail:edit', // 玩家详情页黑名单操作
    playerLoginList: 'player-login:list', // 登录日志
    playerLoginListChannelList: 'player-login:list:channel:list', // 玩家登录日志下渠道筛选
    playerGameList: 'player-game:list', // 查询玩家游戏流水日志
    playerCaptchaList: 'player-captcha:list', // 玩家短信日志

    //黑名单
    appBlacklistBatchDelByPlayerIds: 'app-blacklist:batchDelByPlayerIds', //批量删除-用户ID
    appBlacklistBatchDel: 'app-blacklist:batchDel', //批量删除-黑名单ID
    appBlacklistBatchAdd: 'app-blacklist:batchAdd', //批量新增
    appBlacklistQueryPlayerBlackState: 'app-blacklist:queryPlayerBlackState', //查询单个
    appBlacklistQueryList: 'app-blacklist:queryList', //查询列表

    playerAccountDetailList: 'player-account-detail:list', //  玩家详情-财务管理-资金账户明细
    playerReferRewardRecord: 'player:refer-reward:record', //  玩家详情-财务管理-推广奖励
    playerReferRewardLog: 'player:refer-reward:log', //  玩家详情-财务管理-推广奖励明细
    playerReferRewardStats: 'player:refer-reward:stats', //  玩家详情-财务管理-推广奖励统计
    playerRechargeRecordList: 'player-recharge-record:list', //  玩家详情-财务管理-充值订单列表
    appRechargeUserOrderStatistics: 'app-recharge:userOrderStatistics', //  玩家详情-财务管理-充值订单统计
    playerWithdrawRecordList: 'player-withdraw-record:list', //  玩家详情-财务管理-退款订单列表
    appWithdrawUserOrderStatistics: 'app-withdraw:userOrderStatistics', //  玩家详情-财务管理-退款订单统计
    playerReferAccountStats: 'player:refer-account:stats', //玩家详情-推广账户统计
    playerReferAccountBelows: 'player:refer-account:belows', //玩家详情-推广记录
    playerAccountBlock: 'player:account:block', //玩家详情-违规处罚
    playerFinancialOverviewStats: 'player-financial-overview:stats' //玩家详情-财务概览
}
