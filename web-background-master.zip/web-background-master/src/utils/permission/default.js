export const defaultPermission = {
    admin: 'SUPER_ADMIN', // 超级管理
    //概览
    overviewChannelList: 'overview:channel:list', // 概览筛选渠道
    overviewChannelPackageList: 'overview:channel:package:list', // 概览筛选渠道包
    statsOverview: 'stats:overview', // 统计概览

    //数据中心
    statsChannelList: 'stats:channel:list', // 统计筛选渠道
    statsChannelPackageList: 'stats:channel:package:list', // 统计筛选渠道包
    statsNewDay: 'stats:new:day', // 日新增图表
    statsNewMonth: 'stats:new:month', // 日新增图表
    statsActiveDay: 'stats:active:day', // 日活跃图表
    statsActiveMonth: 'stats:active:month', // 月活跃图表
    statsRetainDay: 'stats:retain:day', // 日留存
    statsRetainWeek: 'stats:retain:week', // 周留存
    statsRetainMonth: 'stats:retain:month', // 月留存
    statsChannel: 'stats:channel', // 渠道统计
    statsChannelRevenue: 'stats:channel:revenue', // 渠道统计-营收统计
    statsChannelPackage: 'stats:channel:package', // 渠道包统计
    statsChannelPackageRevenue: 'stats:channel:package:revenue', // 渠道包统计-营收统计
    statsVersions: 'stats:versions', // 获取应用版本

    //渠道管理
    channelAdd: 'channel:add', // 渠道添加按钮
    channelList: 'channel:list', // 渠道查询
    channelEdit: 'channel:edit', // 渠道编辑
    channelQueryDetail: 'channel:queryDetail', // 渠道详情

    //渠道包管理
    channelPackageList: 'channel:package:list', // 渠道包列表
    channelPackageEdit: 'channel:package:edit', // 渠道包编辑
    channelPackageQRcode: 'channel:package:qrcode', // 渠道包二维码
    channelPackageCopy: 'channel:package:copy', // 渠道包复制
    channelPackageDowload: 'channel:package:dowload', // 渠道包下载
    channelPackageExport: 'channel:package:export', // 渠道包导出
    channelPackageAdd: 'channel:package:add', // 渠道包添加
    channelPackageChannelList: 'channel:package:channel:list', // 渠道包模块下查询渠道列表数据
    channelQueryPackageDetail: 'channel:queryPackageDetail', // 渠道详情

    //游戏管理
    robotList: 'robot:list', // 机器人列表查询
    gameConfigSave: 'game-config:save', //游戏列表保存配置
    gameConfigList: 'game-config:list', //游戏列表查询配置

    //平台管理
    syslogList: 'syslog:list', // 系统操作日志
    menuList: 'menu:list', // 菜单列表查询
    menuAdd: 'menu:add', // 菜单添加
    menuEdit: 'menu:edit', // 菜单编辑
    menuDel: 'menu:del', // 菜单删除
    roleList: 'role:list', // 角色列表查询
    roleAdd: 'role:add', // 角色添加
    roleEdit: 'role:edit', // 角色编辑
    roleDel: 'role:del', // 角色删除
    roleMenuList: 'role:menu:list', // 角色列表下查询菜单列表
    userList: 'user:list', // 账号列表查询
    userAdd: 'user:add', // 账号添加
    userEdit: 'user:edit', // 账号编辑
    userDel: 'user:del', // 账号删除
    userChannelList: 'user:channel:list', // 账号列表下查询渠道列表
    userRoleList: 'user:role:list', // 账号列表下查询角色列表
    appConfigList: 'app-config:list', // 一般配置查询
    appConfigEdit: 'app-config:edit', // 一般配置编辑
    appConfigQuerySmsBalance: 'app-config:querySmsBalance', // 一般配置-查询短信余额
    maintenanceList: 'maintenance:list', // 系统维护查询
    maintenanceEdit: 'maintenance:edit' // 系统维护操作
}
