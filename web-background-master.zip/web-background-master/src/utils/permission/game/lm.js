export const lmPermission = {
    // Rummy-Points游戏
    lmPointsRoomList: 'rummy:points:room:list', // Points-房间列表和底注
    lmPointsRoomEnableDisable: 'rummy:points:room:enableDisable', // Points-启用/禁用房间
    lmPointsRoomEdit: 'rummy:points:room:edit', // Points-编辑房间
    lmPointsRoomAdd: 'rummy:points:room:add', // Points-创建房间
    lmPointsFlowList: 'rummy:points:flow:list', // Points-牌局统计和记录
    lmPointsFlowDetail: 'rummy:points:flow:detail', // Points-牌局详情
    lmPointsReservoirLog: 'rummy:points:reservoir:log', // Points-策略记录
    // Rummy-Pool游戏
    lmPoolRoomEnableDisable: 'rummy:pool:room:enableDisable', // Pool-启用/禁用房间
    lmPoolRoomEdit: 'rummy:pool:room:edit', // Pool-编辑房间
    lmPoolRoomAdd: 'rummy:pool:room:add', // Pool-创建房间
    lmPoolRoomList: 'rummy:pool:room:list', // Pool-房间列表和底注
    lmPoolFlowList: 'rummy:pool:flow:list', // Pool-牌局统计和记录
    lmPoolFlowDetail: 'rummy:pool:flow:detail', // Pool-牌局详情
    lmPoolReservoirLog: 'rummy:pool:reservoir:log', // Pool-策略记录
    // Rummy-Deals游戏
    lmDealsRoomEnableDisable: 'rummy:deals:room:enableDisable', // Deals-启用/禁用房间
    lmDealsRoomEdit: 'rummy:deals:room:edit', // Deals-编辑房间
    lmDealsRoomAdd: 'rummy:deals:room:add', // Deals-创建房间
    lmDealsRoomList: 'rummy:deals:room:list', // Deals-房间列表底注
    lmDealsFlowList: 'rummy:deals:flow:list', // Deals-牌局统计和记录
    lmDealsFlowDetail: 'rummy:deals:flow:detail', // Deals-牌局详情
    lmDealsReservoirLog: 'rummy:deals:reservoir:log', // Deals-策略记录
    // Rummy-练习场
    lmPracticeRoomEnableDisable: 'rummy:practice:room:enableDisable', // 练习场-启用/禁用房间
    lmPracticeRoomEdit: 'rummy:practice:room:edit', // 练习场-编辑房间
    lmPracticeRoomAdd: 'rummy:practice:room:add', // 练习场-创建房间
    lmPracticeRoomList: 'rummy:practice:room:list', // 练习场-房间列表和底注
    lmPracticeConfigGet: 'rummy:config:practice:get', // 查询练习场配置
    lmPracticeConfigSave: 'rummy:config:practice:save', //  保存练习场配置
    // Rummy-机器人
    lmRobotGet: 'rummy:robot:get', // 查询机器人配置
    lmRobotSave: 'rummy:robot:save', //  保存机器人配置
    //全局配置
    lmGlobalGet: 'rummy:global:get', // 查询全局配置
    lmGlobalSave: 'rummy:global:save', //  保存全局配置
    lmGlobalNewbiePoints: 'rummy:global:newbie:points', // 全局新手配置查询points房间
    lmGlobalNewbiePool: 'rummy:global:newbie:pool', // 全局新手配置查询pool房间
    lmGlobalNewbieDeals: 'rummy:global:newbie:deals' // 全局新手配置查询deals房间
}
