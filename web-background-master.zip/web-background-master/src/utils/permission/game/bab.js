export const babPermission = {
    // bab游戏
    babRoomList: 'bab:room:list', //  bab-房间列表和下注币种
    babRoomAdd: 'bab:room:add', //  bab-创建房间
    babRoomEdit: 'bab:room:edit', // bab-编辑房间
    babRoomEnableDisable: 'bab:room:enableDisable', // bab-启用/禁用房间
    babFlowList: 'bab:flow:list', // bab-牌局统计和记录
    babFlowDetail: 'bab:flow:detail', // bab-牌局详情
    babRobotGet: 'bab:robot:get', // bab-查询机器人配置
    babRobotSave: 'bab:robot:save', // bab-保存机器人配置
    babGlobalGet: 'bab:global:get', // bab-查询全局配置
    babGlobalSave: 'bab:global:save', // bab-保存全局配置
    babReservoirLog: 'bab:reservoir:log' // bab-查询蓄水池
}
