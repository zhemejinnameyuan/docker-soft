export const fxqPermission = {
    // 飞行棋游戏-Classic
    fxqClassicRoomList: 'fxq:classic:room:list', // Fxq-Classic-房间列表和房间底注
    fxqClassicRoomAdd: 'fxq:classic:room:add', // Fxq-Classic-创建房间
    fxqClassicRoomEdit: 'fxq:classic:room:edit', // Fxq-Classic-编辑房间
    fxqClassicRoomEnableDisable: 'fxq:classic:room:enableDisable', // Fxq-Classic-启用/禁用房间
    fxqClassicFlowList: 'fxq:classic:flow:list', // Fxq-Classic-牌局统计和牌局记录
    fxqClassicFlowDetail: 'fxq:classic:flow:detail', // Fxq-Classic-牌局详情和回放日志
    fxqClassicReservoirLog: 'fxq:classic:reservoir:log', // Fxq-Classic-策略记录
    // 飞行棋游戏-Quick
    fxqQuickRoomList: 'fxq:quick:room:list', // Fxq-Quick-房间列表和房间底注
    fxqQuickRoomAdd: 'fxq:quick:room:add', // Fxq-Quick-创建房间
    fxqQuickRoomEdit: 'fxq:quick:room:edit', // Fxq-Quick-编辑房间
    fxqQuickRoomEnableDisable: 'fxq:quick:room:enableDisable', // Fxq-Quick-启用/禁用房间
    fxqQuickFlowList: 'fxq:quick:flow:list', // Fxq-Quick-牌局统计和牌局记录
    fxqQuickFlowDetail: 'fxq:quick:flow:detail', // Fxq-Quick-牌局详情和回放日志
    fxqQuickReservoirLog: 'fxq:quick:reservoir:log', // Fxq-Quick-策略记录
    // 飞行棋游戏-master
    fxqMasterRoomList: 'fxq:master:room:list', // Fxq-Master-房间列表和房间底注
    fxqMasterRoomAdd: 'fxq:master:room:add', // Fxq-Master-创建房间
    fxqMasterRoomEdit: 'fxq:master:room:edit', // Fxq-Master-编辑房间
    fxqMasterRoomEnableDisable: 'fxq:master:room:enableDisable', // Fxq-Master-启用/禁用房间
    fxqMasterFlowList: 'fxq:master:flow:list', // Fxq-Master-牌局统计和牌局记录
    fxqMasterFlowDetail: 'fxq:master:flow:detail', // Fxq-Master-牌局详情和回合日志
    fxqMasterReservoirLog: 'fxq:master:reservoir:log', // Fxq-Master-策略记录
    // 飞行棋游戏-机器人和全局配置
    fxqRobotGet: 'fxq:robot:get', // Fxq-查询机器人配置
    fxqRobotSave: 'fxq:robot:save', // Fxq-保存机器人配置
    fxqGlobalGet: 'fxq:global:get', // Fxq-查询全局配置
    fxqGlobalSave: 'fxq:global:save', // Fxq-保存全局配置
    fxqGlobalNewbieQuick: 'fxq:global:newbie:quick', // Fxq-全局配置-Quick新手房列表
    fxqGlobalNewbieMaster: 'fxq:global:newbie:master', // Fxq-全局配置-Master新手房列表
    fxqGlobalNewbieClassic: 'fxq:global:newbie:classic' // Fxq-全局配置-Classic新手房列表
}
