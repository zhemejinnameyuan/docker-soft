export const dltPermission = {
    // dlt游戏
    dltRoomList: 'dlt:room:list', //  dlt-房间列表和下注币种
    dltRoomAdd: 'dlt:room:add', //  dlt-创建房间
    dltRoomEdit: 'dlt:room:edit', // dlt-编辑房间
    dltRoomEnableDisable: 'dlt:room:enableDisable', // dlt-启用/禁用房间
    dltFlowList: 'dlt:flow:list', // dlt-牌局统计和记录
    dltFlowDetail: 'dlt:flow:detail', // dlt-牌局详情
    dltRobotGet: 'dlt:robot:get', // dlt-查询机器人配置
    dltRobotSave: 'dlt:robot:save', // dlt-保存机器人配置
    dltGlobalGet: 'dlt:global:get', // dlt-查询全局配置
    dltGlobalSave: 'dlt:global:save', // dlt-保存全局配置
    dltReservoirLog: 'dlt:reservoir:log' // dlt-查询蓄水池
}
