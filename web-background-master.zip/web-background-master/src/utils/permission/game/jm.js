export const jmPermission = {
    // JM游戏
    jmRoomList: 'jm:room:list', //  JM房间列表
    jmRoomAdd: 'jm:room:add', //  JM创建房间
    jmRoomEdit: 'jm:room:edit', // JM编辑房间
    jmRoomEnableDisable: 'jm:room:enableDisable', // JM启用/禁用房间
    jmFlowList: 'jm:flow:list', // JM牌局统计和记录
    jmFlowDetail: 'jm:flow:detail', // JM牌局详情
    jmRobotGet: 'jm:robot:get', // JM查询机器人配置
    jmRobotSave: 'jm:robot:save', // JM保存机器人配置
    jmGlobalGet: 'jm:global:get', // JM查询全局配置
    jmGlobalSave: 'jm:global:save', // JM保存全局配置
    jmReservoirLog: 'jm:reservoir:log' // JM查询蓄水池
}
