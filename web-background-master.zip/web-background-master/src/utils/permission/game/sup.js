export const supPermission = {
    // 7up游戏
    supRoomList: 'seven_up:room:list', //  sup-房间列表和下注币种
    supRoomAdd: 'seven_up:room:add', //  sup-创建房间
    supRoomEdit: 'seven_up:room:edit', // sup-编辑房间
    supRoomEnableDisable: 'seven_up:room:enableDisable', // sup-启用/禁用房间
    supFlowList: 'seven_up:flow:list', // sup-牌局统计和记录
    supFlowDetail: 'seven_up:flow:detail', // sup-牌局详情
    supRobotGet: 'seven_up:robot:get', // sup-查询机器人配置
    supRobotSave: 'seven_up:robot:save', // sup-保存机器人配置
    supGlobalGet: 'seven_up:global:get', // sup-查询全局配置
    supGlobalSave: 'seven_up:global:save', // sup-保存全局配置
    supReservoirLog: 'seven_up:reservoir:log' // sup-查询蓄水池
}
