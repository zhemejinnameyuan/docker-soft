export const dtPermission = {
    // DT游戏
    dtRoomList: 'dt:room:list', //  DT-房间列表和下注币种
    dtRoomAdd: 'dt:room:add', //  DT-创建房间
    dtRoomEdit: 'dt:room:edit', // DT-编辑房间
    dtRoomEnableDisable: 'dt:room:enableDisable', // DT-启用/禁用房间
    dtFlowList: 'dt:flow:list', // DT-牌局统计和记录
    dtFlowDetail: 'dt:flow:detail', // DT-牌局详情
    dtRobotGet: 'dt:robot:get', // DT-查询机器人配置
    dtRobotSave: 'dt:robot:save', // DT-保存机器人配置
    dtGlobalGet: 'dt:global:get', // DT-查询全局配置
    dtGlobalSave: 'dt:global:save', // DT-保存全局配置
    dtReservoirLog: 'dt:reservoir:log' // DT-查询蓄水池
}
