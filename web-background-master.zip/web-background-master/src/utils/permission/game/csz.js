export const cszPermission = {
    // csz游戏
    cszRoomList: 'csz:room:list', //  csz-房间列表和下注币种
    cszRoomAdd: 'csz:room:add', //  csz-创建房间
    cszRoomEdit: 'csz:room:edit', // csz-编辑房间
    cszRoomEnableDisable: 'csz:room:enableDisable', // csz-启用/禁用房间
    cszFlowList: 'csz:flow:list', // csz-牌局统计和记录
    cszFlowDetail: 'csz:flow:detail', // csz-牌局详情
    cszRobotGet: 'csz:robot:get', // csz-查询机器人配置
    cszRobotSave: 'csz:robot:save', // csz-保存机器人配置
    cszGlobalGet: 'csz:global:get', // csz-查询全局配置
    cszGlobalSave: 'csz:global:save', // csz-保存全局配置
    cszReservoirLog: 'csz:reservoir:log' // csz-查询蓄水池
}
