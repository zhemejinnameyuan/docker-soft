export const tpPermission = {
    // tp房间
    tpRoomList: 'tp:room:list', //TP-房间列表和底注(tp:room:list)
    tpRoomEdit: 'tp:room:edit', //TP-编辑房间(tp:room:edit)
    tpRoomAdd: 'tp:room:add', //TP-创建房间(tp:room:add)
    tpRoomEnableDisable: 'tp:room:enableDisable', //TP-启用/禁用房间(tp:room:enableDisable)
    tpFlowDetail: 'tp:flow:detail', //TP-牌局详情和回放日志(tp:flow:detail)
    tpFlowList: 'tp:flow:list', //TP-牌局统计和牌局记录(tp:flow:list)
    tpReservoirLog: 'tp:reservoir:log', //TP-策略记录
    //练习房
    tpRoomPracticeEdit: 'tp:room:practice:edit', //TP-编辑练习场房间(tp:room:practice:edit)
    tpRoomPracticeAdd: 'tp:room:practice:add', //TP-创建练习场房间(tp:room:practice:add)
    tpRoomPracticeList: 'tp:room:practice:list', //TP-练习场房间列表和底注(tp:room:practice:list)
    tpConfigPracticeGet: 'tp:config:practice:get', //TP-查询练习场配置(tp:config:practice:get)
    tpConfigPracticeSave: 'tp:config:practice:save', //TP-保存练习场配置(tp:config:practice:save)
    tpRoomPracticeEnableDisable: 'tp:room:practice:enableDisable', //TP-练习场启用/禁用房间(tp:room:practice:enableDisable)

    //机器人
    tpRobotGet: 'tp:robot:get', //TP-查询机器人配置(tp:robot:get)
    tpRobotSave: 'tp:robot:save', //TP-保存机器人配置(tp:robot:save)

    //全局配置
    tpGlobalSave: 'tp:global:save', //tp-全局配置保存
    tpGlobalGet: 'tp:global:get' //tp-全局配置查询
}
