export const rbPermission = {
    // rb游戏
    rbRoomList: 'rb:room:list', //  rb-房间列表和下注币种
    rbRoomAdd: 'rb:room:add', //  rb-创建房间
    rbRoomEdit: 'rb:room:edit', // rb-编辑房间
    rbRoomEnableDisable: 'rb:room:enableDisable', // rb-启用/禁用房间
    rbFlowList: 'rb:flow:list', // rb-牌局统计和记录
    rbFlowDetail: 'rb:flow:detail', // rb-牌局详情
    rbRobotGet: 'rb:robot:get', // rb-查询机器人配置
    rbRobotSave: 'rb:robot:save', // rb-保存机器人配置
    rbGlobalGet: 'rb:global:get', // rb-查询全局配置
    rbGlobalSave: 'rb:global:save', // rb-保存全局配置
    rbReservoirLog: 'rb:reservoir:log' // rb-查询蓄水池
}
