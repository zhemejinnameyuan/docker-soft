import Cookies from 'js-cookie'
import Settings from '@/settings'

const TokenKey = Settings.TokenKey

export function getToken() {
    return Cookies.get(TokenKey)
}

export function setToken(token, rememberMe) {
    if (rememberMe) {
        return Cookies.set(TokenKey, token, { expires: Settings.tokenCookieExpires })
    } else {
        return Cookies.set(TokenKey, token)
    }
}

export function removeToken() {
    return Cookies.remove(TokenKey)
}
