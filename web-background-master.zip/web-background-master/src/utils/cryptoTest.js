/* 加解密测试
 * npm install --save buffer
 * npm install --save crypto-js
 * npm install --save node-rsa
 */
global.Buffer = global.Buffer || require('buffer').Buffer
const CryptoJS = require('crypto-js')
const NodeRSA = require('node-rsa')

const PublicKey =
    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCEOkSqINi23z2DUG5CCw/N0KgjEA6l4H8/bjtmn36pBFThqYaYY+R6mviS6mPS3G/nH+W6nOJkkFUa1V7wbcfJLBZl9Ma9Rt0ubKOWl/SIeX5iRyWsZyna7GwbevwM7Lev64DbumGipimZyL3tWZww+YMcheAkPxLglMPtIfHwAwIDAQAB'
const PrivateKey =
    'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIQ6RKog2LbfPYNQbkILD83QqCMQDqXgfz9uO2affqkEVOGphphj5Hqa+JLqY9Lcb+cf5bqc4mSQVRrVXvBtx8ksFmX0xr1G3S5so5aX9Ih5fmJHJaxnKdrsbBt6/Azst6/rgNu6YaKmKZnIve1ZnDD5gxyF4CQ/EuCUw+0h8fADAgMBAAECgYBsRco0BPFvzRzxicq/CY/HWDRVgbB843dO2VSKk8+DVqiqn8Y2wpU0T/F7W7Kh1x9KgjP6urwm3IjTkCRNe5c7VifUKMvOxHt8uciwX8+N1FhWtZ8iWDwcLOqLtaDznLbNJWHYGbQd+Sv7yuUtIbVRrBMYV0RIZWqPMyDSGGapAQJBALqEOZh22nuVCjHHOVGIVLetpTw+P63ZjeWQW0ujI4gi+IJ7dRmwcy6CacnqHcN4airLThOw7tnlB2whlrE2RK8CQQC1fJmUy0UtirFVPnjdZbnEr7Zpcet3rhXgNHpEz6HPPG+HU+B3atoSF0mvSk7d4A8Bh2Tpum4i1keJzEre+8btAkBtQQjP00cVvu7Sy8U6iiY91ZyFll0Mw/QHdbDUtIIau4lgPVsRqjc+FixLlzTKDF38JUzd4fV3c14Oq/ouYgCHAkEAhzRkVm15BAynQBJiiM4YL2eYRcYQ3gBbW8S8sjbdHT6w9+iM+WopPAENbAG376PUihcMHvQ8yMdKVGZWAPkhoQJAcQjEwEgAIdytippkWmfm91kdZIogu6phaoEoJ8lqMlH9mXQAGuCQ6NnSmCnwrm9li2X4DBob2POtlO5trte51A=='

if (typeof btoa === 'undefined') {
    global.btoa = function (str) {
        return Buffer.from(str).toString('base64')
    }
}

if (typeof atob === 'undefined') {
    global.atob = function (b64Encoded) {
        return Buffer.from(b64Encoded, 'base64').toString()
    }
}

function randomString(len) {
    len = len || 32
    const $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'
    const maxPos = $chars.length
    let pwd = ''
    for (let i = 0; i < len; i++) {
        pwd += $chars.charAt(Math.floor(Math.random() * maxPos))
    }
    return pwd
}

function aesIv(key) {
    return key.substring(0, 16)
}

function aesEncrypt(text, key) {
    return CryptoJS.AES.encrypt(text, CryptoJS.enc.Utf8.parse(key), {
        iv: CryptoJS.enc.Utf8.parse(aesIv(key)),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    }).toString()
}

function aesDecrypt(text, key) {
    const result = CryptoJS.AES.decrypt(text, CryptoJS.enc.Utf8.parse(key), {
        iv: CryptoJS.enc.Utf8.parse(aesIv(key)),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    })
    return CryptoJS.enc.Utf8.stringify(result)
}

function rsaEncrypt(data) {
    const nodeRSA = new NodeRSA(PublicKey, 'pkcs8-public')
    nodeRSA.setOptions({ encryptionScheme: 'pkcs1' })
    return nodeRSA.encrypt(data, 'base64', 'utf8')
}

function rsaDecrypt(data) {
    const nodeRSA = new NodeRSA(PrivateKey, 'pkcs8-private')
    nodeRSA.setOptions({ encryptionScheme: 'pkcs1' })
    return nodeRSA.decrypt(data, 'utf8')
}

const key = randomString()
console.log('key: ' + key)
console.log('iv: ' + aesIv(key))
const base64Key = btoa(key)
console.log('base64Key: ' + base64Key)
console.log('base64Iv: ' + btoa(aesIv(key)))

const param = JSON.stringify({
    data: {
        code: 'string'
    }
})
const cipherParam = aesEncrypt(param, key)
console.log('cipher param: ' + cipherParam)
console.log('origin data: ' + aesDecrypt(cipherParam, key))

const cipherKey = rsaEncrypt(base64Key)
console.log('cipher key: ' + cipherKey)
console.log('origin key: ' + rsaDecrypt(cipherKey))

console.log(rsaEncrypt('admin123'))
