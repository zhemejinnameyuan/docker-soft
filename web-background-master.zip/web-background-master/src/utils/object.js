/**
 * 对象操作
 */
import { isNil, isDict, isArray } from './typeof'

/**
 * 返回dic keys
 * @param obj
 * @param parmas {sort}
 * @returns
 */
export function keys(obj, parmas = {}) {
    const { sort } = parmas
    const _keys = Object.keys(obj).filter((k) => {
        return obj[k] !== undefined
    })
    if (sort) {
        if (typeof sort === 'function') {
            _keys.sort(sort)
        } else {
            _keys.sort((l, r) => {
                return l === r ? 0 : l < r ? -1 : 1
            })
        }
    }
    return _keys
}
/** 比较两个对象是否相等 */
export function isEqual(new_val, old_val, params = {}) {
    const is_new_nil = isNil(new_val)
    const is_old_nil = isNil(old_val)
    const { show_log } = params
    if ((is_new_nil && !is_old_nil) || (!is_new_nil && is_old_nil)) {
        show_log && console.log('not Equal (nil)', new_val, old_val)
        return false
    } else if (is_new_nil && is_old_nil) {
        return true
    }
    const new_type = typeof new_val
    const old_type = typeof old_val
    if (new_type !== old_type) {
        show_log && console.log('not Equal (type)', new_type, old_type, new_val, old_val)
        return false
    } else {
        switch (new_type) {
            case 'object':
                if (Array.isArray(new_val)) {
                    if (new_val.length === old_val.length) {
                        for (let i = 0; i < new_val.length; ++i) {
                            if (!isEqual(new_val[i], old_val[i], params)) {
                                return false
                            }
                        }
                        return true
                    } else {
                        show_log && console.log('not Equal (array length)', new_val, old_val)
                        return false
                    }
                } else {
                    const new_class_name = Object.prototype.toString.call(new_val)
                    const old_class_name = Object.prototype.toString.call(old_val)
                    if (new_class_name === old_class_name) {
                        const new_keys = keys(new_val, { sort: true })
                        const old_keys = keys(old_val, { sort: true })
                        if (isEqual(new_keys, old_keys, params)) {
                            for (const k in new_keys) {
                                if (!isEqual(new_val[new_keys[k]], old_val[old_keys[k]], params)) {
                                    return false
                                }
                            }
                            return true
                        }
                    } else {
                        show_log && console.log('not Equal (object classname)', new_class_name, old_class_name, new_val, old_val)
                        return false
                    }
                }
                break
            default: {
                const ret = new_val === old_val
                !ret && show_log && console.log('not Equal (value)', new_val, old_val)
                return ret
            }
        }
    }
}

/**
 * 深度拷贝
 * @param obj 源对象
 * @param deep 深度 防止对象太大导致拷贝出bug 限制为5层
 * @returns
 */
export function deepClone(obj, _deep = undefined) {
    const deep = !isNil(_deep) && _deep < 5 ? _deep : 5

    if (deep <= 0) {
        return obj
    }
    let target = {}
    try {
        if (isDict(obj)) {
            for (const i in obj) {
                target[i] = deepClone(obj[i], deep - 1)
            }
        } else if (isArray(obj)) {
            target = []
            for (let i = 0; i < obj.length; i++) {
                target[i] = deepClone(obj[i], deep - 1)
            }
        } else {
            target = obj
        }
        return target
    } catch (e) {
        console.log('functions deepClone error', e)
        return obj
    }
}
/**
 * 对象合并 注意合并对象只是浅拷贝
 * @param {object} target 目标对象 合并后target会改变
 * @param  {...object} source
 * @return {object} 合并后的对象
 */
export function assign(target, ...source) {
    return Object.assign(target, ...source)
}
/**
 * 对象合并 深度拷贝
 * @param target
 * @param source
 * @returns
 */
export function assignDeep(target, ...source) {
    if (!target) {
        target = {}
    }
    const ttt = source.map((o) => deepClone(o))
    return assign(target, ...ttt)
}
