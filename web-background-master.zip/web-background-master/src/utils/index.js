/**
 * Created by PanJiaChen on 16/11/18.
 */

import { MessageBox, Message } from 'element-ui'
import * as channelApi from '@/api/channel'
import { filterThousandths } from '@/utils/filters'
import { ACCOUNT_GAME_ROOM_TYPE, ACCOUNT_SUB_TYPE } from '@/constant/finance'
import store from '@/store'

/**
 * Parse the time to string
 * @param {(Object|string|number)} time
 * @param {string} cFormat
 * @returns {string}
 */
export function parseTime(time, cFormat) {
    if (arguments.length === 0) {
        return null
    }
    const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
    let date
    if (typeof time === 'undefined' || time === null || time === 'null') {
        return ''
    } else if (typeof time === 'object') {
        date = time
    } else {
        if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
            time = parseInt(time)
        }
        if (typeof time === 'number' && time.toString().length === 10) {
            time = time * 1000
        }
        date = new Date(time)
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay()
    }
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key]
        // Note: getDay() returns 0 on Sunday
        if (key === 'a') {
            return ['日', '一', '二', '三', '四', '五', '六'][value]
        }
        if (result.length > 0 && value < 10) {
            value = '0' + value
        }
        return value || 0
    })
    return time_str
}

/**
 * @param {number} time
 * @param {string} option
 * @returns {string}
 */
export function formatTime(time, option) {
    if (('' + time).length === 10) {
        time = parseInt(time) * 1000
    } else {
        time = +time
    }
    const d = new Date(time)
    const now = Date.now()

    const diff = (now - d) / 1000

    if (diff < 30) {
        return '刚刚'
    } else if (diff < 3600) {
        // less 1 hour
        return Math.ceil(diff / 60) + '分钟前'
    } else if (diff < 3600 * 24) {
        return Math.ceil(diff / 3600) + '小时前'
    } else if (diff < 3600 * 24 * 2) {
        return '1天前'
    }
    if (option) {
        return parseTime(time, option)
    } else {
        return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
    }
}

/**
 * This is just a simple version of deep copy
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 * @param {Object} source
 * @returns {Object}
 */
export function deepClone(source) {
    if (!source && typeof source !== 'object') {
        throw new Error('error arguments', 'deepClone')
    }
    const targetObj = source.constructor === Array ? [] : {}
    Object.keys(source).forEach((keys) => {
        if (source[keys] && typeof source[keys] === 'object') {
            targetObj[keys] = deepClone(source[keys])
        } else {
            targetObj[keys] = source[keys]
        }
    })
    return targetObj
}

/**
 * Check if an element has a class
 * @param {HTMLElement} elm
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass(ele, cls) {
    return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'))
}

/**
 * Add class to element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function addClass(ele, cls) {
    if (!hasClass(ele, cls)) ele.className += ' ' + cls
}

/**
 * Remove class from element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function removeClass(ele, cls) {
    if (hasClass(ele, cls)) {
        const reg = new RegExp('(\\s|^)' + cls + '(\\s|$)')
        ele.className = ele.className.replace(reg, ' ')
    }
}
// 下载文件
export function downloadFile(obj, name, suffix) {
    const url = window.URL.createObjectURL(new Blob([obj]))
    const link = document.createElement('a')
    link.style.display = 'none'
    link.href = url
    const fileName = parseTime(new Date()) + '-' + name + '.' + suffix
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
}

//表格汇总小数点
export function tableSumFixed(param) {
    const { columns, data } = param
    const sums = []
    columns.forEach((column, index) => {
        if (index === 0) {
            sums[index] = '汇总'
            return
        }
        const values = data.map((item) => Number(item[column.property]))
        if (!values.every((value) => isNaN(value))) {
            sums[index] = values
                .reduce((prev, curr) => {
                    const value = Number(curr)
                    if (!isNaN(value)) {
                        return prev + curr
                    } else {
                        return prev
                    }
                }, 0)
                .toFixed(2)
        }
    })
    return sums
}

//生成范围内的数组
export function range(start, end, step = 1) {
    let arr = []
    for (let i = start; i <= end; i++) {
        if (i % step == 0) {
            arr.push(i)
        }
    }
    return arr
}
//根据牌型和牌值 计算真实的牌值-扑克牌
export function getPokerCardValue(type, value) {
    return (type << 4) + (value & 0x0f)
}

//获取数组对应的值
export function getArrayValue(name, index) {
    return name[index] ? name[index] : ''
}

//分转元
export function fenToYuan(fen) {
    return (fen / 100).toFixed(2)
}

//元转分
export function yuanToFen(yuan) {
    return (yuan * 100).toFixed(0)
}

/**
 * 封装 confirm 确认框
 * @param title
 * @param callbackFunction
 * @param catchCallback
 */
export function confirmRequest(title = '确定要操作吗?', callbackFunction, catchCallback) {
    MessageBox.confirm(title, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
    })
        .then(callbackFunction)
        .catch(catchCallback)
}

//字符串转json
export function stringToJson(jsonString) {
    return jsonString ? JSON.parse(jsonString) : []
}

/**
 * 获取渠道列表
 * @param query
 * @returns {Promise<any>}
 */
export async function getChannelList() {
    const query = {
        sort: 'createTime;desc',
        all: true
    }
    let response = await channelApi.list(query)

    return response ? response.data : []
}

/**
 * 获取渠道包列表
 * @param channelId
 * @param name
 * @returns {Promise<any>}
 */
export async function getPackageList(channelId, name) {
    const query = {
        channelId: channelId,
        name: name,
        all: true
    }
    let response = await channelApi.packageList(query)

    return response ? response.data : []
}

/**
 * 处理账户明细摘要
 * @param row
 * @returns {string}
 */
export function getAccountSummary(row) {
    let text = ''
    //游戏输赢
    if ([100, 101].indexOf(row.subType) != -1) {
        text += getArrayValue(ACCOUNT_GAME_ROOM_TYPE, row.gameRoomType)
    }
    text += getArrayValue(ACCOUNT_SUB_TYPE, row.subType)

    text += '(账户余额由<span class="text_blue">' + filterThousandths(fenToYuan(row.beforeAmount)) + '</span>'
    text += '变更为<span class="text_blue">' + filterThousandths(fenToYuan(row.afterAmount)) + '</span>)'
    return text
}

/**
 * 节流
 * @param fnName
 * @param time
 * @returns {(function(): void)|*}
 */
export function throttle(fnName, time) {
    let timeout = null
    let flag = true
    return function () {
        if (flag === true) {
            this[fnName]()
            flag = false
        } else {
            if (timeout) {
                clearTimeout(timeout)
            }
            timeout = setTimeout(() => {
                this[fnName]()
            }, time)
        }
    }
}

/**
 * 获取触发策略概率名称
 * @param type
 * @param value
 * @returns {string}
 */
export function getStrategyValueTitle(type, value) {
    let title = ''
    switch (type) {
        case 'NEWBIE':
            title = value + '<br>局'
            break
        case 'WINNER':
            title = '累计赢金额<br>' + value
            break
        case 'LOSER':
            title = '累计输金额<br>' + value
            break
        case 'BRUSH':
            title = '-'
            break
    }
    return title
}

/**
 * 判断是否渠道用户(排除管理员)
 */
export function isChannelUser() {
    const userInfo = store.getters && store.getters.userInfo
    if (userInfo.channelUser && userInfo.superOrChannelAdmin === false) {
        return true
    }
    return false
}
