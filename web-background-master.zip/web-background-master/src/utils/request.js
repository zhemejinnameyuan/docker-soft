import axios from 'axios'
import settings from '@/settings'
import { getToken } from '@/utils/token'
import router from '@/router/routers'
import { Message } from 'element-ui'
import store from '@/store'
import Cookies from 'js-cookie'
import QueryString from 'qs'

let baseURL = process.env.VUE_APP_API_HOST
if (location.hostname === 'localhost') {
    baseURL = ''
}

const service = axios.create({
    baseURL: baseURL,
    withCredentials: true,
    timeout: settings.timeout
})

service.interceptors.request.use(
    (config) => {
        if (getToken()) {
            config.headers['Authorization'] = getToken()
        }
        if (config.method === 'get') {
            config.paramsSerializer = function (params) {
                return QueryString.stringify(params, { arrayFormat: 'repeat' })
            }
        }
        return config
    },
    (error) => {
        console.error(error)
        return Promise.reject(error)
    }
)

service.interceptors.response.use(
    (response) => {
        const headers = response.headers || {}
        if (headers['content-type'] !== 'application/json' && headers['content-type'] !== 'application/json;charset=UTF-8') {
            return response.data
        }

        const data = response.data
        if (data.code === '0000') {
            return data
        } else if (['0004', '0611', '0612', '0613'].includes(data.code)) {
            store.dispatch('Logout').then(() => {
                Cookies.set('point', 401)
                location.reload()
            })
        } else if (data.code === '0005') {
            router.push({ path: '/403' }).then()
        } else {
            Message.error({
                message: data.code + ':' + data.msg
            })
            return Promise.reject(new Error(JSON.stringify(data)))
        }
    },
    (error) => {
        console.error(error)
        if (!error.response) {
            Message.error({
                message: error.toString(),
                duration: 5000
            })
            return Promise.reject(error)
        }

        const status = error.response.status
        const msg = error.response.data.msg || error.response.data.error
        if (status !== undefined) {
            if (status === 401) {
                store.dispatch('Logout').then(() => {
                    // 未认证用户登录界面提示
                    Cookies.set('point', 401)
                    location.reload()
                })
            } else if (status === 403) {
                // 无权限访问
                router.push({ path: '/403' }).then()
            } else {
                Message.error({
                    message: status + ':' + msg,
                    duration: 5000
                })
            }
        }
        return Promise.reject(error)
    }
)

export default service
