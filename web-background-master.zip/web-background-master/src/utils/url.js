/**
 * 对外显示url参数使用##连接再base64
 * @param  {...any} args [渠道号,邀请码,皮肤id]
 * @returns
 */
export function urlParamBase64Encode(...args) {
    const len = args.length
    var str_params = ''
    for (let i = 0; i < len; i++) {
        if (i === 0) {
            str_params = `**`
        }
        str_params += `${args[i]}**`
    }
    return str_params ? window.btoa(str_params) : ''
}
/** url a参数解析 */
export function urlParamBase64Decode(str_a = '') {
    const _info = window.atob(str_a).split('**')
    return _info.slice(1, _info.length - 1)
}

export function setUrlQuery(url, query) {
    if (!url) return ''
    if (query) {
        const queryArr = []
        for (const key in query) {
            if (query.hasOwnProperty(key)) {
                queryArr.push(`${key}=${query[key]}`)
            }
        }
        if (url.indexOf('?') !== -1) {
            url = `${url}&${queryArr.join('&')}`
        } else {
            url = `${url}?${queryArr.join('&')}`
        }
    }
    return url
}
