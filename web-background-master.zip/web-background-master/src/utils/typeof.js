/**
 * 基础功能以及运算辅助函数
 */
// ////////////////////////////////////////lodash功能实现/////////////////////////////////////////////
/** 是否为空 */
export function isNil(v) {
    return v === undefined || v === null
}
/** 判断是否是NaN 在使用字符串转number时可能会出现nan */
export function isNaN(v) {
    return isNaN(v)
}
/** 是否是数组类型 */
export function isArray(v) {
    return !isNil(v) && Array.isArray(v)
}
/** 是否是布尔类型 */
export function isBoolean(v) {
    return !isNil(v) && typeof v === 'boolean'
}
/** 是否是字符串 */
export function isString(v) {
    return !isNil(v) && typeof v === 'string'
}
/** 是否是数字 */
export function isNumber(v) {
    return !isNil(v) && typeof v === 'number'
}
/** 是否是字典 */
export function isDict(v) {
    return isObject(v) && v.length === undefined
}
/** 是否是对象 */
export function isObject(v) {
    return !isNil(v) && typeof v === 'object'
}
/** 是否是函数 */
export function isFunction(v) {
    return !isNil(v) && typeof v === 'function'
}
/** 判断变量是否是空值 */
export function isEmpty(v) {
    if (isNil(v)) {
        return true
    } else {
        switch (typeof v) {
            case 'string':
                return v === ''
            case 'object':
                if (isArray(v)) {
                    return v.length === 0
                } else {
                    return Object.keys(v).length === 0
                }
            default:
                return false
        }
    }
}

// ////////////////////////////////////////////////////////////////
