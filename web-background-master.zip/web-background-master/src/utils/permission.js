import store from '@/store'
import { defaultPermission } from './permission/default'
import { dtPermission } from './permission/game/dt'
import { lmPermission } from './permission/game/lm'
import { fxqPermission } from './permission/game/fxq'
import { jmPermission } from './permission/game/jm'
import { babPermission } from './permission/game/bab'
import { dltPermission } from './permission/game/dlt'
import { cszPermission } from './permission/game/csz'
import { rbPermission } from './permission/game/rb'
import { supPermission } from './permission/game/sup'
import { tpPermission } from './permission/game/tp'
import { financePermission } from './permission/finance'
import { promotionPermission } from './permission/promotion'
import { playerPermission } from './permission/player'
import { activityPermission } from './permission/activity'

export const permission = Object.assign(
    defaultPermission,
    dtPermission,
    jmPermission,
    lmPermission,
    fxqPermission,
    babPermission,
    dltPermission,
    cszPermission,
    rbPermission,
    supPermission,
    tpPermission,
    financePermission,
    promotionPermission,
    playerPermission,
    activityPermission
)

/**
 * @param {Array} value
 * @returns {Boolean}
 * @example see @/views/permission/directive.vue
 */
export default function checkPermission(value) {
    if (value && value instanceof Array && value.length > 0) {
        const roles = store.getters && store.getters.roles
        const permissionRoles = value

        const hasPermission = roles.some((role) => {
            if (role === permission.admin) {
                return true
            }
            return permissionRoles.includes(role)
        })

        if (!hasPermission) {
            return false
        }
        return true
    } else {
        console.error(`need roles! Like v-permission="['admin','editor']"`)
        return false
    }
}
