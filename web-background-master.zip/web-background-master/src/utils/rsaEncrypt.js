const NodeRSA = require('node-rsa')
const PublicKey =
    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCEOkSqINi23z2DUG5CCw/N0KgjEA6l4H8/bjtmn36pBFThqYaYY+R6mviS6mPS3G/nH+W6nOJkkFUa1V7wbcfJLBZl9Ma9Rt0ubKOWl/SIeX5iRyWsZyna7GwbevwM7Lev64DbumGipimZyL3tWZww+YMcheAkPxLglMPtIfHwAwIDAQAB'
const PrivateKey =
    'MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIQ6RKog2LbfPYNQbkILD83QqCMQDqXgfz9uO2affqkEVOGphphj5Hqa+JLqY9Lcb+cf5bqc4mSQVRrVXvBtx8ksFmX0xr1G3S5so5aX9Ih5fmJHJaxnKdrsbBt6/Azst6/rgNu6YaKmKZnIve1ZnDD5gxyF4CQ/EuCUw+0h8fADAgMBAAECgYBsRco0BPFvzRzxicq/CY/HWDRVgbB843dO2VSKk8+DVqiqn8Y2wpU0T/F7W7Kh1x9KgjP6urwm3IjTkCRNe5c7VifUKMvOxHt8uciwX8+N1FhWtZ8iWDwcLOqLtaDznLbNJWHYGbQd+Sv7yuUtIbVRrBMYV0RIZWqPMyDSGGapAQJBALqEOZh22nuVCjHHOVGIVLetpTw+P63ZjeWQW0ujI4gi+IJ7dRmwcy6CacnqHcN4airLThOw7tnlB2whlrE2RK8CQQC1fJmUy0UtirFVPnjdZbnEr7Zpcet3rhXgNHpEz6HPPG+HU+B3atoSF0mvSk7d4A8Bh2Tpum4i1keJzEre+8btAkBtQQjP00cVvu7Sy8U6iiY91ZyFll0Mw/QHdbDUtIIau4lgPVsRqjc+FixLlzTKDF38JUzd4fV3c14Oq/ouYgCHAkEAhzRkVm15BAynQBJiiM4YL2eYRcYQ3gBbW8S8sjbdHT6w9+iM+WopPAENbAG376PUihcMHvQ8yMdKVGZWAPkhoQJAcQjEwEgAIdytippkWmfm91kdZIogu6phaoEoJ8lqMlH9mXQAGuCQ6NnSmCnwrm9li2X4DBob2POtlO5trte51A=='

export function rsaEncrypt(data) {
    const nodeRSA = new NodeRSA(PublicKey, 'pkcs8-public')
    nodeRSA.setOptions({ encryptionScheme: 'pkcs1' })
    return nodeRSA.encrypt(data, 'base64', 'utf8')
}

export function rsaDecrypt(data) {
    const nodeRSA = new NodeRSA(PrivateKey, 'pkcs8-private')
    nodeRSA.setOptions({ encryptionScheme: 'pkcs1' })
    return nodeRSA.decrypt(data, 'utf8')
}
