import { isNil } from './typeof'
/** 格式化空数据 */
export const filterEmpty = (arg) => {
    if (arg === null || arg === undefined || arg === '') {
        return '--'
    } else {
        return arg
    }
}

/** 格式化成千分位 */
export const filterThousandths = (arg) => {
    var v
    if (arg) {
        if (typeof arg === 'number') {
            if (arg.toString().includes('.')) {
                v = arg.toFixed(2).toString()
            } else {
                v = arg.toString()
            }
        } else {
            v = arg + ''
        }
        v = v.toString().replace(/\d+/, function (n) {
            // 先提取整数部分
            return n.replace(/(\d)(?=(\d{3})+$)/g, function ($1) {
                return $1 + ','
            })
        })
    } else if (!isNil(arg)) {
        v = arg
    }
    return filterEmpty(v)
}

export const filterCion = (arg) => {
    var v
    if (arg) {
        v = (arg / 1).toFixed(2)
    }
    return filterThousandths(v)
}

/** 对象键值判断 */
export const checkObj = (rule, value, callback) => {
    var tag = false
    const judgeObj = (obj) => {
        Object.values(obj).forEach((item) => {
            if (item instanceof Object) {
                judgeObj(item)
            } else if (item === null || item === undefined || item === '') {
                tag = true
            }
        })
    }
    if (!value || !(value instanceof Object)) {
        return callback(new Error(rule.message))
    } else {
        judgeObj(value)
        if (tag) {
            return callback(new Error(rule.message))
        } else {
            callback()
        }
    }
}

/** 数组对象键值判断 */
export const checkArr = (rule, value, callback) => {
    if (!value || !(value instanceof Array)) {
        return callback(new Error(rule.message))
    } else {
        var tag = false
        value.forEach((item) => {
            if (item instanceof Object) {
                Object.values(item).forEach((v) => {
                    if (v === null || v === undefined || v === '') {
                        tag = true
                    }
                })
            } else {
                if (item === null || item === undefined || item === '') {
                    tag = true
                }
            }
        })
        if (tag) {
            return callback(new Error(rule.message))
        } else {
            callback()
        }
    }
}
