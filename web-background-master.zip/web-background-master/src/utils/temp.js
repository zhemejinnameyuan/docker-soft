export const svg_fangkuai = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_ico_fangkuai" /></svg>'
export const svg_meihua = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_ico_meihua" /></svg>'
export const svg_hongtao = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_ico_hongtao" /></svg>'
export const svg_heitao = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_ico_heitao" /></svg>'
export const svg_win = '<svg style="width: 2em;height: 0.9em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_lab_win" /></svg>'
export const svg_huangguan = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_jm_huangguan" /></svg>'
export const svg_hongqi = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_jm_hongqi" /></svg>'
export const svg_jinshaizi = '<svg style="width: 1em;height: 1.3em;vertical-align: -0.15em;fill: currentColor;overflow: hidden;" aria-hidden="true"><use href="#icon-oms_jm_jinshaizi" /></svg>'

export function replaceHtml(txt) {
    if (!txt) return ''
    txt = txt.replace(/♦️/g, svg_fangkuai)
    txt = txt.replace(/♣️/g, svg_meihua)
    txt = txt.replace(/♥️/g, svg_hongtao)
    txt = txt.replace(/♠️/g, svg_heitao)
    txt = txt.replace(/✌️/g, svg_win)
    txt = txt.replace(/👑/g, svg_huangguan)
    txt = txt.replace(/🚩/g, svg_hongqi)
    txt = txt.replace(/金骰子/g, svg_jinshaizi)
    return txt
}
