import { login, logout, userInfo } from '@/api/auth'
import { getToken, removeToken, setToken } from '@/utils/token'
import permission from './permission'

const user = {
    state: {
        token: getToken(),
        userInfo: {},
        roles: []
    },
    mutations: {
        SET_TOKEN: (state, token) => {
            state.token = token
        },
        SET_USER: (state, userInfo) => {
            state.userInfo = userInfo
        },
        SET_ROLES: (state, roles) => {
            state.roles = roles
        }
    },
    actions: {
        Login({ commit }, loginInfo) {
            const rememberMe = loginInfo.rememberMe
            return new Promise((resolve, reject) => {
                login(loginInfo.username.trim(), loginInfo.password, loginInfo.code, loginInfo.key)
                    .then((res) => {
                        const { data } = res
                        setToken(data.token, rememberMe)
                        commit('SET_TOKEN', data.token)
                        resolve(res)
                    })
                    .catch((error) => {
                        reject(error)
                    })
            })
        },
        UserInfo({ commit }) {
            return new Promise((resolve, reject) => {
                userInfo()
                    .then((res) => {
                        commit('SET_USER', res.data)
                        const roles = res.data.roles ? res.data.roles.map((x) => x.name) : []
                        roles.push(res.data.userType)
                        commit('SET_ROLES', roles)
                        resolve(res)
                    })
                    .catch((error) => {
                        reject(error)
                    })
            })
        },
        Logout({ commit }) {
            return new Promise((resolve, reject) => {
                logout()
                    .then((res) => {
                        commit('SET_TOKEN', '')
                        commit('SET_USER', {})
                        removeToken()
                        resolve(res)
                    })
                    .catch((error) => {
                        reject(error)
                    })
            })
        }
    }
}

export default user
