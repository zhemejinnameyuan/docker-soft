const getters = {
    token: (state) => state.user.token,
    userInfo: (state) => state.user.userInfo,
    roles: (state) => state.user.roles,
    size: (state) => state.app.size,
    sidebar: (state) => state.app.sidebar,
    device: (state) => state.app.device,
    visitedViews: (state) => state.tagsView.visitedViews,
    cachedViews: (state) => state.tagsView.cachedViews,
    permission_routers: (state) => state.permission.routers,
    permission_addRouters: (state) => state.permission.addRouters
}
export default getters
