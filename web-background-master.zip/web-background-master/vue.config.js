const path = require('path')
const defaultSettings = require('./src/settings.js')
const WebpackObfuscator = require('webpack-obfuscator')

function resolve(dir) {
    return path.join(__dirname, dir)
}
const Timestamp = new Date().getTime()
// 网站标题
const name = defaultSettings.title

module.exports = {
    publicPath: '/',
    outputDir: 'web-background',
    assetsDir: '',
    lintOnSave: false,
    runtimeCompiler: false,
    productionSourceMap: false,
    devServer: {
        open: true,
        port: 9080,
        https: false,
        overlay: {
            warnings: true,
            errors: true
        },
        proxy: {
            '/api': {
                // target: 'http://192.168.2.41:8011',
                // target: 'http://192.168.2.228:8011',
                target: 'http://192.168.2.205:19080', // test
                // target: 'http://192.168.2.206:19080', // dev
                ws: true,
                changeOrigin: true,
                logLevel: 'debug'
            },
            '/avatar': {
                // target: 'http://192.168.2.41:8011',
                // target: 'http://192.168.2.228:8011',
                target: 'http://192.168.2.205:19080', // test
                // target: 'http://192.168.2.206:19080', // dev
                ws: true,
                changeOrigin: true,
                logLevel: 'debug'
            }
        }
    },
    configureWebpack: {
        // provide the app's title in webpack's name field, so that
        // it can be accessed in index.html to inject the correct title.
        name: name,
        resolve: {
            alias: {
                '@': resolve('src'),
                '@crud': resolve('src/components/Crud')
            }
        },
        output: { // 输出重构  打包编译后的 文件名称  【模块名称.版本号.时间戳】
            filename: `[name].${Timestamp}.js`,
            chunkFilename: `[name].[chunkhash].${Timestamp}.js`
        },
        // plugins: process.env.VUE_APP_ENV === 'prod' ? [
        //     // 低混淆
        //     new WebpackObfuscator({
        //         // 压缩代码
        //         compact: true,
        //         // 是否启用控制流扁平化(降低1.5倍的运行速度)
        //         controlFlowFlattening: false,
        //         // 随机的死代码块（增加了混淆代码的大小）
        //         deadCodeInjection: false,
        //         // 此选项几平不可能使用开发者工具的控制台选项卡
        //         debugProtection: false,
        //         // 如果选中，则会在“控制合”选项大上使用间隔强制调试模式，从而更难使用“开发人员工具”的其他功能。
        //         debugProtectionInterval: false,
        //         // 通过用空西数替换它们来禁用console.1og, console.info, console.error和console.warn。这使得调试器的使用更加
        //         disableConsoleOutput: true,
        //         // 标识符的混淆方式 hexadecimal（十六进秀)mangled(短桥标识符）
        //         identifierNamesGenerator: 'hexadecimal', log: false,
        //         // 是否启用全局变量和函数名称的混淆
        //         renameGlobals: false,
        //         //! 通过固定和随机（在代码泥淆时生成）的位置移动数组。这使得将肌除的字符串的顺序与其原始位置相匹配变得更加因难。如果原
        //         rotatestringArray: true,
        //         // ！混淆后的代码，不能使用代码美化，同时需要配置 cpmpat:true;
        //         selfDefending: true,
        //         // 1/册除字符串文字并将它们放在一个特殊的数组中
        //         stringArray: true,
        //         // 1/ 这里是网上复制来的代码改的，不然会报错，具体报错看下面的贴的！！
        //         // stringArrayEncoding: false,
        //         stringArrayEncoding: ['base64'],
        //         // stringArrayThreshold: 0.75，
        //         //! 1允许启用/禁用字符串转换为unicode转义/序列。Unicode转义序列大大增加了代码大小，并且可以轻松地将字符串恢复为原始祝
        //         unicodeEscapeSequence: false
        //     }, [])
        // ] : []
    },
    chainWebpack: config => {
        config.module
            .rule('svg')
            .exclude.add(resolve('src/assets/icons'))
            .end()
        config.module
            .rule('icons')
            .test(/\.svg$/)
            .include.add(resolve('src/assets/icons'))
            .end()
            .use('svg-sprite-loader')
            .loader('svg-sprite-loader')
            .options({
                symbolId: 'icon-[name]'
            })
            .end()
        config
            // https://webpack.js.org/configuration/devtool/#development
            .when(process.env.NODE_ENV === 'development',
                config => config.devtool('cheap-source-map')
            )
    }
}
