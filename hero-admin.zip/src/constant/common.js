/**
 * 后台账号类型
 */
export const USER_TYPE = {
    SUPER_ADMIN: 'SUPER_ADMIN',
    PROJECT_USER: 'PROJECT_USER'
}

export const USER_TYPE_NAME = {
    SUPER_ADMIN: '超级管理员',
    PROJECT_USER: '项目成员'
}

/**
 * 游戏ID
 */
export const GAME_ID = {
    HERO: 1,
    MAGIC_GIRL: 2
}

/**
 * 游戏列表
 */
export const GAME_LIST = {
    [GAME_ID.HERO]: {
        id: GAME_ID.HERO,
        title: '英雄无敌',
        imgUrl: require('@/assets/images/gameoms_img_hero.png'),
        logoUrl: require('@/assets/images/gameoms_logo_hero.png')
    },
    [GAME_ID.MAGIC_GIRL]: {
        id: GAME_ID.MAGIC_GIRL,
        title: '魔女计划',
        imgUrl: require('@/assets/images/gameoms_img_monv.png'),
        logoUrl: require('@/assets/images/gameoms_logo_monv.png')
    }
}

/**
 * 分页数量
 * @type {number}
 */
export const PAGE_SIZE = 20
