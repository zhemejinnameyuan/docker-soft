import { constantRouterMap } from '@/router/routers'
import Layout from '@/layout/index'

const permission = {
    state: {
        routers: [],
        addRouters: []
    },
    mutations: {
        SET_ROUTERS: (state, routers) => {
            state.addRouters = routers
            state.routers = constantRouterMap.concat(routers)
        }
    },
    actions: {
        generateRoutes({ commit }, asyncRouter) {
            commit('SET_ROUTERS', asyncRouter)
        }
    }
}

/** 待添加到一级路由的数组 */
let moveRouters = []

//只支持二级路由最多遍历3层（发现三级路由就添加到一级路由）
export const filterAsyncRouter = (routers, index = 1) => {
    if (index === 1) {
        moveRouters = []
    }
    // 遍历后台传来的路由字符串，转换为组件对象
    var arr = routers.filter((router, i) => {
        if (router.component) {
            if (router.component === 'Layout') {
                if (router.path === '/') {
                    router.redirect = router.path + router.children[0].path
                    router.children[0].meta.affix = true
                } else if (router.children) {
                    router.redirect = router.path + '/' + router.children[0].path
                }
                router.component = Layout
            } else {
                const component = router.component
                router.component = () => import(`@/views/${component}`)
                if (index > 2) {
                    /** 路由超过二级 */
                    moveRouters.push(router)
                    return false
                }
            }
        }
        if (router.children && router.children.length) {
            router.children = filterAsyncRouter(router.children, index + 1)
        }
        return true
    })

    if (index === 1) {
        return arr.concat(moveRouters)
    } else {
        return arr
    }
}

export default permission
