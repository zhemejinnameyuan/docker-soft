<template>
    <div class="navbar">
        <hamburger id="hamburger-container" :is-active="sidebar.opened" class="hamburger-container" @toggleClick="toggleSideBar" />

        <!--        <breadcrumb id="breadcrumb-container" class="breadcrumb-container" />-->

        <div class="select-game cursor">
            <div class="left-triangle"></div>
            <el-dropdown class="select-container" placement="bottom" @command="dropDownClick">
                <span class="title">
                    {{ getGameInfo(gameId).title }}
                    <i class="el-icon-arrow-down el-icon--right"></i>
                </span>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item style="width: 200px" v-for="item in gameList" :key="item.id" :command="item.id" :disabled="gameId == item.id">
                        <div class="dp-f-space-between mb-10 mt-10">
                            <div class="dp-f-vertical-center">
                                <img :src="getGameInfo(item.id)['logoUrl']" class="mr-5" />
                                {{ getGameInfo(item.id)['title'] }}
                            </div>

                            <div>{{ item.name }}</div>
                        </div>
                    </el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>

            <div class="right-triangle"></div>
        </div>
        <div class="right-menu">
            <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">
                <div class="avatar-wrapper">
                    <span class="user-name">{{ userInfo.username ? userInfo.username : '' }}</span>
                    <img :src="userInfo.avatarPath ? userInfo.avatarPath : Avatar" class="user-avatar" />
                </div>
                <el-dropdown-menu slot="dropdown">
                    <span style="display: block" @click="open">
                        <el-dropdown-item>退出登录</el-dropdown-item>
                    </span>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Hamburger from './Hamburger'
import Avatar from '@/assets/images/avatar.png'
import Base from '@/views/base'
import { getGameId } from '@/utils/token'

export default {
    mixins: [Base],
    components: {
        Hamburger
    },
    data() {
        return {
            Avatar: Avatar,
            dialogVisible: false,
            gameList: [],
            gameId: getGameId()
        }
    },
    created() {
        this.gameList = this.getGameList()
    },
    computed: {
        ...mapGetters(['sidebar', 'device', 'userInfo']),
        show: {
            get() {
                return this.$store.state.settings.showSettings
            },
            set(val) {
                this.$store.dispatch('settings/changeSetting', {
                    key: 'showSettings',
                    value: val
                })
            }
        }
    },
    methods: {
        toggleSideBar() {
            this.$store.dispatch('app/toggleSideBar')
        },
        dropDownClick(command) {
            this.selectGame(command, 'top')
        },
        open() {
            this.$confirm('确定注销并退出系统吗？', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.logout()
            })
        },
        logout() {
            this.$store.dispatch('Logout').then(() => {
                location.reload()
            })
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/element/variables.scss';
.navbar {
    height: $navBarHeught;
    overflow: hidden;
    position: relative;
    background: #ffffff;
    width: 100%;
    box-shadow: 0px 0px 6px 0px rgba(33, 39, 35, 0.1);
    display: flex;

    .hamburger-container {
        display: flex;
        justify-content: center;
        align-items: center;
        line-height: 46px;
        height: 100%;
        float: left;
        transition: background 0.3s;
        -webkit-tap-highlight-color: transparent;
    }

    .breadcrumb-container {
        float: left;
        display: flex;
        align-items: center;
        height: 100%;
    }

    //选择游戏
    .select-game {
        width: 240px;
        margin: 0 auto;
        background: #f7f6f3;
        display: flex;

        ::v-deep .el-dropdown {
            display: block;
            width: 110px;
            margin: 0 auto 0 30px;
        }

        .title {
            height: 40px;
            line-height: 40px;
            border-bottom: 2px solid transparent;
            font-size: 18px;
            color: #292828;
            letter-spacing: 0;
            font-weight: 600;
            font-family: PingFangSC-Semibold;
        }

        .left-triangle {
            width: 50px;
            background-color: #ffffff;
            margin-left: -60px;
            border-bottom: 100px solid #f7f6f3;
            border-left: 100px solid transparent;
        }
        .right-triangle {
            width: 50px;
            margin-right: -60px;
            background-color: #ffffff;
            border-bottom: 100px solid #f7f6f3;
            border-right: 100px solid transparent;
        }
    }

    .errLog-container {
        display: inline-block;
        vertical-align: top;
    }

    .right-menu {
        float: right;
        height: 100%;
        line-height: 50px;

        &:focus {
            outline: none;
        }

        .right-menu-item {
            display: inline-block;
            padding: 0 8px;
            height: 100%;
            font-size: 18px;
            color: #5a5e66;
            vertical-align: text-bottom;
            //display: flex;
            align-items: center;

            &.hover-effect {
                cursor: pointer;
                transition: background 0.3s;

                &:hover {
                    background: rgba(0, 0, 0, 0.025);
                }
            }
        }

        .avatar-container {
            margin-right: 30px;

            .avatar-wrapper {
                margin-top: 5px;
                display: flex;
                flex-direction: row;
                align-items: center;
                position: relative;

                .user-avatar {
                    cursor: pointer;
                    width: 32px;
                    height: 32px;
                    border-radius: 50%;
                }
                .user-name {
                    cursor: pointer;
                    height: 30px;
                    line-height: 30px;
                    font-size: 16px;
                    color: #282829;
                    margin-right: 10px;
                }

                .el-icon-caret-bottom {
                    cursor: pointer;
                    position: absolute;
                    right: -20px;
                    top: 25px;
                    font-size: 12px;
                }
            }
        }
    }
}
</style>
