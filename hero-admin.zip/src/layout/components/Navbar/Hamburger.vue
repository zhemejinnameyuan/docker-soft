<template>
    <div style="padding: 0px 10px; cursor: pointer" @click="toggleClick">
        <svg-icon icon-class="oms_ico_yincangbianlan" style="font-size: 32px" />
    </div>
</template>

<script>
export default {
    name: 'Hamburger',
    props: {
        isActive: {
            type: Boolean,
            default: false
        }
    },
    methods: {
        toggleClick() {
            this.$emit('toggleClick')
        }
    }
}
</script>

<style scoped>
.hamburger {
    display: inline-block;
    vertical-align: middle;
    width: 20px;
    height: 20px;
}
.hamburger-icon {
    cursor: pointer;
    width: 32px;
    height: 32px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(27, 162, 255, 0.1);
    border-radius: 50%;
}
.hamburger-icon:hover {
    background: rgba(0, 0, 0, 0.025);
}

.hamburger.is-active {
    transform: rotate(180deg);
}
</style>
