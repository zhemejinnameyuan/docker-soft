<template>
    <div :class="{ 'has-logo': showLogo }">
        <logo v-if="showLogo" :collapse="isCollapse" />
        <el-scrollbar wrap-class="scrollbar-wrapper">
            <el-menu
                :default-active="activeMenu()"
                :collapse="isCollapse"
                :background-color="variables.menuBg"
                :text-color="variables.menuText"
                :unique-opened="$store.state.settings.uniqueOpened"
                :active-text-color="variables.menuActiveText"
                :collapse-transition="false"
                mode="vertical"
                @open="subOpen"
            >
                <sidebar-item v-for="route in permission_routers" :key="route.path" :item="route" :base-path="route.path" />
            </el-menu>
        </el-scrollbar>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Logo from './Logo'
import SidebarItem from './SidebarItem'
import variables from '@/assets/styles/element/variables.scss'
import path from 'path'

/** 路由选中映射 */
const mapPathKey = ['/pepole/player']

export default {
    components: { Logo, SidebarItem },
    data() {
        return {
            lastPath: ''
        }
    },
    computed: {
        ...mapGetters(['permission_routers', 'sidebar']),

        showLogo() {
            return this.$store.state.settings.sidebarLogo
        },
        variables() {
            return variables
        },
        isCollapse() {
            return !this.sidebar.opened
        }
    },
    methods: {
        subOpen(v) {
            this.permission_routers.forEach((item) => {
                if (item.path.startsWith(v)) {
                    var path_url = path.resolve(v, item.children[0].path)
                    if (path_url !== this.$route.path) {
                        setTimeout(() => {
                            this.$router.push({ path: path_url })
                        }, 300)
                    }
                }
            })
        },
        activeMenu() {
            const route = this.$route
            const { meta, path } = route
            // if set path, the sidebar will highlight the path you set
            if (meta.activeMenu) {
                return meta.activeMenu
            }
            if (!mapPathKey.includes(path)) {
                this.lastPath = path
            }
            return this.lastPath
        }
    }
}
</script>
