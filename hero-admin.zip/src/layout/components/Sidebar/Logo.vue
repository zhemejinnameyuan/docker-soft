<template>
    <div class="sidebar-logo-container" :class="{ collapse: collapse }">
        <transition name="sidebarLogoFade">
            <router-link key="expand" class="sidebar-logo-link" to="/">
                <div class="sidebar-title">{{ title }}</div>
            </router-link>
        </transition>
    </div>
</template>

<script>
export default {
    name: 'SidebarLogo',
    props: {
        collapse: {
            type: Boolean,
            required: true
        }
    },
    data() {
        return {
            title: '游戏管理后台'
        }
    }
}
</script>

<style lang="scss" scoped>
.sidebar-logo-container {
    position: relative;
    text-align: center;
    overflow: hidden;
    height: 40px;
    & .sidebar-logo-link {
        & .sidebar-title {
            width: 240px;
            height: 40px;
            line-height: 40px;
            background-image: radial-gradient(circle at 50% 50%, #fdb400 0%, #f68915 258%);
            border-radius: 0px 0px 20px 0px;
            font-family: PingFangSC-Semibold;
            font-size: 18px;
            color: #ffffff;
            letter-spacing: 0;
            font-weight: 600;
        }
    }

    &.collapse {
        .sidebar-logo {
            margin-right: 0px;
        }
    }
}
</style>
