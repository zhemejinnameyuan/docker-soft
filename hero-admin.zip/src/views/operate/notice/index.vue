<template>
    <div>notice</div>
</template>

<script>
export default {
    name: 'Index'
}
</script>

<style scoped></style>
