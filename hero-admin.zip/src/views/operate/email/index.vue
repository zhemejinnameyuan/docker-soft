<template>
    <div class="app-container">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium">
                    <el-radio-button label="single" style="width: 140px">个人邮件</el-radio-button>
                    <el-radio-button label="all" style="width: 140px">全服邮件</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left">
                    <IconButton size="medium" type="warning" title="添加" icon="oms_ico_add" @click="toAdd" />
                    <IconButton size="medium" type="danger" plain title="删除" @click="toRemove" />
                </div>
                <div class="right">
                    <div class="item">
                        <el-select v-model="search.type" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="发送状态" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="发送完毕" value="1" />
                            <el-option label="发送失败" value="2" />
                            <el-option label="未发送" value="3" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="领取状态" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="已领取" value="1" />
                            <el-option label="未领取" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="邮件标题" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>
                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%" @selection-change="changeSelect">
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="邮件ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="邮件标题" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="邮件内容" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="附件" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="区服" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="角色名称(ID)" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="创建者" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="创建时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="发送时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="领取时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="发送状态" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="领取状态" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="需送达人数\到达人数\领取人数" />
                <el-table-column label="操作" width="100" align="center" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" size="medium" @click="toRemove(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
        </div>

        <!--表单渲染-->
        <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
            <Add v-if="drawerVisible" :dataObj="dataObj" :edit-type="drawerType" @toQuery="toQuery" @onClose="closeDrawer"></Add>
        </Drawer>
    </div>
</template>

<script>
import Add from './add'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import * as api from '@/api/auth/user'
import { PAGE_SIZE } from '@/constant/common'
const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}

export default {
    name: 'Index',
    components: {
        Add,
        Pagination,
        Drawer
    },
    data() {
        return {
            search: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            type: 'single',
            selectsIds: [],
            dataObj: {},
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false
        }
    },
    mounted() {
        this.toQuery()
    },
    methods: {
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '添加邮件'
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toRemove() {
            this.$message.info('todo')
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        }
    }
}
</script>

<style scoped></style>
