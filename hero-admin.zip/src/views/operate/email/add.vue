<template>
    <div class="form-container" style="width: 620px">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px" label-position="top">
            <div class="bg-item">
                <el-form-item label="邮件标题:" prop="username" class="el-form--inline">
                    <el-input class="ml-20" v-model="form.title" style="width: 240px" autocomplete="off" />
                </el-form-item>

                <el-form-item label="邮件内容:" prop="username">
                    <div>
                        <el-input v-model="form.title" type="textarea" rows="5" style="width: 480px" autocomplete="off" />
                    </div>
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'

export default {
    name: 'Edit',
    mixins: [Base],
    components: {},
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            selectRoleVisible: false,
            form: {},
            rules: {},
            type: ''
        }
    },
    mounted() {},
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$message.info('todo')
                }
            })
        },

        toCancel() {
            this.$emit('onClose')
        },
        onClose() {
            this.selectRoleVisible = false
        }
    }
}
</script>
