<template>
    <div class="app-container">
        <div>
            <el-tabs v-model="blackType">
                <el-tab-pane label="黑名单列表" name="1"></el-tab-pane>
                <el-tab-pane label="角色禁言" name="2"></el-tab-pane>
            </el-tabs>
        </div>

        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left">
                    <IconButton v-permission="[permission.userSave]" size="medium" type="warning" icon="oms_ico_add" title="添加" @click="toAdd" />
                    <IconButton v-permission="[permission.userSave]" size="medium" type="danger" plain title="批量移除" @click="toRemove" />
                </div>
                <div class="right">
                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" @change="toQuery" />
                    </div>
                    <div class="item">
                        <el-select v-model="search.type" placeholder="封禁类型" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="账号服ID" value="1" />
                            <el-option label="角色ID" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色ID/账号ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%" @selection-change="changeSelect">
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="id" align="center" label="添加时间" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="封禁类型" />
                <el-table-column :show-overflow-tooltip="true" prop="username" align="center" label="封禁信息" />
                <el-table-column :show-overflow-tooltip="true" width="300" prop="username" align="center" label="封禁原因" />
                <el-table-column :show-overflow-tooltip="true" width="160" prop="username" align="center" label="操作时间" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="操作人" />
                <el-table-column label="操作" width="200" align="center" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" size="medium" v-permission="[permission.userSave]" @click="toRemove(scope.row)">解除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
        </div>

        <!--表单渲染-->
        <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
            <Add v-if="drawerVisible" :dataObj="dataObj" :edit-type="drawerType" @toQuery="toQuery" @onClose="closeDrawer"></Add>
        </Drawer>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import { PAGE_SIZE } from '@/constant/common'
import Add from './add'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        Drawer,
        DateRangePicker,
        Add
    },
    mixins: [Base],
    data() {
        return {
            search: {},
            list: [],
            loading: false,
            total: 0,
            blackType: '1',
            query: defaultQuery,
            selectsIds: [],
            dataObj: {},
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false
        }
    },

    mounted() {
        this.toQuery()
    },
    methods: {
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },
        toRemove() {
            this.$message.info('todo')
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '添加黑名单'
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        }
    }
}
</script>
