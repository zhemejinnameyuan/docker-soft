<template>
    <div class="form-container" style="width: 560px">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px">
            <div class="bg-item">
                <el-form-item label="黑名单类型:" prop="username">
                    <el-select v-model="form.type" placeholder="封禁类型" size="medium" style="width: 240px">
                        <el-option label="账号服ID" value="1" />
                        <el-option label="角色ID" value="2" />
                    </el-select>
                </el-form-item>

                <el-form-item label="信息:" prop="username">
                    <el-input v-model="form.ids" type="textarea" rows="5" style="width: 240px" autocomplete="off" />
                </el-form-item>

                <el-form-item label="原因:" prop="username">
                    <el-input v-model="form.remark" type="textarea" rows="5" style="width: 240px" autocomplete="off" />
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
export default {
    name: 'Edit',
    mixins: [Base],
    components: {},
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {},
            rules: {},
            type: '',
            beforeIds: '',
            afterIds: ''
        }
    },
    mounted() {},
    methods: {
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$message.info('todo')
                }
            })
        },

        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
