<template>
    <div class="mt-20" style="min-width: 1560px">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium">
                    <el-radio-button label="account" style="width: 140px">游戏账号</el-radio-button>
                    <el-radio-button label="serverAccount" style="width: 140px">游戏服账号</el-radio-button>
                    <el-radio-button label="role" style="width: 140px">游戏角色</el-radio-button>
                    <el-radio-button label="transfer" style="width: 140px">游戏转号</el-radio-button>
                    <el-radio-button label="black" style="width: 140px">黑名单信息</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <Account v-if="type === 'account'" />
        <ServerAccount v-if="type === 'serverAccount'" />
        <Role v-if="type === 'role'" />
        <Transfer v-if="type === 'transfer'" />
        <Black v-if="type === 'black'" />
    </div>
</template>

<script>
import Account from './account/index'
import ServerAccount from './serverAccount/index'
import Role from './role/index'
import Transfer from './transfer/index'
import Black from './black/index'

export default {
    name: 'Index',
    components: {
        Account,
        ServerAccount,
        Role,
        Transfer,
        Black
    },
    data() {
        return {
            type: 'account'
        }
    }
}
</script>

<style scoped></style>
