<template>
    <div class="form-container" style="width: 620px">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px" label-position="top">
            <div class="bg-item">
                <el-form-item label="转换前角色ID:" prop="username">
                    <div class="dp-f-vertical-center">
                        <el-input v-model="beforeIds" style="width: 240px" autocomplete="off" />
                        <el-button class="ml-40" type="warning" size="medium" @click="selectRole('before')">选择角色</el-button>
                    </div>
                </el-form-item>

                <el-form-item label="转换后角色ID:" prop="username">
                    <div class="dp-f-vertical-center">
                        <el-input v-model="afterIds" style="width: 240px" autocomplete="off" />
                        <el-button class="ml-40" type="warning" size="medium" @click="selectRole('after')">选择角色</el-button>
                    </div>
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>

        <el-dialog title="选择角色" :append-to-body="true" :visible.sync="selectRoleVisible" :before-close="onClose" width="950px" top="4vh" center>
            <SelectRole v-if="selectRoleVisible" @onClose="onClose" @selectIds="selectIds"></SelectRole>
        </el-dialog>
    </div>
</template>

<script>
import Base from '@/views/base'
import SelectRole from './selectRole'

export default {
    name: 'Edit',
    mixins: [Base],
    components: {
        SelectRole
    },
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            selectRoleVisible: false,
            form: {},
            rules: {},
            type: '',
            beforeIds: '',
            afterIds: ''
        }
    },
    mounted() {},
    methods: {
        selectRole(type) {
            this.type = type
            this.selectRoleVisible = true
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    this.$message.info('todo')
                }
            })
        },
        selectIds(ids) {
            if (this.type === 'before') {
                this.beforeIds = ids.join(',')
            } else {
                this.afterIds = ids.join(',')
            }
        },
        toCancel() {
            this.$emit('onClose')
        },
        onClose() {
            this.selectRoleVisible = false
        }
    }
}
</script>
