<template>
    <div class="bg-container" style="width: 900px">
        <!--工具栏-->
        <div class="search-container mb-10">
            <div class="right">
                <div class="item">
                    <el-select v-model="search.type" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery">
                        <el-option label="区服1" value="1" />
                        <el-option label="区服2" value="2" />
                    </el-select>
                </div>

                <div class="item">
                    <el-input v-model="search.type" placeholder="角色ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                </div>
                <div class="item">
                    <el-input v-model="search.type" placeholder="角色昵称" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                </div>

                <div class="item">
                    <el-input v-model="search.type" placeholder="角色等级" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                </div>

                <div class="item">
                    <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                </div>
            </div>
        </div>
        <!--表格渲染-->
        <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%" @selection-change="changeSelect">
            <el-table-column type="selection" width="55" align="center" />
            <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="角色ID" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="角色名称" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="等级" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="VIP" />
            <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="邀请码" />
            <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="角色创建时间" />
            <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="最后登录时间" />
            <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="登录天数" />
        </el-table>
        <!--分页组件-->
        <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

        <div class="dp-f-reverse mt-20">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Base from '@/views/base'
import { PAGE_SIZE } from '@/constant/common'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination
    },
    mixins: [Base],
    data() {
        return {
            search: {},
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false,
            selectsIds: [],
            batchType: ''
        }
    },

    mounted() {
        this.toQuery()
    },
    methods: {
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        toSubmit() {
            if (this.selectsIds.length === 0) {
                return this.$message.error('请选择数据')
            }
            this.$emit('selectIds', this.selectsIds)
            this.toCancel()
        },
        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
