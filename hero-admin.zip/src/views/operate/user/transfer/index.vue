<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left"></div>
                <div class="right">
                    <IconButton size="medium" type="warning" title="转号" @click="toAdd" />
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="200" prop="id" align="center" label="ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="转换前角色" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="转换前等级" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="转换后角色" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="转换后等级" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="转换时间" />
                <el-table-column :show-overflow-tooltip="true" prop="username" align="center" label="操作时间" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="操作人" />
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
        </div>

        <!--表单渲染-->
        <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
            <Add v-if="drawerVisible" :dataObj="dataObj" :edit-type="drawerType" @toQuery="toQuery" @onClose="closeDrawer"></Add>
        </Drawer>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { PAGE_SIZE } from '@/constant/common'
import Add from './add'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        Drawer,
        Add
    },
    mixins: [Base],
    data() {
        return {
            search: {},
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false,
            selectsIds: [],
            batchType: ''
        }
    },

    mounted() {
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '转号'
            this.drawerType = 'add'
            this.dataObj = {}
        }
    }
}
</script>
