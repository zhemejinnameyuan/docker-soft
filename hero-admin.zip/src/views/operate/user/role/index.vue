<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="right">
                    <div class="item">
                        <el-select v-model="search.type" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="VIP等级" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="VIP0" value="1" />
                            <el-option label="VIP1" value="2" />
                            <el-option label="VIP10" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="性别" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="男" value="1" />
                            <el-option label="女" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>
                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色昵称" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色等级" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>
                    <div class="item">
                        <el-input v-model="search.type" placeholder="邀请码" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" @change="toQuery" />
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="角色ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="角色名称" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="头像" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="性别" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="等级" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="VIP" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="邀请码" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="角色创建时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="最后一次登录时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="登录天数" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="每日在线时长" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="离线时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="总在线时间" />
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import { PAGE_SIZE } from '@/constant/common'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        DateRangePicker
    },
    mixins: [Base],
    data() {
        return {
            search: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery
        }
    },

    mounted() {
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        }
    }
}
</script>
