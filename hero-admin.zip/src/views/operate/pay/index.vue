<template>
    <div class="app-container" style="min-width: 1600px">
        <Report :data-obj="statData" @queryData="queryData" />
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="right">
                    <div class="item">
                        <el-select v-model="search.type" placeholder="全部渠道" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="渠道1" value="1" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="全部子渠道" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="子渠道1" value="1" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.type" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="订单状态" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="支付成功" value="1" />
                            <el-option label="支付中" value="2" />
                            <el-option label="支付失败" value="3" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="订单ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>
                    <div class="item">
                        <el-input v-model="search.type" placeholder="流水ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <el-input v-model="search.type" placeholder="角色ID" size="medium" style="width: 130px" @keyup.enter.native="toQuery" />
                    </div>

                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" start-placeholder="创建开始日期" end-placeholder="创建结束日期" style="width: 240px" @change="toQuery" />
                    </div>

                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" start-placeholder="支付开始日期" end-placeholder="支付结束日期" style="width: 240px" @change="toQuery" />
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="订单ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="支付流水ID" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="角色名称(ID)" />
                <el-table-column :show-overflow-tooltip="true" width="150" prop="username" align="center" label="创建时间" />
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="渠道" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="子渠道" />
                <el-table-column :show-overflow-tooltip="true" width="160" prop="createTime" align="center" label="区服" />
                <el-table-column :show-overflow-tooltip="true" width="160" prop="createTime" align="center" label="充值金额" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="实际充值金额" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="到账游戏币" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="支付时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="到账时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="支付状态">
                    <template slot-scope="scope">
                        <!--                        <el-tag type="danger">支付失败</el-tag>-->
                        <el-tag type="success">支付成功</el-tag>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import DateRangePicker from '@/components/DateRangePicker'
import Base from '@/views/base'
import { PAGE_SIZE } from '@/constant/common'
import Report from './report'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        DateRangePicker,
        Report
    },
    mixins: [Base],
    data() {
        return {
            search: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            statData: {}
        }
    },

    mounted() {
        this.toQuery()
    },
    methods: {
        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        //数据统计
        queryData(isCache = false) {},
        closeDrawer() {
            this.drawerVisible = false
        }
    }
}
</script>
