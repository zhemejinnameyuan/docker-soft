<template>
    <div class="mb-20 dp-f-center">
        <div class="item-box bg-container" style="width: 780px; height: 120px">
            <div class="content">
                <div class="dp-f-space-between">
                    <div class="top-title" style="width: 120px">充值到账</div>
                </div>
                <div class="dp-f ml-40 mt-20">
                    <div class="dp-f">
                        <div class="item-title">累计充值金额:</div>
                        <div class="item-number ml-10" style="width: 160px">{{ 12345678910.0 | filterThousandths }}</div>
                    </div>

                    <div class="dp-f ml-20">
                        <div class="item-title">实际到账游戏币:</div>
                        <div class="item-number ml-10" style="width: 160px">{{ 12345678910.0 | filterThousandths }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="item-box bg-container ml-20" style="width: 780px; height: 120px">
            <div class="content">
                <div class="dp-f-space-between">
                    <div class="top-title" style="width: 100px">充值订单数</div>
                </div>

                <div class="dp-f ml-40 mt-20">
                    <div class="dp-f">
                        <div class="item-title">总充值:</div>
                        <div class="item-number" style="width: 100px">{{ 123456 | filterThousandths }}</div>
                    </div>

                    <div class="vertical-split-line" style="height: 20px" />

                    <div class="dp-c ml-20">
                        <div class="dp-f">
                            <div class="item-title-min" style="font-size: 20px">成功:</div>
                            <div class="item-number-min ml-10 text-green" style="width: 100px">{{ 999999 | filterThousandths }}</div>
                        </div>
                        <span class="item-title-per mt-10">占比:20%</span>
                    </div>

                    <div class="dp-c ml-20">
                        <div class="dp-f">
                            <div class="item-title-min" style="font-size: 20px">失败:</div>
                            <div class="item-number-min ml-10 text-red" style="width: 100px">{{ 999999 | filterThousandths }}</div>
                        </div>
                        <span class="item-title-per mt-10">占比:80%</span>
                    </div>

                    <div class="vertical-split-line" style="height: 20px" />

                    <div class="dp-f ml-20">
                        <div class="item-title-min" style="font-size: 20px">支付中:</div>
                        <div class="item-number-min ml-10" style="width: 100px">{{ 999999 | filterThousandths }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import IconButton from '@/components/IconButton'
import Base from '@/views/base'

export default {
    mixins: [Base],
    components: {
        IconButton
    },
    props: {
        dataObj: {
            type: Object,
            default: function () {
                return null
            }
        }
    },
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            if (!this.loading) {
                this.$emit('queryData', true)
            }
            this.loading = true
            setTimeout(() => {
                this.loading = false
            }, 3000)
        }
    }
}
</script>

<style scoped lang="scss">
.item-title {
    font-family: PingFangSC-Regular;
    font-size: 24px;
    color: #292828;
    letter-spacing: 0;
    font-weight: 400;
}

.item-title-min {
    font-family: PingFangSC-Regular;
    font-size: 20px;
    color: #292828;
    letter-spacing: 0;
    font-weight: 400;
}

.item-number {
    font-family: PingFangSC-Medium;
    font-size: 24px;
    color: #f68915;
    letter-spacing: 0;
    font-weight: 500;
}

.item-number-min {
    font-family: PingFangSC-Medium;
    font-size: 20px;
    color: #06d298;
    letter-spacing: 0;
    font-weight: 500;
}

.top-title {
    border-radius: 4px 0px 8px 0px;
    height: 32px;
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #f68915;
    letter-spacing: 0;
    line-height: 32px;
    font-weight: 500;
    text-align: center;
    background: rgba(246, 137, 21, 0.12);
}

.item-title-per {
    width: 80px;
    padding: 0 10px 0 10px;
    background: #f7f6f5;
    border-radius: 10px;
    height: 22px;
    font-size: 12px;
    color: #686b6d;
    letter-spacing: 0;
    line-height: 22px;
    font-weight: 400;
    text-align: center;
}
</style>
