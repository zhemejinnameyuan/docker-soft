<template>
    <div class="app-container" style="min-width: 1560px">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium" @input="toQuery">
                    <el-radio-button label="device" style="width: 140px">设备留存</el-radio-button>
                    <el-radio-button label="account" style="width: 140px">账号留存</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <div class="bg-container">
            <div class="search-container mt-10 pt-20">
                <div class="left">
                    <div class="ml-20" style="margin-bottom: -20px">
                        <el-tabs v-model="retainType" @tab-click="retainTypeClick">
                            <el-tab-pane label="日留存" name="day"></el-tab-pane>
                            <el-tab-pane label="周留存" name="week"></el-tab-pane>
                            <el-tab-pane label="月留存" name="month"></el-tab-pane>
                        </el-tabs>
                    </div>
                </div>

                <div class="right">
                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" />
                    </div>

                    <div class="item">
                        <el-select v-model="search.terminal" placeholder="全部终端" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="iOS" value="1" />
                            <el-option label="安卓" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.channelId" placeholder="全部渠道" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="渠道1" value="1" />
                            <el-option label="渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.childChannelId" placeholder="全部子渠道" size="medium" style="width: 130px" clearable>
                            <el-option label="子渠道1" value="1" />
                            <el-option label="子渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.serviceId" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item mr-20">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>

            <div class="report-container" v-if="retainType === 'day'">
                <div class="items" style="width: 13%">
                    <div class="item">
                        <span class="title">设备新增</span>
                        <span class="number">1000</span>
                    </div>
                </div>
                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">次日留存</span>
                        <span class="number">
                            50%
                            <span class="text-gray">[500]</span>
                        </span>
                    </div>
                </div>
                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">3日留存</span>
                        <span class="number">
                            40%
                            <span class="text-gray">[400]</span>
                        </span>
                    </div>
                </div>
                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">7日留存</span>
                        <span class="number">
                            30%
                            <span class="text-gray">[300]</span>
                        </span>
                    </div>
                </div>
                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">15日留存</span>
                        <span class="number">
                            20%
                            <span class="text-gray">[200]</span>
                        </span>
                    </div>
                </div>
                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">30日留存</span>
                        <span class="number">
                            15%
                            <span class="text-gray">[150]</span>
                        </span>
                    </div>
                </div>

                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">60日留存</span>
                        <span class="number">
                            12%
                            <span class="text-gray">[120]</span>
                        </span>
                    </div>
                </div>

                <div class="items ml-10" style="width: 13%">
                    <div class="item">
                        <span class="title">90日留存</span>
                        <span class="number">
                            8%
                            <span class="text-gray">[80]</span>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!--        <div class="tool-bar mt-10">-->
        <!--            <el-tooltip class="item icon mr-10" effect="dark" content="导出Excel" placement="top">-->
        <!--                <svg-icon icon-class="oms_ico_download" @click="toDownload" />-->
        <!--            </el-tooltip>-->
        <!--        </div>-->

        <div class="table-container mt-10">
            <el-row>
                <el-col style="margin-bottom: 10px">
                    <el-table ref="table" class="report-table" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                        <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="日期" />

                        <!--日留存-->
                        <el-table-column key="day-0" prop="newCount" width="100" align="center" v-if="retainType === 'day'">
                            <template slot="header">
                                <span>
                                    当日新增
                                    <el-tooltip class="item" effect="dark" content="首次完成初始化的设备数。初始化后续统称为「打开」。卸载应用再安装的设备不会被算为新增设备" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-1" label="次日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-2" label="第2日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-3" label="第3日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-4" label="第4日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-5" label="第5日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-6" label="第6日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-7" label="第7日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-8" label="第8日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-9" label="第9日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-10" label="第10日" v-if="retainType === 'day'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>

                        <!--周留存-->
                        <el-table-column key="week-0" prop="newCount" width="100" align="center" v-if="retainType === 'week'">
                            <template slot="header">
                                <span>
                                    周新增
                                    <el-tooltip class="item" effect="dark" content="首次完成初始化的设备数。初始化后续统称为「打开」。卸载应用再安装的设备不会被算为新增设备" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-1" label="次周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-2" label="2周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-3" label="3周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-4" label="4周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-5" label="5周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-6" label="6周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-7" label="7周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-8" label="8周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-9" label="9周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-10" label="10周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-11" label="11周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-12" label="12周留存" v-if="retainType === 'week'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>

                        <!--月留存-->
                        <el-table-column key="month-0" prop="newCount" width="100" align="center" v-if="retainType === 'month'">
                            <template slot="header">
                                <span>
                                    月新增
                                    <el-tooltip class="item" effect="dark" content="首次完成初始化的设备数。初始化后续统称为「打开」。卸载应用再安装的设备不会被算为新增设备" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-1" label="次月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-2" label="2月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-3" label="3月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-4" label="4月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-5" label="5月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="month-6" label="6月留存" v-if="retainType === 'month'">
                            <template slot-scope="scope">
                                <span>100%</span>
                                <span class="text-gray">[{{ scope.row.newCount }}]</span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import { downloadExcelByElement } from '@/utils'

export default {
    name: 'RetainUser',
    components: {
        DateRangePicker
    },
    data() {
        return {
            type: 'device', //设备or账号 device/account
            search: {},
            loading: false,
            retainType: 'day',
            tableList: [
                {
                    date: '2023-06-20',
                    newCount: 50,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-19',
                    newCount: 50,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-18',
                    newCount: 50,
                    convertDevice: 10000
                }
            ]
        }
    },
    mounted() {},
    methods: {
        toQuery() {},
        retainTypeClick() {},

        toDownload() {
            downloadExcelByElement(document.querySelector('.report-table'), '留存统计')
        }
    }
}
</script>
<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
</style>
