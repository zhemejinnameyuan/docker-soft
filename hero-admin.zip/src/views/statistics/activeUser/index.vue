<template>
    <div class="app-container" style="min-width: 1560px">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium" @input="typeClick">
                    <el-radio-button label="device" style="width: 140px">设备活跃</el-radio-button>
                    <el-radio-button label="account" style="width: 140px">账号活跃</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <div class="chart-container mt-10">
            <div class="search-container">
                <div class="left">
                    <div style="margin-bottom: -20px">
                        <el-tabs v-model="activeType" @tab-click="activeTypeClick">
                            <el-tab-pane label="日活跃" name="day"></el-tab-pane>
                            <el-tab-pane label="周活跃" name="week"></el-tab-pane>
                            <el-tab-pane label="月活跃" name="month"></el-tab-pane>
                        </el-tabs>
                    </div>

                    <div class="ml-10 gray-type-select">
                        <el-select v-model="activeTypeOption" size="medium" style="width: 140px" @change="toQuery">
                            <el-option v-for="(item, index) in activeTypeOptionList[activeType]" :label="item" :value="index" :key="index" />
                        </el-select>
                    </div>
                </div>

                <div class="right">
                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" />
                    </div>

                    <div class="item">
                        <span class="text-gray fs-14 mr-10">VS</span>
                        <DateRangePicker v-model="search.diffDate" size="medium" style="width: 210px" />
                    </div>

                    <div class="item">
                        <el-select v-model="search.terminal" placeholder="全部终端" size="medium" style="width: 110px" @change="toQuery" clearable>
                            <el-option label="iOS" value="1" />
                            <el-option label="安卓" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.channelId" placeholder="全部渠道" size="medium" style="width: 110px" @change="toQuery" clearable>
                            <el-option label="渠道1" value="1" />
                            <el-option label="渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.childChannelId" placeholder="全部子渠道" size="medium" style="width: 120px" clearable>
                            <el-option label="子渠道1" value="1" />
                            <el-option label="子渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.serviceId" placeholder="全部区服" size="medium" style="width: 110px" @change="toQuery" clearable>
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>
            <div id="chart-container" style="margin-top: 20px; width: 100%; height: 360px"></div>
        </div>

        <div class="tool-bar mt-10">
            <el-tooltip class="item icon mr-10 ml-10" effect="dark" content="导出Excel" placement="top">
                <svg-icon icon-class="oms_ico_download" @click="toDownload" />
            </el-tooltip>
            <el-checkbox v-model="isShowPercentage" v-if="activeType !== 'month'">
                <span v-if="activeType === 'day'">显示DAU占比</span>
                <span v-if="activeType === 'week'">显示WAU占比</span>
            </el-checkbox>
        </div>
        <div class="table-container mt-10">
            <el-row>
                <el-col style="margin-bottom: 10px">
                    <el-table ref="table" class="report-table" v-if="showTable" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                        <el-table-column :show-overflow-tooltip="true" prop="date" align="center" label="日期" />
                        <el-table-column :show-overflow-tooltip="true" prop="date" align="center" label="活跃类型">
                            <template>
                                <span>{{ typeText }}活跃</span>
                            </template>
                        </el-table-column>

                        <!--日活跃-->
                        <el-table-column prop="type" align="center" key="day-1" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU({{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当日打开应用的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-2" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU(新{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当日首次打开应用的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-3" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU-2日{{ typeText }}
                                    <el-tooltip class="item" effect="dark" :content="'当日打开过应用且累计登录天数 >= 2 天的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-4" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU-3日{{ typeText }}
                                    <el-tooltip class="item" effect="dark" :content="'当日打开过应用且累计登录天数 >= 3 天的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-5" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU-7日{{ typeText }}
                                    <el-tooltip class="item" effect="dark" :content="'当日打开过应用且累计登录天数 >= 7 天的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-6" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU-14日{{ typeText }}
                                    <el-tooltip class="item" effect="dark" :content="'当日打开过应用且累计登录天数 >= 14 天的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="day-7" v-if="activeType === 'day'">
                            <template slot="header">
                                <span>
                                    DAU-30日{{ typeText }}
                                    <el-tooltip class="item" effect="dark" :content="'当日打开过应用且累计登录天数 >= 30 天的' + typeText + '数。'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占DAU 5.00%)</span>
                            </template>
                        </el-table-column>

                        <!--周活跃-->
                        <el-table-column prop="type" align="center" key="week-1" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU({{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周打开应用的' + typeText + '数，同一' + typeText + '的多次登录只计为 1'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-2" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU(新{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周首次打开应用的' + typeText + '数，同一' + typeText + '的多次登录只计为 1'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-3" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU(2周{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周打开过应用且累计登录天数 >= 2 周的' + typeText + '数'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-4" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU(3周{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周打开过应用且累计登录天数 >= 3 周的' + typeText + '数'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-5" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU(4周{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周打开过应用且累计登录天数 >= 4 周的' + typeText + '数'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="type" align="center" key="week-6" v-if="activeType === 'week'">
                            <template slot="header">
                                <span>
                                    WAU(5周{{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当周打开过应用且累计登录天数 >= 5 周的' + typeText + '数'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                                <span class="show_percentage" v-if="isShowPercentage">(占MAU 5.00%)</span>
                            </template>
                        </el-table-column>

                        <!--月活跃-->
                        <el-table-column prop="type" align="center" key="month-1" v-if="activeType === 'month'">
                            <template slot="header">
                                <span>
                                    MAU({{ typeText }})
                                    <el-tooltip class="item" effect="dark" :content="'当月打开过应用的' + typeText + '数，同一' + typeText + '在周期内的多次打开只记为  1'" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import * as echarts from 'echarts'
import DateRangePicker from '@/components/DateRangePicker'
import { createHourData, grandTotalData, downloadExcelByElement } from '@/utils'
export default {
    name: 'ActiveUser',
    components: {
        DateRangePicker
    },
    data() {
        return {
            type: 'device', //设备or账号 device/account
            typeText: '设备', //设备or账号
            activeType: 'day',
            activeTypeOption: '1',
            isShowPercentage: false, //显示占比
            activeTypeOptionList: {
                day: { 1: 'DAU(设备)', 2: 'DAU(新设备)', 3: 'DAU-2日设备', 4: 'DAU-3日设备', 5: 'DAU-7日设备', 6: 'DAU-14日设备', 7: 'DAU-30日设备' },
                week: { 1: 'WAU(设备)', 2: 'WAU(新设备)', 3: 'WAU-2周设备', 4: 'DAU-3周设备', 5: 'DAU-4周设备', 6: 'DAU-5周设备' },
                month: { 1: '月活跃(设备)' }
            },
            search: {},
            loading: false,
            showTable: true,
            chartContainer: '',
            chartType: 'line',
            tableList: [
                {
                    date: '2023-06-20',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-19',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-18',
                    newCount: 20000,
                    convertDevice: 10000
                }
            ]
        }
    },
    mounted() {
        this.initChart()
    },
    methods: {
        typeClick() {
            this.typeText = this.type === 'device' ? '设备' : '账号'
            this.refreshTable()
        },
        refreshTable: function () {
            let that = this
            that.showTable = false
            that.$nextTick(function () {
                that.showTable = true
            })
        },
        activeTypeClick() {
            this.activeTypeOption = '1'
            this.isShowPercentage = false
        },
        toQuery() {
            this.initChart(this.type)
        },
        toDownload() {
            downloadExcelByElement(document.querySelector('.report-table'), '活跃统计')
        },
        initChart(type) {
            const _that = this
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('chart-container'))
            }

            //默认数据处理
            let newUserData = [140, 152, 130, 110, 70, 65, 50, 85, 86, 62, 75, 78, 75, 82, 135, 158, 145, 172, 205, 170, 170, 262, 225, 228]

            let legendData = ['今日活跃']
            let colorData = ['#2EBFFF']
            let seriesData = [
                {
                    name: '今日活跃',
                    type: this.chartType,
                    barGap: '15%',
                    barWidth: '10',
                    data: newUserData
                }
            ]

            //对比数据处理
            if (this.search.diffDate) {
                let newUserDiffData = [125, 152, 130, 110, 70, 65, 50, 85, 86, 62, 75, 78, 75, 82, 135, 158, 145, 172, 205, 170, 170, 162, 125, 128]

                if (type === 'total') {
                    newUserDiffData = grandTotalData(newUserDiffData)
                }
                legendData = ['今日活跃', '对比活跃']
                colorData = ['#2EBFFF', '#FF8400']

                seriesData = [
                    {
                        name: '今日活跃',
                        type: this.chartType,
                        barGap: '15%',
                        barWidth: '10',
                        data: newUserData
                    },
                    {
                        name: '对比活跃',
                        type: this.chartType,
                        barGap: '15%',
                        barWidth: '10',
                        data: newUserDiffData
                    }
                ]
            }

            // 组装图表
            const xAxisData = createHourData()
            const option = {
                grid: {
                    top: '50',
                    left: '15',
                    right: '15',
                    bottom: '50',
                    containLabel: true
                },
                color: colorData,
                title: {
                    text: '日活跃',
                    textStyle: {
                        color: '#292828'
                    },
                    left: 'center',
                    top: '0'
                },
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        magicType: {
                            type: ['line', 'bar'],
                            title: {
                                bar: '切换为柱状图',
                                line: '切换为折线图'
                            }
                        }
                    }
                },
                legend: [
                    {
                        top: 'bottom',
                        data: legendData
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {
                    name: '人'
                },
                series: seriesData
            }
            this.chartContainer.setOption(option, true)

            // 监听点击切换图表事件
            this.chartContainer.on('magictypechanged', function (params) {
                _that.chartType = params.currentType
            })
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
.show_percentage {
    margin-left: 10px;
    font-size: 12px;
    color: gray;
}
</style>
