<template>
    <div class="app-container" style="min-width: 1560px">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium" @input="toQuery">
                    <el-radio-button label="device" style="width: 140px">设备付费</el-radio-button>
                    <el-radio-button label="account" style="width: 140px">账号付费</el-radio-button>
                    <el-radio-button label="userWorth" style="width: 140px">用户价值</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <div class="report-container" v-if="type !== 'userWorth'">
            <div class="items" style="width: 16%">
                <div class="item">
                    <span class="title">收入</span>
                    <span class="number">999</span>
                </div>
            </div>
            <div class="items ml-10" style="width: 16%">
                <div class="item">
                    <span class="title">付费人数</span>
                    <span class="number">999</span>
                </div>
            </div>
            <div class="items ml-10" style="width: 16%">
                <div class="item">
                    <span class="title">付费次数</span>
                    <span class="number">99</span>
                </div>
            </div>
            <div class="items ml-10" style="width: 16%">
                <div class="item">
                    <span class="title">付费率</span>
                    <span class="number">99%</span>
                </div>
            </div>
            <div class="items ml-10" style="width: 16%">
                <div class="item">
                    <span class="title">ARPU</span>
                    <span class="number">999.00</span>
                </div>
            </div>
            <div class="items ml-10" style="width: 16%">
                <div class="item">
                    <span class="title">ARPPU</span>
                    <span class="number">999.00</span>
                </div>
            </div>
        </div>

        <div class="chart-container mt-10">
            <div class="search-container">
                <div class="left" v-if="type !== 'userWorth'">
                    <div class="mr-20 fs-16" style="font-weight: 500">主纬度:</div>
                    <div style="margin-bottom: -20px">
                        <el-tabs v-model="payType" @tab-click="payTypeClick">
                            <el-tab-pane label="日期" name="date"></el-tab-pane>
                            <el-tab-pane label="商品" name="goods"></el-tab-pane>
                        </el-tabs>
                    </div>

                    <div class="ml-10 gray-type-select">
                        <el-select v-model="payTypeOption" size="medium" style="width: 140px" @change="toQuery">
                            <el-option v-for="(item, index) in payTypeOptionList[payType]" :label="item" :value="index" :key="index" />
                        </el-select>
                    </div>
                </div>

                <div class="right">
                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" />
                    </div>
                    <div class="item">
                        <el-select v-model="search.terminal" placeholder="全部终端" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="iOS" value="1" />
                            <el-option label="安卓" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.channelId" placeholder="全部渠道" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="渠道1" value="1" />
                            <el-option label="渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.childChannelId" placeholder="全部子渠道" size="medium" style="width: 130px" clearable>
                            <el-option label="子渠道1" value="1" />
                            <el-option label="子渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.serviceId" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>

            <div id="chart-container" style="margin-top: 20px; width: 100%; height: 360px"></div>
        </div>

        <!--        <div class="tool-bar mt-10">-->
        <!--            <el-tooltip class="item icon mr-10" effect="dark" content="导出Excel" placement="top">-->
        <!--                <svg-icon icon-class="oms_ico_download" @click="toDownload" />-->
        <!--            </el-tooltip>-->
        <!--        </div>-->

        <div class="table-container mt-10">
            <el-row>
                <el-col style="margin-bottom: 10px">
                    <!--设备付费和账号付费-->
                    <el-table ref="table" class="report-table" v-if="type !== 'userWorth'" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                        <!--设备和账号 日期维度-->
                        <el-table-column key="date-0" prop="date" align="center" label="日期" v-if="payType === 'date'" />
                        <el-table-column key="date-1" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    收入
                                    <el-tooltip class="item" effect="dark" content="玩家的付费总金额。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="date-2" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    付费人数
                                    <el-tooltip class="item" effect="dark" content="有付费行为的去重设备数量。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="date-3" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    付费次数
                                    <el-tooltip class="item" effect="dark" content="付费行为的总次数。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="date-4" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    付费率
                                    <el-tooltip class="item" effect="dark" content="付费账号占整体设备的比例。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="date-5" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    ARPU
                                    <el-tooltip class="item" effect="dark" content="平均每个设备的收入。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="date-6" align="center" v-if="payType === 'date'">
                            <template slot="header">
                                <span>
                                    ARPPU
                                    <el-tooltip class="item" effect="dark" content="平均每个付费设备的收入。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>

                        <!--设备和账号 商品维度-->
                        <el-table-column key="goods-0" align="center" v-if="payType === 'goods'">
                            <template slot="header">
                                <span>
                                    商品名称
                                    <el-tooltip class="item" effect="dark" content="商品的名称。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="goods-1" align="center" v-if="payType === 'goods'">
                            <template slot="header">
                                <span>
                                    商品收入
                                    <el-tooltip class="item" effect="dark" content="玩家的付费总金额。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column key="goods-2" align="center" v-if="payType === 'goods'">
                            <template slot="header">
                                <span>
                                    付费次数
                                    <el-tooltip class="item" effect="dark" content="付费行为的总次数。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                    </el-table>

                    <!--用户价值-->
                    <el-table ref="table" class="report-table" v-if="type === 'userWorth'" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                        <el-table-column prop="date" align="center" width="120" label="日期" />
                        <el-table-column prop="newCount" align="center" width="120" label="新增设备" />
                        <el-table-column align="center" width="120">
                            <template slot="header">
                                <span>
                                    1日贡献
                                    <el-tooltip class="item" effect="dark" content="某日新增设备中，平均每个设备在 1 日内（即当日）的付费金额。" placement="top">
                                        <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                    </el-tooltip>
                                </span>
                            </template>
                            <template slot-scope="scope">
                                <span>{{ scope.row.newCount }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="newCount" align="center" label="2日贡献" />
                        <el-table-column prop="newCount" align="center" label="3日贡献" />
                        <el-table-column prop="newCount" align="center" label="4日贡献" />
                        <el-table-column prop="newCount" align="center" label="5日贡献" />
                        <el-table-column prop="newCount" align="center" label="6日贡献" />
                        <el-table-column prop="newCount" align="center" label="7日贡献" />
                        <el-table-column prop="newCount" align="center" label="8日贡献" />
                        <el-table-column prop="newCount" align="center" label="9日贡献" />
                        <el-table-column prop="newCount" align="center" label="10日贡献" />
                        <el-table-column prop="newCount" align="center" label="11日贡献" />
                        <el-table-column prop="newCount" align="center" label="12日贡献" />
                        <el-table-column prop="newCount" align="center" label="13日贡献" />
                        <el-table-column prop="newCount" align="center" label="14日贡献" />
                        <el-table-column prop="newCount" align="center" label="15日贡献" />
                        <el-table-column prop="newCount" align="center" label="30日贡献" />
                        <el-table-column prop="newCount" align="center" label="60日贡献" />
                        <el-table-column prop="newCount" align="center" label="90日贡献" />
                        <el-table-column prop="newCount" align="center" label="120日贡献" />
                        <el-table-column prop="newCount" align="center" label="150日贡献" />
                        <el-table-column prop="newCount" align="center" label="180日贡献" />
                        <el-table-column prop="newCount" align="center" label="360日贡献" />
                    </el-table>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import * as echarts from 'echarts'
import DateRangePicker from '@/components/DateRangePicker'
import { createHourData, downloadExcelByElement } from '@/utils'

export default {
    name: 'PayUser',
    components: {
        DateRangePicker
    },
    data() {
        return {
            dateOne: '',
            diffDate: '',
            type: 'device', //设备or账号 device/account
            payType: 'date',
            payTypeOption: '1',
            isShowPercentage: false, //显示占比
            payTypeOptionList: {
                date: { 1: '收入', 2: '付费人数', 3: '付费次数', 4: '付费率', 5: 'ARPU', 6: 'ARPPU' },
                goods: { 1: '收入', 2: '付费次数' }
            },
            search: {},
            loading: false,
            chartContainer: '',
            chartType: 'line',
            tableList: [
                {
                    date: '2023-06-20',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-19',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-18',
                    newCount: 20000,
                    convertDevice: 10000
                }
            ]
        }
    },
    mounted() {
        this.initChart()
    },
    methods: {
        toQuery() {
            this.initChart()
        },
        payTypeClick() {
            this.payTypeOption = '1'
            this.initChart()
        },
        toDownload() {
            downloadExcelByElement(document.querySelector('.report-table'), '付费统计')
        },
        initChart() {
            const _that = this
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('chart-container'))
            }

            switch (this.type) {
                case 'device':
                case 'account':
                    //设备付费+账号付费
                    if (this.payType === 'date') {
                        //日期
                        this.deviceAccountDateChart()
                    } else {
                        //商品
                        this.deviceAccountGoodsChartBar()
                    }
                    break
                case 'userWorth':
                    //用户价值付费
                    this.userWorthChart()
                    break
            }
            // 监听点击切换图表事件
            this.chartContainer.on('magictypechanged', function (params) {
                _that.chartType = params.currentType
            })
        },
        //设备付费+账号付费(日期)
        deviceAccountDateChart() {
            //默认数据处理
            let dataObj = [120, 122, 110, 120, 110, 165, 150, 185, 186, 162, 175, 178, 175, 182, 135, 158, 145, 172, 205, 170, 170, 262, 125, 128]

            let title = this.payTypeOptionList[this.payType][this.payTypeOption]

            let legendData = [title]
            let colorData = ['#2EBFFF']
            let seriesData = [
                {
                    name: title,
                    type: this.chartType,
                    barGap: '15%',
                    barWidth: '10',
                    data: dataObj
                }
            ]

            // 组装图表
            const xAxisData = createHourData()
            const option = {
                grid: {
                    top: '50',
                    left: '15',
                    right: '15',
                    bottom: '50',
                    containLabel: true
                },
                color: colorData,
                title: {
                    text: title,
                    textStyle: {
                        color: '#292828'
                    },
                    left: 'center',
                    top: '0'
                },
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        magicType: {
                            type: ['line', 'bar'],
                            title: {
                                bar: '切换为柱状图',
                                line: '切换为折线图'
                            }
                        }
                    }
                },
                legend: [
                    {
                        top: 'bottom',
                        data: legendData
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {},
                series: seriesData
            }

            this.chartContainer.setOption(option, true)
        },
        //设备付费+账号付费(商品)-横向柱状
        deviceAccountGoodsChartBar() {
            const that = this
            //默认数据处理
            let dataObj = [120, 122, 110, 120, 223]

            let title = this.payTypeOptionList[this.payType][this.payTypeOption]

            let colorData = ['#2EBFFF']
            let seriesData = [
                {
                    name: title,
                    type: 'bar',
                    radius: '50%',
                    barGap: '15%',
                    barWidth: '10',
                    data: dataObj
                }
            ]

            // 组装图表
            const option = {
                grid: {
                    top: '50',
                    left: '15',
                    right: '15',
                    bottom: '50',
                    containLabel: true
                },
                color: colorData,
                title: {
                    text: title,
                    textStyle: {
                        color: '#292828'
                    },
                    left: 'center',
                    top: '0'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                toolbox: {
                    show: true,
                    feature: {
                        myBar: {
                            show: true,
                            title: '切换为柱状图',
                            icon: 'path://M6.7,22.9h10V48h-10V22.9zM24.9,13h10v35h-10V13zM43.2,2h10v46h-10V2zM3.1,58h53.7',
                            onclick: function () {
                                that.deviceAccountGoodsChartBar()
                            }
                        },
                        myPie: {
                            show: true,
                            title: '切换为饼状图',
                            icon: 'path://M512 98.304C282.624 98.304 98.304 282.624 98.304 512s184.32 413.696 413.696 413.696c229.376 0 413.696-184.32 413.696-413.696S741.376 98.304 512 98.304zM888.832 491.52l-331.776 0 233.472-233.472C847.872 323.584 884.736 401.408 888.832 491.52zM512 888.832c-208.896 0-376.832-167.936-376.832-376.832 0-208.896 167.936-376.832 376.832-376.832 98.304 0 184.32 36.864 253.952 98.304l-266.24 266.24c-4.096 4.096-4.096 8.192-4.096 12.288 0 12.288 8.192 20.48 20.48 20.48l376.832 0C876.544 729.088 712.704 888.832 512 888.832z',
                            onclick: function () {
                                that.deviceAccountGoodsChartPie()
                            }
                        }
                    }
                },
                xAxis: {
                    type: 'value'
                },
                yAxis: {
                    type: 'category',
                    data: ['com.hero.one', 'com.hero.two', 'com.hero.three', 'com.hero.four', 'com.hero.five']
                },
                series: seriesData
            }

            this.chartContainer.setOption(option, true)
        },
        //设备付费+账号付费(商品)-饼状
        deviceAccountGoodsChartPie() {
            const that = this
            //默认数据处理
            let dataObj = [
                { value: 1048, name: 'com.hero.one' },
                { value: 735, name: 'com.hero.two' },
                { value: 580, name: 'com.hero.three' },
                { value: 484, name: 'com.hero.four' },
                { value: 300, name: 'com.hero.five' }
            ]

            let title = this.payTypeOptionList[this.payType][this.payTypeOption]

            let seriesData = [
                {
                    name: title,
                    type: 'pie',
                    radius: '50%',
                    data: dataObj
                }
            ]

            // 组装图表
            const option = {
                grid: {
                    top: '50',
                    left: '15',
                    right: '15',
                    bottom: '50',
                    containLabel: true
                },
                toolbox: {
                    show: true,
                    feature: {
                        myBar: {
                            show: true,
                            title: '切换为柱状图',
                            icon: 'path://M6.7,22.9h10V48h-10V22.9zM24.9,13h10v35h-10V13zM43.2,2h10v46h-10V2zM3.1,58h53.7',
                            onclick: function () {
                                that.deviceAccountGoodsChartBar()
                            }
                        },
                        myPie: {
                            show: true,
                            title: '切换为饼状图',
                            icon: 'path://M512 98.304C282.624 98.304 98.304 282.624 98.304 512s184.32 413.696 413.696 413.696c229.376 0 413.696-184.32 413.696-413.696S741.376 98.304 512 98.304zM888.832 491.52l-331.776 0 233.472-233.472C847.872 323.584 884.736 401.408 888.832 491.52zM512 888.832c-208.896 0-376.832-167.936-376.832-376.832 0-208.896 167.936-376.832 376.832-376.832 98.304 0 184.32 36.864 253.952 98.304l-266.24 266.24c-4.096 4.096-4.096 8.192-4.096 12.288 0 12.288 8.192 20.48 20.48 20.48l376.832 0C876.544 729.088 712.704 888.832 512 888.832z',
                            onclick: function () {
                                that.deviceAccountGoodsChartPie()
                            }
                        }
                    }
                },
                title: {
                    text: title,
                    textStyle: {
                        color: '#292828'
                    },
                    left: 'center',
                    top: '0'
                },
                tooltip: {
                    trigger: 'item'
                },

                series: seriesData
            }

            this.chartContainer.setOption(option, true)
        },
        //图表-用户价值
        userWorthChart() {
            //默认数据处理
            let dataObj = [110, 112, 120, 130, 170, 165, 150, 185, 186, 612, 175, 178, 175, 182, 235, 258, 245, 272, 305, 270, 170, 262]

            let legendData = ['贡献']
            let colorData = ['#2EBFFF']
            let seriesData = [
                {
                    name: '贡献',
                    type: this.chartType,
                    barGap: '15%',
                    barWidth: '10',
                    data: dataObj
                }
            ]

            // 组装图表
            const xAxisData = [
                '1日贡献',
                '2日贡献',
                '3日贡献',
                '4日贡献',
                '5日贡献',
                '6日贡献',
                '7日贡献',
                '8日贡献',
                '9日贡献',
                '10日贡献',
                '11日贡献',
                '12日贡献',
                '13日贡献',
                '14日贡献',
                '15日贡献',
                '30日贡献',
                '60日贡献',
                '90日贡献',
                '120日贡献',
                '150日贡献',
                '180日贡献',
                '360日贡献'
            ]
            const option = {
                grid: {
                    top: '50',
                    left: '15',
                    right: '15',
                    bottom: '50',
                    containLabel: true
                },
                color: colorData,
                title: {
                    text: '用户价值',
                    textStyle: {
                        color: '#292828'
                    },
                    left: 'center',
                    top: '0'
                },
                tooltip: {},
                toolbox: {
                    show: true,
                    feature: {
                        magicType: {
                            type: ['line', 'bar'],
                            title: {
                                bar: '切换为柱状图',
                                line: '切换为折线图'
                            }
                        }
                    }
                },
                legend: [
                    {
                        top: 'bottom',
                        data: legendData
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {
                    name: '贡献'
                },
                series: seriesData
            }

            this.chart.setOption(option, true)
        }
    }
}
</script>
<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
</style>
