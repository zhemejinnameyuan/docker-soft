<template>
    <div class="app-container">
        <div class="select-tab-container">
            <div>
                <el-radio-group v-model="type" size="medium" @input="toQuery">
                    <el-radio-button label="new" style="width: 140px">新增活跃留存统计</el-radio-button>
                    <el-radio-button label="income" style="width: 140px">收入统计</el-radio-button>
                </el-radio-group>
            </div>
        </div>

        <div class="bg-container">
            <div class="search-container p-20">
                <div class="right">
                    <div class="item">
                        <DateRangePicker v-model="search.date" size="medium" style="width: 210px" />
                    </div>

                    <div class="item">
                        <el-select v-model="search.type" placeholder="类型" size="medium" style="width: 130px" @change="toQuery">
                            <el-option label="设备" value="1" />
                            <el-option label="账号" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.terminal" placeholder="全部终端" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="iOS" value="1" />
                            <el-option label="安卓" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.channelId" placeholder="全部渠道" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="渠道1" value="1" />
                            <el-option label="渠道2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <el-select v-model="search.childChannelId" placeholder="全部子渠道" size="medium" style="width: 130px" clearable>
                            <el-option label="子渠道1" value="1" />
                            <el-option label="子渠道2" value="2" />
                        </el-select>
                    </div>
                    <div class="item">
                        <el-select v-model="search.serviceId" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery" clearable>
                            <el-option label="区服1" value="1" />
                            <el-option label="区服2" value="2" />
                        </el-select>
                    </div>

                    <div class="item">
                        <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                    </div>
                </div>
            </div>

            <!--            <div class="tool-bar">-->
            <!--                <el-tooltip class="item icon mr-10" effect="dark" content="导出Excel" placement="top">-->
            <!--                    <svg-icon icon-class="oms_ico_download" @click="toDownload" />-->
            <!--                </el-tooltip>-->
            <!--            </div>-->

            <div class="table-container mt-10">
                <el-row>
                    <el-col style="margin-bottom: 10px">
                        <el-table ref="table" class="report-table" v-if="type === 'new'" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="日期" />
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="渠道名称(ID)" />
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="子渠道名称(ID)" />
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" width="100" align="center">
                                <template slot="header">
                                    <span>
                                        新增设备
                                        <el-tooltip class="item" effect="dark" content="首次完成 初始化的设备数。初始化后续统称为「打开」。卸载应用再安装的设备不会被算为新增设备。" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" width="100" align="center">
                                <template slot="header">
                                    <span>
                                        设备活跃
                                        <el-tooltip class="item" effect="dark" content="当日打开应用的设备数。" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="次日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="2日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="3日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="4日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="5日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="6日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="7日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="15日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="30日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="60日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                            <el-table-column width="120" prop="date" align="center" label="90日留存">
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}%</span>
                                </template>
                            </el-table-column>
                        </el-table>

                        <el-table ref="table" class="report-table" v-if="type === 'income'" v-loading="loading" highlight-current-row style="width: 100%" :data="tableList">
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="日期" />
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="渠道名称(ID)" />
                            <el-table-column :show-overflow-tooltip="true" width="120" prop="date" align="center" label="子渠道名称(ID)" />
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        充值人数/新增充值人数
                                        <el-tooltip class="item" effect="dark" content="有付费行为的去重账号数量。/有付费行为的去重新设备数量。" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        收入/新增收入
                                        <el-tooltip class="item" effect="dark" content="当天玩家付费总金额/当天新增玩家的付费金额。" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        付费率/新设备/老设备
                                        <el-tooltip class="item" effect="dark" content="付费设备占整体设备的比例/新付费设备占整体设备的比例/老付费设备占整体设备的比例" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        ARPU
                                        <el-tooltip class="item" effect="dark" content="平均每个设备的收入" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>

                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        ARPPU
                                        <el-tooltip class="item" effect="dark" content="平均每个付费设备的收入" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>

                            <el-table-column :show-overflow-tooltip="true" prop="newCount" align="center">
                                <template slot="header">
                                    <span>
                                        累计收入
                                        <el-tooltip class="item" effect="dark" content="从首日截至目前的付费总金额。" placement="top">
                                            <IconButton class="refresh" size="medium" type="text" style="font-size: 13px; margin-left: 2px" icon="oms_ico_query" />
                                        </el-tooltip>
                                    </span>
                                </template>
                                <template slot-scope="scope">
                                    <span>{{ scope.row.newCount }}</span>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>

                <!--分页组件-->
                <Pagination v-if="total" :page-sizes="[10, 20, 50]" :query="search" :total="total" @pageChangeHandler="toQuery(true)" />
            </div>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import Pagination from '@/components/Pagination'
import { downloadExcelByElement } from '@/utils'
export default {
    name: 'Package',
    components: {
        DateRangePicker,
        Pagination
    },
    data() {
        return {
            type: 'new',
            search: {
                page: 1,
                size: 10,
                sort: 'id;desc',
                all: false
            },
            loading: false,
            chart: '',
            chartType: 'line',
            total: 20,
            tableList: [
                {
                    date: '2023-06-20',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-19',
                    newCount: 20000,
                    convertDevice: 10000
                },
                {
                    date: '2023-06-18',
                    newCount: 20000,
                    convertDevice: 10000
                }
            ]
        }
    },
    mounted() {},
    methods: {
        toQuery() {},
        toDownload() {
            downloadExcelByElement(document.querySelector('.report-table'), '子渠道统计')
        }
    }
}
</script>
<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
</style>
