<template>
    <div :class="isFull ? 'chart-panel is-full' : 'chart-panel'" v-loading="loading">
        <div class="head-bar">
            <div class="left">
                <div class="mr-20">
                    <span class="title">实时新增人数</span>
                </div>
                <div class="select-item">
                    <el-select v-model="search.type" size="mini" placeholder="" @change="toQuery">
                        <el-option label="小时" value="hour"></el-option>
                    </el-select>
                </div>

                <div class="ml-10">
                    <DateRangePicker v-model="search.date" style="width: 210px" @change="toQuery" :clearable="false" />
                </div>
                <div class="ml-10">
                    <label class="text-gray fs-12 mr-10">VS</label>
                    <DateRangePicker v-model="search.comparedDate" style="width: 210px" @change="toQuery" />
                </div>
            </div>
            <div class="right">
                <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                    <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" :content="isFull ? '还原' : '放大'" placement="top">
                    <svg-icon icon-class="oms_ico_quanping" @click="showFull" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" content="导出Excel" placement="top">
                    <svg-icon icon-class="oms_ico_download" @click="downloadExcel" />
                </el-tooltip>
            </div>
        </div>

        <div class="data-content mt-10">
            <div class="data-report" v-if="!isFull">
                <div class="dp-f mt-20">
                    <div class="update-time-pre-line" style="background: #0cc2ee"></div>
                    <span class="update-time">2023-06-29 16:00:02</span>
                </div>

                <div class="dp-c ml-20">
                    <div class="mt-10">
                        <span class="big-number" style="color: #0cc2ee">35,000</span>
                    </div>

                    <div class="dp-c mt-20">
                        <span class="title">最大值</span>
                        <span class="number mt-10">640</span>
                    </div>

                    <div class="dp-c mt-20">
                        <span class="title">均值</span>
                        <span class="number mt-10">320</span>
                    </div>
                </div>
            </div>

            <div class="data-chart ml-20">
                <div class="dp-f-reverse mb-10" style="margin-top: -10px">
                    <el-tooltip effect="dark" :content="showType === 'chart' ? '切换表格' : '切换趋势图'" placement="top">
                        <div class="change-type-text" @click="changeShowType">
                            {{ showType === 'chart' ? '表格' : '趋势图' }}
                        </div>
                    </el-tooltip>

                    <el-tooltip class="icon mr-20" effect="dark" :content="chartShowLabel ? '隐藏数值' : '显示数值'" placement="top" v-if="showType === 'chart'">
                        <svg-icon :icon-class="chartShowLabel ? 'oms_ico_yingcang' : 'oms_ico_xianshi'" @click="changeShowLabel" />
                    </el-tooltip>
                </div>

                <div id="new-chart-container" :class="isFull ? 'data-chart-container-full' : 'data-chart-container'" v-show="showType === 'chart'"></div>

                <div v-show="showType === 'table'">
                    <el-table class="chart-report-table" :data="tableData" border style="width: 100%" max-height="280">
                        <el-table-column prop="date" align="center" sortable label="日期" width="180" />
                        <el-table-column prop="count" align="center" sortable label="实时在线人数" />
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import * as echarts from 'echarts'
import { createHourData, downloadExcel } from '@/utils'
export default {
    name: 'RealtimeNew',
    components: {
        DateRangePicker
    },
    props: {
        isFull: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            chartContainer: '', //图表容器
            showType: 'chart', //图表或表格 chart/table
            chartShowLabel: false, //图表:是否显示数值
            search: {
                type: 'hour',
                date: [],
                comparedDate: []
            },
            loading: false,
            tableData: [
                {
                    date: '2023-06-01 00:00',
                    count: 10
                },
                {
                    date: '2023-06-01 01:00',
                    count: 20
                },
                {
                    date: '2023-06-01 02:00',
                    count: 15
                },
                {
                    date: '2023-06-01 03:00',
                    count: 25
                },
                {
                    date: '2023-06-01 04:00',
                    count: 25
                },
                {
                    date: '2023-06-01 05:00',
                    count: 25
                },
                {
                    date: '2023-06-01 06:00',
                    count: 25
                },
                {
                    date: '2023-06-01 07:00',
                    count: 25
                }
            ]
        }
    },
    mounted() {
        this.search.date.push(this.$moment().format('YYYY-MM-DD 00:00:00'))
        this.search.date.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.initChart()
    },
    methods: {
        showFull() {
            this.$emit('showFullCallBack', !this.isFull, 'realtimeNew')
        },
        toQuery() {
            this.loading = true

            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        },
        //切换表格/图表
        changeShowType() {
            this.showType = this.showType === 'chart' ? 'table' : 'chart'
        },
        //切换数值显示
        changeShowLabel() {
            this.chartShowLabel = !this.chartShowLabel
            this.initChart()
        },
        //导出数据
        downloadExcel() {
            const header = ['date', 'count']
            const headerZh = {
                date: '日期',
                count: '实时新增人数'
            }
            downloadExcel(header, headerZh, this.tableData, '实时新增人数')
        },
        resizeChart() {
            this.chartContainer && this.chartContainer.resize()
        },
        initChart() {
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('new-chart-container'))
            }

            //默认数据处理
            let data = [140, 152, 130, 110, 70, 65, 50, 85, 86, 62, 75, 78, 75, 82, 135, 158, 145, 172, 205, 170, 170, 262, 225, 228]

            let legendData = ['新增']
            let colorData = ['#0CC2EE']
            let seriesData = [
                {
                    name: '新增',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: data
                }
            ]

            // 组装图表
            const xAxisData = createHourData()
            const option = {
                grid: {
                    top: '30',
                    left: '15',
                    right: '15',
                    bottom: '35',
                    containLabel: true
                },
                color: colorData,
                tooltip: {
                    show: true,
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgb(229,229,231,0.4)'
                        }
                    }
                },

                legend: [
                    {
                        top: 'bottom',
                        data: legendData
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {
                    name: '人',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed'
                        }
                    }
                },
                series: seriesData
            }
            this.chartContainer.setOption(option, true)
        }
    }
}
</script>
<style scoped lang="scss">
@import '~@/assets/styles/realtime.scss';
</style>
