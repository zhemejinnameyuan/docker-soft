<template>
    <div class="report-panel" v-loading="loading">
        <div class="top">
            <div>
                <span class="title">实时数据</span>
            </div>

            <div class="dp-f">
                <div class="ml-10">
                    <el-select v-model="search.terminal" placeholder="全部终端" size="medium" style="width: 130px" @change="toQuery" clearable>
                        <el-option label="iOS" value="1" />
                        <el-option label="安卓" value="2" />
                    </el-select>
                </div>

                <div class="ml-10">
                    <el-select v-model="search.channelId" placeholder="全部渠道" size="medium" style="width: 130px" @change="toQuery" clearable>
                        <el-option label="渠道1" value="1" />
                        <el-option label="渠道2" value="2" />
                    </el-select>
                </div>
                <div class="ml-10">
                    <el-select v-model="search.childChannelId" placeholder="全部子渠道" size="medium" style="width: 130px" clearable>
                        <el-option label="子渠道1" value="1" />
                        <el-option label="子渠道2" value="2" />
                    </el-select>
                </div>
                <div class="ml-10">
                    <el-select v-model="search.serviceId" placeholder="全部区服" size="medium" style="width: 130px" @change="toQuery" clearable>
                        <el-option label="区服1" value="1" />
                        <el-option label="区服2" value="2" />
                    </el-select>
                </div>

                <div class="ml-10">
                    <IconButton size="mini" style="height: 40px" type="warning" icon="oms_ico_search" @click="toQuery" />
                </div>
            </div>
        </div>
        <div class="split-line"></div>

        <div class="report">
            <div class="items" style="background: rgba(21, 202, 246, 0.08)">
                <div class="item">
                    <div class="item-title">今日新增人数</div>
                    <div class="item-week ml-20">2023-06-27(二)</div>
                </div>

                <div class="item dp-f-baseline" style="margin-top: 26px">
                    <div class="item-number">999</div>
                    <div class="item-number-title">人</div>
                </div>
                <div class="item" style="margin-top: 15px">
                    <div class="ratio">
                        <div class="ratio-title">日环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                            <span :class="getPercentageColor(2000, 500)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 500) }}</span>
                        </div>
                    </div>
                    <div class="ratio ml-30">
                        <div class="ratio-title">周环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                            <span :class="getPercentageColor(2000, 500)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 500) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="items ml-20" style="background: rgba(21, 246, 83, 0.08)">
                <div class="item">
                    <div class="item-title">今日活跃人数</div>
                    <div class="item-week ml-20">2023-06-27(二)</div>
                </div>

                <div class="item dp-f-baseline" style="margin-top: 26px">
                    <div class="item-number" style="color: #10d54d">999</div>
                    <div class="item-number-title">人</div>
                </div>
                <div class="item" style="margin-top: 15px">
                    <div class="ratio">
                        <div class="ratio-title">日环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                            <span :class="getPercentageColor(2000, 500)" style="margin-top: 7px">{{ getPercentageRatio(2000, 500) }}</span>
                        </div>
                    </div>
                    <div class="ratio ml-30">
                        <div class="ratio-title">周环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 5000)" :icon-class="getPercentageIcon(2000, 5000)" />
                            <span :class="getPercentageColor(2000, 5000)" style="margin-top: 7px">{{ getPercentageRatio(2000, 5000) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="items ml-20" style="background: rgba(246, 146, 21, 0.08)">
                <div class="item">
                    <div class="item-title">今日付费人数</div>
                    <div class="item-week ml-20">2023-06-27(二)</div>
                </div>

                <div class="item dp-f-baseline" style="margin-top: 26px">
                    <div class="item-number" style="color: #f68915">999</div>
                    <div class="item-number-title">人</div>
                </div>
                <div class="item" style="margin-top: 15px">
                    <div class="ratio">
                        <div class="ratio-title">日环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                            <span :class="getPercentageColor(2000, 500)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 500) }}</span>
                        </div>
                    </div>
                    <div class="ratio ml-30">
                        <div class="ratio-title">周环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 5000)" :icon-class="getPercentageIcon(2000, 5000)" />
                            <span :class="getPercentageColor(2000, 5000)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 5000) }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="items ml-20" style="background: rgba(246, 48, 21, 0.08)">
                <div class="item">
                    <div class="item-title">今日付费金额</div>
                    <div class="item-week ml-20">2023-06-27(二)</div>
                </div>

                <div class="item dp-f-baseline" style="margin-top: 26px">
                    <div class="item-number" style="color: #f2260a">999,999.00</div>
                    <div class="item-number-title"></div>
                </div>
                <div class="item" style="margin-top: 15px">
                    <div class="ratio">
                        <div class="ratio-title">日环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                            <span :class="getPercentageColor(2000, 500)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 500) }}</span>
                        </div>
                    </div>
                    <div class="ratio ml-30">
                        <div class="ratio-title">周环比</div>
                        <div class="ring-ratio ml-10">
                            <svg-icon v-if="getPercentageIcon(2000, 5000)" :icon-class="getPercentageIcon(2000, 5000)" />
                            <span :class="getPercentageColor(2000, 5000)" style="margin-top: 7px; font-size: 14px">{{ getPercentageRatio(2000, 5000) }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
export default {
    name: 'Report',
    mixins: [Base],
    data() {
        return {
            loading: false,
            search: {}
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        }
    }
}
</script>

<style scoped lang="scss">
.report-panel {
    height: 290px;
    width: 100%;
    background: #ffffff;
    box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.1);
    border-radius: 4px;

    .top {
        height: 76px;
        padding: 20px 40px 20px 20px;

        display: flex;
        justify-content: space-between;
        align-items: center;
        .title {
            font-family: PingFangSC-Medium;
            font-size: 20px;
            color: #292828;
            font-weight: 500;
        }
    }

    .report {
        height: 210px;
        padding: 30px 40px 30px 40px;
        display: flex;
        align-items: center;
        //justify-content: space-between;

        .items {
            //width: 360px;
            width: 24%;
            height: 150px;
            padding: 24px 30px 24px 30px;
            border-radius: 4px;

            .item {
                display: flex;

                &-title {
                    font-family: PingFangSC-Medium;
                    font-size: 18px;
                    color: #292828;
                    letter-spacing: 0;
                    line-height: 18px;
                    font-weight: 500;
                }

                &-week {
                    font-family: PingFangSC-Regular;
                    font-size: 14px;
                    color: #6f6c65;
                    letter-spacing: 0;
                    line-height: 14px;
                    font-weight: 400;
                }

                &-number {
                    font-family: PingFangSC-Medium;
                    font-size: 36px;
                    color: #0cc2ee;
                    letter-spacing: 0;
                    line-height: 30px;
                    font-weight: 500;
                }

                &-number-title {
                    font-family: PingFangSC-Regular;
                    font-size: 14px;
                    color: #292828;
                    letter-spacing: 0;
                    line-height: 14px;
                    font-weight: 400;
                    margin-left: 4px;
                }

                .ratio {
                    display: flex;
                    align-items: center;
                    justify-items: baseline;

                    &-title {
                        font-family: PingFangSC-Regular;
                        font-size: 14px;
                        color: #6f6c65;
                        letter-spacing: 0;
                        line-height: 14px;
                        font-weight: 400;
                    }
                }
            }
        }

        .items:hover {
            box-shadow: 0 0 20px 0 #0a103205, 0 14px 40px 0 #0a103208, 0 20px 60px 0 #0a10320d;
        }
    }
}

.report-panel:hover {
    box-shadow: 0 0 20px 0 #0a103205, 0 14px 40px 0 #0a103208, 0 20px 60px 0 #0a10320d;
}
</style>
