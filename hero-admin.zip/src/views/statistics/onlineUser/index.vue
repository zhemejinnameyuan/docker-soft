<template>
    <div class="app-container" style="min-width: 1560px">
        <!--全屏-->
        <DialogFull :visible.sync="isFull" :title="fullTitle">
            <RealtimeOnlinePanel v-if="fullType === 'realtimeOnline'" ref="realtimeOnlineFull" :is-full="isFull" @showFullCallBack="showFull" />
            <RealtimeNewPanel v-if="fullType === 'realtimeNew'" ref="realtimeNewFull" :is-full="isFull" @showFullCallBack="showFull" />
            <RealtimePayUserPanel v-if="fullType === 'realtimePayUser'" ref="realtimePayUserFull" :is-full="isFull" @showFullCallBack="showFull" />
            <RealtimePayAmountPanel v-if="fullType === 'realtimePayAmount'" ref="realtimePayAmountFull" :is-full="isFull" @showFullCallBack="showFull" />
        </DialogFull>

        <div>
            <ReportPanel />
        </div>

        <div class="mt-10">
            <RealtimeOnlinePanel ref="realtimeOnline" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="mt-10">
            <RealtimeNewPanel ref="realtimeNew" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="mt-10">
            <RealtimePayUserPanel ref="realtimePayUser" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="mt-10">
            <RealtimePayAmountPanel ref="realtimePayAmount" :is-full="isFull" @showFullCallBack="showFull" />
        </div>
    </div>
</template>

<script>
import DialogFull from '@/components/DialogFull'
import ReportPanel from './panel/report'
import RealtimeOnlinePanel from './panel/realtimeOnline'
import RealtimeNewPanel from './panel/realtimeNew'
import RealtimePayUserPanel from './panel/realtimePayUser'
import RealtimePayAmountPanel from './panel/realtimePayAmount'
export default {
    name: 'OnlineUser',
    components: {
        ReportPanel,
        RealtimeOnlinePanel,
        RealtimeNewPanel,
        RealtimePayUserPanel,
        RealtimePayAmountPanel,
        DialogFull
    },
    data() {
        return {
            isFull: false,
            fullType: '',
            fullTitleConf: {
                realtimeOnline: '实时在线人数',
                realtimeNew: '实时新增人数',
                realtimePayUser: '实时付费人数',
                realtimePayAmount: '实时付费金额'
            },
            fullTitle: ''
        }
    },
    mounted() {
        window.addEventListener('resize', this.resizeChartEvents)
    },
    beforeDestroy() {
        window.removeEventListener('resize', this.resizeChartEvents)
    },
    methods: {
        showFull(isFull, type) {
            this.isFull = isFull
            this.fullType = type
            this.fullTitle = this.fullTitleConf[type]
        },
        resizeChartEvents() {
            this.$refs.realtimeOnline && this.$refs.realtimeOnline.resizeChart()
            this.$refs.realtimeNew && this.$refs.realtimeNew.resizeChart()
            this.$refs.realtimePayUser && this.$refs.realtimePayUser.resizeChart()
            this.$refs.realtimePayAmount && this.$refs.realtimePayAmount.resizeChart()

            this.$refs.realtimeOnlineFull && this.$refs.realtimeOnlineFull.resizeChart()
            this.$refs.realtimeNewFull && this.$refs.realtimeNewFull.resizeChart()
            this.$refs.realtimePayUserFull && this.$refs.realtimePayUserFull.resizeChart()
            this.$refs.realtimePayAmountFull && this.$refs.realtimePayAmountFull.resizeChart()
        }
    }
}
</script>
