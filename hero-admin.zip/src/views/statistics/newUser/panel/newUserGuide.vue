<template>
    <div :class="isFull ? 'chart-panel is-full' : 'chart-panel'" v-loading="loading">
        <div class="head-bar">
            <div class="left">
                <div class="mr-20">
                    <span class="title">新手引导转化</span>
                </div>
                <div class="select-item" style="width: 60px">
                    <el-select v-model="search.serverId" size="mini" placeholder="" @change="toQuery">
                        <el-option label="区服1" value="1"></el-option>
                        <el-option label="区服2" value="2"></el-option>
                    </el-select>
                </div>

                <div class="ml-10">
                    <DateRangePicker v-model="search.date" style="width: 210px" @change="toQuery" :clearable="false" />
                </div>
            </div>

            <div class="right ml-20">
                <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                    <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" :content="isFull ? '还原' : '放大'" placement="top">
                    <svg-icon icon-class="oms_ico_quanping" @click="showFull" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" content="导出Excel" placement="top">
                    <svg-icon icon-class="oms_ico_download" @click="downloadExcel" />
                </el-tooltip>
            </div>
        </div>
        <div class="data-content mt-10">
            <div class="data-chart ml-20">
                <div class="dp-f-reverse mb-10" style="margin-top: -10px">
                    <el-tooltip effect="dark" :content="showType === 'chart' ? '切换表格' : '切换趋势图'" placement="top">
                        <div class="change-type-text" @click="changeShowType">
                            {{ showType === 'chart' ? '表格' : '趋势图' }}
                        </div>
                    </el-tooltip>

                    <el-tooltip class="icon mr-20" effect="dark" :content="chartShowLabel ? '隐藏数值' : '显示数值'" placement="top" v-if="showType === 'chart'">
                        <svg-icon :icon-class="chartShowLabel ? 'oms_ico_yingcang' : 'oms_ico_xianshi'" @click="changeShowLabel" />
                    </el-tooltip>
                </div>
                <div id="new-user-guide-chart-container" :class="isFull ? 'data-chart-container-full' : 'data-chart-container'" v-show="showType === 'chart'"></div>

                <div v-show="showType === 'table'">
                    <el-table class="chart-report-table" :data="tableData" border style="width: 100%" max-height="280">
                        <el-table-column align="center" label="总体" width="180">
                            <template>总体</template>
                        </el-table-column>
                        <el-table-column align="center" label="新增用户" width="180">
                            <template>总体</template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤1)">
                            <template>1000</template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤2)">
                            <template>
                                <div :class="getPercentageBgColor(80)">
                                    <div>800</div>
                                    <div>80%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤3)">
                            <template>
                                <div :class="getPercentageBgColor(70)">
                                    <div>700</div>
                                    <div>70%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤4)">
                            <template>
                                <div :class="getPercentageBgColor(60)">
                                    <div>600</div>
                                    <div>60%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤5)">
                            <template>
                                <div :class="getPercentageBgColor(55)">
                                    <div>55</div>
                                    <div>55%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤6)">
                            <div :class="getPercentageBgColor(35)">
                                <div>35</div>
                                <div>35%</div>
                            </div>
                        </el-table-column>
                        <el-table-column align="center" label="完成新手引导(步骤7)">
                            <template>
                                <div :class="getPercentageBgColor(10)">
                                    <div>10</div>
                                    <div>10%</div>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import * as echarts from 'echarts'
import { downloadExcel } from '@/utils'
import Base from '@/views/base'

export default {
    name: 'NewUserGuide',
    mixins: [Base],
    components: {
        DateRangePicker
    },
    props: {
        isFull: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            chartContainer: '', //图表容器
            showType: 'chart', //图表或表格 chart/table
            chartShowLabel: true, //图表:是否显示数值
            search: {
                serverId: '1',
                date: [],
                comparedDate: []
            },
            loading: false,
            tableData: [
                {
                    date: '2023-06-01 00:00',
                    count: 10
                }
            ]
        }
    },
    mounted() {
        this.search.date.push(this.$moment().format('YYYY-MM-DD 00:00:00'))
        this.search.date.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.initChart()
    },
    methods: {
        showFull() {
            this.$emit('showFullCallBack', !this.isFull, 'newUserGuide')
        },
        toQuery() {
            this.loading = true

            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        },
        //切换表格/图表
        changeShowType() {
            this.showType = this.showType === 'chart' ? 'table' : 'chart'
        },
        //切换数值显示
        changeShowLabel() {
            this.chartShowLabel = !this.chartShowLabel
            this.initChart()
        },
        //导出数据
        downloadExcel() {
            const header = ['date', 'count']
            const headerZh = {
                date: '总体',
                count: '新增用户'
            }
            downloadExcel(header, headerZh, this.tableData, '新手引导转化')
        },
        resizeChart() {
            this.chartContainer && this.chartContainer.resize()
        },
        initChart() {
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('new-user-guide-chart-container'))
            }
            //箭头图片
            const jiantouImg = require('@/assets/images/gameoms_ico_jiantou.png')
            //箭头间距
            let jiantouDistance = 50

            //默认数据处理
            let dataOne = [12000, 8900, 7800, 6700, 5600, 4500, 2000]
            let dataTwo = []
            let dataOnePercentage = []
            let dataTwoPercentage = []
            let dataThreePercentage = []

            //处理步骤差值和百分比
            for (let i = 0; i < dataOne.length; i++) {
                dataThreePercentage.push(100)
                if (i === 0) {
                    dataTwo.push(0)
                    dataOnePercentage.push(100)
                    dataTwoPercentage.push(0)
                    continue
                }
                //差值
                dataTwo[i] = dataOne[i - 1] - dataOne[i]
                //百分比
                dataOnePercentage[i] = _.round((dataOne[i] / dataOne[0]) * 100, 2)
                dataTwoPercentage[i] = _.round((dataTwo[i] / dataOne[0]) * 100, 2)
            }

            let colorData = ['#2BAAF3', '#CBF6FF', '#ffffff']
            let seriesData = [
                {
                    name: '深色背景',
                    type: 'bar',
                    stack: 'one',
                    data: dataOnePercentage,
                    barWidth: '60',
                    barMinHeight: 0,
                    label: {
                        show: this.chartShowLabel,
                        color: '#fff',
                        position: 'insideTop',
                        formatter: function (params) {
                            //处理占比百分比:下一步骤/第一步骤*100%
                            let content = '{classNameA|' + params.data + '%}\n' + '{classNameB|' + dataOne[params.dataIndex] + '}'
                            return content
                        },
                        rich: {
                            classNameA: {
                                color: '#FFFFFF',
                                fontSize: 12,
                                fontWeight: 500,
                                align: 'center',
                                fontFamily: 'PingFangSC-Medium'
                            },
                            classNameB: {
                                color: 'rgba(255,255,255,0.80)',
                                fontSize: 14,
                                fontWeight: 400,
                                align: 'center',
                                lineHeight: 18,
                                fontFamily: 'PingFangSC-Medium'
                            }
                        }
                    }
                },
                {
                    name: '浅色背景',
                    type: 'bar',
                    stack: 'one',
                    data: dataTwoPercentage
                },
                {
                    name: '用于显示对比百分比',
                    type: 'bar',
                    stack: 'two',
                    barWidth: 1,
                    data: dataThreePercentage,
                    label: {
                        show: this.chartShowLabel,
                        position: 'right',
                        align: 'left',
                        distance: jiantouDistance,
                        formatter: function (params) {
                            if (params.dataIndex !== dataOne.length - 1) {
                                //处理对比百分比:下一步骤/上个步骤*100%
                                let percentage = _.round((dataOne[params.dataIndex + 1] / dataOne[params.dataIndex]) * 100, 2)
                                return '{classNameC|' + percentage + '%' + '\n' + '}'
                            } else {
                                return ''
                            }
                        },
                        rich: {
                            classNameC: {
                                color: '#6F6C65',
                                width: 50,
                                height: 30,
                                lineHeight: 10,
                                fontSize: 12,
                                fontFamily: 'Microsoft YaHei',
                                align: 'center',
                                backgroundColor: {
                                    image: jiantouImg
                                }
                            }
                        }
                    }
                }
            ]
            // 组装图表
            const xAxisData = ['步骤1:完成新手引导', '步骤2:完成新手引导2', '步骤3:完成新手引导3', '步骤4:完成新手引导4', '步骤5:完成新手引导5', '步骤6:完成新手引导6', '步骤7:完成新手引导7']
            const option = {
                grid: {
                    top: '30',
                    left: '15',
                    right: '15',
                    bottom: '35',
                    containLabel: true
                },
                color: colorData,
                tooltip: {
                    show: true,
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgb(229,229,231,0.4)'
                        }
                    },
                    formatter: function (params) {
                        //处理占比数据和总数据
                        const tar = params[0]
                        return tar.name + '<br>总体:' + dataOne[tar.dataIndex] + '(' + tar.value + '%)'
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#292828'
                            }
                        }
                    }
                ],
                yAxis: {
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed'
                        }
                    },
                    axisLabel: { formatter: '{value}%' }
                },
                series: seriesData
            }
            this.chartContainer.setOption(option, true)
        }
    }
}
</script>
<style scoped lang="scss">
@import '~@/assets/styles/new-user.scss';
</style>
