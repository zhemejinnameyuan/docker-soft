<template>
    <div :class="isFull ? 'chart-panel is-full' : 'chart-panel'" v-loading="loading">
        <div class="head-bar">
            <div class="left">
                <div class="mr-20">
                    <span class="title">新增用户破冰时长</span>
                </div>
                <div class="select-item ml-5">
                    <el-select v-model="search.type" size="mini" placeholder="" @change="toQuery">
                        <el-option label="天" value="1"></el-option>
                    </el-select>
                </div>

                <div class="select-item ml-5" style="width: 70px">
                    <el-select v-model="search.serverId" size="mini" placeholder="" @change="toQuery">
                        <el-option label="区服1" value="1"></el-option>
                        <el-option label="区服2" value="2"></el-option>
                    </el-select>
                </div>

                <div class="ml-10">
                    <DateRangePicker v-model="search.date" style="width: 210px" @change="toQuery" :clearable="false" />
                </div>
            </div>
            <div class="right">
                <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                    <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" :content="isFull ? '还原' : '放大'" placement="top">
                    <svg-icon icon-class="oms_ico_quanping" @click="showFull" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" content="导出Excel" placement="top">
                    <svg-icon icon-class="oms_ico_download" @click="downloadExcel" />
                </el-tooltip>
            </div>
        </div>

        <div class="data-content mt-10">
            <div class="data-chart ml-20">
                <div class="dp-f-reverse mb-10" style="margin-top: -10px">
                    <el-tooltip effect="dark" :content="showType === 'chart' ? '切换表格' : '切换趋势图'" placement="top">
                        <div class="change-type-text" @click="changeShowType">
                            {{ showType === 'chart' ? '表格' : '趋势图' }}
                        </div>
                    </el-tooltip>
                </div>

                <div id="break-ice-time-chart-container" :class="isFull ? 'data-chart-container-full' : 'data-chart-container'" v-show="showType === 'chart'"></div>

                <div v-show="showType === 'table'">
                    <el-table class="chart-report-table" :data="tableData" border style="width: 100%" max-height="260">
                        <el-table-column align="center" prop="date" label="日期" width="180" />
                        <el-table-column align="center" prop="count" label="用户数">
                            <template>1000</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="间隔数">
                            <template>234次</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="平均值">
                            <template>1天2小时3分4秒</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="最小值">
                            <template>3分4秒</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="下四分位">
                            <template>3分4秒</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="中位数">
                            <template>3分4秒</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="上四分位">
                            <template>3分4秒</template>
                        </el-table-column>
                        <el-table-column align="center" prop="count" label="最大值">
                            <template>3分4秒</template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import * as echarts from 'echarts'
import { downloadExcel, formatSecondToStr, getWeek } from '@/utils'
import Base from '@/views/base'

export default {
    name: 'BreakIceTime',
    mixins: [Base],
    components: {
        DateRangePicker
    },
    props: {
        isFull: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            chartContainer: '', //图表容器
            showType: 'chart', //图表或表格 chart/table
            search: {
                serverId: '1',
                type: '1',
                date: [],
                comparedDate: []
            },
            loading: false,
            tableData: [
                {
                    date: '2023-06-01',
                    count: 10
                },
                {
                    date: '2023-06-02',
                    count: 20
                }
            ]
        }
    },
    mounted() {
        this.search.date.push(this.$moment().format('YYYY-MM-DD 00:00:00'))
        this.search.date.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.initChart()
    },
    methods: {
        showFull() {
            this.$emit('showFullCallBack', !this.isFull, 'breakIceTime')
        },
        toQuery() {
            this.loading = true

            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        },
        //切换表格/图表
        changeShowType() {
            this.showType = this.showType === 'chart' ? 'table' : 'chart'
        },

        //导出数据
        downloadExcel() {
            const header = ['date', 'count']
            const headerZh = {
                date: '日期',
                count: '实时新增人数'
            }
            downloadExcel(header, headerZh, this.tableData, '新增用户破冰时长')
        },
        resizeChart() {
            this.chartContainer && this.chartContainer.resize()
        },
        initChart() {
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('break-ice-time-chart-container'))
            }

            const data = [
                [111324, 322039, 347362, 674398, 733942],
                [1325, 2039, 7362, 174398, 533942],
                [1326, 2039, 7362, 174398, 533942]
            ]

            const xAxisData = ['2023-07-04(' + getWeek('2023-07-04') + ')', '2023-07-05(' + getWeek('2023-07-05') + ')', '2023-07-06(' + getWeek('2023-07-06') + ')']

            //默认数据处理
            let seriesData = [
                {
                    name: '总体',
                    type: 'boxplot',
                    itemStyle: {
                        borderWidth: 2,
                        color: 'rgb(210,227,255)',
                        borderColor: 'rgb(29,112,227)'
                    },
                    emphasis: {
                        itemStyle: {
                            borderWidth: 2,
                            color: 'rgb(88,146,243)',
                            borderColor: 'rgb(29,112,227)'
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        textStyle: {
                            fontSize: 12,
                            width: 250
                        },
                        extraCssText: 'width:250px;',
                        formatter: function (params) {
                            let content = '<div>' + xAxisData[params.dataIndex] + '<div>'
                            content += '<span style="display:inline-block;width: 100px">最大值:</span><span>' + formatSecondToStr(params.data[5]) + '</span><br>'
                            content += '<span style="display:inline-block;width: 100px">上四分位:</span><span>' + formatSecondToStr(params.data[4]) + '</span><br>'
                            content += '<span style="display:inline-block;width: 100px">中位数:</span><span>' + formatSecondToStr(params.data[3]) + '</span><br>'
                            content += '<span style="display:inline-block;width: 100px">下四分位:</span><span>' + formatSecondToStr(params.data[2]) + '</span><br>'
                            content += '<span style="display:inline-block;width: 100px">最低值:</span><span>' + formatSecondToStr(params.data[1]) + '</span><br>'
                            return content
                        }
                    },
                    data: data
                }
            ]

            // 组装图表
            const option = {
                grid: {
                    top: '30',
                    left: '15',
                    right: '15',
                    bottom: '35',
                    containLabel: true
                },
                tooltip: {
                    show: true,
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgb(229,229,231,0.4)'
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData
                    }
                ],
                yAxis: {
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed'
                        }
                    },
                    type: 'value',
                    min: 0,
                    max: 691200,
                    interval: 172800,
                    axisLabel: {
                        formatter: function (value) {
                            if (value === 0) {
                                return '0秒'
                            } else {
                                return value / 86400 + '天'
                            }
                        }
                    }
                },
                series: seriesData
            }
            this.chartContainer.setOption(option, true)
        }
    }
}
</script>
<style scoped lang="scss">
@import '~@/assets/styles/realtime.scss';
</style>
