<template>
    <div :class="isFull ? 'chart-panel is-full' : 'chart-panel'" v-loading="loading">
        <div class="head-bar">
            <div class="left">
                <div class="mr-20">
                    <span class="title">各渠道新增留存率</span>
                </div>
                <div class="select-item">
                    <el-select v-model="search.day" size="mini" placeholder="" @change="toQuery">
                        <el-option label="7日" value="7"></el-option>
                        <el-option label="14日" value="14"></el-option>
                        <el-option label="30日" value="30"></el-option>
                    </el-select>
                </div>

                <div class="select-item ml-5">
                    <el-select v-model="search.type" size="mini" placeholder="" @change="toQuery">
                        <el-option label="流失" value="1"></el-option>
                        <el-option label="留存" value="2"></el-option>
                    </el-select>
                </div>

                <div class="ml-10">
                    <DateRangePicker v-model="search.date" style="width: 210px" @change="toQuery" :clearable="false" />
                </div>
            </div>
            <div class="right">
                <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                    <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" :content="isFull ? '还原' : '放大'" placement="top">
                    <svg-icon icon-class="oms_ico_quanping" @click="showFull" />
                </el-tooltip>
                <el-tooltip class="item icon ml-20" effect="dark" content="导出Excel" placement="top">
                    <svg-icon icon-class="oms_ico_download" @click="downloadExcel" />
                </el-tooltip>
            </div>
        </div>

        <div class="data-content mt-10">
            <div class="data-chart ml-20">
                <div class="dp-f-reverse mb-10" style="margin-top: -10px">
                    <el-tooltip effect="dark" :content="showType === 'chart' ? '切换表格' : '切换趋势图'" placement="top">
                        <div class="change-type-text" @click="changeShowType">
                            {{ showType === 'chart' ? '表格' : '趋势图' }}
                        </div>
                    </el-tooltip>

                    <el-tooltip class="icon mr-20" effect="dark" :content="chartShowLabel ? '隐藏数值' : '显示数值'" placement="top" v-if="showType === 'chart'">
                        <svg-icon :icon-class="chartShowLabel ? 'oms_ico_yingcang' : 'oms_ico_xianshi'" @click="changeShowLabel" />
                    </el-tooltip>
                </div>

                <div id="channel-retain-chart-container" :class="isFull ? 'data-chart-container-full' : 'data-chart-container'" v-show="showType === 'chart'"></div>

                <div v-show="showType === 'table'">
                    <el-table class="chart-report-table" :data="tableData" border style="width: 100%" max-height="260">
                        <el-table-column align="center" label="日期" width="180">
                            <template slot-scope="scope">
                                <i class="icon el-icon-circle-plus-outline" @click="showMoreTable" />
                                {{ scope.row.date }}
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="新增设备数">
                            <template>1000</template>
                        </el-table-column>
                        <el-table-column align="center" label="当日">
                            <template>
                                <div :class="getPercentageBgColor(80)">
                                    <div>800</div>
                                    <div>80%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="次日">
                            <template>
                                <div :class="getPercentageBgColor(50)">
                                    <div>300</div>
                                    <div>50%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="第2日">
                            <template>
                                <div :class="getPercentageBgColor(40)">
                                    <div>300</div>
                                    <div>40%</div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" label="第3日">
                            <template>
                                <div :class="getPercentageBgColor(30)">
                                    <div>300</div>
                                    <div>30%</div>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
        </div>

        <!--详情-->
        <div>
            <el-dialog append-to-body :close-on-click-modal="false" :before-close="dialogCancel" :visible.sync="dialogShowMoreTable" title="详情" width="1400px">
                <el-table class="chart-report-table" :data="tableData" border style="width: 100%" max-height="260">
                    <el-table-column align="center" label="日期" width="180">
                        <template slot-scope="scope">
                            {{ scope.row.date }}
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="新增设备数">
                        <template>1000</template>
                    </el-table-column>
                    <el-table-column align="center" label="当日">
                        <template>
                            <div :class="getPercentageBgColor(80)">
                                <div>800</div>
                                <div>80%</div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="次日">
                        <template>
                            <div :class="getPercentageBgColor(50)">
                                <div>300</div>
                                <div>50%</div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="第2日">
                        <template>
                            <div :class="getPercentageBgColor(40)">
                                <div>300</div>
                                <div>40%</div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="第3日">
                        <template>
                            <div :class="getPercentageBgColor(30)">
                                <div>300</div>
                                <div>30%</div>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
            </el-dialog>
        </div>
    </div>
</template>

<script>
import DateRangePicker from '@/components/DateRangePicker'
import * as echarts from 'echarts'
import { downloadExcel } from '@/utils'
import Base from '@/views/base'

export default {
    name: 'ChannelRetain',
    mixins: [Base],
    components: {
        DateRangePicker
    },
    props: {
        isFull: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            chartContainer: '', //图表容器
            showType: 'chart', //图表或表格 chart/table
            chartShowLabel: false, //图表:是否显示数值
            dialogShowMoreTable: false,
            search: {
                day: '7',
                type: '1',
                date: [],
                comparedDate: []
            },
            loading: false,
            tableData: [
                {
                    date: '总体',
                    count: 10
                },
                {
                    date: '2023-06-01 01:00',
                    count: 20
                }
            ]
        }
    },
    mounted() {
        this.search.date.push(this.$moment().format('YYYY-MM-DD 00:00:00'))
        this.search.date.push(this.$moment().format('YYYY-MM-DD 23:59:59'))
        this.initChart()
    },
    methods: {
        showMoreTable() {
            this.dialogShowMoreTable = true
        },
        dialogCancel() {
            this.dialogShowMoreTable = false
        },
        showFull() {
            this.$emit('showFullCallBack', !this.isFull, 'channelRetain')
        },
        toQuery() {
            this.loading = true

            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        },
        //切换表格/图表
        changeShowType() {
            this.showType = this.showType === 'chart' ? 'table' : 'chart'
        },
        //切换数值显示
        changeShowLabel() {
            this.chartShowLabel = !this.chartShowLabel
            this.initChart()
        },
        //导出数据
        downloadExcel() {
            const header = ['date', 'count']
            const headerZh = {
                date: '日期',
                count: '实时新增人数'
            }
            downloadExcel(header, headerZh, this.tableData, '各渠道新增留存率')
        },
        resizeChart() {
            this.chartContainer && this.chartContainer.resize()
        },
        //生成留存数据天数刻度
        createDayXAxisData(day) {
            let xAxisData = []
            for (let i = 0; i <= day; i++) {
                if (i === 0) {
                    xAxisData.push('当日')
                } else if (i === 1) {
                    xAxisData.push('次日')
                } else {
                    xAxisData.push(`第${i}日`)
                }
            }

            return xAxisData
        },
        initChart() {
            if (!this.chartContainer) {
                this.chartContainer = echarts.init(document.getElementById('channel-retain-chart-container'))
            }

            //默认数据处理
            let totalData = [50, 45, 35, 25, 15, 10, 5, 3]
            let tencentData = [55, 30, 40, 30, 25, 15, 10, 13]
            let netEasyData = [60, 37, 39, 25, 15, 12, 8, 3]
            let xiaomiData = [70, 38, 32, 26, 25, 20, 15, 13]
            let huaweiData = [65, 39, 34, 20, 35, 20, 25, 13]

            let legendData = ['总体', '腾讯', '网易', '小米', '华为']
            let colorData = ['#4E2BE8', '#6ECE20', '#F82490', '#F68915', '#2EBFFF']
            let seriesData = [
                {
                    name: '总体',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: totalData
                },
                {
                    name: '腾讯',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: tencentData
                },
                {
                    name: '网易',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: netEasyData
                },
                {
                    name: '小米',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: xiaomiData
                },
                {
                    name: '华为',
                    type: 'line',
                    barGap: '15%',
                    barWidth: '10',
                    label: {
                        show: this.chartShowLabel,
                        position: 'top'
                    },
                    data: huaweiData
                }
            ]

            // 组装图表
            const xAxisData = this.createDayXAxisData(7)
            const option = {
                grid: {
                    top: '30',
                    left: '15',
                    right: '15',
                    bottom: '35',
                    containLabel: true
                },
                color: colorData,
                tooltip: {
                    show: true,
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgb(229,229,231,0.4)'
                        }
                    }
                },

                legend: [
                    {
                        top: 'bottom',
                        data: legendData
                    }
                ],
                xAxis: [
                    {
                        type: 'category',
                        data: xAxisData,
                        axisLine: {
                            lineStyle: {
                                color: '#A1A4A7'
                            }
                        },
                        axisTick: {
                            show: false
                        }
                    }
                ],
                yAxis: {
                    min: 0,
                    max: 100,
                    interval: 20,
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed'
                        }
                    },
                    axisLabel: { formatter: '{value}%' }
                },
                series: seriesData
            }
            this.chartContainer.setOption(option, true)
        }
    }
}
</script>
<style scoped lang="scss">
@import '~@/assets/styles/realtime.scss';
</style>
