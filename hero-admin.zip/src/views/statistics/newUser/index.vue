<template>
    <div class="app-container" style="min-width: 1560px">
        <!--全屏-->
        <DialogFull :visible.sync="isFull" :title="fullTitle">
            <DayNewUser v-if="fullType === 'dayNewUser'" ref="dayNewUserFull" :is-full="isFull" @showFullCallBack="showFull" />
            <DeviceConvert v-if="fullType === 'deviceConvert'" ref="deviceConvertFull" :is-full="isFull" @showFullCallBack="showFull" />
            <NewUserGuide v-if="fullType === 'newUserGuide'" ref="newUserGuideFull" :is-full="isFull" @showFullCallBack="showFull" />
            <NewUserLevel v-if="fullType === 'newUserLevel'" ref="newUserLevelFull" :is-full="isFull" @showFullCallBack="showFull" />
            <NewUserTask v-if="fullType === 'newUserTask'" ref="newUserTaskFull" :is-full="isFull" @showFullCallBack="showFull" />
            <ChannelRetain v-if="fullType === 'channelRetain'" ref="channelRetainFull" :is-full="isFull" @showFullCallBack="showFull" />
            <NewUserPay v-if="fullType === 'newUserPay'" ref="newUserPayFull" :is-full="isFull" @showFullCallBack="showFull" />
            <FirstPayConvert v-if="fullType === 'firstPayConvert'" ref="firstPayConvertFull" :is-full="isFull" @showFullCallBack="showFull" />
            <BreakIceTime v-if="fullType === 'breakIceTime'" ref="breakIceTimeFull" :is-full="isFull" @showFullCallBack="showFull" />
            <Ltv v-if="fullType === 'ltv'" ref="ltvFull" :is-full="isFull" @showFullCallBack="showFull" />
        </DialogFull>

        <div class="dp-f">
            <div style="width: calc(50% - 10px); min-width: 750px">
                <DayNewUser ref="dayNewUser" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
            <div class="ml-20" style="width: calc(50% - 10px); min-width: 750px">
                <DeviceConvert ref="deviceConvert" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
        </div>

        <div class="mt-10">
            <NewUserGuide ref="newUserGuide" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="mt-10 dp-f" style="width: 100%">
            <div style="width: calc(50% - 10px); min-width: 750px">
                <NewUserLevel ref="newUserLevel" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
            <div class="ml-20" style="width: calc(50% - 10px); min-width: 750px">
                <NewUserTask ref="newUserTask" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
        </div>

        <div class="mt-10">
            <ChannelRetain ref="channelRetain" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="dp-f mt-10">
            <div style="width: calc(50% - 10px); min-width: 750px">
                <NewUserPay ref="newUserPay" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
            <div class="ml-20" style="width: calc(50% - 10px); min-width: 750px">
                <FirstPayConvert ref="firstPayConvert" :is-full="isFull" @showFullCallBack="showFull" />
            </div>
        </div>

        <div class="mt-10">
            <BreakIceTime ref="breakIceTime" :is-full="isFull" @showFullCallBack="showFull" />
        </div>

        <div class="mt-10">
            <Ltv ref="ltv" :is-full="isFull" @showFullCallBack="showFull" />
        </div>
    </div>
</template>

<script>
import DialogFull from '@/components/DialogFull'
import DayNewUser from './panel/dayNewUser'
import DeviceConvert from './panel/deviceConvert'
import NewUserGuide from './panel/newUserGuide'
import NewUserLevel from './panel/newUserLevel'
import NewUserTask from './panel/newUserTask'
import ChannelRetain from './panel/channelRetain'
import NewUserPay from './panel/newUserPay'
import FirstPayConvert from './panel/firstPayConvert'
import BreakIceTime from './panel/breakIceTime'
import Ltv from './panel/ltv'

export default {
    name: 'NewUser',
    components: {
        DayNewUser,
        DialogFull,
        DeviceConvert,
        NewUserGuide,
        NewUserLevel,
        NewUserTask,
        ChannelRetain,
        NewUserPay,
        FirstPayConvert,
        BreakIceTime,
        Ltv
    },
    data() {
        return {
            isFull: false,
            fullType: '',
            fullTitleConf: {
                dayNewUser: '每日新增人数',
                deviceConvert: '设备转化',
                newUserGuide: '新手引导转化',
                newUserLevel: '新增主线关卡/战役/等级情况',
                newUserTask: '新增首日完成主线任务数',
                channelRetain: '各渠道新增留存率',
                newUserPay: '新增首日付费数据',
                firstPayConvert: '首充转化',
                breakIceTime: '新增用户破冰时长',
                ltv: 'LTV内购'
            },
            fullTitle: ''
        }
    },
    mounted() {
        window.addEventListener('resize', this.resizeChartEvents)
    },
    beforeDestroy() {
        window.removeEventListener('resize', this.resizeChartEvents)
    },
    methods: {
        showFull(isFull, type) {
            this.isFull = isFull
            this.fullType = type
            this.fullTitle = this.fullTitleConf[type]
        },
        resizeChartEvents() {
            this.$refs.dayNewUser && this.$refs.dayNewUser.resizeChart()
            this.$refs.deviceConvert && this.$refs.deviceConvert.resizeChart()
            this.$refs.newUserGuide && this.$refs.newUserGuide.resizeChart()
            this.$refs.newUserLevel && this.$refs.newUserLevel.resizeChart()
            this.$refs.newUserTask && this.$refs.newUserTask.resizeChart()
            this.$refs.channelRetain && this.$refs.channelRetain.resizeChart()
            this.$refs.newUserPay && this.$refs.newUserPay.resizeChart()
            this.$refs.firstPayConvert && this.$refs.firstPayConvert.resizeChart()
            this.$refs.breakIceTime && this.$refs.breakIceTime.resizeChart()
            this.$refs.ltv && this.$refs.ltv.resizeChart()

            this.$refs.dayNewUserFull && this.$refs.dayNewUserFull.resizeChart()
            this.$refs.deviceConvertFull && this.$refs.deviceConvertFull.resizeChart()
            this.$refs.newUserGuideFull && this.$refs.newUserGuideFull.resizeChart()
            this.$refs.newUserLevelFull && this.$refs.newUserGuideFull.resizeChart()
            this.$refs.newUserTaskFull && this.$refs.newUserTaskFull.resizeChart()
            this.$refs.channelRetainFull && this.$refs.channelRetainFull.resizeChart()
            this.$refs.newUserPayFull && this.$refs.newUserPayFull.resizeChart()
            this.$refs.firstPayConvertFull && this.$refs.firstPayConvertFull.resizeChart()
            this.$refs.breakIceTimeFull && this.$refs.breakIceTimeFull.resizeChart()
            this.$refs.ltvFull && this.$refs.ltvFull.resizeChart()
        }
    }
}
</script>
