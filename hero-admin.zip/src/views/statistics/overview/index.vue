<template>
    <div class="app-container dp-c" style="min-width: 1560px">
        <div class="mt-10">
            <PayReport />
        </div>

        <div class="dp-f" style="width: 100%">
            <div class="dp-c" style="width: 75.6%">
                <DayReport />
                <DayPayReport />
            </div>

            <div style="width: 23%; margin-left: 1.31%">
                <UserReport />
            </div>
        </div>
    </div>
</template>
<script>
import Base from '@/views/base'
import PayReport from './components/pay'
import DayReport from './components/day'
import DayPayReport from './components/dayPay'
import UserReport from './components/user'

export default {
    name: 'Overview',
    components: {
        PayReport,
        DayReport,
        DayPayReport,
        UserReport
    },
    mixins: [Base],
    data() {
        return {}
    },
    mounted() {},
    methods: {}
}
</script>
