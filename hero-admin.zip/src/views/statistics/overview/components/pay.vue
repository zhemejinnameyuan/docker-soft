<template>
    <div class="data-report-summary-container" style="width: 100%; height: 380px" v-loading="loading">
        <div class="head">
            <div class="dp-f-vertical-center">
                <div class="title-pre-color" style="background-color: #faa900"></div>
                <span class="title">付费情况</span>
                <span class="tips">每10分钟刷新一次数据</span>
            </div>
            <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
            </el-tooltip>
        </div>

        <div class="content">
            <div class="dp-c">
                <div class="income">
                    <span class="title">收入</span>
                    <span class="number ml-40" v-auto-font-size="'50'" style="width: 250px">9,180,000.00</span>
                </div>

                <div class="user">
                    <div class="item" style="margin-left: 60px">
                        <span class="title">付费人数</span>
                        <span class="number" style="width: 140px" v-auto-font-size="'24'">123,456,789</span>
                    </div>

                    <div class="item" style="margin-left: 20px">
                        <span class="title" style="font-weight: 400">ARPU</span>
                        <span class="number" style="color: #d79b1f; width: 80px" v-auto-font-size="'24'">8,000.00</span>
                    </div>

                    <div class="item" style="margin-left: 60px">
                        <span class="title" style="font-weight: 400">ARRPU</span>
                        <span class="number" style="color: #d79b1f; width: 80px" v-auto-font-size="'24'">3,456.00</span>
                    </div>
                </div>
            </div>

            <div class="pay-user">
                <div id="pay-user-chart" style="width: 230px; height: 330px"></div>
            </div>

            <div class="pay-terminal">
                <div id="pay-terminal-chart" style="width: 230px; height: 330px"></div>
            </div>
        </div>
    </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
    name: 'Pay',
    data() {
        return {
            loading: false,
            payUserChart: '',
            payTerminalChart: ''
        }
    },
    mounted() {
        this.initUserChart()
        this.initTerminalChart()
    },
    updated() {
        this.initUserChart()
        this.initTerminalChart()
        this.initTerminalChart()
    },
    methods: {
        toQuery() {
            this.loading = true
            this.initUserChart()
            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        },
        initUserChart() {
            if (!this.payUserChart) {
                this.payUserChart = echarts.init(document.getElementById('pay-user-chart'))
            }
            let payUser = _.random(100, 1000)
            let notPayUser = _.random(100, 1000)
            // 指定图表的配置项和数据
            const option = {
                title: {
                    text: '付费设备占比',
                    left: '25%',
                    top: '90%'
                },
                color: ['#F7CF05', '#02E3CD'],
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    top: '43%',
                    left: 'center',
                    selectedMode: true,
                    itemWidth: 12,
                    itemHeight: 12,
                    borderRadius: 10
                },
                series: [
                    {
                        name: '付费设备占比',
                        type: 'pie',
                        radius: ['65%', '90%'],
                        avoidLabelOverlap: false,
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: payUser, name: '付费' },
                            { value: notPayUser, name: '未付费' }
                        ]
                    }
                ]
            }
            this.payUserChart.setOption(option)
        },
        initTerminalChart() {
            if (!this.payTerminalChart) {
                this.payTerminalChart = echarts.init(document.getElementById('pay-terminal-chart'))
            }
            let androidData = _.random(100, 10000)
            let h5Data = _.random(100, 10000)

            // 指定图表的配置项和数据
            const option = {
                title: {
                    text: '付费终端占比',
                    left: '25%',
                    top: '90%'
                },
                color: ['#3E7FFF', '#FF9823'],
                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },
                legend: {
                    orient: 'vertical',
                    top: '43%',
                    left: 'center',
                    selectedMode: true,
                    itemWidth: 12,
                    itemHeight: 12,
                    borderRadius: 20
                },
                series: [
                    {
                        name: '付费终端占比',
                        type: 'pie',
                        radius: ['65%', '90%'],
                        avoidLabelOverlap: false,
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        },
                        data: [
                            { value: androidData, name: '安卓' },
                            { value: h5Data, name: 'H5' }
                        ]
                    }
                ]
            }
            this.payTerminalChart.setOption(option)
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
.data-report-summary-container {
    .content {
        padding: 20px 30px 30px 30px;
        display: flex;
        justify-content: space-between;

        .income {
            width: 520px;
            height: 120px;
            display: flex;
            justify-content: center;
            align-items: center;
            .title {
                font-family: PingFangSC-Medium;
                font-size: 39px;
                color: #292828;
                letter-spacing: 0;
                line-height: 32px;
                font-weight: 500;
            }
            .number {
                font-family: PingFangSC-Medium;
                font-size: 50px;
                color: #ed5f00;
                letter-spacing: 0;
                line-height: 40px;
                font-weight: 500;
            }
        }

        .user {
            background: rgba(255, 199, 0, 0.06);
            border-radius: 4px;
            width: 520px;
            height: 120px;
            display: flex;
            //justify-content: center;
            align-items: center;

            .item {
                display: flex;
                flex-direction: column;

                .title {
                    font-family: PingFangSC-Medium;
                    font-size: 16px;
                    color: #292828;
                    letter-spacing: 0;
                    line-height: 16px;
                    font-weight: 500;
                }

                .number {
                    font-family: PingFangSC-Medium;
                    font-size: 24px;
                    color: #faa900;
                    letter-spacing: 0;
                    line-height: 24px;
                    font-weight: 500;
                    margin-top: 20px;
                }
            }
        }

        .pay-user {
            margin-left: 80px;
            margin-top: -50px;
        }

        .pay-terminal {
            margin-left: 80px;
            margin-right: 80px;
            margin-top: -50px;
        }
    }
}
</style>
