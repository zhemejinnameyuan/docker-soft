<template>
    <div class="data-report-summary-container mt-20" style="width: 100%; height: 210px" v-loading="loading">
        <div class="head">
            <div class="dp-f-vertical-center">
                <div class="title-pre-color" style="background-color: #1ba2ff"></div>
                <span class="title">每日概览</span>
                <span class="tips">每10分钟刷新一次数据</span>
            </div>

            <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
            </el-tooltip>
        </div>

        <div class="content">
            <div class="items" style="width: 49%">
                <div class="item">
                    <span class="max-title">今日新增</span>
                    <span class="max-number">123,456</span>

                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="vertical-split-line ml-30 mr-40 mt-30"></div>
                <div class="item">
                    <span class="title">iOS新增</span>
                    <span class="number" style="color: #1a82c9">12,345</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">安卓新增</span>
                    <span class="number" style="color: #33a4ba">12,345</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">新增账号</span>
                    <span class="number">123,456</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(200, 500)" :icon-class="getPercentageIcon(200, 500)" />
                        <span :class="getPercentageColor(200, 500)" style="margin-top: 6px">{{ getPercentageRatio(200, 500) }}</span>
                    </div>
                </div>
            </div>

            <div class="items" style="width: 49%; margin-left: 2%">
                <div class="item">
                    <span class="max-title">今日活跃</span>
                    <span class="max-number">123,456</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="vertical-split-line ml-30 mr-40 mt-30"></div>
                <div class="item">
                    <span class="title">iOS活跃</span>
                    <span class="number" style="color: #1a82c9">999,999</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(200, 500)" :icon-class="getPercentageIcon(200, 500)" />
                        <span :class="getPercentageColor(200, 500)" style="margin-top: 6px">{{ getPercentageRatio(200, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">安卓活跃</span>
                    <span class="number" style="color: #33a4ba">12,345</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(200, 500)" :icon-class="getPercentageIcon(200, 500)" />
                        <span :class="getPercentageColor(200, 500)" style="margin-top: 6px">{{ getPercentageRatio(200, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">付费活跃</span>
                    <span class="number">12,345</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(200, 500)" :icon-class="getPercentageIcon(200, 500)" />
                        <span :class="getPercentageColor(200, 500)" style="margin-top: 6px">{{ getPercentageRatio(200, 500) }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'

export default {
    name: 'Day',
    mixins: [Base],
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
.data-report-summary-container {
    .content {
        padding: 20px 30px 20px 30px;
        display: flex;

        .items {
            height: 110px;
            background: rgba(27, 162, 255, 0.05);
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            padding: 0 30px 0 30px;

            .item {
                display: flex;
                flex-direction: column;

                .max-title {
                    margin-top: 16px;
                    font-size: 16px;
                    line-height: 16px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 500;
                    height: 22px;
                }

                .max-number {
                    font-family: PingFangSC-Medium;
                    font-size: 24px;
                    line-height: 24px;
                    color: #1ba2ff;
                    letter-spacing: 0;
                    font-weight: 500;
                    margin-top: 6px;
                    margin-bottom: 6px;
                }

                .title {
                    margin-top: 20px;
                    font-size: 14px;
                    line-height: 14px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 400;
                    height: 20px;
                }

                .number {
                    font-family: PingFangSC-Medium;
                    font-size: 18px;
                    line-height: 18px;
                    height: 26px;
                    width: 70px;
                    color: #6f6c65;
                    letter-spacing: 0;
                    font-weight: 500;
                    margin-top: 5px;
                }
            }
        }
    }
}
</style>
