<template>
    <div class="data-report-summary-container mt-20" style="width: 100%; height: 210px" v-loading="loading">
        <div class="head">
            <div class="dp-f-vertical-center">
                <div class="title-pre-color" style="background-color: #fb8316"></div>
                <span class="title">每日付费</span>
                <span class="tips">每10分钟刷新一次数据</span>
            </div>
            <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
            </el-tooltip>
        </div>

        <div class="content">
            <div class="items" style="width: 49%">
                <div class="item">
                    <span class="max-title">今日付费人数</span>
                    <span class="max-number">800,000</span>

                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="vertical-split-line ml-30 mr-40 mt-30"></div>
                <div class="item">
                    <span class="title">新付费人数</span>
                    <span class="number">999,999</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">老付费人数</span>
                    <span class="number">999,999</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-40">
                    <span class="title">付费率/新/老</span>
                    <span class="number" style="color: #6f6c65">999,999</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(200, 500)" :icon-class="getPercentageIcon(200, 500)" />
                        <span :class="getPercentageColor(200, 500)" style="margin-top: 6px">{{ getPercentageRatio(200, 500) }}</span>
                    </div>
                </div>
            </div>

            <div class="items" style="width: 49%; margin-left: 2%">
                <div class="item mr-30">
                    <span class="max-title">今日收入</span>
                    <span class="max-number">800,000</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-30 mr-30">
                    <span class="max-title">今日ARPU</span>
                    <span class="max-number">800,000</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>

                <div class="item ml-30 mr-30">
                    <span class="max-title">今日ARPPU</span>
                    <span class="max-number">800,000</span>
                    <div class="ring-ratio">
                        <svg-icon v-if="getPercentageIcon(2000, 500)" :icon-class="getPercentageIcon(2000, 500)" />
                        <span :class="getPercentageColor(2000, 500)" style="margin-top: 6px">{{ getPercentageRatio(2000, 500) }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'

export default {
    name: 'DayPay',
    mixins: [Base],
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
.data-report-summary-container {
    .content {
        padding: 20px 30px 20px 30px;
        display: flex;

        .items {
            height: 110px;
            background: rgba(255, 80, 41, 0.05);
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            padding: 0 30px 0 30px;
            .item {
                display: flex;
                flex-direction: column;

                .max-title {
                    margin-top: 16px;
                    font-size: 16px;
                    line-height: 16px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 500;
                    height: 22px;
                }

                .max-number {
                    font-family: PingFangSC-Medium;
                    font-size: 24px;
                    line-height: 24px;
                    color: #fb8316;
                    letter-spacing: 0;
                    font-weight: 500;
                    margin-top: 6px;
                    margin-bottom: 6px;
                }

                .title {
                    margin-top: 20px;
                    font-size: 14px;
                    line-height: 14px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 400;
                    height: 20px;
                }

                .number {
                    font-family: PingFangSC-Medium;
                    font-size: 18px;
                    line-height: 18px;
                    height: 26px;
                    width: 70px;
                    color: #d37f32;
                    letter-spacing: 0;
                    font-weight: 500;
                    margin-top: 5px;
                }
            }
        }
    }
}
</style>
