<template>
    <div class="data-report-summary-container mt-20" style="width: 100%; height: 440px" v-loading="loading">
        <div class="head">
            <div class="dp-f-vertical-center">
                <div class="title-pre-color" style="background-color: #2f53e1"></div>
                <span class="title">用户总数</span>
                <span class="tips">每10分钟刷新一次数据</span>
            </div>

            <el-tooltip class="item icon" effect="dark" content="刷新" placement="top">
                <svg-icon icon-class="oms_ico_reset" @click="toQuery" />
            </el-tooltip>
        </div>

        <div class="content">
            <div class="items" style="width: 100%; height: 330px">
                <div class="item dp-c">
                    <span class="max-title">总设备数</span>
                    <span class="max-number">999,999</span>
                </div>

                <div class="item dp-c mt-20">
                    <span class="max-title">总账号数</span>
                    <span class="max-number">999,999</span>
                </div>

                <div class="item dp-f mt-30">
                    <div class="dp-c">
                        <span class="title">iOS设备</span>
                        <span class="number" style="width: 90px">2,000</span>
                        <span class="ratio">占比:{{ getPercentage(2000, 3000) }}</span>
                    </div>
                    <div class="dp-c ml-40">
                        <span class="title">安卓设备</span>
                        <span class="number" style="width: 90px">1,000</span>
                        <span class="ratio">占比:{{ getPercentage(1000, 3000) }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'
export default {
    name: 'User',
    mixins: [Base],
    data() {
        return {
            loading: false
        }
    },
    methods: {
        toQuery() {
            this.loading = true
            const _that = this
            setTimeout(function () {
                _that.loading = false
            }, 500)
        }
    }
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/data-report.scss';
.data-report-summary-container {
    .content {
        padding: 20px 30px 40px 30px;

        .items {
            display: flex;
            flex-direction: column;
            background: rgba(0, 32, 255, 0.05);
            border-radius: 4px;
            padding: 20px 30px 20px 30px;

            .item {
                .max-title {
                    font-family: PingFangSC-Medium;
                    font-size: 16px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 500;
                }

                .max-number {
                    font-family: PingFangSC-Medium;
                    font-size: 24px;
                    color: #4f6feb;
                    letter-spacing: 0;
                    line-height: 28px;
                    font-weight: 500;
                    margin-top: 10px;
                }

                .title {
                    font-family: PingFangSC-Regular;
                    font-size: 16px;
                    color: #292828;
                    letter-spacing: 0;
                    font-weight: 400;
                }

                .number {
                    font-family: PingFangSC-Medium;
                    font-size: 18px;
                    color: #4356a2;
                    letter-spacing: 0;
                    line-height: 18px;
                    font-weight: 500;
                    margin-top: 10px;
                }
                .ratio {
                    font-family: PingFangSC-Regular;
                    font-size: 12px;
                    color: #6f6c65;
                    letter-spacing: 0;
                    font-weight: 400;
                    margin-top: 10px;
                }
            }
        }
    }
}
</style>
