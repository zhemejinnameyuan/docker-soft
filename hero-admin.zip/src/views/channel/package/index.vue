<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left"></div>
                <div class="right">
                    <IconButton size="medium" type="warning" icon="oms_ico_add" title="添加子渠道" @click="toAdd" />
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="子渠道名称" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="子渠道KEY">
                    <template slot-scope="scope">KEY</template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="渠道名称" />
                <el-table-column :show-overflow-tooltip="true" width="100" prop="username" align="center" label="审核版本">
                    <template slot-scope="scope">1.0.0</template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100" prop="username" align="center" label="当前版本">
                    <template slot-scope="scope">1.0.0</template>
                </el-table-column>

                <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="创建时间" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="最后一次修改时间" />
                <el-table-column label="操作" align="center" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" class="mr-10" size="medium" @click="toEdit(scope.row)">编辑子渠道</el-button>
                        <el-button type="text" class="mr-10" size="medium" @click="toDelete(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

            <!--表单渲染-->
            <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
                <Edit v-if="drawerVisible && drawerType === 'add'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
                <Edit v-if="drawerVisible && drawerType === 'edit'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
            </Drawer>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { PAGE_SIZE, USER_TYPE, USER_TYPE_NAME } from '@/constant/common'
import Edit from './edit'
const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        Drawer,
        Edit
    },
    mixins: [Base],
    data() {
        return {
            USER_TYPE,
            USER_TYPE_NAME,
            gameList: [],
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false,
            selectsIds: [],
            batchType: ''
        }
    },
    computed: {},
    created() {},
    mounted() {
        this.gameList = this.getGameList()
        this.toQuery()
    },
    methods: {
        selectBatch() {
            if (!this.selectsIds.length) {
                return this.$message.error('请先选择数据')
            }
            return this.$message.info('todo-' + this.batchType)
        },
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },

        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '添加子渠道'
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toEdit() {
            this.drawerVisible = true
            this.drawerTitle = '编辑子渠道'
            this.drawerType = 'edit'
            this.dataObj = {}
        },
        toDelete(row) {
            this.$message.info('todo')
        }
    }
}
</script>
