<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left"></div>
                <div class="right">
                    <IconButton size="medium" type="warning" icon="oms_ico_add" title="添加区服" @click="toAdd" />
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="区服ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="区服名称" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="子渠道名称">
                    <template slot-scope="scope">KEY</template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="排序">
                    <template slot-scope="scope">
                        <i class="el-icon-rank cursor"></i>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100" prop="username" align="center" label="开启状态">
                    <template slot-scope="scope">
                        <span class="service-text-normal">正常</span>
                        <!--                        <span class="service-text-down">停服</span>-->
                        <!--                        <span class="service-text-maintain">维护</span>-->
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="100" prop="username" align="center" label="区服状态">
                    <template slot-scope="scope">
                        <el-tag type="danger">火爆</el-tag>
                        <!--                        <el-tag type="success">推荐</el-tag>-->
                        <!--                        <el-tag type="warning">即将开放</el-tag>-->
                        <!--                        <el-tag type="info">正常</el-tag>-->
                        <!--                        <el-tag>新服</el-tag>-->
                    </template>
                </el-table-column>

                <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="创建时间" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" align="center" label="最后一次修改时间" />
                <el-table-column label="操作" align="center" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" class="mr-10" size="medium" @click="toEdit(scope.row)">编辑区服</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

            <!--表单渲染-->
            <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
                <Edit v-if="drawerVisible && drawerType === 'add'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
                <Edit v-if="drawerVisible && drawerType === 'edit'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
            </Drawer>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { PAGE_SIZE, USER_TYPE, USER_TYPE_NAME } from '@/constant/common'
import Edit from './edit'
import Sortable from 'sortablejs'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        Drawer,
        Edit
    },
    mixins: [Base],
    data() {
        return {
            USER_TYPE,
            USER_TYPE_NAME,
            gameList: [],
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false,
            selectsIds: [],
            batchType: '',
            apiObjDrag: []
        }
    },
    computed: {},
    created() {
        this.$nextTick(() => {
            this.rowDrop()
        })
    },
    mounted() {
        this.gameList = this.getGameList()
        this.toQuery()
    },
    methods: {
        //行-拖拽
        rowDrop() {
            const tbody = document.querySelector('.el-table__body-wrapper tbody')
            const _this = this
            Sortable.create(tbody, {
                onEnd({ newIndex, oldIndex }) {
                    const currRow = _this.list.splice(oldIndex, 1)[0]
                    _this.list.splice(newIndex, 0, currRow)
                    //   拖动后获取newIdex
                    let arr = Array.from(_this.list)
                    _this.apiObjDrag = arr.map((item, index) => {
                        return {
                            id: item.id,
                            dictSort: index
                        }
                    })
                }
            })
        },
        selectBatch() {
            if (!this.selectsIds.length) {
                return this.$message.error('请先选择数据')
            }
            return this.$message.info('todo-' + this.batchType)
        },
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },

        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '添加区服'
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toEdit() {
            this.drawerVisible = true
            this.drawerTitle = '编辑区服'
            this.drawerType = 'edit'
            this.dataObj = {}
        }
    }
}
</script>

<style lang="scss" scoped>
.service-text-normal {
    color: #06d298;
}

.service-text-maintain {
    color: #f68915;
}

.service-text-down {
    color: #d20b06;
}
</style>
