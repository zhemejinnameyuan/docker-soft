<template>
    <div class="form-container" style="width: 620px">
        <el-form ref="form" :model="form" :rules="rules" label-width="110px">
            <div class="bg-item">
                <el-form-item label="渠道名称:" prop="name">
                    <el-input v-model="form.name" style="width: 240px" minlength="1" maxlength="10" placeholder="请输入1-10位字母或数字" autocomplete="off" />
                </el-form-item>

                <el-form-item class="mt-20" label="渠道KEY:" prop="port">
                    <el-input v-model="form.port" style="width: 240px" placeholder="请输入渠道KEY" />
                </el-form-item>

                <el-form-item class="mt-20" label="是否有版号:" prop="code">
                    <el-radio-group v-model="form.code" size="mini">
                        <el-radio label="true">有版号</el-radio>
                        <el-radio label="false">无版号</el-radio>
                    </el-radio-group>
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'

export default {
    name: 'Edit',
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {},
            rules: {
                name: [{ required: true, message: '请填写名称', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.form = { ...this.dataObj }
    },
    methods: {
        toSubmit() {
            return this.$message.info('todo')
            this.$refs.form.validate((valid) => {})
        },
        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
