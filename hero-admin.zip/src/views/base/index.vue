<script>
import { fenToYuan, yuanToFen, tableSumFixed, range, getArrayValue } from '@/utils/index'
import { filterEmpty, filterThousandths } from '@/utils/filters'
import { textColor, getPercentage, getPercentageRatio, getPercentageColor, getPercentageIcon, getPercentageBgColor } from './expand'

import checkPermission, { permission } from '@/utils/permission'
import store from '@/store'
import { GAME_LIST } from '@/constant/common'
import { getAvailableGameList, setGameID, setGameIdRedirect } from '@/utils/token'

export default {
    data() {
        return {
            permission,
            disabled: false
        }
    },

    methods: {
        checkPermission,
        textColor,
        getPercentage,
        getPercentageRatio,
        getPercentageIcon,
        getPercentageColor,
        getPercentageBgColor,
        tableSumFixed,
        getArrayValue,
        range,
        fenToYuan,
        yuanToFen,
        filterEmpty,
        filterThousandths,

        toHome() {
            window.open('/')
        },
        getUserInfo() {
            return store.getters && store.getters.userInfo
        },
        //判断用户是否是超管
        isSuperAdmin() {
            let userInfo = this.getUserInfo()
            return userInfo['userType'] === permission.admin
        },
        //获取所有游戏列表
        getGameList() {
            let gameList = []
            if (this.isSuperAdmin()) {
                for (let i in GAME_LIST) {
                    gameList.push(GAME_LIST[i])
                }
            } else {
                //普通用户,只显示用户配置的游戏
                const userAllGameList = getAvailableGameList()
                for (let i in GAME_LIST) {
                    if (_.indexOf(userAllGameList, i) !== -1) {
                        gameList.push(GAME_LIST[i])
                    }
                }
            }
            return gameList
        },
        //获取游戏信息
        getGameInfo(id) {
            return GAME_LIST[id]
        },
        //选择游戏
        selectGame(id, type) {
            //设置游戏ID
            setGameID(id)
            if (type === 'homePage') {
                //记录选择游戏状态,跳转是否判断
                setGameIdRedirect(1)
            }
            this.$router.push({ path: '/redirect' })
            window.location.reload()
        },
        copySuccess() {
            this.$message.success('复制成功')
        },
        copyError() {
            this.$message.error('复制失败')
        }
    }
}
</script>
