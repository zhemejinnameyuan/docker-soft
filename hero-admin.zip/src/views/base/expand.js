import _ from 'loadsh'

/**
 * 数字颜色
 * @param val
 * @returns {string}
 */
export function textColor(val) {
    if (val > 0) {
        return 'text_red'
    }
    if (val < 0) {
        return 'text_green'
    }
    return ''
}

/**
 * 计算百分比
 * @param num
 * @param total
 * @returns {string}
 */
export function getPercentage(num, total) {
    if (_.isNull(num) || _.isNull(total)) {
        return '--'
    }
    if (num === 0 || total === 0) {
        return '0%'
    }
    if (!_.isNull(num) && !_.isNull(total)) {
        var a = ((Math.abs(num) / Math.abs(total)) * 100).toFixed(2) + '%'
        if (num < 0) {
            a = '-' + a
        }
        return a
    }
    return '--'
}

/**
 * 计算环比
 * @param curr
 * @param before
 * @returns {string}
 */
export function getPercentageRatio(curr, before) {
    if (_.isNull(curr) || _.isNull(before)) {
        return '--'
    }
    if (curr !== before) {
        if (curr > 0 && parseInt(before) === 0) {
            return parseInt(curr * 100) + '%'
        }
        if (parseInt(curr) === 0 && before > 0) {
            return '-100%'
        }
        return (((curr - before) / before) * 100).toFixed(2) + '%'
    }
    return '持平'
}

/**
 * 环比颜色
 * @param val1
 * @param val2
 * @returns {string}
 */
export function getPercentageColor(val1, val2) {
    const val = val1 - val2
    if (val > 0) {
        return 'ring-ratio-up'
    } else if (val < 0) {
        return 'ring-ratio-down'
    }
    return ''
}

/**
 * 环比icon
 * @param val1
 * @param val2
 * @returns {string}
 */
export function getPercentageIcon(val1, val2) {
    const val = val1 - val2
    if (val > 0) {
        return 'oms_ico_shangsheng'
    } else if (val < 0) {
        return 'oms_ico_xiajiang'
    }
    return ''
}

/**
 * 获取百分比背景样式
 * @param number
 * @returns {string}
 */
export function getPercentageBgColor(number) {
    let tmp = _.floor(number / 10) * 10
    return 'bg-percentage-color-' + tmp
}
