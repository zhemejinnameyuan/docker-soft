<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left">
                    <el-select v-model="batchType" placeholder="批量操作" size="medium" class="filter-item" style="width: 160px" @change="selectBatch">
                        <el-option label="启动" :value="'up'" />
                        <el-option label="停止" :value="'down'" />
                        <el-option label="推送" :value="'push'" />
                        <el-option label="重置活动" :value="'reset_activity'" />
                        <el-option label="重置道具表" :value="'reset_props'" />
                    </el-select>
                </div>
                <div class="right">
                    <el-button size="medium" type="warning" plain @click="toSql">执行SQL</el-button>
                    <el-button size="medium" type="warning" plain @click="toMerge">合服</el-button>
                    <IconButton size="medium" type="warning" icon="oms_ico_add" title="添加服务器" @click="toAdd" />
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%" @selection-change="changeSelect">
                <el-table-column type="selection" width="55" align="center" />
                <el-table-column :show-overflow-tooltip="true" width="80" prop="id" align="center" label="服务器ID" />
                <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="服务器名称" />
                <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="客户端连接地址">
                    <template slot-scope="scope">127.0.0.1</template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="物理服务器地址">
                    <template slot-scope="scope">127.0.0.1</template>
                </el-table-column>
                <el-table-column label="合并服务器" width="100" align="center">
                    <template slot-scope="scope">--</template>
                </el-table-column>
                <el-table-column label="服务器维护状态" width="120" align="center">
                    <template slot-scope="scope">
                        <span class="service-text-normal">正常</span>
                        <!--                        <span class="service-text-down">停服</span>-->
                        <!--                        <span class="service-text-maintain">维护</span>-->
                    </template>
                </el-table-column>

                <el-table-column label="注册状态" width="120" align="center">
                    <template slot-scope="scope">
                        <div class="table_state_switch">
                            <el-switch v-model="scope.row.enableFlag" @change="toEnabled(scope.row)"></el-switch>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column label="状态" width="120" align="center">
                    <template slot-scope="scope">
                        <el-tag type="danger">火爆</el-tag>
                        <!--                        <el-tag type="success">推荐</el-tag>-->
                        <!--                        <el-tag type="warning">即将开放</el-tag>-->
                        <!--                        <el-tag type="info">正常</el-tag>-->
                        <!--                        <el-tag>新服</el-tag>-->
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="开服时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="服务器更新时间" />
                <el-table-column :show-overflow-tooltip="true" width="155" prop="createTime" align="center" label="服务器最近操作时间" />

                <el-table-column label="操作" width="200" align="center" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" class="mr-10" size="medium" @click="toDetail(scope.row)">服务器详情</el-button>
                        <el-button type="text" class="mr-10" size="medium" @click="toLog(scope.row)">日志查询</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

            <!--表单渲染-->
            <Drawer :visible.sync="drawerVisible" :title="drawerTitle">
                <Edit v-if="drawerVisible && drawerType === 'add'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
                <Merge v-if="drawerVisible && drawerType === 'merge'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Merge>
                <Sql v-if="drawerVisible && drawerType === 'sql'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Sql>
                <Detail v-if="drawerVisible && drawerType === 'detail'" :dataObj="dataObj" @toQuery="toQuery" @onClose="closeDrawer"></Detail>
            </Drawer>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { PAGE_SIZE, USER_TYPE, USER_TYPE_NAME } from '@/constant/common'
import { confirmRequest } from '@/utils'
import Edit from './edit'
import Merge from './merge'
import Sql from './sql'
import Detail from './detail'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'Index',
    components: {
        Pagination,
        Drawer,
        Edit,
        Merge,
        Sql,
        Detail
    },
    mixins: [Base],
    data() {
        return {
            USER_TYPE,
            USER_TYPE_NAME,
            gameList: [],
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerTitle: '',
            drawerVisible: false,
            selectsIds: [],
            batchType: ''
        }
    },
    computed: {},
    created() {},
    mounted() {
        this.gameList = this.getGameList()
        this.toQuery()
    },
    methods: {
        selectBatch() {
            if (!this.selectsIds.length) {
                return this.$message.error('请先选择数据')
            }
            return this.$message.info('todo-' + this.batchType)
        },
        changeSelect(val) {
            this.selectsIds = []
            val.forEach((e) => {
                this.selectsIds.push(e.id)
            })
        },
        toEnabled(data) {
            let title = '是否启用?'
            if (!data.enableFlag) {
                title = '是否禁用？'
            }
            confirmRequest(
                title,
                () => {
                    api.edit(data)
                        .then((res) => {
                            if (data.enableFlag) {
                                this.$message.success('启用成功')
                            } else {
                                this.$message.success('禁用成功')
                            }
                        })
                        .catch(() => {
                            data.enableFlag = !data.enableFlag
                        })
                },
                () => {
                    data.enableFlag = !data.enableFlag
                }
            )
        },

        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerTitle = '添加服务器'
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toSql() {
            this.drawerVisible = true
            this.drawerTitle = '执行SQL'
            this.drawerType = 'sql'
            this.dataObj = {}
        },
        toMerge() {
            this.drawerVisible = true
            this.drawerTitle = '合服'
            this.drawerType = 'merge'
            this.dataObj = {}
        },
        toDetail(row) {
            this.drawerVisible = true
            this.drawerTitle = '服务器详情'
            this.drawerType = 'detail'
            this.dataObj = row
        },
        toLog(row) {
            // this.drawerVisible = true
            // this.drawerTitle = '日志查询'
            // this.drawerType = 'log'
            // this.dataObj = row
        }
    }
}
</script>

<style lang="scss" scoped>
.service-text-normal {
    color: #06d298;
}

.service-text-maintain {
    color: #f68915;
}

.service-text-down {
    color: #d20b06;
}
</style>
