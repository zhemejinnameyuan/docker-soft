<template>
    <div class="form-container" style="width: 620px">
        <el-form ref="form" :model="form" :rules="rules" label-width="140px">
            <div class="bg-item">
                <el-form-item label="服务器:" prop="name">
                    <el-select v-model="form.serverId" size="medium" class="filter-item" style="width: 240px" multiple>
                        <el-option label="1" :value="1" />
                        <el-option label="2" :value="2" />
                        <el-option label="3" :value="3" />
                    </el-select>
                </el-form-item>

                <el-form-item label="请输入SQL:" prop="name">
                    <el-input v-model="form.port" type="textarea" style="width: 240px" rows="5" placeholder="请输入sql" />
                </el-form-item>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import Base from '@/views/base'

export default {
    name: 'Merge',
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {},
            rules: {
                name: [{ required: true, message: '请填写服务器名称', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.form = { ...this.dataObj }
    },
    methods: {
        toSubmit() {
            return this.$message.info('todo')
            this.$refs.form.validate((valid) => {})
        },
        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
