<template>
    <div class="form-container" style="width: 900px">
        <el-form class="detail-form" ref="form" :model="form" label-width="100px" label-position="right">
            <div class="dp-f">
                <div>
                    <div class="dp-f-vertical-center">
                        <div class="item_title">服务器详情</div>
                        <div class="ml-10">
                            <el-tag type="success">正常</el-tag>
                        </div>
                    </div>
                    <div class="bg-item mt-10" style="width: 400px">
                        <el-form-item label="服务器名称:">
                            <span class="des_title">服务器名称1111222</span>
                        </el-form-item>
                        <el-form-item label="实际服务器ID:">
                            <span class="des_title">1</span>
                        </el-form-item>
                    </div>
                </div>

                <div class="ml-20">
                    <div class="item_title">服务器监控信息</div>
                    <div class="bg-item mt-10" style="width: 400px">
                        <el-form-item label="当前在线人数:">
                            <span class="des_title">1123</span>
                        </el-form-item>
                        <el-form-item label="总内存:">
                            <span class="des_title">100MB</span>
                        </el-form-item>
                    </div>
                </div>
            </div>

            <div class="mt-20">
                <div class="item_title">服务器详情</div>
                <div class="mt-10">
                    <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                        <el-table-column :show-overflow-tooltip="true" width="80" prop="id" align="center" label="角色ID" />
                        <el-table-column :show-overflow-tooltip="true" width="120" prop="name" align="center" label="角色名称" />
                        <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="GM权限" />
                        <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="禁言状态" />
                        <el-table-column :show-overflow-tooltip="true" width="120" prop="username" align="center" label="封禁状态" />

                        <el-table-column label="操作" width="200" align="center" fixed="right">
                            <template slot-scope="scope">
                                <el-tag class="cursor ml-5 mr-5" @click="toAction(scope.row)">下线</el-tag>
                                <el-tag class="cursor ml-5 mr-5" @click="toAction(scope.row)" type="warning">禁言</el-tag>
                                <el-tag class="cursor ml-5 mr-5" @click="toAction(scope.row)" type="danger">封禁</el-tag>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />
                </div>
            </div>
        </el-form>
    </div>
</template>

<script>
import Pagination from '@/components/Pagination'
import Base from '@/views/base'

export default {
    name: 'Edit',
    mixins: [Base],
    components: { Pagination },
    props: {
        dataObj: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            form: {},
            total: 0,
            list: [
                {
                    id: 1,
                    name: 'name'
                }
            ]
        }
    },
    mounted() {
        this.form = { ...this.dataObj }
    },
    methods: {
        toQuery() {},
        toAction() {
            return this.$message.info('todo')
        },
        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>
