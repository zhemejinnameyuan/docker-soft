<template>
    <div class="app-container role">
        <div class="bg-container">
            <!--工具栏-->
            <div style="padding-top: 20px">
                <el-row>
                    <el-col :xs="24" :sm="24" :md="16" :lg="16" :xl="17" class="role-col">
                        <IconButton v-permission="[permission.roleSave]" size="medium" type="warning" icon="oms_ico_add" title="添加角色" @click="toAdd" />
                    </el-col>
                </el-row>
            </div>
            <!-- 表单渲染 -->
            <el-dialog append-to-body :close-on-click-modal="false" :before-close="toCancel" :visible.sync="dialogVisible" :title="dialogTitle" width="520px">
                <el-form ref="form" :inline="true" :model="form" :rules="rules" size="small" label-width="100px">
                    <el-form-item label="角色名称" prop="name">
                        <el-input v-model="form.name" maxlength="12" minlength="2" placeholder="请输入2-12个字" show-word-limit style="width: 280px" />
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button type="info" plain @click="toCancel">取消</el-button>
                    <el-button type="warning" @click="toSubmit">确认</el-button>
                </div>
            </el-dialog>
            <el-row :gutter="15">
                <!--角色管理-->
                <el-col :xs="24" :sm="24" :md="16" :lg="16" :xl="17" style="margin-bottom: 10px">
                    <el-table ref="table" v-loading="loading" class="game-table" highlight-current-row style="width: 100%" :data="list" @current-change="handleCurrentChange">
                        <el-table-column prop="id" width="100" label="ID" align="center" />
                        <el-table-column prop="name" label="角色" width="200" align="center" />
                        <el-table-column :show-overflow-tooltip="true" width="200" prop="createTime" label="创建时间" align="center" />
                        <el-table-column :show-overflow-tooltip="true" width="200" prop="updateTime" label="修改时间" align="center" />
                        <el-table-column prop="operator" label="操作人" width="155" align="center" />
                        <el-table-column label="操作" width="200" align="center" fixed="right">
                            <template slot-scope="scope">
                                <el-button type="text" class="mr-10" size="medium" @click="toEdit(scope.row)">编辑角色</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页组件-->
                    <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery" />
                </el-col>
                <!-- 菜单授权 -->
                <el-col v-if="currentId" :xs="24" :sm="24" :md="8" :lg="8" :xl="7">
                    <el-card class="box-card" shadow="never">
                        <div slot="header" class="clearfix">
                            <el-tooltip class="item" effect="dark" content="选择指定角色分配菜单" placement="top">
                                <span class="role-span">菜单分配</span>
                            </el-tooltip>
                            <el-button v-permission="[permission.roleSave]" :loading="menuLoading" size="medium" style="float: right; padding: 6px 9px" type="warning" @click="saveMenu">
                                确 定
                            </el-button>
                        </div>
                        <el-tree ref="menu" :data="menus" :default-checked-keys="menuIds" :props="defaultProps" show-checkbox node-key="id" />
                    </el-card>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/role'
import * as apiMenu from '@/api/auth/menu'
import { PAGE_SIZE } from '@/constant/common'
import Pagination from '@/components/Pagination'
import Base from '@/views/base'

const defaultForm = {
    page: 1,
    size: PAGE_SIZE,
    id: null,
    name: null,
    description: null
}
export default {
    name: 'Role',
    components: { Pagination },
    mixins: [Base],
    data() {
        return {
            list: [],
            dialogTitle: '',

            loading: false,
            query: defaultForm,
            dialogVisible: false,
            currentId: 0,
            menuLoading: false,
            menus: [],
            menuIds: [],
            defaultProps: {
                children: 'children',
                label: 'title',
                isLeaf: function (data, node) {
                    return !data.hasChildren
                }
            },
            rules: {
                name: [
                    { required: true, message: '请输入2-12个字', trigger: 'blur', min: 2, max: 12 },
                    { pattern: /^[a-zA-Z0-9\u4e00-\u9fa5]+$/, message: '只能输入中文、字母和数字', trigger: 'blur' }
                ]
            },
            form: {
                name: null,
                id: null
            },
            total: 0
        }
    },
    mounted() {
        this.toQuery()
        this.getMenuData()
    },
    methods: {
        toQuery() {
            if (this.checkPermission([this.permission.roleList])) {
                this.loading = true
                api.queryRole(this.query)
                    .then((res) => {
                        this.list = res.data
                        this.total = res.page.tc
                        this.loading = false
                    })
                    .catch(() => {
                        this.loading = false
                    })
            }
        },
        getMenuData() {
            setTimeout(() => {
                if (this.checkPermission([this.permission.menuList])) {
                    apiMenu.queryMenu().then((res) => {
                        this.menus = res.data
                    })
                }
            }, 100)
        },

        //角色点击,菜单分配
        handleCurrentChange(val) {
            if (val) {
                this.currentId = val.id
                this.$nextTick(() => {
                    this.$refs.menu.setCheckedKeys([])
                    this.selectId(val.menus)
                })
            }
        },
        //渲染菜单
        selectId(menus) {
            this.menuIds = []
            const lastIds = []
            const getMenuItem = function (menu) {
                for (let index = 0; index < menu.length; index++) {
                    const element = menu[index]
                    if (!element.hasChildren) {
                        lastIds.push(element.id)
                    } else {
                        getMenuItem(element.children)
                    }
                }
            }
            getMenuItem(this.menus)
            menus &&
                menus.forEach((item) => {
                    const tag = lastIds.find((a) => item.id === a)
                    if (tag) {
                        this.menuIds.push(tag)
                    }
                })
        },
        //新增角色
        saveMenu() {
            const arr1 = this.$refs.menu.getHalfCheckedKeys()
            const arr2 = this.$refs.menu.getCheckedKeys()
            const menuIds = arr1.concat(arr2)
            this.menuLoading = true
            const role = { roleId: this.currentId, menuId: menuIds }
            api.relationMenu(role)
                .then(() => {
                    this.menuLoading = false
                    this.updateMenu()
                    this.$message.success('保存成功')
                })
                .catch(() => {
                    this.menuLoading = false
                })
        },
        //编辑角色
        updateMenu() {
            api.queryRole({ id: this.currentId }).then((res) => {
                for (let i = 0; i < this.list.length; i++) {
                    if (res.data[0].id === this.list[i].id) {
                        this.list[i] = res.data[0]
                        break
                    }
                }
            })
        },
        toAdd() {
            this.form.name = ''
            this.form.id = null
            this.dialogTitle = '添加角色'
            this.dialogVisible = true
        },
        toEdit(data) {
            this.form.name = data.name
            this.form.id = data.id
            this.dialogTitle = '编辑角色'
            this.dialogVisible = true
        },
        toCancel() {
            this.dialogVisible = false
        },
        //提交
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.dialogTitle === '添加角色') {
                        api.add(this.form)
                            .then(() => {
                                this.$message.success('操作成功')
                                this.toQuery()
                                this.toCancel()
                            })
                            .catch(() => {
                                this.toCancel()
                            })
                    } else {
                        api.edit(this.form)
                            .then(() => {
                                this.$message.success('操作成功')
                                this.toQuery()
                                this.toCancel()
                            })
                            .catch(() => {
                                this.toCancel()
                            })
                    }
                }
            })
        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.role {
    .mr-10 {
        margin-right: 10px;
    }
    .role-span {
        font-weight: bold;
        color: #303133;
        font-size: 15px;
    }

    .role-col {
        display: flex;
        justify-content: flex-end;
        margin-bottom: 10px;
        padding-right: 7px;
    }
    .op-button {
        margin-left: 10px;
        font-size: 20px;
    }

    ::v-deep {
        .el-card__body {
            background: #f7f7f7;
        }
        .el-card__header {
            background: #e9fafd;
            border-bottom: 0px solid #ebeef5;
        }
        .el-tree {
            background: #f7f7f7;
        }
        .el-card {
            border: 0px solid #000000;
        }
    }
}
</style>
