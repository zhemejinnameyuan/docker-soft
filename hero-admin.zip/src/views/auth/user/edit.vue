<template>
    <div class="form-container" style="width: 620px">
        <el-form ref="form" :model="form" :rules="rules" label-width="90px">
            <div class="bg-item">
                <el-form-item label="账号:" prop="username">
                    <el-input
                        v-model="form.username"
                        minlength="6"
                        maxlength="12"
                        style="width: 240px"
                        placeholder="请输入6-12位字母或数字"
                        autocomplete="off"
                        :disabled="editType === 'edit'"
                        :readonly="editType === 'edit'"
                    />
                </el-form-item>

                <el-form-item class="mt-20" label="密码:" prop="showPassword">
                    <el-input v-model="form.showPassword" type="password" minlength="6" maxlength="12" style="width: 240px" placeholder="请输入6-12位密码" autocomplete="new-password" />
                </el-form-item>
            </div>

            <div class="split-line mt-30 mb-30" style="width: 540px" />

            <div>
                <label>编辑用户项目权限</label>
                <div class="mt-30 ml-40">
                    <el-radio v-model="form.userType" :label="USER_TYPE.SUPER_ADMIN">
                        设置为超级管理员
                        <el-tooltip class="icon" effect="dark" content="超级管理员:拥有项目对所有权限" placement="top-start">
                            <svg-icon icon-class="oms_ico_query" style="height: 14px; width: 14px" />
                        </el-tooltip>
                    </el-radio>
                    <el-radio v-model="form.userType" :label="USER_TYPE.PROJECT_USER">设置为项目成员</el-radio>
                </div>
            </div>

            <div class="mt-40">
                <div class="admin-content" v-if="form.userType === USER_TYPE.SUPER_ADMIN">该用户是超级管理员，拥有所有权限。</div>

                <div class="normal-user-content" v-if="form.userType === USER_TYPE.PROJECT_USER">
                    <div class="text-gray fs-14 dp-f-center">您可以修改以下权限</div>

                    <div class="mt-20 ml-40 dp-f-vertical-center" v-for="item in gameList" :key="item.id">
                        <el-checkbox v-model="gameIds[item.id]">
                            <div class="dp-f-vertical-center">
                                <img :src="item.logoUrl" class="mr-5" />
                                {{ item.title }}
                            </div>
                        </el-checkbox>

                        <el-select v-model="gameRoles[item.id]" style="margin-left: 210px">
                            <el-option v-for="(item2, index2) in roleList" :key="index2" :label="item2.name" :value="item2.id" />
                        </el-select>
                    </div>
                </div>
            </div>
        </el-form>
        <div class="dp-f-reverse" style="margin-top: 100px">
            <el-button type="warning" size="medium" @click="toSubmit">确 定</el-button>
            <el-button class="mr-10" size="medium" type="info" plain @click="toCancel">取 消</el-button>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import * as apiRole from '@/api/auth/role'
import { rsaEncrypt } from '@/utils/rsaEncrypt'
import Base from '@/views/base'
import { USER_TYPE } from '@/constant/common'

export default {
    name: 'Edit',
    mixins: [Base],
    props: {
        dataObj: {
            type: Object,
            required: true
        },
        editType: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            USER_TYPE,
            gameList: [],
            gameId: {},
            gameAuth: {},
            form: {
                roles: []
            },
            roleList: [],
            gameIds: [],
            gameRoles: [],
            rules: {
                username: [
                    { required: true, message: '请输入账号', trigger: 'blur' },
                    { pattern: /^[a-zA-Z0-9_]+$/, message: '只能输入字母或数字', trigger: 'blur' },
                    { min: 6, max: 12, message: '长度在 6 到 12 个字符', trigger: 'blur' }
                ],
                showPassword: [
                    { required: this.editType === 'add', message: '请输入密码', trigger: 'blur' },
                    { min: 6, max: 18, message: '密码长度在 6 到 18 个字符', trigger: 'blur' }
                ],
                roles: [{ required: true, message: '请选择角色', trigger: 'blur' }]
            }
        }
    },
    mounted() {
        this.$nextTick(() => {
            this.gameList = this.getGameList()
            this.getRoles()
        })

        this.form = { ...this.dataObj }

        //处理已选择的权限
        if (this.form.roles && this.form.roles.length > 0) {
            this.form.roles.forEach((res) => {
                this.gameIds[res.projectId] = true
                this.gameRoles[res.projectId] = res.id
            })
        }
    },
    methods: {
        getRoles() {
            apiRole.queryRole({ all: true }).then((res) => {
                this.roleList = res.data
            })
        },
        toSubmit() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    const data = { ...this.form }
                    if (data.roles) {
                        data.roles = [{ id: data.roles }]
                    }

                    if (data.showPassword) {
                        data.showPassword = rsaEncrypt(data.showPassword)
                    }

                    //处理权限
                    let newRoles = []
                    if (data.userType === USER_TYPE.PROJECT_USER) {
                        this.gameList.forEach((res) => {
                            if (this.gameIds[res.id] && this.gameRoles[res.id]) {
                                newRoles.push({ id: this.gameRoles[res.id], projectId: res.id })
                            }
                        })
                        if (newRoles.length === 0) {
                            return this.$message.error('项目成员需设置权限')
                        }
                    }
                    data.roles = newRoles

                    if (this.editType === 'add') {
                        api.add(data).then((res) => {
                            this.$message.success('添加成功')
                            this.toCancel()
                            this.$emit('toQuery')
                        })
                    } else {
                        api.edit(data).then((res) => {
                            this.$message.success('修改成功')
                            this.toCancel()
                            this.$emit('toQuery')
                        })
                    }
                }
            })
        },
        toCancel() {
            this.$emit('onClose')
        }
    }
}
</script>

<style scoped lang="scss">
.admin-content {
    border: 1px solid rgba(227, 225, 224, 1);
    border-radius: 4px;
    padding: 20px 25px 20px 25px;

    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #6f6c65;
    font-weight: 400;
}

.normal-user-content {
    border: 1px solid rgba(227, 225, 224, 1);
    border-radius: 4px;
    padding: 20px 25px 20px 25px;
}
</style>
