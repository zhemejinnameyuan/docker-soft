<template>
    <div class="app-container">
        <div class="bg-container">
            <!--工具栏-->
            <div class="search-container p-20">
                <div class="left"></div>
                <div class="right">
                    <IconButton v-permission="[permission.userSave]" size="medium" type="warning" icon="oms_ico_add" title="添加账号" @click="toAdd" />
                </div>
            </div>
            <!--表格渲染-->
            <el-table ref="table" v-loading="loading" class="game-table" :data="list" style="width: 100%">
                <el-table-column :show-overflow-tooltip="true" width="100" prop="id" align="center" label="ID" />
                <el-table-column :show-overflow-tooltip="true" width="200" prop="username" align="center" label="账号" />
                <el-table-column :show-overflow-tooltip="true" width="250" prop="username" align="center" label="账号类型">
                    <template slot-scope="scope">
                        <span>{{ getArrayValue(USER_TYPE_NAME, scope.row.userType) }}</span>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200" label="项目" align="center">
                    <template slot-scope="scope">
                        <div v-if="scope.row.userType === USER_TYPE.SUPER_ADMIN">所有项目</div>

                        <div v-else class="cursor">
                            <el-popover placement="bottom" width="200" trigger="hover">
                                <div v-for="(item, index) in scope.row.roles" :key="index">
                                    <div class="dp-f-space-between mb-10 mt-10">
                                        <div class="dp-f-vertical-center">
                                            <img :src="getGameInfo(item.projectId)['logoUrl']" class="mr-5" />
                                            {{ getGameInfo(item.projectId)['title'] }}
                                        </div>

                                        <div>{{ item.name }}</div>
                                    </div>
                                </div>

                                <span slot="reference">{{ scope.row.roles.length }}个项目</span>
                            </el-popover>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :show-overflow-tooltip="true" width="200" prop="updateTime" align="center" label="最后活动时间" />
                <el-table-column label="状态" align="center" prop="enableFlag">
                    <template slot-scope="scope">
                        <div class="table_state_switch">
                            <el-switch v-model="scope.row.enableFlag" @change="toEnabled(scope.row)"></el-switch>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="200" align="center" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="text" size="medium" v-permission="[permission.userSave]" @click="toEdit(scope.row)">编辑账号</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--分页组件-->
            <Pagination v-if="list.length" :total="total" :query="query" @pageChangeHandler="toQuery(true)" />

            <!--表单渲染-->
            <Drawer :visible.sync="drawerVisible" :title="drawerType === 'edit' ? '编辑账号' : '添加账号'">
                <Edit v-if="drawerVisible" :dataObj="dataObj" :edit-type="drawerType" @toQuery="toQuery" @onClose="closeDrawer"></Edit>
            </Drawer>
        </div>
    </div>
</template>

<script>
import * as api from '@/api/auth/user'
import Pagination from '@/components/Pagination'
import Drawer from '@/components/Drawer'
import Base from '@/views/base'
import { PAGE_SIZE, USER_TYPE, USER_TYPE_NAME } from '@/constant/common'
import { confirmRequest } from '@/utils'
import Edit from './edit'

const defaultQuery = {
    page: 1,
    size: PAGE_SIZE,
    sort: 'createTime;asc',
    createTime: []
}
export default {
    name: 'User',
    components: {
        Pagination,
        Drawer,
        Edit
    },
    mixins: [Base],
    data() {
        return {
            USER_TYPE,
            USER_TYPE_NAME,
            gameList: [],
            dataObj: {},
            list: [],
            loading: false,
            total: 0,
            query: defaultQuery,
            drawerType: '',
            drawerVisible: false
        }
    },
    computed: {},
    created() {},
    mounted() {
        this.gameList = this.getGameList()
        this.toQuery()
    },
    methods: {
        toEnabled(data) {
            let title = '是否确定启用该用户?'
            if (!data.enableFlag) {
                title = '禁用后该用户无法登录，并且无法正常使用后台功能，是否确定禁用该用户？'
            }
            confirmRequest(
                title,
                () => {
                    api.edit(data)
                        .then((res) => {
                            if (data.enableFlag) {
                                this.$message.success('启用成功')
                            } else {
                                this.$message.success('禁用成功')
                            }
                        })
                        .catch(() => {
                            data.enableFlag = !data.enableFlag
                        })
                },
                () => {
                    data.enableFlag = !data.enableFlag
                }
            )
        },

        toQuery(page) {
            if (!page) {
                this.query.page = 1
            }
            this.loading = true
            api.list(this.query)
                .then((rep) => {
                    //权限按项目ID排序
                    for (let i = 0; i < rep.data.length; i++) {
                        rep.data[i].roles = _.sortBy(rep.data[i].roles, function (o) {
                            return o.projectId
                        })
                    }

                    this.list = rep.data
                    this.total = rep.page.tc
                    this.loading = false
                })
                .catch(() => {
                    this.loading = false
                })
        },
        closeDrawer() {
            this.drawerVisible = false
        },
        toAdd() {
            this.drawerVisible = true
            this.drawerType = 'add'
            this.dataObj = {}
        },
        toEdit(row) {
            this.drawerVisible = true
            this.drawerType = 'edit'
            this.dataObj = row
        }
    }
}
</script>
