<script>
export default {
    created() {
        //根据用户所选项目,自动跳转到第一个路由
        //排除固定路由,所以取第6个
        let firstPath = this.$router.getRoutes()[6]

        console.log(this.$router.getRoutes())
        this.$router.push({ path: firstPath.path })
    },
    render: function (h) {
        return h() // avoid warning message
    }
}
</script>
