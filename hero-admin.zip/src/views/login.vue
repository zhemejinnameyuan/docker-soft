<template>
    <div class="container" :style="'background-image:url(' + Background + ');'">
        <div class="big-title">游戏管理后台</div>
        <div class="login-container">
            <el-form ref="loginForm" :model="loginForm" :rules="loginRules" label-position="left" label-width="0px" class="login-form">
                <span class="welcome-title">欢迎登录</span>

                <div class="input-box">
                    <el-form-item prop="username">
                        <svg-icon icon-class="gameoms_login_ico_ac" style="width: 18px; height: 20px"></svg-icon>
                        <el-input v-model="loginForm.username" maxlength="32" type="text" autocomplete="new-password" placeholder="输入账号" />
                    </el-form-item>
                    <el-form-item prop="password">
                        <svg-icon icon-class="gameoms_login_ico_pw" style="width: 18px; height: 20px"></svg-icon>
                        <el-input v-model="loginForm.password" maxlength="64" type="password" autocomplete="new-password" placeholder="输入密码" show-password @keyup.enter.native="handleLogin" />
                    </el-form-item>
                    <el-form-item prop="code">
                        <svg-icon icon-class="gameoms_login_ico_code" style="width: 18px; height: 20px"></svg-icon>
                        <el-input v-model="loginForm.code" maxlength="6" auto-complete="off" placeholder="输入验证码" @keyup.enter.native="submitLogin" style="width: 260px" />
                        <img v-if="captchaImg" :src="captchaImg" height="36px" width="120px" @click="getCode" alt="code" />
                    </el-form-item>
                </div>
                <el-form-item>
                    <el-button :loading="loading" size="medium" class="login-btn" @click.native.prevent="submitLogin">
                        <span v-if="!loading" style="color: #ffffff">登 录</span>
                        <span v-else style="color: #ffffff">登 录 中...</span>
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
import Background from '@/assets/images/gameoms_bg_login.png'
import * as api from '@/api/auth'
import { rsaEncrypt } from '@/utils/rsaEncrypt'

export default {
    name: 'Login',
    data() {
        return {
            Background: Background,
            captchaImg: '',
            cookiePass: '',
            loginForm: {
                username: '',
                password: '',
                rememberMe: false,
                code: '',
                key: ''
            },
            loginRules: {
                username: [{ required: true, trigger: 'blur', message: '账号不能为空' }],
                password: [{ required: true, trigger: 'blur', message: '密码不能为空' }],
                code: [{ required: true, trigger: 'change', message: '验证码不能为空' }]
            },
            loading: false,
            redirect: undefined
        }
    },
    watch: {
        $route: {
            handler: function (route) {
                this.redirect = route.query && route.query.redirect
            },
            immediate: true
        }
    },
    created() {
        this.getCode()
    },
    methods: {
        getCode() {
            api.getCaptcha().then((res) => {
                this.captchaImg = res.data.img
                this.loginForm.key = res.data.key
            })
        },
        submitLogin() {
            this.$refs.loginForm.validate((valid) => {
                const loginInfo = {
                    username: this.loginForm.username,
                    password: this.loginForm.password,
                    rememberMe: this.loginForm.rememberMe,
                    code: this.loginForm.code,
                    key: this.loginForm.key
                }
                if (loginInfo.password !== this.cookiePass) {
                    loginInfo.password = rsaEncrypt(loginInfo.password)
                }
                if (valid) {
                    this.loading = true
                    this.$store
                        .dispatch('Login', loginInfo)
                        .then(() => {
                            this.loading = false
                            this.$router.push({ path: '/' })
                            // this.$router.push({ path: this.redirect || '/' })
                        })
                        .catch((e) => {
                            this.loading = false
                        })
                } else {
                    return false
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
.container {
    height: 100%;
    background-size: cover;
    display: flex;

    .big-title {
        margin-top: 40px;
        margin-left: 60px;
        font-family: HiraginoSansCNS-W6;
        font-size: 40px;
        color: #1a1a19;
        font-weight: 600;
        width: 240px;
        height: 56px;
        white-space: nowrap;
    }

    .login-container {
        width: 100vw;
        height: 100%;
        display: flex;
        align-items: center;

        .login-form {
            margin: 0 auto;
            padding-left: 250px;

            .welcome-title {
                margin-left: 120px;
                text-align: center;
                font-family: PingFangSC-Semibold;
                font-size: 40px;
                color: #1a1a19;
                line-height: 40px;
                font-weight: 600;
            }

            .welcome-title:after {
                margin-left: 120px;
                margin-bottom: 45px;
                content: '';
                display: block;
                margin-top: 10px;
                height: 4px;
                width: 160px;
                background-image: linear-gradient(269deg, #f8e38e 1%, #f2cc69 100%);
                border-radius: 2px;
            }

            .input-box {
                .el-form-item {
                    height: 68px;
                }
                ::v-deep {
                    .el-input {
                        width: 380px;
                        height: 50px;
                        font-size: 18px;
                    }

                    .el-input__inner {
                        height: 50px;
                        background: #ffffff;
                        border: 0;
                        border-radius: 8px;
                    }

                    .el-form-item__content {
                        border-bottom: 1px solid rgba(111, 108, 101, 0.4);
                    }
                }
            }

            .login-btn {
                width: 400px;
                height: 50px;
                font-size: 20px;
                font-weight: 500;
                background-image: radial-gradient(circle at 50% 50%, #ffbc17 0%, #f68915 394%);
                border-radius: 4px;
                margin-top: 25px;
            }
        }
    }
}
</style>
