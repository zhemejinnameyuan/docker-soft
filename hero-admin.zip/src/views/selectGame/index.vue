<template>
    <div class="app-wrapper">
        <div class="main-container" style="margin-left: 0px; height: 100%" v-if="selectGameStatus !== '1'">
            <navbar />
            <div class="select-game-container" :style="'background-image:url(' + Background + ');'">
                <div class="game-items" v-for="item in gameList" :key="item.id" :title="item.title" @click="selectGame(item.id, 'homePage')">
                    <img :src="item.imgUrl" />
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Background from '@/assets/images/gameoms_bg_select.png'
import Navbar from './navbar'
import Base from '@/views/base'
import { getGameIdRedirect, setGameIdRedirect } from '@/utils/token'
export default {
    name: 'SelectGame',
    mixins: [Base],
    components: {
        Navbar
    },
    data() {
        return {
            Background: Background,
            selectGameStatus: '0',
            gameList: []
        }
    },
    created() {
        this.selectGameStatus = getGameIdRedirect()

        if (this.selectGameStatus === '1') {
            setGameIdRedirect('0')
            this.$router.push({ path: '/redirect' })
        } else {
            this.gameList = this.getGameList()
        }
    },
    methods: {}
}
</script>

<style lang="scss" scoped>
@import '~@/assets/styles/element/variables.scss';

.app-wrapper {
    position: relative;
    height: 100%;
    width: 100%;

    &.mobile.openSidebar {
        position: fixed;
        top: 0;
    }
}

.select-game-container {
    height: calc(100% - #{$navBarHeught});
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;

    .game-items {
        margin: 0 40px 0 40px;
        img {
            height: 560px;
            width: 420px;
        }
        :hover {
            box-shadow: 0px 0px 18px 2px rgba(0, 60, 8, 0.25);
            border-radius: 15px;
            cursor: pointer;
        }
    }
}
</style>
