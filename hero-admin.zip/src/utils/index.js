import { MessageBox } from 'element-ui'
import _ from 'loadsh'
import FileSaver from 'file-saver'
import * as XLSX from 'xlsx'

/**
 * Parse the time to string
 * @param {(Object|string|number)} time
 * @param {string} cFormat
 * @returns {string}
 */

export function parseTime(time, cFormat) {
    if (arguments.length === 0) {
        return null
    }
    const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
    let date
    if (typeof time === 'undefined' || time === null || time === 'null') {
        return ''
    } else if (typeof time === 'object') {
        date = time
    } else {
        if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
            time = parseInt(time)
        }
        if (typeof time === 'number' && time.toString().length === 10) {
            time = time * 1000
        }
        date = new Date(time)
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay()
    }
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key]
        // Note: getDay() returns 0 on Sunday
        if (key === 'a') {
            return ['日', '一', '二', '三', '四', '五', '六'][value]
        }
        if (result.length > 0 && value < 10) {
            value = '0' + value
        }
        return value || 0
    })
    return time_str
}

/**
 * @param {number} time
 * @param {string} option
 * @returns {string}
 */
export function formatTime(time, option) {
    if (('' + time).length === 10) {
        time = parseInt(time) * 1000
    } else {
        time = +time
    }
    const d = new Date(time)
    const now = Date.now()

    const diff = (now - d) / 1000

    if (diff < 30) {
        return '刚刚'
    } else if (diff < 3600) {
        // less 1 hour
        return Math.ceil(diff / 60) + '分钟前'
    } else if (diff < 3600 * 24) {
        return Math.ceil(diff / 3600) + '小时前'
    } else if (diff < 3600 * 24 * 2) {
        return '1天前'
    }
    if (option) {
        return parseTime(time, option)
    } else {
        return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
    }
}

/**
 * This is just a simple version of deep copy
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 * @param {Object} source
 * @returns {Object}
 */
export function deepClone(source) {
    if (!source && typeof source !== 'object') {
        throw new Error('error arguments', 'deepClone')
    }
    const targetObj = source.constructor === Array ? [] : {}
    Object.keys(source).forEach((keys) => {
        if (source[keys] && typeof source[keys] === 'object') {
            targetObj[keys] = deepClone(source[keys])
        } else {
            targetObj[keys] = source[keys]
        }
    })
    return targetObj
}

/**
 * Check if an element has a class
 * @param {HTMLElement} elm
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass(ele, cls) {
    return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'))
}

/**
 * Add class to element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function addClass(ele, cls) {
    if (!hasClass(ele, cls)) ele.className += ' ' + cls
}

/**
 * Remove class from element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function removeClass(ele, cls) {
    if (hasClass(ele, cls)) {
        const reg = new RegExp('(\\s|^)' + cls + '(\\s|$)')
        ele.className = ele.className.replace(reg, ' ')
    }
}

/**
 * 封装 confirm 确认框
 * @param title
 * @param callbackFunction
 * @param catchCallback
 */
export function confirmRequest(title = '确定要操作吗?', callbackFunction, catchCallback) {
    MessageBox.confirm(title, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
    })
        .then(callbackFunction)
        .catch(catchCallback)
}

// 下载文件
export function downloadFile(obj, name, suffix) {
    const url = window.URL.createObjectURL(new Blob([obj]))
    const link = document.createElement('a')
    link.style.display = 'none'
    link.href = url
    const fileName = parseTime(new Date()) + '-' + name + '.' + suffix
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
}

//表格汇总小数点
export function tableSumFixed(param) {
    const { columns, data } = param
    const sums = []
    columns.forEach((column, index) => {
        if (index === 0) {
            sums[index] = '汇总'
            return
        }
        const values = data.map((item) => Number(item[column.property]))
        if (!values.every((value) => isNaN(value))) {
            sums[index] = values
                .reduce((prev, curr) => {
                    const value = Number(curr)
                    if (!isNaN(value)) {
                        return prev + curr
                    } else {
                        return prev
                    }
                }, 0)
                .toFixed(2)
        }
    })
    return sums
}

//生成范围内的数组
export function range(start, end, step = 1) {
    let arr = []
    for (let i = start; i <= end; i++) {
        if (i % step === 0) {
            arr.push(i)
        }
    }
    return arr
}

//获取数组对应的值
export function getArrayValue(name, index) {
    return name[index] ? name[index] : ''
}

//分转元
export function fenToYuan(fen) {
    return (fen / 100).toFixed(2)
}

//元转分
export function yuanToFen(yuan) {
    return (yuan * 100).toFixed(0)
}

//字符串转json
export function stringToJson(jsonString) {
    return jsonString ? JSON.parse(jsonString) : []
}

/**
 * 节流
 * @param fnName
 * @param time
 * @returns {(function(): void)|*}
 */
export function throttle(fnName, time) {
    let timeout = null
    let flag = true
    return function () {
        if (flag === true) {
            this[fnName]()
            flag = false
        } else {
            if (timeout) {
                clearTimeout(timeout)
            }
            timeout = setTimeout(() => {
                this[fnName]()
            }, time)
        }
    }
}

/**
 * 生成00-24小时节点
 */
export function createHourData() {
    return [
        '00:00',
        '01:00',
        '02:00',
        '03:00',
        '04:00',
        '05:00',
        '06:00',
        '07:00',
        '08:00',
        '09:00',
        '10:00',
        '11:00',
        '12:00',
        '13:00',
        '14:00',
        '15:00',
        '16:00',
        '17:00',
        '18:00',
        '19:00',
        '20:00',
        '21:00',
        '22:00',
        '23:00'
    ]
}

/**
 * 数组累计
 * exp [1,1,2,5,6] => [1,2,4,9,15]
 */
export function grandTotalData(arr) {
    if (!_.isArray(arr)) {
        return []
    }
    for (let i in arr) {
        let index = _.toNumber(i)
        if (index === 0) {
            continue
        }
        arr[i] = _.add(arr[index], arr[index - 1])
    }
    return arr
}

/**
 * 处理数据并下载excel
 * @param header
 * @param header_zh
 * @param exportData
 * @param fileName
 * exp
    // const header = ['date', 'count']
    // const headerZh = {
    //     date: '日期',
    //     count: '次数'
    // }
    // downloadCsv(header, headerZh, this.tableData, '在线人数')
 */
export function downloadExcel(header, header_zh, exportData, fileName = '数据') {
    const workbook = XLSX.utils.book_new()
    const worksheet = XLSX.utils.json_to_sheet([header_zh, ...exportData], { header: header, skipHeader: true })

    XLSX.utils.book_append_sheet(workbook, worksheet, 'sheet')
    XLSX.writeFile(workbook, fileName + '.csv')
}

/**
 * 下载excel,table内容直接导出
 * @param content
 * @param fileName
 */
export function downloadExcelByElement(content, fileName = '数据') {
    const wb = XLSX.utils.table_to_book(content)
    const wbout = XLSX.write(wb, {
        bookType: 'csv',
        bookSST: true,
        type: 'array'
    })
    try {
        FileSaver.saveAs(new Blob([wbout], { type: 'text/csv' }), fileName + '.csv')
    } catch (e) {
        if (typeof console !== 'undefined') console.log(e, wbout)
    }
}

/**
 * 秒转天/小时/分/秒
 * @param seconds
 * @returns {string}
 */
export function formatSecondToStr(seconds) {
    let daySec = 86400
    let hourSec = 3600
    let minuteSec = 60
    let dd = Math.floor(seconds / daySec)
    let hh = Math.floor((seconds % daySec) / hourSec)
    let mm = Math.floor((seconds % hourSec) / minuteSec)
    let ss = seconds % minuteSec
    if (dd > 0) {
        return dd + '天' + hh + '小时' + mm + '分钟' + ss + '秒'
    } else if (hh > 0) {
        return hh + '小时' + mm + '分钟' + ss + '秒'
    } else if (mm > 0) {
        return mm + '分钟' + ss + '秒'
    } else {
        return ss + '秒'
    }
}

/**
 * 获取周几
 * @param date
 * @returns {string}
 */
export function getWeek(date) {
    let dateList = ['日', '一', '二', '三', '四', '五', '六']
    return dateList[new Date(date).getDay()]
}
