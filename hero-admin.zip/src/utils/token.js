import Cookies from 'js-cookie'
import Settings from '@/settings'

const TokenKey = Settings.TokenKey
const GameIdKey = 'game-id'
const GameRedirectStatus = 'game-redirect-status'
const AvailableGameList = 'available-game-list'

//获取token
export function getToken() {
    return Cookies.get(TokenKey)
}

//设置token
export function setToken(token, rememberMe) {
    if (rememberMe) {
        return Cookies.set(TokenKey, token, { expires: Settings.tokenCookieExpires })
    } else {
        return Cookies.set(TokenKey, token)
    }
}

//移除token
export function removeAll() {
    Cookies.remove(TokenKey)
    Cookies.remove(GameIdKey)
    Cookies.remove(GameRedirectStatus)
    Cookies.remove(AvailableGameList)
}

//获取-选择的游戏ID
export function getGameId() {
    return Cookies.get(GameIdKey)
}

//设置-选择的游戏ID
export function setGameID(gameId) {
    return Cookies.set(GameIdKey, gameId)
}

//获取-记录选择游戏状态
export function getGameIdRedirect() {
    return Cookies.get(GameRedirectStatus)
}

//设置-记录选择游戏状态
export function setGameIdRedirect(type) {
    return Cookies.set(GameRedirectStatus, type)
}

//获取-账户配置的所有游戏
export function getAvailableGameList() {
    return Cookies.get(AvailableGameList)
}

//设置-账户配置的所有游戏
export function setAvailableGameList(gameList) {
    return Cookies.set(AvailableGameList, gameList)
}
