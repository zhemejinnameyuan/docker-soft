export const defaultPermission = {
    admin: 'SUPER_ADMIN', // 超级管理

    //账号管理模块
    menuList: 'menu:list', // 菜单列表
    menuSave: 'menu:save', // 菜单操作
    roleList: 'role:list', // 角色列表
    roleSave: 'role:save', //角色操作
    userList: 'user:list', // 账号列表
    userSave: 'user:save' // 账号操作
}
