/** 格式化空数据 */
export const filterEmpty = (arg) => {
    if (arg === null || arg === undefined || arg === '') {
        return '--'
    } else {
        return arg
    }
}

/** 格式化成千分位 */
export const filterThousandths = (arg) => {
    var v
    if (arg) {
        if (typeof arg === 'number') {
            if (arg.toString().includes('.')) {
                v = arg.toFixed(2).toString()
            } else {
                v = arg.toString()
            }
        } else {
            v = arg + ''
        }
        v = v.toString().replace(/\d+/, function (n) {
            // 先提取整数部分
            return n.replace(/(\d)(?=(\d{3})+$)/g, function ($1) {
                return $1 + ','
            })
        })
    } else if (!_.isNil(arg)) {
        v = arg
    }
    return filterEmpty(v)
}
