import router from './routers'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import Settings from '@/settings'
import { getToken } from '@/utils/token'
import store from '@/store'
import * as apiMenu from '@/api/auth/menu'
import { filterAsyncRouter } from '@/store/modules/permission'

NProgress.configure({ showSpinner: false })

// 免登录白名单
const whiteList = ['/login']

router.beforeEach((to, from, next) => {
    if (to.meta.title) {
        document.title = to.meta.title + ' - ' + Settings.title
    }
    NProgress.start()
    if (getToken()) {
        if (to.path === '/login') {
            next({ path: to.query.redirect || '/' })
            NProgress.done()
        } else if (to.path === '/403') {
            next()
        } else {
            if (!store.getters.userInfo.username) {
                store
                    .dispatch('UserInfo')
                    .then((res) => {
                        loadMenus(next, to)
                    })
                    .catch((e) => {
                        console.error(e)
                        store.dispatch('Logout').then(() => {
                            // 重新实例化vue-router对象 避免bug
                            location.reload()
                        })
                    })
            } else {
                next()
            }
        }
    } else {
        if (whiteList.indexOf(to.path) !== -1) {
            next()
        } else {
            next(`/login?redirect=${to.fullPath}`)
            NProgress.done()
        }
    }
})

// 加载用户菜单
export const loadMenus = (next, to) => {
    apiMenu.queryUserMenu().then((res) => {
        let menuData = res.data
        const asyncRouter = res.data ? filterAsyncRouter(menuData) : []
        asyncRouter.push({ path: '*', redirect: '/404', hidden: true })
        store.dispatch('generateRoutes', asyncRouter).then(() => {
            router.addRoutes(asyncRouter)
            next({ ...to, replace: true })
        })
    })
}

router.afterEach(() => {
    NProgress.done()
})
