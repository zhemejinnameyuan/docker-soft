<template>
    <el-drawer ref="drawer" :append-to-body="appendToBody" :size="size" :visible="visible" :with-header="false" @close="close">
        <div class="fc_drawer">
            <div class="drawer_header">
                <span class="drawer_header_title">{{ title }}</span>
                <IconButton type="text" size="medium" style="font-size: 24px; color: #a1a4a7" icon="oms_ico_close" @click="$refs.drawer.closeDrawer()" />
            </div>
            <div class="drawer_content no-scrollbar">
                <slot />
            </div>
        </div>
    </el-drawer>
</template>
<script>
export default {
    props: {
        title: {
            type: String,
            default: '详情'
        },
        size: {
            type: Number,
            default: null
        },
        visible: {
            type: Boolean,
            default: false
        },
        appendToBody: {
            type: Boolean,
            default: false
        }
    },

    methods: {
        close() {
            this.$emit('update:visible', false)
        }
    }
}
</script>

<style lang="scss" scoped>
::v-deep .el-drawer {
    border-radius: 8px;
}
.fc_drawer {
    width: 100%;
    display: flex;
    flex-direction: column;
    .drawer_header {
        width: 100%;
        height: 50px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0px 20px 0px 30px;
        background: rgba(27, 162, 255, 0.05);
        &_title {
            font-size: 16px;
            color: #282829;
            font-weight: 500;
        }
    }
    .drawer_content {
        display: flex;
        flex-direction: column;
        width: 100%;
        height: calc(100vh - 50px);
        overflow-y: scroll;
    }
}
</style>
