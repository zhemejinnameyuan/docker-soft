<template>
    <el-button :loading="loading && !icon" :type="type" :disabled="disabled" :size="size" :plain="plain" @click="toClick">
        <svg-icon v-if="icon" :icon-class="icon" :class="{ loading: loading && icon }" />
        {{ title }}
    </el-button>
</template>
<script>
export default {
    name: 'IconButton',
    props: {
        size: {
            type: String,
            default: ''
        },
        type: {
            type: String,
            default: ''
        },
        icon: {
            type: String,
            default: ''
        },
        plain: {
            type: Boolean,
            default: false
        },
        loading: {
            type: Boolean,
            default: false
        },

        disabled: {
            type: Boolean,
            default: false
        },

        title: {
            type: String,
            default: ''
        }
    },
    methods: {
        toClick() {
            this.$emit('click')
        }
    }
}
</script>
<style lang="scss" scoped>
.loading {
    /*animation (动画) :绑定选择器, 4s完成动画 linear(匀速) infinite(循环) */
    animation: loading 2s linear infinite;
}
@keyframes loading {
    /*以百分比来规定改变发生的时间 也可以通过"from"和"to",等价于0% 和 100%*/
    0% {
        /*rotate(2D旋转) scale(放大或者缩小) translate(移动) skew(翻转)*/
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}
</style>
