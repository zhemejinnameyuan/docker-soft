<template>
    <div>
        <el-image-viewer v-bind="$attrs" v-on="$listeners" style="z-index: 9999" />
    </div>
</template>

<script>
// 图片预览组件
import ElImageViewer from 'element-ui/packages/image/src/image-viewer'

export default {
    name: 'ImagePreview',
    components: { ElImageViewer }
}
</script>

<style lang="scss" scoped>
::v-deep .el-image-viewer__btn.el-image-viewer__close {
    color: #fff;
}
</style>
