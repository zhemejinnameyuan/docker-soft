<template>
    <div class="dp-f week-picker">
        <el-date-picker
            v-model="starWeek"
            style="width: 140px"
            format="yyyy-W"
            placeholder="开始周"
            size="medium"
            :picker-options="starPickerOptions"
            type="week"
            :clearable="false"
            @change="starChange"
        />
        <span>-</span>
        <el-date-picker
            v-model="endWeek"
            format="yyyy-W"
            class="end"
            style="width: 140px"
            :picker-options="endPickerOptions"
            placeholder="结束周"
            size="medium"
            type="week"
            :clearable="false"
            @change="endChange"
        />
    </div>
</template>
<script>
const format_str = 'yyyy-MM-dd'
export default {
    components: {},
    model: {
        prop: 'value', // 绑定的值，通过父组件传递
        event: 'update'
    },
    props: {
        value: { required: true }
    },
    data() {
        return {
            starPickerOptions: {
                firstDayOfWeek: 1
            },
            endPickerOptions: {
                firstDayOfWeek: 1
            },
            starWeek: null,
            endWeek: null
        }
    },
    watch: {
        value: {
            handler(val) {
                if (val && val.length) {
                    this.starWeek = val[0]
                    this.endWeek = val[1]
                }
            }
        }
    },
    methods: {
        starChange(time) {
            if (this.endWeek && this.endWeek.getTime() < this.starWeek.getTime()) {
                var arr = [this.starWeek, this.endWeek]
                this.starWeek = arr[1]
                this.endWeek = arr[0]
            }
            if (this.starWeek && this.endWeek) {
                this.$emit('update', [this.starWeek, this.endWeek])
                this.$emit('change', [this.starWeek, this.endWeek])
            }
        },
        endChange(time) {
            if (!time) {
                this.starWeek = null
                this.endWeek = null
                this.$emit('update', null)
                this.$emit('change', null)
            }
            if (this.starWeek && this.starWeek.getTime() > this.endWeek.getTime()) {
                var arr = [this.starWeek, this.endWeek]
                this.starWeek = arr[1]
                this.endWeek = arr[0]
            }
            if (this.starWeek && this.endWeek) {
                this.$emit('update', [this.starWeek, this.endWeek])
                this.$emit('change', [this.starWeek, this.endWeek])
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.week-picker {
    border: 1px solid #dcdfe6;
    box-sizing: border-box;
    border-radius: 4px;
    ::v-deep .el-input__prefix .el-icon-date {
        margin-top: 2px;
    }
    .end {
        ::v-deep .el-input__prefix {
            display: none;
        }
    }
}
::v-deep .el-input__inner {
    text-align: center;
    height: 34px;
    border: 0px solid #dcdfe6;
}
</style>
