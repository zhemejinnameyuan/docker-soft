import Vue from 'vue'
import store from '@/store'

/**
 * 排除渠道用户（渠道管理员除外）
 */
const handleExcludeChannel = (el, binding) => {
    const userInfo = store.getters && store.getters.userInfo
    if (userInfo.channelUser && userInfo.superOrChannelAdmin === false) {
        el.parentNode && el.parentNode.removeChild(el)
    }
}
Vue.directive('ExcludeChannelUser', {
    inserted: handleExcludeChannel
})
