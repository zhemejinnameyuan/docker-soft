<!--分页-->
<template>
    <el-pagination
        :page-size.sync="query.size"
        :total="_.toNumber(total)"
        :current-page.sync="query.page"
        style="margin-top: 8px"
        layout="total, prev, pager, next, sizes,jumper"
        :page-sizes="pageSizes"
        background
        @size-change="pageChangeHandler"
        @current-change="pageChangeHandler"
    />
</template>
<script>
export default {
    props: {
        query: {
            type: Object,
            default: null
        },
        pageSizes: {
            type: Array,
            default: function () {
                return [20, 50, 100, 200]
            }
        },
        total: {
            type: [Number, String],
            default: function () {
                return 0
            }
        }
    },
    methods: {
        pageChangeHandler() {
            this.$emit('pageChangeHandler')
        }
    }
}
</script>
<style lang="scss" scoped>
::v-deep .el-select {
    input {
        background: #ffffff;
    }
}

::v-deep .el-pager .number {
    color: #f68915 !important;
}

::v-deep .el-pager .active {
    color: #ffffff !important;
    background-color: #f68915 !important;
}
</style>
