<template>
    <div>
        <div class="input-number-range" :class="{ 'is-disabled': disabled }">
            <div class="flex">
                <div class="from" :style="{ width: rangeWidth }">
                    <el-input
                        v-show="fromShow"
                        ref="input_from"
                        v-model="userInputForm"
                        size="medium"
                        :style="{ width: rangeWidth }"
                        :disabled="disabled"
                        :placeholder="minPlaceholder"
                        :clearable="clearable"
                        @blur="handleBlurFrom"
                        @focus="handleFocusFrom"
                        @input="handleInputFrom"
                        @change="handleInputChangeFrom"
                    />
                </div>
                <span class="input-append-desc" v-if="fromAppendDesc">{{ fromAppendDesc }}</span>
                <span class="input-append-desc" v-if="rangeSeparator" style="margin: 0 2px 0 2px">{{ rangeSeparator }}</span>
                <div class="to">
                    <el-input
                        v-show="toShow"
                        ref="input_to"
                        v-model="userInputTo"
                        size="medium"
                        :style="{ width: rangeWidth }"
                        :disabled="disabled"
                        :placeholder="maxPlaceholder"
                        :clearable="clearable"
                        @blur="handleBlurTo"
                        @focus="handleFocusTo"
                        @input="handleInputTo"
                        @change="handleInputChangeTo"
                    />
                </div>
                <span class="input-append-desc" v-if="toAppendDesc">{{ toAppendDesc }}</span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'InputNumberRange',

    props: {
        minPlaceholder: {
            type: String,
            default: '请输入'
        },
        maxPlaceholder: {
            type: String,
            default: '请输入'
        },
        rangeSeparator: {
            type: String,
            default: '-'
        },
        minNumber: {
            type: Number,
            default: 0
        },
        maxNumber: {
            type: Number,
            default: 999999
        },
        rangeWidth: {
            type: String,
            default: '170px'
        },
        value: { required: true },

        // 是否禁用
        disabled: {
            type: Boolean,
            default: false
        },
        clearable: {
            type: Boolean,
            default: false
        },

        // 精度参数
        precision: {
            type: Number,
            default: 0,
            validator(val) {
                return val >= 0 && val === parseInt(val, 10)
            }
        },

        fromShow: {
            type: Boolean,
            default: true
        },
        toShow: {
            type: Boolean,
            default: true
        },
        fromAppendDesc: {
            type: String,
            default: ''
        },
        toAppendDesc: {
            type: String,
            default: ''
        }
    },

    data() {
        return {
            userInputForm: null,
            userInputTo: null
        }
    },

    watch: {
        value: {
            immediate: true,
            handler(value) {
                if (value instanceof Object && this.precision !== undefined) {
                    this.userInputForm = typeof value.l === 'number' ? value.l : null
                    this.userInputTo = typeof value.r === 'number' ? value.r : null
                }
            }
        }
    },

    methods: {
        // 根据精度保留数字
        toPrecision(num, precision) {
            if (precision === undefined) precision = 0
            return parseFloat(Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision))
        },

        handleBlurFrom(event) {
            this.$emit('blurfrom', event)
        },

        handleFocusFrom(event) {
            this.$emit('focusfrom', event)
        },

        handleBlurTo(event) {
            this.$emit('blurto', event)
        },

        handleFocusTo(event) {
            this.$emit('focusto', event)
        },

        handleInputFrom(value) {
            this.$emit('inputfrom', value)
            // this.userInputFrom = value
        },

        handleInputTo(value) {
            this.$emit('inputto', value)
            // this.userInputTo = value
        },

        // from输入框change事件
        handleInputChangeFrom(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.$emit('input', { l: null, r: this.userInputTo })
                this.$emit('changefrom', this.userInputForm)
                return
            }

            // 初始化数字精度
            this.userInputForm = this.setPrecisionValue(value)

            this.userInputForm = this.userInputForm < this.minNumber ? this.minNumber : this.userInputForm

            // 如果from > to 将from值替换成to
            if (typeof this.userInputTo === 'number') {
                this.userInputForm = parseFloat(this.userInputForm) <= parseFloat(this.userInputTo) ? this.userInputForm : this.userInputTo
            }
            this.$emit('input', { l: this.userInputForm, r: this.userInputTo })
            this.$emit('changefrom', this.userInputForm)
        },

        // to输入框change事件
        handleInputChangeTo(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.$emit('input', { l: this.userInputForm, r: null })
                this.$emit('changefrom', this.userInputTo)
                return
            }

            // 初始化数字精度
            this.userInputTo = this.setPrecisionValue(value)

            this.userInputTo = this.userInputTo > this.maxNumber ? this.maxNumber : this.userInputTo

            if (typeof this.userInputForm === 'number') {
                this.userInputTo = parseFloat(this.userInputTo) >= parseFloat(this.userInputForm) ? this.userInputTo : this.userInputForm
            }
            this.$emit('input', { l: this.userInputForm, r: this.userInputTo })
            this.$emit('changeto', this.userInputTo)
        },

        // 设置成精度数字
        setPrecisionValue(value) {
            if (this.precision !== undefined) {
                const val = this.toPrecision(value, this.precision)
                return val
            }
            return null
        }
    }
}
</script>
<style lang="scss" scoped>
// 取消element原有的input框样式
::v-deep .el-input__inner {
    width: 100px;
    height: 40px;
    font-size: 16px;
    text-align: center;
    color: #282829;
}
.input-number-range {
    background-color: transparent;
}
.flex {
    display: flex;
    flex-direction: row;
    width: 100%;
    align-items: center;
    .center {
        width: 40px;
        display: flex;
        justify-content: center;
        padding: 0px 8px;
        height: 20px;
        font-size: 10px;
        color: #282829;
        letter-spacing: 0;
        line-height: 20px;
        font-weight: 400;
    }
}
.is-disabled {
    background-color: #eef0f6;
    border-color: #e4e7ed;
    color: #c0c4cc;
    cursor: not-allowed;
}
</style>
