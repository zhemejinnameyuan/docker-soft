<template>
    <el-dialog :title="title" :visible.sync="visible" :before-close="beforeClose" width="95%" top="4vh" center>
        <slot />
    </el-dialog>
</template>
<script>
export default {
    props: {
        title: {
            type: String,
            default: '详情'
        },
        visible: {
            type: Boolean,
            default: false
        }
    },

    methods: {
        beforeClose() {
            this.$emit('update:visible', false)
        }
    }
}
</script>

<style scoped lang="scss">
::v-deep {
    .el-dialog__header {
        background: #ffffff;
        border-radius: 10px;
    }
    .el-dialog__title {
        display: inline-block;
        width: 100%;
        text-align: center;
    }
    .el-dialog__body {
        height: 85vh;
    }
}
</style>
