<script>
import { DatePicker } from 'element-ui'

export default {
    name: 'DatePicker',
    mixins: [DatePicker],
    props: {
        type: {
            type: String,
            default: 'date'
        },
        valueFormat: {
            type: String,
            default: (_) => {
                return 'yyyy-MM-dd'
            }
        },
        pickerOptions: {
            type: DatePicker,
            default: (_) => {
                return {
                    disabledDate(time) {
                        return time.getTime() > Date.now() - 86400 * 1000
                    }
                }
            }
        },
        size: {
            type: String,
            default: 'medium'
        },
        placeholder: {
            type: String,
            default: '选择日期'
        }
    }
}
</script>
