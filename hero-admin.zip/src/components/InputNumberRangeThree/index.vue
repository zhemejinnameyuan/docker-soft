<template>
    <div>
        <div class="input-number-range" :class="{ 'is-disabled': disabled }">
            <div class="flex">
                <el-input
                    ref="input_x"
                    v-model="userInputX"
                    size="medium"
                    :style="{ width: rangeWidth }"
                    :disabled="disabled"
                    :placeholder="xPlaceholder"
                    :clearable="clearable"
                    @change="handleInputChangeX"
                />
                <div class="x—separator">
                    {{ xSeparator }}
                </div>
                <el-input
                    ref="input_y"
                    v-model="userInputY"
                    size="medium"
                    :style="{ width: rangeWidth }"
                    :disabled="disabled"
                    :placeholder="yPlaceholder"
                    :clearable="clearable"
                    @change="handleInputChangeY"
                />
                <div class="center">
                    {{ rangeSeparator }}
                </div>
                <el-input
                    ref="input_z"
                    v-model="userInputZ"
                    size="medium"
                    :style="{ width: lastRangeWidth || rangeWidth }"
                    :disabled="disabled"
                    :placeholder="zPlaceholder"
                    :clearable="clearable"
                    @change="handleInputChangeZ"
                />
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'InputNumberRangeThree',

    props: {
        xPlaceholder: {
            type: String,
            default: '请输入'
        },
        yPlaceholder: {
            type: String,
            default: '请输入'
        },
        zPlaceholder: {
            type: String,
            default: '请输入'
        },
        rangeSeparator: {
            type: String,
            default: '-'
        },
        xSeparator: {
            type: String,
            default: '人'
        },
        minNumber: {
            type: Number,
            default: 0
        },
        maxNumber: {
            type: Number,
            default: 999999
        },
        rangeWidth: {
            type: String,
            default: '170px'
        },
        lastRangeWidth: {
            type: String,
            default: null
        },
        value: { required: true },

        // 是否禁用
        disabled: {
            type: Boolean,
            default: false
        },
        clearable: {
            type: Boolean,
            default: false
        },

        // 精度参数
        precision: {
            type: Number,
            default: 0,
            validator(val) {
                return val >= 0 && val === parseInt(val, 10)
            }
        }
    },

    data() {
        return {
            userInputX: null,
            userInputY: null,
            userInputZ: null
        }
    },

    watch: {
        value: {
            immediate: true,
            handler(value) {
                if (value instanceof Object && this.precision !== undefined) {
                    this.userInputX = typeof value.x === 'number' ? value.x : null
                    this.userInputY = typeof value.y === 'number' ? value.y : null
                    this.userInputZ = typeof value.z === 'number' ? value.z : null
                }
            }
        }
    },

    methods: {
        // 根据精度保留数字
        toPrecision(num, precision) {
            if (precision === undefined) precision = 0
            return parseFloat(Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision))
        },
        handleInputChangeX(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.$emit('input', { x: null, y: this.userInputY, z: this.userInputZ })
                return
            }
            // 初始化数字精度
            this.userInputX = this.setPrecisionValue(value)
            this.$emit('input', { x: this.userInputX, y: this.userInputY, z: this.userInputZ })
        },
        // y输入框change事件
        handleInputChangeY(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.$emit('input', { x: this.userInputX, y: null, z: this.userInputZ })
                return
            }

            // 初始化数字精度
            this.userInputY = this.setPrecisionValue(value)
            this.userInputY = this.userInputY < this.minNumber ? this.minNumber : this.userInputY
            // 如果y > z
            if (typeof this.userInputZ === 'number') {
                this.userInputY = parseFloat(this.userInputY) <= parseFloat(this.userInputZ) ? this.userInputY : this.userInputZ
            }
            this.$emit('input', { x: this.userInputX, y: this.userInputY, z: this.userInputZ })
        },

        // z输入框change事件
        handleInputChangeZ(value) {
            // 如果是非数字空返回null
            if (isNaN(value) || value === '') {
                this.$emit('input', { x: this.userInputX, y: this.userInputY, z: null })
                return
            }

            // 初始化数字精度
            this.userInputZ = this.setPrecisionValue(value)

            this.userInputZ = this.userInputZ > this.maxNumber ? this.maxNumber : this.userInputZ

            if (typeof this.userInputY === 'number') {
                this.userInputZ = parseFloat(this.userInputZ) >= parseFloat(this.userInputY) ? this.userInputZ : this.userInputY
            }
            this.$emit('input', { x: this.userInputX, y: this.userInputY, z: this.userInputZ })
        },

        // 设置成精度数字
        setPrecisionValue(value) {
            if (this.precision !== undefined) {
                const val = this.toPrecision(value, this.precision)
                return val
            }
            return null
        }
    }
}
</script>
<style lang="scss" scoped>
// 取消element原有的input框样式
::v-deep .el-input__inner {
    margin: 0;
    padding: 0 15px;
    background-color: white;
    border-radius: 0px;
}
.input-number-range {
    background-color: transparent;
}
.flex {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    margin-right: 20px;

    .center {
        margin: 1px 10px 0px 10px;
        width: 20px;
        height: 20px;
        text-align: center;
        background: white;
        font-size: 14px;
        color: #a1a4a7;
        letter-spacing: 0;
        text-align: center;
        line-height: 20px;
        font-weight: 400;
    }
}
.is-disabled {
    background-color: #eef0f6;
    border-color: #e4e7ed;
    color: #c0c4cc;
    cursor: not-allowed;
}
.x—separator {
    width: 20px;
    background: #e3e3e3;
    height: 36px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 12px;
    color: #686b6d;
    letter-spacing: 0;
    font-weight: 400;
}
</style>
