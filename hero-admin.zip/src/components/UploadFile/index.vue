<template>
    <div>
        <el-upload
            ref="uploadFile"
            action="#"
            :http-request="urlUploadHandle"
            :on-remove="handleRemove"
            :on-error="handleError"
            :before-remove="beforeRemove"
            :on-exceed="handleExceed"
            :multiple="multiple"
            :limit="this.limit"
            :file-list="fileList"
            :accept="accept"
        >
            <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
    </div>
</template>

<script>
import * as api from '@/api/public'
export default {
    name: 'UploadFile',
    props: {
        fileSize: {
            type: Number,
            default: 2
        },
        fileExt: {
            type: Array,
            default() {
                return ['image/jpeg', 'image/jpg', 'image/png', 'video/mp4']
            }
        },
        limit: {
            type: Number,
            default: 1
        },
        multiple: {
            type: Boolean,
            default: false
        },
        accept: {
            type: String,
            default: '.png,.jpg,.jpeg,.mp4'
        },
        //已经上传的文件，用于渲染
        existFileList: {
            type: Array,
            default() {
                return []
            }
        }
    },
    data() {
        return {
            fileList: []
        }
    },

    mounted() {
        this.fileList = this.existFileList
    },
    methods: {
        //上传处理
        urlUploadHandle(options) {
            let _this = this
            let { file } = options
            api.getUploadUrl({ filename: file.name }).then(function (response) {
                let url = response.data.l //上传地址
                let path = response.data.r //相对路径
                let domain = response.domain.file
                // 发送 put 请求
                let header = { 'Content-Type': file.type }
                api.putFile(url, file, header).then(function (res) {
                    if (res.status === 200) {
                        let tmp = { name: file.name, url: path, domain: domain }
                        //单文件覆盖，多文件追加
                        if (_this.limit > 1) {
                            _this.fileList.push(tmp)
                        } else {
                            _this.fileList = [tmp]
                        }
                        _this.updateFileList(_this.fileList)
                    } else {
                        this.$message.error('上传失败！')
                    }
                })
            })
        },
        //上传前操作
        beforeUpload(file) {
            if (this.fileExt.indexOf(file.type) === -1) {
                this.$message.error('文件格式不正确!只支持以下格式：' + this.fileExt.join(','))
                return false
            }
            if (file.size / 1024 / 1024 > this.fileSize) {
                this.$message.error('文件大小不能超过' + this.fileSize + 'MB!')
                return false
            }
            return true
        },
        //移除
        handleRemove(file) {
            let fileListTmp = this.fileList
            for (let i = 0; i < fileListTmp.length; i++) {
                if (file.name === fileListTmp[i].name) {
                    fileListTmp.splice(i, 1)
                    break
                }
            }
            this.updateFileList(fileListTmp)
        },
        //错误
        handleError() {
            return this.$message.error('上传失败，服务器错误')
        },
        //处理上传数量限制
        handleExceed(files, fileList) {
            if (this.limit > 1) {
                return this.$message.error('最多只能上传' + this.limit + '文件')
            } else {
                //单文件覆盖
                this.$set(fileList[0], 'raw', files[0])
                this.$set(fileList[0], 'name', files[0].name)
                this.$refs.uploadFile.clearFiles()
                this.$refs.uploadFile.handleStart(files[0])
                this.$refs.uploadFile.submit()
            }
        },
        //删除前提示
        beforeRemove(file, fileList) {
            return this.$confirm(`确定移除 ${file.name}？`)
        },
        //处理上传文件列表
        updateFileList(fileList) {
            this.fileList = fileList
            let updateFileListArr = []
            for (let i in fileList) {
                updateFileListArr[i] = fileList[i].url
            }
            //更新文件回调
            this.$emit('updateFileList', updateFileListArr)
        }
    }
}
</script>
