import Vue from 'vue'
import App from './App.vue'
import router from './router/routers'
import store from './store'
import Cookies from 'js-cookie'
import 'normalize.css/normalize.css'
import Element from 'element-ui'
import './assets/styles/element/element-variables.scss'
import './assets/styles/index.scss'
import './assets/icons'
import './router/index'
import permission from './components/Permission'
import './components/sticky'
import './components/AutoFontSize'
import './components/ExcludeChanneUser'
import VueHighlightJS from 'vue-highlightjs'
import VueClipboard from 'vue-clipboard2'
import IconButton from './components/IconButton/index.vue'
import * as Filters from './utils/filters'
// moment js
import moment from 'moment'
Vue.prototype.$moment = moment
moment.locale('zh-CN')
//loadsh
import _ from 'loadsh'
Vue.prototype._ = _
//拖拽
import VueDND from 'awe-dnd'
Vue.use(VueDND)

Vue.use(VueClipboard)
Vue.use(Element, {
    size: Cookies.get('size') || 'small' // set element-ui default size
})
Vue.use(permission)
Vue.use(VueHighlightJS)
Vue.component('IconButton', IconButton)
Object.keys(Filters).forEach((key) => {
    Vue.filter(key, Filters[key])
})
Vue.config.productionTip = false
// console.log('ENV: ', process.env)
new Vue({
    render: (h) => h(App),
    router,
    store
}).$mount('#app')
