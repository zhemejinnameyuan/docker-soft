import request from '@/utils/request'

//获取用户菜单
export function queryUserMenu(params) {
    return request({
        url: '/api/admin/menu/queryUserMenu',
        method: 'get',
        params
    })
}

//菜单列表
export function queryMenu(params) {
    return request({
        url: '/api/admin/menu/queryMenu',
        method: 'get',
        params
    })
}

//菜单添加
export function add(data) {
    return request({
        url: '/api/admin/menu/add',
        method: 'post',
        data
    })
}

//菜单编辑
export function edit(data) {
    return request({
        url: '/api/admin/menu/edit',
        method: 'post',
        data
    })
}

//菜单删除
export function del(ids) {
    return request({
        url: '/api/admin/menu/del',
        method: 'post',
        data: ids
    })
}
