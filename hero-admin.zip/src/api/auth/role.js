import request from '@/utils/request'

//角色列表
export function queryRole(params) {
    return request({
        url: '/api/admin/role/queryRole',
        method: 'get',
        params
    })
}

//添加角色
export function add(data) {
    return request({
        url: '/api/admin/role/add',
        method: 'post',
        data
    })
}

//编辑角色
export function edit(data) {
    return request({
        url: '/api/admin/role/edit',
        method: 'post',
        data
    })
}

//删除角色
export function del(ids) {
    return request({
        url: '/api/admin/role/del',
        method: 'post',
        data: ids
    })
}

//分配菜单
export function relationMenu(data) {
    return request({
        url: '/api/admin/role/relationMenu',
        method: 'post',
        data
    })
}
