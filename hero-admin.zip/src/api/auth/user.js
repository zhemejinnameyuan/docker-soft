import request from '@/utils/request'
import { rsaEncrypt } from '@/utils/rsaEncrypt'

export function updateMyPass(user) {
    const data = {
        oldPass: rsaEncrypt(user.oldPass),
        newPass: rsaEncrypt(user.newPass)
    }
    return request({
        url: '/api/admin/user/updateMyPass/',
        method: 'post',
        data
    })
}

export function updateMyUserInfo(data) {
    return request({
        url: '/api/admin/user/updateMyUserInfo/',
        method: 'post',
        data
    })
}

export function list(params) {
    return request({
        url: '/api/admin/user/list',
        method: 'get',
        params
    })
}

export function add(data) {
    return request({
        url: '/api/admin/user/add',
        method: 'post',
        data
    })
}

export function edit(data) {
    return request({
        url: '/api/admin/user/edit',
        method: 'post',
        data
    })
}

export function del(ids) {
    return request({
        url: '/api/admin/user/del',
        method: 'post',
        data: ids
    })
}

export function resetPassword(data) {
    return request({
        url: '/api/admin/user/resetPassword',
        method: 'post',
        data
    })
}

export function onlineUsers(params) {
    return request({
        url: '/api/admin/user/onlineUsers',
        method: 'get',
        params
    })
}

export function kickOut(tokens) {
    return request({
        url: '/api/admin/user/kickOut',
        method: 'post',
        data: tokens
    })
}

export function resetSecretKey(data) {
    return request({
        url: '/api/admin/user/resetSecretKey',
        method: 'post',
        data: data
    })
}
