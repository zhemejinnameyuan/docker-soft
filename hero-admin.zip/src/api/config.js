import request from '@/utils/request'

//编辑配置
export function edit(data) {
    return request({
        url: '/api/admin/app-config/edit',
        method: 'post',
        data
    })
}

//查询配置列表
export function list(params) {
    return request({
        url: '/api/admin/app-config/list',
        method: 'get',
        params
    })
}

//查询短信余额
export function querySmsBalance(params) {
    return request({
        url: '/api/admin/app-config/querySmsBalance',
        method: 'get',
        params
    })
}
