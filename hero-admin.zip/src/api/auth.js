import request from '@/utils/request'

//获取验证码
export function getCaptcha() {
    return request({
        url: '/api/admin/auth/captcha',
        method: 'GET'
    })
}

//登录
export function login(username, password, code, key) {
    return request({
        url: '/api/admin/auth/login',
        method: 'post',
        data: {
            username,
            password,
            code,
            key
        }
    })
}

//登录用户信息
export function userInfo() {
    return request({
        url: '/api/admin/auth/userInfo',
        method: 'get'
    })
}

//退出
export function logout() {
    return request({
        url: '/api/admin/auth/logout',
        method: 'post'
    })
}
