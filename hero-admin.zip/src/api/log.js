import request from '@/utils/request'

/**
 * 清空日志
 */
export function clear(data) {
    return request({
        url: '/api/admin/log/clear',
        method: 'post',
        data
    })
}

/**
 * 查询系统日志
 */
export function list(params) {
    return request({
        url: '/api/admin/log/list',
        method: 'get',
        params
    })
}

/**
 * 查询操作行为
 */
export function title() {
    return request({
        url: '/api/admin/log/title',
        method: 'get'
    })
}
