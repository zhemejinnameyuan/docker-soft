<template>
    <div id="app">
        <router-view />
    </div>
</template>

<script>
import settings from './settings'
export default {
    name: 'App',
    mounted() {
        console.log(
            `%c version: %c ${settings.version}`,
            'background:#35495e ; padding: 1px; border-radius: 3px 0 0 3px;  color: #fff',
            'background:#007aff ;padding: 1px; border-radius: 0 3px 3px 0;  color: #fff; font-weight: bold;'
        )
    }
}
</script>
